/**
 * Doctor Dashboard nested/source tabs.
 * Keeps tab state local to each top-level Doctor Dashboard section.
 */
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.dior-source-group').forEach(function (group) {
        const buttons = group.querySelectorAll(':scope > .dior-content-pad > .dior-source-subtabs .dior-source-subtab-btn');
        const panels = group.querySelectorAll(':scope > .dior-content-pad > .dior-source-subcontent > .dior-tab-panel');
        if (!buttons.length || !panels.length) return;
        function activate(target) {
            buttons.forEach(function (btn) {
                btn.classList.toggle('active', btn.getAttribute('data-source-target') === target);
            });
            panels.forEach(function (panel) {
                panel.classList.toggle('active', panel.id === 'source-' + target);
            });
        }
        buttons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                activate(btn.getAttribute('data-source-target'));
            });
        });
        const initial = group.querySelector('.dior-source-subtab-btn.active');
        activate(initial ? initial.getAttribute('data-source-target') : buttons[0].getAttribute('data-source-target'));
    });
});
