<?php include DIOR_PORTAL_PATH . 'templates/doctor-tabs/patient-review.php'; ?>
