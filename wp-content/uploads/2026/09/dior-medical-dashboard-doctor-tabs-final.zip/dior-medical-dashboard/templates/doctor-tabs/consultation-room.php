<?php include DIOR_PORTAL_PATH . 'templates/doctor-tabs/consultation-room.php'; ?>
