<section class="dior-tab-panel dior-ic-44a70a0420" id="tab-feedback">
    <div class="master-table-wrapper">
        <div class="master-table-container">
            <div class="master-table-card">
                
                <!-- Header -->
                <div class="master-table-header">
                    <div class="header-content dior-ic-6a2286ff56">
                        <div class="table-title-section">
                            <h2 class="table-title">Feedback & Support</h2>
                            <div class="title-accent"></div>
                        </div>
                        <div class="header-actions-group dior-ic-c047e12f84">
                            <div class="search-container dior-ic-7e521c6e89">
                                <i class="fa-solid fa-magnifying-glass search-icon dior-ic-bc24164497"></i>
                                <input type="text" placeholder="Search records..." class="search-input dior-ic-fc89dcce8b">
                            </div>
                            <div class="action-buttons dior-ic-6c10502845">
                                <button class="action-btn action-btn-primary dior-ic-e654e3916a"><i class="fa-solid fa-plus"></i></button>
                                <button class="action-btn action-btn-success dior-ic-cf7c00244f"><i class="fa-solid fa-file-arrow-down"></i></button>
                                <button class="action-btn action-btn-info dior-ic-85fdbe7fee"><i class="fa-solid fa-rotate-right"></i></button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Table Content -->
                <div class="table-content dior-ic-cd60c2926b">
                    <table class="dior-ic-80816b495c">
                        <thead>
                            <tr class="dior-ic-2e693db070">
                                <th class="dior-ic-eae16ff263"><input type="checkbox"></th>
                                <th class="dior-ic-da19ee3bab">Ticket ID <i class="fa-solid fa-sort dior-ic-c3c6ca2a51"></i></th>
                                <th class="dior-ic-da19ee3bab">Subject <i class="fa-solid fa-sort dior-ic-c3c6ca2a51"></i></th>
                                <th class="dior-ic-da19ee3bab">Category <i class="fa-solid fa-sort dior-ic-c3c6ca2a51"></i></th>
                                <th class="dior-ic-da19ee3bab">Rating <i class="fa-solid fa-sort dior-ic-c3c6ca2a51"></i></th>
                                <th class="dior-ic-da19ee3bab">Date <i class="fa-solid fa-sort dior-ic-c3c6ca2a51"></i></th>
                                <th class="dior-ic-da19ee3bab">Status <i class="fa-solid fa-sort dior-ic-c3c6ca2a51"></i></th>
                                <th class="dior-ic-da19ee3bab">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Row 1 -->
                            <tr onmouseover="this.style.background='#F8FAFC'" onmouseout="this.style.background='transparent'" class="dior-ic-58d80925cf">
                                <td class="dior-ic-30853ea1b7"><input type="checkbox"></td>
                                <td class="dior-ic-431ed18bef">TKT001</td>
                                <td class="dior-ic-87f84aa894">Excellent Service by Dr. Smith</td>
                                <td class="dior-ic-431ed18bef">Doctor Feedback</td>
                                <td class="dior-ic-431ed18bef">5</td>
                                <td class="dior-ic-6327b670d0"><i class="fa-regular fa-calendar dior-ic-10b26ad0a4"></i><span class="dior-ic-fe2c3371d2">Nov 20, 2024</span></td>
                                <td class="dior-ic-30853ea1b7"><span class="dior-ic-9cd0a88c9e">Closed</span></td>
                                <td class="dior-ic-30853ea1b7">
                                    <div class="dior-ic-6c10502845">
                                        <button class="action-icon-btn edit-btn"><i class="fa-solid fa-pen"></i></button>
                                        <button class="action-icon-btn delete-btn"><i class="fa-solid fa-trash-can"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <!-- Row 2 -->
                            <tr onmouseover="this.style.background='#F8FAFC'" onmouseout="this.style.background='transparent'" class="dior-ic-58d80925cf">
                                <td class="dior-ic-30853ea1b7"><input type="checkbox"></td>
                                <td class="dior-ic-431ed18bef">TKT002</td>
                                <td class="dior-ic-87f84aa894">Long Waiting Time</td>
                                <td class="dior-ic-431ed18bef">Complaint</td>
                                <td class="dior-ic-431ed18bef">2</td>
                                <td class="dior-ic-6327b670d0"><i class="fa-regular fa-calendar dior-ic-10b26ad0a4"></i><span class="dior-ic-fe2c3371d2">Nov 15, 2024</span></td>
                                <td class="dior-ic-30853ea1b7"><span class="dior-ic-f979ecfb45">Resolved</span></td>
                                <td class="dior-ic-30853ea1b7">
                                    <div class="dior-ic-6c10502845">
                                        <button class="action-icon-btn edit-btn"><i class="fa-solid fa-pen"></i></button>
                                        <button class="action-icon-btn delete-btn"><i class="fa-solid fa-trash-can"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <!-- Row 3 -->
                            <tr onmouseover="this.style.background='#F8FAFC'" onmouseout="this.style.background='transparent'" class="dior-ic-58d80925cf">
                                <td class="dior-ic-30853ea1b7"><input type="checkbox"></td>
                                <td class="dior-ic-431ed18bef">TKT003</td>
                                <td class="dior-ic-87f84aa894">App Login Issue</td>
                                <td class="dior-ic-431ed18bef">Technical Support</td>
                                <td class="dior-ic-431ed18bef"></td>
                                <td class="dior-ic-6327b670d0"><i class="fa-regular fa-calendar dior-ic-10b26ad0a4"></i><span class="dior-ic-fe2c3371d2">Nov 24, 2024</span></td>
                                <td class="dior-ic-30853ea1b7"><span class="dior-ic-5159fcab16">In Progress</span></td>
                                <td class="dior-ic-30853ea1b7">
                                    <div class="dior-ic-6c10502845">
                                        <button class="action-icon-btn edit-btn"><i class="fa-solid fa-pen"></i></button>
                                        <button class="action-icon-btn delete-btn"><i class="fa-solid fa-trash-can"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <!-- Row 4 -->
                            <tr onmouseover="this.style.background='#F8FAFC'" onmouseout="this.style.background='transparent'" class="dior-ic-58d80925cf">
                                <td class="dior-ic-30853ea1b7"><input type="checkbox"></td>
                                <td class="dior-ic-431ed18bef">TKT004</td>
                                <td class="dior-ic-87f84aa894">Cleanliness Feedback</td>
                                <td class="dior-ic-431ed18bef">Hospital Facilities</td>
                                <td class="dior-ic-431ed18bef">4</td>
                                <td class="dior-ic-6327b670d0"><i class="fa-regular fa-calendar dior-ic-10b26ad0a4"></i><span class="dior-ic-fe2c3371d2">Nov 10, 2024</span></td>
                                <td class="dior-ic-30853ea1b7"><span class="dior-ic-9cd0a88c9e">Closed</span></td>
                                <td class="dior-ic-30853ea1b7">
                                    <div class="dior-ic-6c10502845">
                                        <button class="action-icon-btn edit-btn"><i class="fa-solid fa-pen"></i></button>
                                        <button class="action-icon-btn delete-btn"><i class="fa-solid fa-trash-can"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <!-- Row 5 -->
                            <tr onmouseover="this.style.background='#F8FAFC'" onmouseout="this.style.background='transparent'" class="dior-ic-58d80925cf">
                                <td class="dior-ic-30853ea1b7"><input type="checkbox"></td>
                                <td class="dior-ic-431ed18bef">TKT005</td>
                                <td class="dior-ic-87f84aa894">Billing Query</td>
                                <td class="dior-ic-431ed18bef">Billing</td>
                                <td class="dior-ic-431ed18bef"></td>
                                <td class="dior-ic-6327b670d0"><i class="fa-regular fa-calendar dior-ic-10b26ad0a4"></i><span class="dior-ic-fe2c3371d2">Nov 25, 2024</span></td>
                                <td class="dior-ic-30853ea1b7"><span class="dior-ic-bf63c0b7be">Open</span></td>
                                <td class="dior-ic-30853ea1b7">
                                    <div class="dior-ic-6c10502845">
                                        <button class="action-icon-btn edit-btn"><i class="fa-solid fa-pen"></i></button>
                                        <button class="action-icon-btn delete-btn"><i class="fa-solid fa-trash-can"></i></button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Footer -->
                <div class="dior-ic-332750da74">
                    0 selected / 5 total
                </div>
            </div>
        </div>
    </div>
</section>
