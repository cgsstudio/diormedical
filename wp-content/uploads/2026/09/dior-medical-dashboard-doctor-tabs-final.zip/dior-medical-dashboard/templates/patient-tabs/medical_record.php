<section class="dior-tab-panel dior-ic-44a70a0420" id="tab-medical_record">
                    <div class="dior-page-header-box">
                        <div>
                            <h2>Medical Record</h2>
                        </div>
                    </div>
                    
                    <div class="section-body dior-ic-de85b14db8">
                        <div class="row g-3 mb-4 no-print dior-ic-57fbdcec40">
                            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 dior-ic-0fcdb8259f">
                                <div class="card kpi-mini-card border-0 shadow-sm p-3 h-100 dior-ic-702f6c09ec">
                                    <div class="d-flex align-items-center gap-3 dior-ic-b7f55b7e4a">
                                        <div class="kpi-icon-box bg-blue-gradient text-white rounded-14 flex-shrink-0 shadow-sm dior-ic-7e3bf34afe">
                                            <i class="fas fa-stream"></i>
                                        </div>
                                        <div class="flex-grow-1 overflow-hidden dior-ic-aea598fd73">
                                            <div class="d-flex align-items-center justify-content-between mb-1 dior-ic-bce91fe330">
                                                <span class="text-xs text-muted font-weight-600 text-uppercase text-truncate dior-ic-d48d9220c2">Milestones</span>
                                                <span class="badge bg-primary-subtle text-primary rounded-pill text-2xs dior-ic-b9bd20e3e0">Active</span>
                                            </div>
                                            <h5 class="mb-0 font-weight-bold text-dark text-truncate dior-ic-c4e98ce9b3">6 Care Events</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 dior-ic-0fcdb8259f">
                                <div class="card kpi-mini-card border-0 shadow-sm p-3 h-100 dior-ic-702f6c09ec">
                                    <div class="d-flex align-items-center gap-3 dior-ic-b7f55b7e4a">
                                        <div class="kpi-icon-box bg-cyan-gradient text-white rounded-14 flex-shrink-0 shadow-sm dior-ic-95ecf5b0d8">
                                            <i class="fas fa-heartbeat"></i>
                                        </div>
                                        <div class="flex-grow-1 overflow-hidden dior-ic-aea598fd73">
                                            <div class="d-flex align-items-center justify-content-between mb-1 dior-ic-bce91fe330">
                                                <span class="text-xs text-muted font-weight-600 text-uppercase text-truncate dior-ic-d48d9220c2">Care Phase</span>
                                                <span class="badge bg-info-subtle text-info rounded-pill text-2xs dior-ic-c37f987d84">Phase 2</span>
                                            </div>
                                            <h5 class="mb-0 font-weight-bold text-dark text-truncate dior-ic-c4e98ce9b3">Post-Op Recovery</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 dior-ic-0fcdb8259f">
                                <div class="card kpi-mini-card border-0 shadow-sm p-3 h-100 dior-ic-702f6c09ec">
                                    <div class="d-flex align-items-center gap-3 dior-ic-b7f55b7e4a">
                                        <div class="kpi-icon-box bg-purple-gradient text-white rounded-14 flex-shrink-0 shadow-sm dior-ic-2a23691ffa">
                                            <i class="fas fa-user-md"></i>
                                        </div>
                                        <div class="flex-grow-1 overflow-hidden dior-ic-aea598fd73">
                                            <div class="d-flex align-items-center justify-content-between mb-1 dior-ic-bce91fe330">
                                                <span class="text-xs text-muted font-weight-600 text-uppercase text-truncate dior-ic-d48d9220c2">Lead Physician</span>
                                                <span class="badge bg-purple-subtle text-purple rounded-pill text-2xs dior-ic-f6785667b0">Cardiology</span>
                                            </div>
                                            <h5 class="mb-0 font-weight-bold text-dark text-truncate dior-ic-c4e98ce9b3">Dr. Sarah Smith</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 dior-ic-0fcdb8259f">
                                <div class="card kpi-mini-card border-0 shadow-sm p-3 h-100 dior-ic-702f6c09ec">
                                    <div class="d-flex align-items-center gap-3 dior-ic-b7f55b7e4a">
                                        <div class="kpi-icon-box bg-emerald-gradient text-white rounded-14 flex-shrink-0 shadow-sm dior-ic-f20b23555a">
                                            <i class="fas fa-shield-alt"></i>
                                        </div>
                                        <div class="flex-grow-1 overflow-hidden dior-ic-aea598fd73">
                                            <div class="d-flex align-items-center justify-content-between mb-1 dior-ic-bce91fe330">
                                                <span class="text-xs text-muted font-weight-600 text-uppercase text-truncate dior-ic-d48d9220c2">EMR Security</span>
                                                <span class="badge bg-success-subtle text-success rounded-pill text-2xs dior-ic-4db3afa214">HIPAA</span>
                                            </div>
                                            <h5 class="mb-0 font-weight-bold text-success text-truncate dior-ic-c2f54c19e7"><i class="fas fa-lock me-1 text-xs"></i> Encrypted</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card border-0 shadow-sm rounded-16 mb-4 no-print dior-ic-18f15f6b14">
                            <div class="card-body p-3 dior-ic-30853ea1b7">
                                <div class="row align-items-center g-3 dior-ic-5f76b1419d">
                                    <div class="col-lg-8 dior-ic-aea598fd73">
                                        <div class="d-flex flex-wrap gap-2 dior-ic-c10bc232ce">
                                            <button type="button" class="btn btn-sm btn-primary dior-ic-b83363301a"><i class="fas fa-th-large me-1"></i> All Events (6) </button>
                                            <button type="button" class="btn btn-sm btn-light dior-ic-acadeac91e"><i class="fas fa-stethoscope me-1 text-primary dior-ic-0c27d9541a"></i> Consultations </button>
                                            <button type="button" class="btn btn-sm btn-light dior-ic-acadeac91e"><i class="fas fa-pills me-1 text-purple dior-ic-2552c485b6"></i> Prescriptions </button>
                                            <button type="button" class="btn btn-sm btn-light dior-ic-acadeac91e"><i class="fas fa-file-medical-alt me-1 text-info dior-ic-93cffbc604"></i> Diagnostics &amp; Scans </button>
                                            <button type="button" class="btn btn-sm btn-light dior-ic-acadeac91e"><i class="fas fa-user-md me-1 text-danger dior-ic-961ef1396d"></i> Procedures </button>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 d-flex gap-2 dior-ic-04e1c988f3">
                                        <div class="input-group search-input-group flex-grow-1 dior-ic-81029c50e5">
                                            <span class="input-group-text dior-ic-8ae62c593e"><i class="fas fa-search"></i></span>
                                            <input type="text" placeholder="Search medical history..." class="form-control dior-ic-c87dae7386">
                                        </div>
                                        <button type="button" title="Print Care History" class="btn btn-sm btn-outline-secondary px-3 dior-ic-30bc658af7"><i class="fas fa-print"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card border-0 shadow-sm rounded-16 dior-ic-18f15f6b14">
                            <div class="card-header bg-transparent py-3 px-4 d-flex align-items-center justify-content-between dior-ic-a6b4a26983">
                                <h5 class="card-title-text mb-0 dior-ic-e6680bba01"><i class="fas fa-history me-2 text-primary dior-ic-9e5c8d5e64"></i>Patient Treatment &amp; Clinical Timeline Log</h5>
                                <span class="patient-id-badge text-xs px-3 py-1 font-weight-bold dior-ic-90ce95a680">Patient: <?php echo esc_html($profile['full_name']); ?> (#<?php echo esc_html($profile['patient_id'] ?? 'PAT-' . rand(1000, 9999)); ?>)</span>
                            </div>
                            <div class="card-body p-4 p-md-5 dior-ic-4315250082">
                                <div class="modern-treatment-timeline position-relative dior-ic-3bc278421b">
                                    
                                    <!-- Event 1: DIAGNOSTIC -->
                                    <div class="mr-timeline-item">
                                        <div class="mr-timeline-time-col">
                                            <span class="dior-ic-14731f6c49">Today</span>
                                            <span class="dior-ic-07e1c2794e"><i class="far fa-clock me-1"></i>03:45 AM</span>
                                            <span class="dior-ic-81a2aacd66">Just now</span>
                                        </div>
                                        <div class="dior-ic-f69dfb2b50">
                                            <div class="mr-timeline-vertical-line dior-ic-cb3a74261f"></div>
                                            <div class="mr-timeline-icon-node dior-ic-8045bf2ab1">
                                                <i class="fas text-white fa-file-medical-alt dior-ic-31bb4f1b09"></i>
                                            </div>
                                        </div>
                                        <div class="mr-timeline-content-card">
                                            <div class="dior-ic-eba8b27042">
                                                <div class="dior-ic-33aac0e461">
                                                    <span class="dior-ic-b382a6228c"> DIAGNOSTIC </span>
                                                    <h5 class="dior-ic-fceca4a64a">Chest X-Ray &amp; Digital Radiology Scan</h5>
                                                </div>
                                                <div class="dior-ic-b1d844752a">
                                                    <img src="https://ui-avatars.com/api/?name=Helen+Miller&background=random" alt="Dr. Helen Miller" class="dior-ic-2061ceb509">
                                                    <div>
                                                        <span class="dior-ic-9bbdb950cc">Dr. Helen Miller</span>
                                                        <small class="dior-ic-3a4133fe41">Radiologist Specialist</small>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="dior-ic-972dc92ce3"> Digital X-ray imaging performed for post-op thoracic evaluation. Lungs clear bilaterally, diaphragm contour normal, no acute focal consolidation or pleural effusion observed. </p>
                                            <div class="dior-ic-2f0bf46977">
                                                <span class="dior-ic-d59351bad1"><i class="fas fa-paperclip me-1"></i> Attached Medical Files (2):</span>
                                                <div class="dior-ic-c10bc232ce">
                                                    <button type="button" class="dior-ic-3b4d05ddb3">
                                                        <i class="fas fa-file-pdf dior-ic-bbfc66681c"></i><span>XRay_Scan_Chest_Posterior.pdf</span><small class="dior-ic-e5b7658379">(2.4 MB)</small><i class="fas fa-download"></i>
                                                    </button>
                                                    <button type="button" class="dior-ic-3b4d05ddb3">
                                                        <i class="fas fa-file-image dior-ic-4bbd5da241"></i><span>Radiology_DICOM_View.jpg</span><small class="dior-ic-e5b7658379">(5.1 MB)</small><i class="fas fa-download"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Event 2: CONSULTATION -->
                                    <div class="mr-timeline-item">
                                        <div class="mr-timeline-time-col">
                                            <span class="dior-ic-14731f6c49">20 Sep 2026</span>
                                            <span class="dior-ic-07e1c2794e"><i class="far fa-clock me-1"></i>01:30 PM</span>
                                            <span class="dior-ic-81a2aacd66">4 days ago</span>
                                        </div>
                                        <div class="dior-ic-f69dfb2b50">
                                            <div class="mr-timeline-vertical-line dior-ic-faf62239fc"></div>
                                            <div class="mr-timeline-icon-node dior-ic-3c3a35ad9a">
                                                <i class="fas text-white fa-stethoscope dior-ic-31bb4f1b09"></i>
                                            </div>
                                        </div>
                                        <div class="mr-timeline-content-card">
                                            <div class="dior-ic-eba8b27042">
                                                <div class="dior-ic-33aac0e461">
                                                    <span class="dior-ic-8174d83c91"> CONSULTATION </span>
                                                    <h5 class="dior-ic-fceca4a64a">Cardiology Follow-Up Consultation</h5>
                                                </div>
                                                <div class="dior-ic-b1d844752a">
                                                    <img src="https://ui-avatars.com/api/?name=John+Deo&background=random" alt="Dr. John Deo" class="dior-ic-2061ceb509">
                                                    <div>
                                                        <span class="dior-ic-9bbdb950cc">Dr. John Deo</span>
                                                        <small class="dior-ic-3a4133fe41">Senior Cardiologist</small>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="dior-ic-e042bd824c"> Routine post-procedural cardiology assessment. Patient reported significant improvement in stamina with minor incisional discomfort. Vital signs stable, normal sinus rhythm on ECG. </p>
                                            <div class="dior-ic-5b56531d97">
                                                <p class="dior-ic-82fcd876e7"><i class="fas fa-quote-left me-2 text-primary opacity-50 dior-ic-3104e188cf"></i>"Patient is recovering ahead of schedule. Resume light aerobic walking for 20 mins daily." </p>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Event 3: PRESCRIPTION -->
                                    <div class="mr-timeline-item">
                                        <div class="mr-timeline-time-col">
                                            <span class="dior-ic-14731f6c49">15 Sep 2026</span>
                                            <span class="dior-ic-07e1c2794e"><i class="far fa-clock me-1"></i>02:00 PM</span>
                                            <span class="dior-ic-81a2aacd66">1 week ago</span>
                                        </div>
                                        <div class="dior-ic-f69dfb2b50">
                                            <div class="mr-timeline-vertical-line dior-ic-c380c2f85c"></div>
                                            <div class="mr-timeline-icon-node dior-ic-6cbf4b7782">
                                                <i class="fas text-white fa-pills dior-ic-31bb4f1b09"></i>
                                            </div>
                                        </div>
                                        <div class="mr-timeline-content-card">
                                            <div class="dior-ic-eba8b27042">
                                                <div class="dior-ic-33aac0e461">
                                                    <span class="dior-ic-6f24c3b5a8"> PRESCRIPTION </span>
                                                    <h5 class="dior-ic-fceca4a64a">Post-Op Medication &amp; Discharge Prescription</h5>
                                                </div>
                                                <div class="dior-ic-b1d844752a">
                                                    <img src="https://ui-avatars.com/api/?name=Sarah+Smith&background=random" alt="Dr. Sarah Smith" class="dior-ic-2061ceb509">
                                                    <div>
                                                        <span class="dior-ic-9bbdb950cc">Dr. Sarah Smith</span>
                                                        <small class="dior-ic-3a4133fe41">Attending Physician</small>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="dior-ic-e042bd824c"> Prescribed post-op antibiotic regimen and daily anticoagulant therapy. Recommended follow-up lab work in 14 days. </p>
                                            <div class="dior-ic-593add7c69">
                                                <span class="dior-ic-6ea52b4fa0"><i class="fas fa-pills me-1"></i> Prescribed Dosage &amp; Medications:</span>
                                                <div class="dior-ic-c10bc232ce">
                                                    <span class="dior-ic-e28156cc2b"><i class="fas fa-check-circle me-1 dior-ic-4bbd5da241"></i> Amoxicillin 500mg (TID x 7 days) </span>
                                                    <span class="dior-ic-e28156cc2b"><i class="fas fa-check-circle me-1 dior-ic-4bbd5da241"></i> Clopidogrel 75mg (OD) </span>
                                                    <span class="dior-ic-e28156cc2b"><i class="fas fa-check-circle me-1 dior-ic-4bbd5da241"></i> Paracetamol 650mg (PRN for pain) </span>
                                                </div>
                                            </div>
                                            <div class="dior-ic-2f0bf46977">
                                                <span class="dior-ic-d59351bad1"><i class="fas fa-paperclip me-1"></i> Attached Medical Files (2):</span>
                                                <div class="dior-ic-c10bc232ce">
                                                    <button type="button" class="dior-ic-3b4d05ddb3">
                                                        <i class="fas fa-file-pdf dior-ic-bbfc66681c"></i><span>Discharge_Prescription_Signed.pdf</span><small class="dior-ic-e5b7658379">(1.2 MB)</small><i class="fas fa-download"></i>
                                                    </button>
                                                    <button type="button" class="dior-ic-3b4d05ddb3">
                                                        <i class="fas fa-file-pdf dior-ic-bbfc66681c"></i><span>Lab_Order_Blood_Panel.pdf</span><small class="dior-ic-e5b7658379">(850 KB)</small><i class="fas fa-download"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Event 4: SURGERY -->
                                    <div class="mr-timeline-item">
                                        <div class="mr-timeline-time-col">
                                            <span class="dior-ic-14731f6c49">04 Sep 2026</span>
                                            <span class="dior-ic-07e1c2794e"><i class="far fa-clock me-1"></i>10:30 AM</span>
                                            <span class="dior-ic-81a2aacd66">2 weeks ago</span>
                                        </div>
                                        <div class="dior-ic-f69dfb2b50">
                                            <div class="mr-timeline-vertical-line dior-ic-44548e8be3"></div>
                                            <div class="mr-timeline-icon-node dior-ic-697e5532aa">
                                                <i class="fas text-white fa-user-md dior-ic-31bb4f1b09"></i>
                                            </div>
                                        </div>
                                        <div class="mr-timeline-content-card">
                                            <div class="dior-ic-eba8b27042">
                                                <div class="dior-ic-33aac0e461">
                                                    <span class="dior-ic-5c4569621a"> SURGERY </span>
                                                    <h5 class="dior-ic-fceca4a64a">Minimally Invasive Cardiac Angioplasty</h5>
                                                </div>
                                                <div class="dior-ic-b1d844752a">
                                                    <img src="https://ui-avatars.com/api/?name=Sarah+Smith&background=random" alt="Dr. Sarah Smith" class="dior-ic-2061ceb509">
                                                    <div>
                                                        <span class="dior-ic-9bbdb950cc">Surgical Team Lead: Dr. Sarah Smith</span>
                                                        <small class="dior-ic-3a4133fe41">Lead Cardiac Surgeon</small>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="dior-ic-e042bd824c"> Successful minimally invasive catheter angioplasty with stent placement in LAD coronary artery. Hemodynamics stabilized throughout 2-hour procedure with zero intraoperative complications. </p>
                                            <div class="dior-ic-b75bfd6594">
                                                <span class="dior-ic-838a1f3287"><i class="fas fa-user-md me-1 dior-ic-bbfc66681c"></i> Attending Surgical Specialist Team:</span>
                                                <div class="dior-ic-f725034276">
                                                    <img src="https://ui-avatars.com/api/?name=Doc+A&background=random" class="dior-ic-ecbe4e4583">
                                                    <img src="https://ui-avatars.com/api/?name=Doc+B&background=random" class="dior-ic-3142a29e03">
                                                    <img src="https://ui-avatars.com/api/?name=Doc+C&background=random" class="dior-ic-709ccc55b7">
                                                    <img src="https://ui-avatars.com/api/?name=Doc+D&background=random" class="dior-ic-a0063571cf">
                                                    <span class="dior-ic-b3c0646eef">4 Surgeons &amp; Anesthesiologist</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Event 5: CONSULTATION -->
                                    <div class="mr-timeline-item">
                                        <div class="mr-timeline-time-col">
                                            <span class="dior-ic-14731f6c49">29 Aug 2026</span>
                                            <span class="dior-ic-07e1c2794e"><i class="far fa-clock me-1"></i>01:30 PM</span>
                                            <span class="dior-ic-81a2aacd66">3 weeks ago</span>
                                        </div>
                                        <div class="dior-ic-f69dfb2b50">
                                            <div class="mr-timeline-vertical-line dior-ic-e37d314bf3"></div>
                                            <div class="mr-timeline-icon-node dior-ic-3c3a35ad9a">
                                                <i class="fas text-white fa-stethoscope dior-ic-31bb4f1b09"></i>
                                            </div>
                                        </div>
                                        <div class="mr-timeline-content-card">
                                            <div class="dior-ic-eba8b27042">
                                                <div class="dior-ic-33aac0e461">
                                                    <span class="dior-ic-8174d83c91"> CONSULTATION </span>
                                                    <h5 class="dior-ic-fceca4a64a">Initial Clinical Examination &amp; Pre-Op Assessment</h5>
                                                </div>
                                                <div class="dior-ic-b1d844752a">
                                                    <img src="https://ui-avatars.com/api/?name=Sarah+Smith&background=random" alt="Dr. Sarah Smith" class="dior-ic-2061ceb509">
                                                    <div>
                                                        <span class="dior-ic-9bbdb950cc">Dr. Sarah Smith</span>
                                                        <small class="dior-ic-3a4133fe41">Attending Physician</small>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="dior-ic-e042bd824c"> Comprehensive intake evaluation and diagnostic workup prior to scheduling cardiac intervention. </p>
                                            <div class="dior-ic-5b56531d97">
                                                <p class="dior-ic-82fcd876e7"><i class="fas fa-quote-left me-2 text-primary opacity-50 dior-ic-3104e188cf"></i>"Advised immediate angiogram testing based on exercise stress test results and persistent angina." </p>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Event 6: SYSTEM -->
                                    <div class="mr-timeline-item">
                                        <div class="mr-timeline-time-col">
                                            <span class="dior-ic-14731f6c49">25 Aug 2026</span>
                                            <span class="dior-ic-07e1c2794e"><i class="far fa-clock me-1"></i>12:13 PM</span>
                                            <span class="dior-ic-81a2aacd66">1 month ago</span>
                                        </div>
                                        <div class="dior-ic-f69dfb2b50">
                                            <div class="mr-timeline-vertical-line dior-ic-c3bef71984"></div>
                                            <div class="mr-timeline-icon-node dior-ic-01ea12d48a">
                                                <i class="fas text-white fa-id-card dior-ic-31bb4f1b09"></i>
                                            </div>
                                        </div>
                                        <div class="mr-timeline-content-card">
                                            <div class="dior-ic-eba8b27042">
                                                <div class="dior-ic-33aac0e461">
                                                    <span class="dior-ic-9378edcfeb"> SYSTEM </span>
                                                    <h5 class="dior-ic-fceca4a64a">Patient EMR Onboarding &amp; ID Generation</h5>
                                                </div>
                                                <div class="dior-ic-b1d844752a">
                                                    <img src="https://ui-avatars.com/api/?name=Admin&background=random" alt="Hospital Registrar" class="dior-ic-2061ceb509">
                                                    <div>
                                                        <span class="dior-ic-9bbdb950cc">Hospital Registrar</span>
                                                        <small class="dior-ic-3a4133fe41">Medical Records Admin</small>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="dior-ic-9316028665"> Generated permanent patient electronic health record ID #PAT-1082 and verified insurance coverage. </p>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


                <!-- ============================================================== -->
                <!-- 6. BILLING & PAYMENT TAB -->
