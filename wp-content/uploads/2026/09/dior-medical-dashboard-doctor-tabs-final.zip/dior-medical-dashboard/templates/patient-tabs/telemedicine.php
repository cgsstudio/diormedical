<section class="dior-tab-panel dior-ic-44a70a0420" id="tab-telemedicine">
    <div class="master-table-wrapper">
        <div class="master-table-container">
            <div class="master-table-card">
                <div class="master-table-header">
                    <div class="header-content">
                        <div class="table-title-section">
                            <h2 class="table-title">Telemedicine / Video Consultations</h2>
                            <div class="title-accent"></div>
                        </div>
                        <div class="header-actions-group">
                            <div class="search-container">
                                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                                <input type="text" id="dior-tele-search-input" placeholder="Search records..." aria-label="Search box" class="search-input" onkeyup="diorFilterTele()">
                            </div>
                            <div class="action-buttons">
                                <button type="button" aria-label="Add new record" class="action-btn action-btn-primary dior-ic-54410f9b78">
                                    <i class="fa-solid fa-plus"></i>
                                </button>
                                <button type="button" aria-label="Export to CSV" class="action-btn action-btn-success" title="Export to CSV" onclick="diorDownloadTeleCSV()">
                                    <i class="fa-solid fa-file-arrow-down"></i>
                                </button>
                                <button type="button" aria-label="Refresh data" class="action-btn action-btn-info" title="Refresh Page" onclick="window.location.reload()">
                                    <i class="fa-solid fa-rotate-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-content">
                    <table class="master-modern-table" id="dior-tele-table">
                        <thead>
                            <tr>
                                <th class="dior-ic-3fa4d8d717">
                                    <input type="checkbox" class="dior-ic-52ff4d551f">
                                </th>
                                <th>SESSION ID <i class="fa-solid fa-sort"></i></th>
                                <th>DOCTOR <i class="fa-solid fa-sort"></i></th>
                                <th>SPECIALTY <i class="fa-solid fa-sort"></i></th>
                                <th>DATE <i class="fa-solid fa-sort"></i></th>
                                <th>TIME <i class="fa-solid fa-sort"></i></th>
                                <th>DURATION <i class="fa-solid fa-sort"></i></th>
                                <th>TYPE <i class="fa-solid fa-sort"></i></th>
                                <th>STATUS <i class="fa-solid fa-sort"></i></th>
                                <th>ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody id="dior-tele-tbody">
                            <?php
                            $tele_mock = [
                                ['TM001', 'Dr. Sarah Smith', 'General Physician', 'Nov 26, 2024', '10:00 AM', '30 minutes', 'Follow-up', 'Scheduled', '#3B82F6', '#DBEAFE'],
                                ['TM002', 'Dr. Michael Johnson', 'Cardiologist', 'Nov 24, 2024', '02:00 PM', '45 minutes', 'Initial Consultation', 'Completed', '#10B981', '#D1FAE5'],
                                ['TM003', 'Dr. Emily Davis', 'Dermatologist', 'Nov 27, 2024', '11:00 AM', '30 minutes', 'Prescription Renewal', 'Scheduled', '#3B82F6', '#DBEAFE'],
                                ['TM004', 'Dr. Robert Wilson', 'Psychiatrist', 'Nov 23, 2024', '09:00 AM', '60 minutes', 'Therapy Session', 'Completed', '#10B981', '#D1FAE5'],
                                ['TM005', 'Dr. Lisa Anderson', 'Pediatrician', 'Nov 25, 2024', '03:00 PM', '30 minutes', 'Follow-up', 'Cancelled', '#EF4444', '#FEE2E2'],
                                ['TM006', 'Dr. James Miller', 'Orthopedic Surgeon', 'Nov 28, 2024', '01:30 PM', '30 minutes', 'Follow-up', 'Scheduled', '#3B82F6', '#DBEAFE'],
                                ['TM007', 'Dr. Sophia Martinez', 'Endocrinologist', 'Nov 22, 2024', '04:00 PM', '45 minutes', 'Initial Consultation', 'Completed', '#10B981', '#D1FAE5'],
                                ['TM008', 'Dr. Daniel Thompson', 'Neurologist', 'Nov 29, 2024', '12:00 PM', '30 minutes', 'Diagnostic Review', 'Scheduled', '#3B82F6', '#DBEAFE'],
                                ['TM009', 'Dr. Ava Brown', 'Ophthalmologist', 'Nov 21, 2024', '05:00 PM', '20 minutes', 'Check-up', 'Completed', '#10B981', '#D1FAE5']
                            ];
                            foreach ($tele_mock as $tm):
                            ?>
                            <tr>
                                <td><input type="checkbox" class="dior-ic-52ff4d551f"></td>
                                <td><span class="cell-text"><?php echo esc_html($tm[0]); ?></span></td>
                                <td>
                                    <div class="cell-content cell-image-name dior-ic-c4a200d5b6">
                                        <img alt="Doctor avatar" class="cell-avatar" src="https://ui-avatars.com/api/?name=<?php echo urlencode($tm[1]); ?>&background=random" class="dior-ic-90c82cbe20">
                                        <div class="cell-text-wrapper">
                                            <div class="cell-text dior-ic-df2950dda9"><?php echo esc_html($tm[1]); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td><span class="cell-text dior-ic-794116ec9b"><?php echo esc_html($tm[2]); ?></span></td>
                                <td>
                                    <div class="cell-content cell-icon-text">
                                        <i class="fa-regular fa-calendar cell-icon dior-ic-d53ea48df0"></i>
                                        <span class="cell-text"><?php echo esc_html($tm[3]); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <div class="cell-content cell-icon-text">
                                        <i class="fa-regular fa-clock cell-icon dior-ic-4bbd5da241"></i>
                                        <span class="cell-text"><?php echo esc_html($tm[4]); ?></span>
                                    </div>
                                </td>
                                <td><span class="cell-text"><?php echo esc_html($tm[5]); ?></span></td>
                                <td><span class="cell-text"><?php echo esc_html($tm[6]); ?></span></td>
                                <td>
                                    <div class="cell-content">
                                        <div class="dior-dyn-status dior-dyn-bg-<?php echo esc_attr(sanitize_html_class(ltrim($tm[9], '#'))); ?> dior-dyn-color-<?php echo esc_attr(sanitize_html_class(ltrim($tm[8], '#'))); ?>">
                                            <?php echo esc_html($tm[7]); ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="cell-actions">
                                        <button type="button" class="action-icon-btn edit-btn" title="Edit Record"><i class="fa-solid fa-pen"></i></button>
                                        <button type="button" class="action-icon-btn delete-btn" title="Delete Record"><i class="fa-regular fa-trash-can"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="master-table-footer">
                    <span class="page-count" id="dior-tele-page-count">0 selected / <?php echo count($tele_mock); ?> total</span>
                    
                    <div class="master-pagination" id="dior-tele-pagination">
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</section>
                <!-- ============================================================== -->
                <!-- 5. MEDICAL RECORD TAB -->
                <!-- ============================================================== -->
