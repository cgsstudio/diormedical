<section class="dior-tab-panel dior-ic-44a70a0420" id="tab-emergency">
    
    <!-- Top Action Cards -->
    <div class="dior-ic-597dc7a00c">
        <!-- Request Ambulance -->
        <div class="dior-ic-f5e657b8f6">
            <div class="dior-ic-050317ce29">
                <i class="fa-solid fa-truck-medical"></i>
            </div>
            <h4 class="dior-ic-4f9a9fe05d">Request Ambulance</h4>
            <p class="dior-ic-b4344ed8fa">Immediate emergency assistance</p>
            <button type="button" onmouseover="this.style.background='#EF4444'; this.style.color='#fff';" onmouseout="this.style.background='transparent'; this.style.color='#EF4444';" class="dior-ic-7f1daa7fb4">Call Now</button>
        </div>
        
        <!-- Emergency Doctor -->
        <div class="dior-ic-f5e657b8f6">
            <div class="dior-ic-d1eca3c91b">
                <i class="fa-solid fa-user-doctor"></i>
            </div>
            <h4 class="dior-ic-4f9a9fe05d">Emergency Doctor</h4>
            <p class="dior-ic-b4344ed8fa">Connect with available doctors</p>
            <button type="button" onmouseover="this.style.background='#F59E0B'; this.style.color='#fff';" onmouseout="this.style.background='transparent'; this.style.color='#F59E0B';" class="dior-ic-a0664572fd">Contact</button>
        </div>
        
        <!-- Digital Health Card -->
        <div class="dior-ic-f5e657b8f6">
            <div class="dior-ic-12cb12d607">
                <i class="fa-solid fa-id-card"></i>
            </div>
            <h4 class="dior-ic-4f9a9fe05d">Digital Health Card</h4>
            <p class="dior-ic-b4344ed8fa">Access your medical records</p>
            <button type="button" onmouseover="this.style.background='#14B8A6'; this.style.color='#fff';" onmouseout="this.style.background='transparent'; this.style.color='#14B8A6';" class="dior-ic-6713853875">View Card</button>
        </div>
    </div>

    <div class="master-table-wrapper">
        <div class="master-table-container">
            <div class="master-table-card">
                <div class="master-table-header">
                    <div class="header-content">
                        <div class="table-title-section">
                            <h2 class="table-title">Emergency Contacts</h2>
                            <div class="title-accent"></div>
                        </div>
                        <div class="header-actions-group">
                            <div class="search-container">
                                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                                <input type="text" id="dior-emerg-search-input" placeholder="Search records..." aria-label="Search box" class="search-input" onkeyup="diorFilterEmerg()">
                            </div>
                            <div class="action-buttons">
                                <button type="button" aria-label="Add new record" class="action-btn action-btn-primary dior-ic-54410f9b78">
                                    <i class="fa-solid fa-plus"></i>
                                </button>
                                <button type="button" aria-label="Export to CSV" class="action-btn action-btn-success" title="Export to CSV" onclick="diorDownloadEmergCSV()">
                                    <i class="fa-solid fa-file-arrow-down"></i>
                                </button>
                                <button type="button" aria-label="Refresh data" class="action-btn action-btn-info" title="Refresh Page" onclick="window.location.reload()">
                                    <i class="fa-solid fa-rotate-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-content">
                    <table class="master-modern-table" id="dior-emerg-table">
                        <thead>
                            <tr>
                                <th class="dior-ic-3fa4d8d717">
                                    <input type="checkbox" class="dior-ic-52ff4d551f">
                                </th>
                                <th>CONTACT NAME <i class="fa-solid fa-sort"></i></th>
                                <th>RELATION <i class="fa-solid fa-sort"></i></th>
                                <th>PHONE NUMBER <i class="fa-solid fa-sort"></i></th>
                                <th>PRIORITY <i class="fa-solid fa-sort"></i></th>
                                <th>ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody id="dior-emerg-tbody">
                            <?php
                            $emerg_mock = [
                                ['Jane Doe', 'Spouse', '555-0101', 'Primary', '#EF4444', '#FEE2E2'],
                                ['John Doe Sr.', 'Parent', '555-0103', 'Secondary', '#3B82F6', '#DBEAFE']
                            ];
                            foreach ($emerg_mock as $em):
                            ?>
                            <tr>
                                <td><input type="checkbox" class="dior-ic-52ff4d551f"></td>
                                <td><span class="cell-text dior-ic-794116ec9b"><?php echo esc_html($em[0]); ?></span></td>
                                <td><span class="cell-text dior-ic-794116ec9b"><?php echo esc_html($em[1]); ?></span></td>
                                <td><span class="cell-text dior-ic-794116ec9b"><?php echo esc_html($em[2]); ?></span></td>
                                <td>
                                    <div class="cell-content">
                                        <div class="dior-dyn-status dior-dyn-bg-<?php echo esc_attr(sanitize_html_class(ltrim($em[5], '#'))); ?> dior-dyn-color-<?php echo esc_attr(sanitize_html_class(ltrim($em[4], '#'))); ?>">
                                            <?php echo esc_html($em[3]); ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="cell-actions">
                                        <button type="button" class="action-icon-btn edit-btn" title="Edit Record"><i class="fa-solid fa-pen"></i></button>
                                        <button type="button" class="action-icon-btn delete-btn" title="Delete Record"><i class="fa-regular fa-trash-can"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="master-table-footer">
                    <span class="page-count" id="dior-emerg-page-count">0 selected / <?php echo count($emerg_mock); ?> total</span>
                    
                    <div class="master-pagination" id="dior-emerg-pagination">
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</section>
