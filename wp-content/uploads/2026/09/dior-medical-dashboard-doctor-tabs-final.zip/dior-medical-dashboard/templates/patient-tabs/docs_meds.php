<section class="dior-tab-panel" id="tab-docs_meds">
                    <div class="dior-page-header-box">
                        <div>
                            <h2>Medical Documents & Active Prescriptions</h2>
                        </div>
                        <div class="dior-header-action-group">
                            <button type="button" class="dior-btn-gold-secondary dior-ic-9a404bf6a0"
                                onclick="diorOpenModal('modal-change-pharmacy')">
                                <i class="fa-solid fa-store"></i> Update Pharmacy Preference
                            </button>
                        </div>
                    </div>

                    <!-- Prescriptions Section -->
                    <!-- Prescriptions Section -->
                    <div class="master-table-wrapper">
                        <div class="master-table-container">
                            <div class="master-table-card">
                                <div class="master-table-header">
                                    <div class="header-content">
                                        <div class="table-title-section">
                                            <h2 class="table-title">Prescriptions</h2>
                                            <div class="title-accent"></div>
                                        </div>
                                        <div class="header-actions-group">
                                            <div class="search-container">
                                                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                                                <input type="text" id="dior-rx-search-input" placeholder="Search records..." aria-label="Search box" class="search-input" onkeyup="diorFilterRx()">
                                            </div>
                                            <div class="action-buttons">
                                                <button type="button" aria-label="Add new record" class="action-btn action-btn-primary">
                                                    <i class="fa-solid fa-plus"></i>
                                                </button>
                                                <button type="button" aria-label="Export to CSV" class="action-btn action-btn-success" title="Export to CSV" onclick="diorDownloadRxCSV()">
                                                    <i class="fa-solid fa-file-arrow-down"></i>
                                                </button>
                                                <button type="button" aria-label="Refresh data" class="action-btn action-btn-info" title="Refresh Page" onclick="window.location.reload()">
                                                    <i class="fa-solid fa-rotate-right"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="table-content">
                                    <table class="master-modern-table" id="dior-rx-table">
                                        <thead>
                                            <tr>
                                                <th>ID <i class="fa-solid fa-sort"></i></th>
                                                <th>TITLE <i class="fa-solid fa-sort"></i></th>
                                                <th>CREATED BY <i class="fa-solid fa-sort"></i></th>
                                                <th>DATE <i class="fa-solid fa-sort"></i></th>
                                                <th>DISEASES <i class="fa-solid fa-sort"></i></th>
                                                <th>ACTIONS <i class="fa-solid fa-sort"></i></th>
                                            </tr>
                                        </thead>
                                        <tbody id="dior-rx-tbody">
                                            <?php
                                            $prescription_mock = [
                                                ['#A348', 'Prescription 1', 'Dr.Jacob Ryan', 'May 12, 2016', 'Fever'],
                                                ['#A645', 'Prescription 2', 'Dr.Rajesh', 'May 12, 2016', 'Cholera'],
                                                ['#A873', 'Prescription 3', 'Dr.Jay Soni', 'May 12, 2016', 'Jaundice'],
                                                ['#A927', 'Prescription 4', 'Dr.John Deo', 'May 12, 2016', 'Typhod'],
                                                ['#A228', 'Prescription 5', 'Dr.Megha Trivedi', 'May 12, 2016', 'Maleria'],
                                                ['#A345', 'Prescription 6', 'Dr.Sarah Smith', 'May 12, 2016', 'Infection'],
                                                ['#A765', 'Prescription 7', 'Dr.Jacob Ryan', 'May 12, 2016', 'Fever'],
                                                ['#A125', 'Prescription 8', 'Dr.Rajesh', 'May 12, 2016', 'Cholera'],
                                                ['#A126', 'Prescription 9', 'Dr.Jay Soni', 'May 13, 2016', 'Jaundice'],
                                                ['#A127', 'Prescription 10', 'Dr.John Deo', 'May 14, 2016', 'Typhod']
                                            ];
                                            foreach ($prescription_mock as $pm):
                                            ?>
                                            <tr>
                                                <td><span class="cell-text"><?php echo esc_html($pm[0]); ?></span></td>
                                                <td><span class="cell-text"><?php echo esc_html($pm[1]); ?></span></td>
                                                <td><span class="cell-text"><?php echo esc_html($pm[2]); ?></span></td>
                                                <td>
                                                    <div class="cell-content cell-icon-text">
                                                        <i class="fa-regular fa-calendar cell-icon"></i>
                                                        <span class="cell-text"><?php echo esc_html($pm[3]); ?></span>
                                                    </div>
                                                </td>
                                                <td><span class="cell-text"><?php echo esc_html($pm[4]); ?></span></td>
                                                <td>
                                                    <div class="cell-content action-cell">
                                                        <button type="button" class="action-btn action-btn-info" title="Download" onclick="diorDownloadRxPdf('<?php echo esc_js($pm[0]); ?>')">
                                                            <i class="fa-solid fa-download"></i>
                                                        </button>
                                                        <button type="button" class="action-btn action-btn-danger" title="Delete" onclick="diorDeleteRxRow(this)">
                                                            <i class="fa-solid fa-trash-can"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="master-table-footer">
                                    <span class="page-count" id="dior-rx-page-count">0 selected / <?php echo count($prescription_mock); ?> total</span>
                                    
                                    <div class="master-pagination" id="dior-rx-pagination">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                                            
                </section>
