<section class="dior-tab-panel dior-ic-44a70a0420" id="tab-documents">
    <div class="master-table-wrapper">
        <div class="master-table-container">
            <div class="master-table-card">
                <div class="master-table-header">
                    <div class="header-content">
                        <div class="table-title-section">
                            <h2 class="table-title">My Documents &amp; Reports</h2>
                            <div class="title-accent"></div>
                        </div>
                        <div class="header-actions-group">
                            <div class="search-container">
                                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                                <input type="text" id="dior-docs-search-input" placeholder="Search records..." aria-label="Search box" class="search-input" onkeyup="diorFilterDocs()">
                            </div>
                            <div class="action-buttons">
                                <button type="button" aria-label="Add new record" class="action-btn action-btn-primary dior-ic-54410f9b78">
                                    <i class="fa-solid fa-plus"></i>
                                </button>
                                <button type="button" aria-label="Export to CSV" class="action-btn action-btn-success" title="Export to CSV" onclick="diorDownloadDocsCSV()">
                                    <i class="fa-solid fa-file-arrow-down"></i>
                                </button>
                                <button type="button" aria-label="Refresh data" class="action-btn action-btn-info" title="Refresh Page" onclick="window.location.reload()">
                                    <i class="fa-solid fa-rotate-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-content">
                    <table class="master-modern-table" id="dior-docs-table">
                        <thead>
                            <tr>
                                <th class="dior-ic-3fa4d8d717">
                                    <input type="checkbox" class="dior-ic-52ff4d551f">
                                </th>
                                <th>DOCUMENT TITLE <i class="fa-solid fa-sort"></i></th>
                                <th>CATEGORY <i class="fa-solid fa-sort"></i></th>
                                <th>TYPE <i class="fa-solid fa-sort"></i></th>
                                <th>UPLOAD DATE <i class="fa-solid fa-sort"></i></th>
                                <th>SIZE <i class="fa-solid fa-sort"></i></th>
                                <th>STATUS <i class="fa-solid fa-sort"></i></th>
                                <th>ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody id="dior-docs-tbody">
                            <?php
                            $docs_mock = [
                                ['Discharge Summary - Nov 2024', 'Medical Report', 'PDF', '#EF4444', '#FEE2E2', 'Nov 20, 2024', '2.5 MB', 'Verified', '#10B981', '#D1FAE5'],
                                ['Blood Test Results', 'Lab Report', 'PDF', '#EF4444', '#FEE2E2', 'Nov 18, 2024', '1.2 MB', 'Verified', '#10B981', '#D1FAE5'],
                                ['Vaccination Certificate', 'Certificate', 'PDF', '#EF4444', '#FEE2E2', 'Jan 15, 2024', '0.8 MB', 'Verified', '#10B981', '#D1FAE5'],
                                ['Insurance Policy 2024', 'Insurance', 'PDF', '#EF4444', '#FEE2E2', 'Jan 1, 2024', '3.0 MB', 'Verified', '#10B981', '#D1FAE5'],
                                ['X-Ray Chest', 'Radiology', 'JPG', '#3B82F6', '#DBEAFE', 'Nov 19, 2024', '5.5 MB', 'Verified', '#10B981', '#D1FAE5'],
                                ['Prescription - Dr. Smith', 'Prescription', 'PDF', '#EF4444', '#FEE2E2', 'Nov 20, 2024', '0.5 MB', 'Verified', '#10B981', '#D1FAE5'],
                                ['MRI Scan Report', 'Radiology', 'PDF', '#EF4444', '#FEE2E2', 'Dec 10, 2023', '4.2 MB', 'Verified', '#10B981', '#D1FAE5'],
                                ['Allergy Test', 'Lab Report', 'PDF', '#EF4444', '#FEE2E2', 'Jun 15, 2023', '1.5 MB', 'Verified', '#10B981', '#D1FAE5']
                            ];
                            foreach ($docs_mock as $dm):
                            ?>
                            <tr>
                                <td><input type="checkbox" class="dior-ic-52ff4d551f"></td>
                                <td><span class="cell-text dior-ic-794116ec9b"><?php echo esc_html($dm[0]); ?></span></td>
                                <td><span class="cell-text dior-ic-794116ec9b"><?php echo esc_html($dm[1]); ?></span></td>
                                <td>
                                    <div class="cell-content">
                                        <div class="dior-dyn-status dior-dyn-bg-<?php echo esc_attr(sanitize_html_class(ltrim($dm[4], '#'))); ?> dior-dyn-color-<?php echo esc_attr(sanitize_html_class(ltrim($dm[3], '#'))); ?>">
                                            <?php echo esc_html($dm[2]); ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="cell-content cell-icon-text">
                                        <i class="fa-regular fa-calendar cell-icon dior-ic-d53ea48df0"></i>
                                        <span class="cell-text"><?php echo esc_html($dm[5]); ?></span>
                                    </div>
                                </td>
                                <td><span class="cell-text"><?php echo esc_html($dm[6]); ?></span></td>
                                <td>
                                    <div class="cell-content">
                                        <div class="dior-dyn-status dior-dyn-bg-<?php echo esc_attr(sanitize_html_class(ltrim($dm[9], '#'))); ?> dior-dyn-color-<?php echo esc_attr(sanitize_html_class(ltrim($dm[8], '#'))); ?>">
                                            <?php echo esc_html($dm[7]); ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="cell-actions">
                                        <button type="button" class="action-icon-btn edit-btn" title="Edit Record"><i class="fa-solid fa-pen"></i></button>
                                        <button type="button" class="action-icon-btn delete-btn" title="Delete Record"><i class="fa-regular fa-trash-can"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="master-table-footer">
                    <span class="page-count" id="dior-docs-page-count">0 selected / <?php echo count($docs_mock); ?> total</span>
                    
                    <div class="master-pagination" id="dior-docs-pagination">
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</section>
