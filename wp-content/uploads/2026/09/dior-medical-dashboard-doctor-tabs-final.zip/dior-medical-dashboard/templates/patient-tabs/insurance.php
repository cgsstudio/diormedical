<section class="dior-tab-panel dior-ic-44a70a0420" id="tab-insurance">
    <div class="master-table-wrapper">
        <div class="master-table-container">
            <div class="master-table-card">
                <div class="master-table-header">
                    <div class="header-content">
                        <div class="table-title-section">
                            <h2 class="table-title">Insurance & Claims</h2>
                            <div class="title-accent"></div>
                        </div>
                        <div class="header-actions-group">
                            <div class="search-container">
                                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                                <input type="text" id="dior-insurance-search-input" placeholder="Search records..." aria-label="Search box" class="search-input" onkeyup="diorFilterInsurance()">
                            </div>
                            <div class="action-buttons">
                                <button type="button" aria-label="Add new record" class="action-btn action-btn-primary dior-ic-54410f9b78">
                                    <i class="fa-solid fa-plus"></i>
                                </button>
                                <button type="button" aria-label="Export to CSV" class="action-btn action-btn-success" title="Export to CSV" onclick="diorDownloadInsuranceCSV()">
                                    <i class="fa-solid fa-file-arrow-down"></i>
                                </button>
                                <button type="button" aria-label="Refresh data" class="action-btn action-btn-info" title="Refresh Page" onclick="window.location.reload()">
                                    <i class="fa-solid fa-rotate-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-content">
                    <table class="master-modern-table" id="dior-insurance-table">
                        <thead>
                            <tr>
                                <th class="dior-ic-3fa4d8d717">
                                    <input type="checkbox" class="dior-ic-52ff4d551f">
                                </th>
                                <th>CLAIM ID <i class="fa-solid fa-sort"></i></th>
                                <th>POLICY ID <i class="fa-solid fa-sort"></i></th>
                                <th>CLAIM DATE <i class="fa-solid fa-sort"></i></th>
                                <th>CLAIM TYPE <i class="fa-solid fa-sort"></i></th>
                                <th>CLAIM AMOUNT ($) <i class="fa-solid fa-sort"></i></th>
                                <th>APPROVED ($) <i class="fa-solid fa-sort"></i></th>
                                <th>SUBMITTED <i class="fa-solid fa-sort"></i></th>
                                <th>STATUS <i class="fa-solid fa-sort"></i></th>
                                <th>ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody id="dior-insurance-tbody">
                            <?php
                            $insurance_mock = [
                                ['CLM001', 'POL001', 'Nov 20, 2024', 'Hospitalization', '5000', '4500', 'Nov 20, 2024', 'Approved', '#10B981', '#D1FAE5'],
                                ['CLM002', 'POL001', 'Nov 18, 2024', 'Outpatient', '1500', '', 'Nov 18, 2024', 'Under Review', '#F59E0B', '#FEF3C7'],
                                ['CLM003', 'POL002', 'Nov 15, 2024', 'Surgery', '3000', '3000', 'Nov 15, 2024', 'Approved', '#10B981', '#D1FAE5'],
                                ['CLM004', 'POL001', 'Nov 22, 2024', 'Pharmacy', '800', '600', 'Nov 22, 2024', 'Partially Approved', '#3B82F6', '#DBEAFE'],
                                ['CLM005', 'POL003', 'Nov 10, 2024', 'Dental', '2000', '0', 'Nov 10, 2024', 'Rejected', '#EF4444', '#FEE2E2']
                            ];
                            foreach ($insurance_mock as $im):
                            ?>
                            <tr>
                                <td><input type="checkbox" class="dior-ic-52ff4d551f"></td>
                                <td><span class="cell-text"><?php echo esc_html($im[0]); ?></span></td>
                                <td><span class="cell-text"><?php echo esc_html($im[1]); ?></span></td>
                                <td>
                                    <div class="cell-content cell-icon-text">
                                        <i class="fa-regular fa-calendar cell-icon dior-ic-d53ea48df0"></i>
                                        <span class="cell-text"><?php echo esc_html($im[2]); ?></span>
                                    </div>
                                </td>
                                <td><span class="cell-text"><?php echo esc_html($im[3]); ?></span></td>
                                <td><span class="cell-text"><?php echo esc_html($im[4]); ?></span></td>
                                <td><span class="cell-text"><?php echo esc_html($im[5]); ?></span></td>
                                <td>
                                    <div class="cell-content cell-icon-text">
                                        <i class="fa-regular fa-calendar cell-icon dior-ic-d53ea48df0"></i>
                                        <span class="cell-text"><?php echo esc_html($im[6]); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <div class="cell-content">
                                        <div class="dior-dyn-status dior-dyn-bg-<?php echo esc_attr(sanitize_html_class(ltrim($im[9], '#'))); ?> dior-dyn-color-<?php echo esc_attr(sanitize_html_class(ltrim($im[8], '#'))); ?>">
                                            <?php echo esc_html($im[7]); ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="cell-actions">
                                        <button type="button" class="action-icon-btn edit-btn" title="Edit Record"><i class="fa-solid fa-pen"></i></button>
                                        <button type="button" class="action-icon-btn delete-btn" title="Delete Record"><i class="fa-regular fa-trash-can"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="master-table-footer">
                    <span class="page-count" id="dior-insurance-page-count">0 selected / <?php echo count($insurance_mock); ?> total</span>
                    
                    <div class="master-pagination" id="dior-insurance-pagination">
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</section>
                <!-- ============================================================== -->
                <!-- 4. DOCS & MEDS (Documents + Prescriptions) TAB -->
                <!-- ============================================================== -->
