<section class="dior-tab-panel dior-ic-44a70a0420" id="tab-notifications">
    <div class="master-table-wrapper">
        <div class="master-table-container">
            <div class="master-table-card">
                <div class="master-table-header">
                    <div class="header-content">
                        <div class="table-title-section">
                            <h2 class="table-title">Notifications Center</h2>
                            <div class="title-accent"></div>
                        </div>
                        <div class="header-actions-group">
                            <div class="search-container">
                                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                                <input type="text" id="dior-notif-search-input" placeholder="Search records..." aria-label="Search box" class="search-input" onkeyup="diorFilterNotif()">
                            </div>
                            <div class="action-buttons">
                                <button type="button" aria-label="Add new record" class="action-btn action-btn-primary dior-ic-54410f9b78">
                                    <i class="fa-solid fa-plus"></i>
                                </button>
                                <button type="button" aria-label="Export to CSV" class="action-btn action-btn-success" title="Export to CSV" onclick="diorDownloadNotifCSV()">
                                    <i class="fa-solid fa-file-arrow-down"></i>
                                </button>
                                <button type="button" aria-label="Refresh data" class="action-btn action-btn-info" title="Refresh Page" onclick="window.location.reload()">
                                    <i class="fa-solid fa-rotate-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-content">
                    <table class="master-modern-table" id="dior-notif-table">
                        <thead>
                            <tr>
                                <th class="dior-ic-3fa4d8d717">
                                    <input type="checkbox" class="dior-ic-52ff4d551f">
                                </th>
                                <th>TITLE <i class="fa-solid fa-sort"></i></th>
                                <th>MESSAGE <i class="fa-solid fa-sort"></i></th>
                                <th>TYPE <i class="fa-solid fa-sort"></i></th>
                                <th>DATE <i class="fa-solid fa-sort"></i></th>
                                <th>TIME <i class="fa-solid fa-sort"></i></th>
                                <th>STATUS <i class="fa-solid fa-sort"></i></th>
                                <th>ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody id="dior-notif-tbody">
                            <?php
                            $notif_mock = [
                                ['Appointment Reminder', 'You have an appointment with Dr. Smith tomorrow at', 'Reminder', '#F59E0B', '#FEF3C7', 'Nov 25, 2024', '09:00 AM', 'Unread', '#EF4444', '#FEE2E2'],
                                ['Lab Report Ready', 'Your blood test results are now available.', 'Info', '#3B82F6', '#DBEAFE', 'Nov 24, 2024', '02:30 PM', 'Unread', '#EF4444', '#FEE2E2'],
                                ['Vaccination Due', 'Flu shot is due next week.', 'Alert', '#EF4444', '#FEE2E2', 'Nov 23, 2024', '11:00 AM', 'Read', '#10B981', '#D1FAE5'],
                                ['Bill Payment', 'Invoice #INV-2024-001 is pending payment.', 'Alert', '#EF4444', '#FEE2E2', 'Nov 22, 2024', '10:00 AM', 'Read', '#10B981', '#D1FAE5'],
                                ['Health Tip', 'Drink at least 8 glasses of water today.', 'Info', '#3B82F6', '#DBEAFE', 'Nov 21, 2024', '08:00 AM', 'Read', '#10B981', '#D1FAE5'],
                                ['System Maintenance', 'System will be down for maintenance on Sunday 2 AM', 'Info', '#3B82F6', '#DBEAFE', 'Nov 20, 2024', '05:00 PM', 'Read', '#10B981', '#D1FAE5'],
                                ['Prescription Refill', 'Your prescription for Metformin is running low.', 'Reminder', '#F59E0B', '#FEF3C7', 'Nov 19, 2024', '09:00 AM', 'Read', '#10B981', '#D1FAE5'],
                                ['Welcome', 'Welcome to MediDash Patient Portal!', 'Info', '#3B82F6', '#DBEAFE', 'Nov 1, 2024', '10:00 AM', 'Read', '#10B981', '#D1FAE5']
                            ];
                            foreach ($notif_mock as $nm):
                            ?>
                            <tr>
                                <td><input type="checkbox" class="dior-ic-52ff4d551f"></td>
                                <td><span class="cell-text dior-ic-794116ec9b"><?php echo esc_html($nm[0]); ?></span></td>
                                <td><span class="cell-text dior-ic-794116ec9b"><?php echo esc_html($nm[1]); ?></span></td>
                                <td>
                                    <div class="cell-content">
                                        <div class="dior-dyn-status dior-dyn-bg-<?php echo esc_attr(sanitize_html_class(ltrim($nm[4], '#'))); ?> dior-dyn-color-<?php echo esc_attr(sanitize_html_class(ltrim($nm[3], '#'))); ?>">
                                            <?php echo esc_html($nm[2]); ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="cell-content cell-icon-text">
                                        <i class="fa-regular fa-calendar cell-icon dior-ic-d53ea48df0"></i>
                                        <span class="cell-text"><?php echo esc_html($nm[5]); ?></span>
                                    </div>
                                </td>
                                <td><span class="cell-text dior-ic-794116ec9b"><?php echo esc_html($nm[6]); ?></span></td>
                                <td>
                                    <div class="cell-content">
                                        <div class="dior-dyn-status dior-dyn-bg-<?php echo esc_attr(sanitize_html_class(ltrim($nm[9], '#'))); ?> dior-dyn-color-<?php echo esc_attr(sanitize_html_class(ltrim($nm[8], '#'))); ?>">
                                            <?php echo esc_html($nm[7]); ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="cell-actions">
                                        <button type="button" class="action-icon-btn edit-btn" title="Edit Record"><i class="fa-solid fa-pen"></i></button>
                                        <button type="button" class="action-icon-btn delete-btn" title="Delete Record"><i class="fa-regular fa-trash-can"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="master-table-footer">
                    <span class="page-count" id="dior-notif-page-count">0 selected / <?php echo count($notif_mock); ?> total</span>
                    
                    <div class="master-pagination" id="dior-notif-pagination">
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</section>
