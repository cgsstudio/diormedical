/**
 * DIOR Dashboard — Static Table Interactions
 * Keeps the existing dashboard UI intact while adding reliable:
 * - Doctor table pagination/search
 * - Edit modal + row update
 * - Delete row
 * - Bulk delete
 * - Pagination refresh after edits/deletes
 */
(function () {
    'use strict';

    var PAGE_SIZE = 5;

    function getRows(table) {
        return Array.prototype.slice.call(table.querySelectorAll('tbody > tr'));
    }

    function getSearchInput(table) {
        var card = table.closest('.view-appointment-card, .dior-box, .dior-card, .dior-tab-panel');
        return card ? card.querySelector('.va-search-box input, .dior-search-input') : null;
    }

    function getActiveRows(table) {
        var input = getSearchInput(table);
        var query = input ? input.value.trim().toLowerCase() : '';

        return getRows(table).filter(function (row) {
            if (!query) return true;
            return row.innerText.toLowerCase().indexOf(query) !== -1;
        });
    }

    function getPaginationHost(table) {
        var card = table.closest('.view-appointment-card');
        if (!card) return null;

        var host = card.querySelector('.va-footer');
        if (!host) {
            host = card.querySelector('.dior-static-pagination');
        }
        if (!host) {
            host = document.createElement('div');
            host.className = 'dior-static-pagination';
            card.appendChild(host);
        }
        host.classList.add('dior-static-pagination');
        return host;
    }

    function updateSelectionCount(table, total) {
        var card = table.closest('.view-appointment-card');
        if (!card) return;

        var info = card.querySelector('.va-pagination-text, .va-table-stats');
        if (!info) return;

        var selected = table.querySelectorAll('tbody .va-checkbox:checked').length;
        info.innerHTML = selected + ' selected / ' + total + ' total';
    }

    function renderTable(table, requestedPage) {
        if (!table || !table.querySelector('tbody')) return;

        var rows = getRows(table);
        var activeRows = getActiveRows(table);
        var total = activeRows.length;
        var totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

        var state = table._diorStaticPagination || { page: 1 };
        state.page = Math.max(1, Math.min(parseInt(requestedPage || state.page, 10) || 1, totalPages));
        table._diorStaticPagination = state;

        rows.forEach(function (row) {
            row.style.display = 'none';
        });

        var start = (state.page - 1) * PAGE_SIZE;
        var end = Math.min(start + PAGE_SIZE, total);

        activeRows.slice(start, end).forEach(function (row) {
            row.style.display = '';
        });

        var host = getPaginationHost(table);
        if (!host) return;

        if (total <= PAGE_SIZE) {
            host.style.display = 'none';
        } else {
            host.style.display = 'flex';

            var html = '';
            html += '<button type="button" class="va-page-btn" data-static-page="' + (state.page - 1) + '" ' + (state.page === 1 ? 'disabled' : '') + ' aria-label="Previous page"><i class="fa-solid fa-chevron-left"></i></button>';

            for (var page = 1; page <= totalPages; page++) {
                html += '<button type="button" class="va-page-btn ' + (page === state.page ? 'active' : '') + '" data-static-page="' + page + '">' + page + '</button>';
            }

            html += '<button type="button" class="va-page-btn" data-static-page="' + (state.page + 1) + '" ' + (state.page === totalPages ? 'disabled' : '') + ' aria-label="Next page"><i class="fa-solid fa-chevron-right"></i></button>';

            host.innerHTML =
                '<div class="va-pagination-text">Showing <strong>' +
                (total ? start + 1 : 0) +
                '</strong> to <strong>' +
                end +
                '</strong> of <strong>' +
                total +
                '</strong> entries</div>' +
                '<div class="va-pagination-nav">' + html + '</div>';

            host.querySelectorAll('[data-static-page]').forEach(function (button) {
                button.addEventListener('click', function () {
                    if (button.disabled) return;
                    renderTable(table, parseInt(button.getAttribute('data-static-page'), 10));
                });
            });
        }

        updateSelectionCount(table, total);
    }

    function findEditableValueCell(cell) {
        var target = cell.querySelector('.va-user-name, .cell-text, .status-cell-text, .notes-text');
        return target || null;
    }

    function readCellValue(cell) {
        var target = findEditableValueCell(cell);
        return target ? target.textContent.trim() : cell.textContent.trim();
    }

    function writeCellValue(cell, value) {
        var target = findEditableValueCell(cell);

        if (target) {
            target.textContent = value;
            return;
        }

        var nodes = Array.prototype.slice.call(cell.childNodes);
        var textNodes = nodes.filter(function (node) {
            return node.nodeType === Node.TEXT_NODE && node.textContent.trim() !== '';
        });

        if (textNodes.length) {
            textNodes[0].textContent = ' ' + value;
            textNodes.slice(1).forEach(function (node) {
                node.textContent = '';
            });
            return;
        }

        cell.textContent = value;
    }

    function createModal() {
        var existing = document.getElementById('dior-static-edit-modal');
        if (existing) return existing;

        var modal = document.createElement('div');
        modal.id = 'dior-static-edit-modal';
        modal.className = 'dior-static-edit-modal';
        modal.innerHTML =
            '<div class="dior-static-edit-dialog" role="dialog" aria-modal="true" aria-labelledby="dior-static-edit-title">' +
                '<div class="dior-static-edit-header">' +
                    '<h3 id="dior-static-edit-title">Edit Record</h3>' +
                    '<button type="button" class="dior-static-edit-close" data-edit-close aria-label="Close">&times;</button>' +
                '</div>' +
                '<form id="dior-static-edit-form">' +
                    '<div class="dior-static-edit-fields"></div>' +
                    '<div class="dior-static-edit-footer">' +
                        '<button type="submit" class="dior-static-submit">Save</button>' +
                        '<button type="button" class="dior-static-cancel" data-edit-close>Close</button>' +
                    '</div>' +
                '</form>' +
            '</div>';

        document.body.appendChild(modal);

        modal.addEventListener('click', function (event) {
            if (event.target === modal || event.target.closest('[data-edit-close]')) {
                closeModal();
            }
        });

        modal.querySelector('#dior-static-edit-form').addEventListener('submit', function (event) {
            event.preventDefault();

            var row = modal._editRow;
            if (!row) return;

            var fields = modal.querySelectorAll('[data-edit-index]');
            fields.forEach(function (input) {
                var index = parseInt(input.getAttribute('data-edit-index'), 10);
                var cells = row.querySelectorAll('td');
                if (cells[index]) writeCellValue(cells[index], input.value.trim());
            });

            closeModal();

            var table = row.closest('table');
            if (table && table._diorStaticPagination) {
                renderTable(table, table._diorStaticPagination.page);
            }

            Swal.fire({
                title: 'Success!',
                text: 'Record has been updated successfully.',
                icon: 'success',
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true
            });
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && modal.classList.contains('is-open')) {
                closeModal();
            }
        });

        return modal;
    }

    function openModal(row) {
        var table = row.closest('table');
        if (!table) return;

        var modal = createModal();
        var headers = Array.prototype.slice.call(table.querySelectorAll('thead th'));
        var cells = Array.prototype.slice.call(row.querySelectorAll('td'));
        var fieldsWrap = modal.querySelector('.dior-static-edit-fields');

        fieldsWrap.innerHTML = '';

        cells.forEach(function (cell, index) {
            if (!headers[index]) return;
            if (cell.querySelector('input[type="checkbox"]')) return;
            if (cell.querySelector('.va-row-actions, .cell-actions')) return;

            var label = headers[index].textContent.replace(/\s+/g, ' ').trim();
            if (!label || label.toLowerCase() === 'actions') return;

            var value = readCellValue(cell);
            var field = document.createElement('div');
            field.className = 'dior-static-edit-field';
            field.innerHTML =
                '<label>' + escapeHtml(label) + '</label>' +
                '<input type="text" data-edit-index="' + index + '" value="' + escapeHtml(value) + '" autocomplete="off">';

            fieldsWrap.appendChild(field);
        });

        modal._editRow = row;
        modal.classList.add('is-open');

        var firstInput = fieldsWrap.querySelector('input');
        if (firstInput) {
            setTimeout(function () {
                firstInput.focus();
                firstInput.select();
            }, 30);
        }
    }

    function closeModal() {
        var modal = document.getElementById('dior-static-edit-modal');
        if (modal) {
            modal.classList.remove('is-open');
            modal._editRow = null;
        }
    }

    function escapeHtml(value) {
        return String(value).replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char];
        });
    }

    function isTrashButton(button) {
        return !!button.querySelector('.fa-trash, .fa-trash-can, .fa-trash-alt, .fa-regular.fa-trash-can');
    }

    function deleteRow(button) {
        var row = button.closest('tr');
        if (!row) return;

        Swal.fire({
            title: 'Are you sure?',
            text: 'You want to delete this record?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#EF4444',
            cancelButtonColor: '#64748B',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel'
        }).then(function (result) {
            if (result.isConfirmed) {
                var table = row.closest('table');
                row.remove();

                if (table) {
                    var nextPage = table._diorStaticPagination ? table._diorStaticPagination.page : 1;
                    renderTable(table, nextPage);
                }

                Swal.fire({
                    title: 'Deleted!',
                    text: 'Record has been deleted successfully.',
                    icon: 'success',
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true
                });
            }
        });
    }

    function bindDoctorTables() {
        document.querySelectorAll('.va-table').forEach(function (table) {
            renderTable(table, table._diorStaticPagination ? table._diorStaticPagination.page : 1);
        });
    }

    function bindSearch() {
        document.addEventListener('input', function (event) {
            var input = event.target;
            if (!input.matches('.va-search-box input, .dior-search-input')) return;

            var table = input.closest('.view-appointment-card, .dior-box, .dior-card, .dior-tab-panel');
            if (!table) return;

            var target = table.querySelector('.va-table');
            if (target) renderTable(target, 1);
        });
    }

    document.addEventListener('click', function (event) {
        var editButton = event.target.closest('.va-btn-edit, .action-icon-btn.edit-btn');
        if (editButton && !editButton.matches('.dior-mark-notification-read') && editButton.querySelector('.fa-pen')) {
            event.preventDefault();
            event.stopPropagation();
            var editRow = editButton.closest('tr');
            if (editRow) openModal(editRow);
            return;
        }

        var deleteButton = event.target.closest('.va-btn-delete, .action-icon-btn.delete-btn');
        if (deleteButton && isTrashButton(deleteButton)) {
            event.preventDefault();
            event.stopPropagation();
            deleteRow(deleteButton);
            return;
        }

        var bulkDelete = event.target.closest('#ap-bulk-delete');
        if (bulkDelete) {
            event.preventDefault();
            var bulkTable = bulkDelete.closest('.view-appointment-card') ? bulkDelete.closest('.view-appointment-card').querySelector('.va-table') : null;
            if (!bulkTable) return;

            var selected = bulkTable.querySelectorAll('tbody .va-checkbox:checked');
            if (!selected.length) return;

            Swal.fire({
                title: 'Are you sure?',
                text: 'You want to delete ' + selected.length + ' selected records?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#EF4444',
                cancelButtonColor: '#64748B',
                confirmButtonText: 'Yes, delete them!',
                cancelButtonText: 'Cancel'
            }).then(function (result) {
                if (result.isConfirmed) {
                    selected.forEach(function (checkbox) {
                        var row = checkbox.closest('tr');
                        if (row) row.remove();
                    });

                    if (bulkTable._diorStaticPagination) {
                        renderTable(bulkTable, bulkTable._diorStaticPagination.page);
                    } else {
                        renderTable(bulkTable, 1);
                    }

                    Swal.fire({
                        title: 'Deleted!',
                        text: selected.length + ' records have been deleted successfully.',
                        icon: 'success',
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true
                    });
                }
            });
        }
    });

    document.addEventListener('change', function (event) {
        if (!event.target.matches('.va-table thead .va-checkbox')) return;

        var table = event.target.closest('table');
        if (!table) return;

        table.querySelectorAll('tbody .va-checkbox').forEach(function (checkbox) {
            checkbox.checked = event.target.checked;
        });

        updateSelectionCount(table, getActiveRows(table).length);
    });

    bindSearch();

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bindDoctorTables);
    } else {
        bindDoctorTables();
    }

    // Dashboard tabs are injected/activated dynamically; initialize new tables automatically.
    if (window.MutationObserver) {
        var observer = new MutationObserver(function () {
            document.querySelectorAll('.va-table').forEach(function (table) {
                if (!table._diorStaticPagination) {
                    renderTable(table, 1);
                }
            });
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }
})();
