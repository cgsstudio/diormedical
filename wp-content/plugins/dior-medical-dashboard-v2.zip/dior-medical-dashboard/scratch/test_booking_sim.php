<?php
require_once 'c:/xampp/htdocs/diormedical/wp-load.php';
require_once 'c:/xampp/htdocs/diormedical/wp-content/plugins/dior-medical-dashboard/dior-medical-dashboard.php';

// Test booking as User 12 (Test one)
wp_set_current_user(12);

$_POST = [
    'action' => 'dior_patient_book_appointment',
    'nonce' => wp_create_nonce('dior_portal_nonce'),
    'doctorId' => 1695,
    'doctor_name' => 'Dr. James Chen, DO',
    'date' => date('Y-m-d', strtotime('+1 day')),
    'time' => '10:00 AM',
    'condition' => 'Urgent Care Telehealth',
    'notes' => 'Testing appointment booking',
    'name' => 'Test one',
    'email' => 'test@gmail.com',
    'phone' => '(555) 123-4567'
];

echo "Simulating booking request...\n";
try {
    // Call Dior_Appointment_Service::book_appointment directly
    $result = Dior_Appointment_Service::book_appointment([
        'patient_id'     => 12,
        'doctor_id'      => 1695,
        'doctor_user_id' => 6,
        'provider'       => 'Dr. James Chen, DO',
        'condition'      => 'Urgent Care Telehealth',
        'visit_type'     => 'Video Visit (HD)',
        'appt_date'      => date('Y-m-d', strtotime('+1 day')),
        'appt_time'      => '10:00 AM',
        'join_url'       => 'https://zoom.us/join',
        'payment_status' => 'Paid',
        'notes'          => 'Testing appointment booking'
    ]);

    if (is_wp_error($result)) {
        echo "ERROR: " . $result->get_error_message() . "\n";
    } else {
        echo "SUCCESS: Booked appointment with ID: " . $result . "\n";
        $apts = Dior_Patient_Portal_Data::get_patient_appointments(12);
        echo "Patient 12 total appointments: " . count($apts) . "\n";
    }
} catch (Throwable $e) {
    echo "EXCEPTION: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n";
}
