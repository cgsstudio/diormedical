<?php
require_once 'c:/xampp/htdocs/diormedical/wp-load.php';

echo "--- WPDDB_DOCTOR POSTS ---\n";
$posts = get_posts(['post_type' => 'wpddb_doctor', 'post_status' => 'any', 'numberposts' => -1]);
foreach ($posts as $p) {
    echo "Post ID: " . $p->ID . " | Title: " . $p->post_title . " | Status: " . $p->post_status . "\n";
}

echo "\n--- WP USERS (DOCTORS) ---\n";
$users = get_users();
foreach ($users as $u) {
    echo "User ID: " . $u->ID . " | Email: " . $u->user_email . " | Name: " . $u->display_name . " | Roles: " . implode(',', $u->roles) . "\n";
}

echo "\n--- DOCBOOKER TABLES ---\n";
global $wpdb;
$tables = $wpdb->get_col("SHOW TABLES LIKE '%wpddb%'");
print_r($tables);
