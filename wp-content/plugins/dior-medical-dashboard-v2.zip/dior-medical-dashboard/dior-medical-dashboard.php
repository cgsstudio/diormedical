<?php
/**
 * Plugin Name: Dior Medical - Patient Portal & Dashboard
 * Plugin URI:  https://diormedical.com
 * Description: Luxury, secure, state-of-the-art Patient Portal & Authentication System for Dior Medical Telehealth & Urgent Care.
 * Version:     2.0
 * Author:      Dior Medical Team
 * Author URI:  https://diormedical.com
 * Text Domain: dior-medical
 */

if (!defined('ABSPATH')) {
    exit;
}

define('DIOR_PORTAL_VERSION', '2.0');
define('DIOR_PORTAL_PATH', plugin_dir_path(__FILE__));
define('DIOR_PORTAL_URL', plugin_dir_url(__FILE__));

// Aliases for backwards compatibility
define('DIOR_AUTH_VERSION', DIOR_PORTAL_VERSION);
define('DIOR_AUTH_PATH', DIOR_PORTAL_PATH);
define('DIOR_AUTH_URL', DIOR_PORTAL_URL);

// ========================================
// DYNAMIC FEATURES & ENTERPRISE SERVICES (v3.0)
// ========================================

// Include core database and services layer
if (!class_exists('Dior_DB')) {
    require_once(DIOR_PORTAL_PATH . 'includes/class-dior-db.php');
}
if (!class_exists('Dior_Auth_Service')) {
    require_once(DIOR_PORTAL_PATH . 'includes/class-dior-auth-service.php');
}
if (!class_exists('Dior_Audit_Service')) {
    require_once(DIOR_PORTAL_PATH . 'includes/class-dior-audit-service.php');
}
if (!class_exists('Dior_Encounter_Service')) {
    require_once(DIOR_PORTAL_PATH . 'includes/class-dior-encounter-service.php');
}
if (!class_exists('Dior_Appointment_Service')) {
    require_once(DIOR_PORTAL_PATH . 'includes/class-dior-appointment-service.php');
}
if (!class_exists('Dior_Medical_Analytics')) {
    require_once(DIOR_PORTAL_PATH . 'includes/class-dior-analytics.php');
}
if (!class_exists('Dior_Medical_REST_API')) {
    require_once(DIOR_PORTAL_PATH . 'includes/class-dior-rest-api.php');
}
if (!class_exists('Dior_Medical_Secure_Files')) {
    require_once(DIOR_PORTAL_PATH . 'includes/class-dior-secure-files.php');
}

/**
 * Universal Dynamic Relative Notification Time Formatter
 * 
 * Accurately computes human relative time (e.g. "Just now", "15 min ago", "2 hours ago", "Yesterday at 3:15 PM", "Sep 8, 2026")
 * Supports unix timestamp integer, MySQL created_at datetime string, and intelligent regex extraction from legacy notification IDs.
 */
if (!function_exists('dior_format_notification_time')) {
    function dior_format_notification_time($notif) {
        $now = current_time('timestamp');
        $ts = null;

        if (is_array($notif)) {
            // 1. Direct timestamp
            if (!empty($notif['timestamp']) && is_numeric($notif['timestamp'])) {
                $ts = intval($notif['timestamp']);
            }
            // 2. created_at or datetime field
            elseif (!empty($notif['created_at']) && ($parsed = strtotime($notif['created_at']))) {
                $ts = $parsed;
            }
            elseif (!empty($notif['datetime']) && ($parsed = strtotime($notif['datetime']))) {
                $ts = $parsed;
            }
            // 3. Extract unix timestamp from notification ID (e.g., DN-RX-1725852000-45, NOTIF-1725852000, notif_1725852000_123, NOTIF-HIPAA-1725852000)
            elseif (!empty($notif['id']) && preg_match('/(?:DN|NOTIF|notif)[-_](?:[A-Za-z0-9]+[-_])?(\d{10})/i', $notif['id'], $matches)) {
                $val = intval($matches[1]);
                if ($val > 1500000000 && $val <= $now + 86400) {
                    $ts = $val;
                }
            }
            // 4. Check if 'time' field contains a parsable date/time string other than "Just now"
            elseif (!empty($notif['time']) && $notif['time'] !== 'Just now' && ($parsed = strtotime($notif['time']))) {
                $ts = $parsed;
            }
        } elseif (is_numeric($notif)) {
            $ts = intval($notif);
        }

        if ($ts !== null) {
            $diff = $now - $ts;
            if ($diff < 0) {
                $diff = 0;
            }
            if ($diff < 60) {
                return 'Just now';
            } elseif ($diff < 3600) {
                $mins = floor($diff / 60);
                return $mins == 1 ? '1 min ago' : $mins . ' min ago';
            } elseif ($diff < 86400) {
                $hours = floor($diff / 3600);
                return $hours == 1 ? '1 hour ago' : $hours . ' hours ago';
            } elseif ($diff < 172800) {
                return 'Yesterday at ' . date('g:i A', $ts);
            } elseif ($diff < 604800) {
                $days = floor($diff / 86400);
                return $days . ' days ago';
            } else {
                return date('M j, Y', $ts);
            }
        }

        if (is_array($notif) && !empty($notif['time'])) {
            return $notif['time'];
        }
        return 'Just now';
    }
}

// Initialize database, analytics, and secure files on plugin load
add_action('plugins_loaded', function () {
    if (class_exists('Dior_DB')) {
        Dior_DB::init();
    }
    if (class_exists('Dior_Medical_Analytics')) {
        Dior_Medical_Analytics::init();
    }
    if (class_exists('Dior_Medical_REST_API')) {
        Dior_Medical_REST_API::init();
    }
    if (class_exists('Dior_Medical_Secure_Files')) {
        Dior_Medical_Secure_Files::init();
    }
});


// Completely disable WordPress Admin Bar on all frontend portal pages
add_filter('show_admin_bar', '__return_false', 9999);
add_action('init', function () {
    if (!is_admin()) {
        show_admin_bar(false);
    }
}, 9999);
add_action('wp_head', function () {
    echo '<style id="dior-hide-adminbar-css">#wpadminbar { display: none !important; height: 0 !important; min-height: 0 !important; visibility: hidden !important; opacity: 0 !important; pointer-events: none !important; } html, body, html.elementor-html, html body.admin-bar { margin-top: 0 !important; padding-top: 0 !important; top: 0 !important; }</style>';
}, 9999);

/**
 * Patient Data Helper Class
 * Handles retrieval and persistence of patient-specific portal data
 */
class Dior_Patient_Portal_Data
{

    /**
     * Get or initialize patient profile data
     */
    public static function get_patient_profile($user_id)
    {
        $user = get_userdata($user_id);
        if (!$user)
            return [];

        // Get HIPAAtizer intake data if available
        $hipaa_intake = get_user_meta($user_id, 'dior_hipaa_intake', true);

        // Use HIPAAtizer data as primary source, fallback to user meta
        $first_name = get_user_meta($user_id, 'first_name', true) ?: $user->first_name;
        $last_name = get_user_meta($user_id, 'last_name', true) ?: $user->last_name;

        if (!empty($hipaa_intake) && is_array($hipaa_intake)) {
            $first_name = $hipaa_intake['first_name'] ?: $first_name;
            $last_name = $hipaa_intake['last_name'] ?: $last_name;
        }

        $phone = get_user_meta($user_id, 'phone', true) ?: '';
        $dob = get_user_meta($user_id, 'dob', true) ?: '';
        $gender = get_user_meta($user_id, 'gender', true) ?: '';
        $address = get_user_meta($user_id, 'address', true) ?: '';

        if (!empty($hipaa_intake) && is_array($hipaa_intake)) {
            $phone = $hipaa_intake['phone'] ?: $phone;
            $dob = $hipaa_intake['dob'] ?: $dob;
            if (!empty($hipaa_intake['address']) && !empty($hipaa_intake['city']) && !empty($hipaa_intake['state'])) {
                $address = trim($hipaa_intake['address'] . ' ' . $hipaa_intake['city'] . ', ' . $hipaa_intake['state'] . ' ' . $hipaa_intake['zip']);
            }

            // Update user meta with HIPAAtizer data for consistency
            if (!empty($hipaa_intake['phone'])) {
                update_user_meta($user_id, 'phone', $hipaa_intake['phone']);
            }
            if (!empty($hipaa_intake['dob'])) {
                update_user_meta($user_id, 'dob', $hipaa_intake['dob']);
            }
            if (!empty($address)) {
                update_user_meta($user_id, 'address', $address);
            }
        }

        $patient_id = get_user_meta($user_id, 'patient_id', true);

        if (empty($patient_id)) {
            $patient_id = 'DM-' . (10000 + ($user_id % 90000));
            update_user_meta($user_id, 'patient_id', $patient_id);
        }

        // Emergency contact - check HIPAAtizer data first
        $em_name = get_user_meta($user_id, 'emergency_name', true) ?: '';
        $em_rel = get_user_meta($user_id, 'emergency_relation', true) ?: '';
        $em_phone = get_user_meta($user_id, 'emergency_phone', true) ?: '';

        // Preferred Pharmacy
        $pharmacy_name = get_user_meta($user_id, 'preferred_pharmacy_name', true) ?: '';
        $pharmacy_address = get_user_meta($user_id, 'preferred_pharmacy_address', true) ?: '';
        $pharmacy_phone = get_user_meta($user_id, 'preferred_pharmacy_phone', true) ?: '';

        // Eligibility snapshots (Read only)
        $is_18_verified = get_user_meta($user_id, 'is_18_verified', true) ?: '';
        $pregnancy_status = get_user_meta($user_id, 'pregnancy_status', true) ?: '';
        $state_eligible = get_user_meta($user_id, 'state_eligible', true) ?: '';

        return [
            'user_id' => $user_id,
            'patient_id' => $patient_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'full_name' => trim($first_name . ' ' . $last_name) ?: $user->display_name,
            'email' => $user->user_email,
            'phone' => $phone,
            'dob' => $dob,
            'gender' => $gender,
            'address' => $address,
            'emergency_name' => $em_name,
            'emergency_relation' => $em_rel,
            'emergency_phone' => $em_phone,
            'pharmacy_name' => $pharmacy_name,
            'pharmacy_address' => $pharmacy_address,
            'pharmacy_phone' => $pharmacy_phone,
            'is_18_verified' => $is_18_verified,
            'pregnancy_status' => $pregnancy_status,
            'state_eligible' => $state_eligible,
            'has_hipaa_intake' => !empty($hipaa_intake),
            'hipaa_intake' => $hipaa_intake ?: [],
        ];
    }

    /**
     * Get patient appointments
     */
    public static function get_patient_appointments($user_id)
    {
        return Dior_Appointment_Service::get_patient_appointments($user_id);
    }

    /**
     * Get patient prescriptions & pharmacy details
     */
    public static function get_patient_prescriptions($user_id)
    {
        $prescriptions = get_user_meta($user_id, 'dior_prescriptions', true);

        if (!is_array($prescriptions)) {
            $prescriptions = [];
            update_user_meta($user_id, 'dior_prescriptions', $prescriptions);
        }

        return $prescriptions;
    }

    /**
     * Get patient payments & invoices
     */
    public static function get_patient_payments($user_id)
    {
        $payments = get_user_meta($user_id, 'dior_payments', true);

        if (!is_array($payments)) {
            $payments = [];
            update_user_meta($user_id, 'dior_payments', $payments);
        }

        return $payments;
    }

    /**
     * Get medical documents
     */
    public static function get_patient_documents($user_id)
    {
        return Dior_Medical_Secure_Files::get_patient_documents($user_id);
    }

    /**
     * Get condition-specific questionnaires
     */
    public static function get_patient_questionnaires($user_id)
    {
        $questionnaires = get_user_meta($user_id, 'dior_questionnaires', true);

        if (!is_array($questionnaires)) {
            $questionnaires = [];
            update_user_meta($user_id, 'dior_questionnaires', $questionnaires);
        }

        return $questionnaires;
    }

    /**
     * Get patient notifications
     */
    public static function get_patient_notifications($user_id)
    {
        $notifications = get_user_meta($user_id, 'dior_notifications', true);

        if (!is_array($notifications)) {
            $notifications = [];
            update_user_meta($user_id, 'dior_notifications', $notifications);
        }

        return $notifications;
    }
}

/**
 * Main Dior Medical Auth & Patient Dashboard Class
 */
class Dior_Medical_Auth
{

    public static function init()
    {
        // Disable WordPress Admin Bar for clean web-app experience
        add_filter('show_admin_bar', '__return_false');

        // Enqueue styles & scripts
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);

        // Shortcodes
        add_shortcode('dior_login_form', [__CLASS__, 'render_login_form']);
        add_shortcode('dior_registration_form', [__CLASS__, 'render_registration_form']);
        add_shortcode('dior_patient_dashboard', [__CLASS__, 'render_patient_dashboard']);
        add_shortcode('dior_book_visit_page', [__CLASS__, 'render_book_visit_page']);

        // Redirect non-logged-in users from private dashboards to login page
        add_action('template_redirect', [__CLASS__, 'check_dashboard_access_redirect']);

        // Auth AJAX Endpoints
        add_action('wp_ajax_nopriv_dior_ajax_login', [__CLASS__, 'handle_login']);
        add_action('wp_ajax_dior_ajax_login', [__CLASS__, 'handle_login']);

        add_action('wp_ajax_nopriv_dior_ajax_register', [__CLASS__, 'handle_register']);
        add_action('wp_ajax_dior_ajax_register', [__CLASS__, 'handle_register']);

        add_action('wp_ajax_dior_ajax_logout', [__CLASS__, 'handle_logout']);
        add_action('wp_ajax_nopriv_dior_ajax_logout', [__CLASS__, 'handle_logout']);

        // Patient Dashboard AJAX Endpoints (Logged-in & Public Booking)
        add_action('wp_ajax_dior_patient_save_profile', [__CLASS__, 'ajax_save_profile']);
        add_action('wp_ajax_dior_patient_change_password', [__CLASS__, 'ajax_change_password']);
        add_action('wp_ajax_dior_patient_book_appointment', [__CLASS__, 'ajax_book_appointment']);
        add_action('wp_ajax_nopriv_dior_patient_book_appointment', [__CLASS__, 'ajax_book_appointment']);
        add_action('wp_ajax_dior_patient_book', [__CLASS__, 'ajax_book_appointment']);
        add_action('wp_ajax_nopriv_dior_patient_book', [__CLASS__, 'ajax_book_appointment']);
        add_action('wp_ajax_dior_patient_reschedule_appointment', [__CLASS__, 'ajax_reschedule_appointment']);
        add_action('wp_ajax_dior_patient_cancel_appointment', [__CLASS__, 'ajax_cancel_appointment']);
        add_action('wp_ajax_dior_patient_submit_questionnaire', [__CLASS__, 'ajax_submit_questionnaire']);
        add_action('wp_ajax_dior_patient_pay_invoice', [__CLASS__, 'ajax_pay_invoice']);
        add_action('wp_ajax_dior_patient_mark_notification_read', [__CLASS__, 'ajax_mark_notification_read']);
        add_action('wp_ajax_dior_patient_mark_all_notifications_read', [__CLASS__, 'ajax_mark_all_notifications_read']);
        add_action('wp_ajax_dior_patient_update_pharmacy', [__CLASS__, 'ajax_update_pharmacy']);
        add_action('wp_ajax_dior_patient_check_intake_status', [__CLASS__, 'ajax_check_intake_status']);

        // DocBooker Live Booking Synchronization Hook
        add_action('wpddb_booking_created', [__CLASS__, 'on_docbooker_booking_created'], 10, 1);

        // HIPAAtizer Webhook Receiver (no-priv so HIPAAtizer server can POST)
        add_action('wp_ajax_nopriv_dior_hipaa_webhook', [__CLASS__, 'ajax_hipaa_webhook']);
        add_action('wp_ajax_dior_hipaa_webhook', [__CLASS__, 'ajax_hipaa_webhook']);

        // REST API: /wp-json/dior/v1/hipaa-webhook
        add_action('rest_api_init', function () {
            register_rest_route('dior/v1', '/hipaa-webhook', [
                'methods' => 'POST',
                'callback' => [__CLASS__, 'rest_hipaa_webhook'],
                'permission_callback' => '__return_true', // HIPAAtizer server posts here
            ]);
        });

        // Auto-create pages on init & admin_init
        add_action('init', [__CLASS__, 'ensure_pages_exist']);
        add_action('admin_init', [__CLASS__, 'ensure_pages_exist']);

        // Role-based Login Redirect (Doctors -> /doctor-dashboard/, Patients -> /patient-dashboard/)
        add_filter('login_redirect', [__CLASS__, 'custom_login_redirect'], 99, 3);

        // Template Canvas Override (Elementor Canvas mode)
        add_filter('template_include', [__CLASS__, 'override_page_template'], 99);
    }

    /**
     * Enqueue CSS & JS
     */
    public static function enqueue_assets()
    {

        // Analytics dashboard (NEW)
        if (is_admin() && current_user_can('manage_options')) {
            wp_enqueue_script(
                'chartjs',
                'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js',
                [],
                '3.9.1',
                true
            );

            wp_enqueue_script(
                'dior-analytics',
                DIOR_PORTAL_URL . 'assets/js/dior-analytics.js',
                ['jquery', 'chartjs'],
                DIOR_PORTAL_VERSION,
                true
            );

            wp_enqueue_style(
                'dior-analytics-css',
                DIOR_PORTAL_URL . 'assets/css/dior-analytics.css',
                [],
                DIOR_PORTAL_VERSION
            );

            wp_localize_script('dior-analytics', 'diorAnalyticsData', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('dior_analytics_nonce'),
            ]);
        }
        // Font Awesome for modern icons
        wp_enqueue_style(
            'font-awesome-6',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
            [],
            '6.5.1'
        );

        // Auth Styles
        wp_enqueue_style(
            'dior-auth-css',
            DIOR_AUTH_URL . 'assets/css/dior-auth.css',
            [],
            DIOR_PORTAL_VERSION
        );

        $css_ver = file_exists(DIOR_PORTAL_PATH . 'assets/css/dior-dashboard.css') ? filemtime(DIOR_PORTAL_PATH . 'assets/css/dior-dashboard.css') : DIOR_PORTAL_VERSION;
        $js_ver = file_exists(DIOR_PORTAL_PATH . 'assets/js/dior-dashboard.js') ? filemtime(DIOR_PORTAL_PATH . 'assets/js/dior-dashboard.js') : DIOR_PORTAL_VERSION;

        // Dashboard Styles
        wp_enqueue_style(
            'dior-dashboard-css',
            DIOR_PORTAL_URL . 'assets/css/dior-dashboard.css',
            ['dior-auth-css'],
            $css_ver
        );

        // Auth JS
        wp_enqueue_script(
            'dior-auth-js',
            DIOR_AUTH_URL . 'assets/js/dior-auth.js',
            ['jquery'],
            DIOR_PORTAL_VERSION,
            true
        );

        wp_enqueue_script(
            'html2pdf',
            'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js',
            [],
            '0.10.1',
            true
        );

        // Dashboard JS
        wp_enqueue_script(
            'dior-dashboard-js',
            DIOR_PORTAL_URL . 'assets/js/dior-dashboard.js',
            ['jquery'],
            $js_ver,
            true
        );

        // Doctor Dashboard JS
        if (file_exists(DIOR_PORTAL_PATH . 'assets/js/dior-doctor.js')) {
            wp_enqueue_script(
                'dior-doctor-js',
                DIOR_PORTAL_URL . 'assets/js/dior-doctor.js',
                ['jquery'],
                filemtime(DIOR_PORTAL_PATH . 'assets/js/dior-doctor.js'),
                true
            );
        }

        $portal_url = home_url('/patient-dashboard/');
        $login_url = home_url('/diro-login/');
        $reg_url = home_url('/diro-registration/');
        $current_user_id = get_current_user_id();
        $hipaa_intake_data = $current_user_id ? get_user_meta($current_user_id, 'dior_hipaa_intake', true) : null;
        $profile_data = $current_user_id ? Dior_Patient_Portal_Data::get_patient_profile($current_user_id) : null;

        $localize_data = [
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => esc_url_raw(rest_url()),
            'rest_nonce' => wp_create_nonce('wp_rest'),
            'nonce' => wp_create_nonce('dior_portal_nonce'),
            'auth_nonce' => wp_create_nonce('dior_auth_nonce'),
            'portal_url' => $portal_url,
            'login_url' => $login_url,
            'register_url' => $reg_url,
            'home_url' => home_url('/'),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
            'current_user_id' => $current_user_id,
            'has_hipaa_intake' => !empty($hipaa_intake_data),
            'hipaa_intake' => $hipaa_intake_data ?: [],
            'patient_profile' => $profile_data ?: []
        ];

        wp_localize_script('dior-auth-js', 'dior_auth_vars', $localize_data);
        wp_localize_script('dior-dashboard-js', 'dior_vars', $localize_data);
        if (file_exists(DIOR_PORTAL_PATH . 'assets/js/dior-doctor.js')) {
            wp_localize_script('dior-doctor-js', 'dior_doctor_vars', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('dior_doctor_nonce'),
                'portal_nonce' => wp_create_nonce('dior_portal_nonce'),
                'current_user_id' => $current_user_id
            ]);
        }
    }

    /**
     * Ensure /diro-login/, /diro-registration/, /patient-dashboard/, and /book-visit/ pages exist
     */
    public static function ensure_pages_exist()
    {
        // Patient Dashboard Page (/patient-dashboard/)
        $dashboard_page = get_page_by_path('patient-dashboard');
        if (!$dashboard_page) {
            $old_portal = get_page_by_path('patient-portal');
            if ($old_portal) {
                wp_update_post([
                    'ID' => $old_portal->ID,
                    'post_name' => 'patient-dashboard'
                ]);
                $dash_id = $old_portal->ID;
            } else {
                $dash_id = wp_insert_post([
                    'post_title' => 'Patient Dashboard',
                    'post_name' => 'patient-dashboard',
                    'post_content' => '[dior_patient_dashboard]',
                    'post_status' => 'publish',
                    'post_type' => 'page'
                ]);
            }
        } else {
            $dash_id = $dashboard_page->ID;
        }
        if (!empty($dash_id) && !is_wp_error($dash_id)) {
            update_post_meta($dash_id, '_wp_page_template', 'elementor_canvas');
        }

        // Login Page (/diro-login/)
        $login_page = get_page_by_path('diro-login');
        if (!$login_page) {
            $old_login = get_page_by_path('login');
            if ($old_login) {
                wp_update_post([
                    'ID' => $old_login->ID,
                    'post_name' => 'diro-login'
                ]);
                $login_id = $old_login->ID;
            } else {
                $login_id = wp_insert_post([
                    'post_title' => 'Patient Login',
                    'post_name' => 'diro-login',
                    'post_content' => '[dior_login_form]',
                    'post_status' => 'publish',
                    'post_type' => 'page'
                ]);
            }
        } else {
            $login_id = $login_page->ID;
        }
        if (!empty($login_id) && !is_wp_error($login_id)) {
            update_post_meta($login_id, '_wp_page_template', 'elementor_canvas');
        }

        // Registration Page (/diro-registration/)
        $reg_page = get_page_by_path('diro-registration');
        if (!$reg_page) {
            $old_reg = get_page_by_path('register');
            if ($old_reg) {
                wp_update_post([
                    'ID' => $old_reg->ID,
                    'post_name' => 'diro-registration'
                ]);
                $reg_id = $old_reg->ID;
            } else {
                $reg_id = wp_insert_post([
                    'post_title' => 'Patient Registration',
                    'post_name' => 'diro-registration',
                    'post_content' => '[dior_registration_form]',
                    'post_status' => 'publish',
                    'post_type' => 'page'
                ]);
            }
        } else {
            $reg_id = $reg_page->ID;
        }
        if (!empty($reg_id) && !is_wp_error($reg_id)) {
            update_post_meta($reg_id, '_wp_page_template', 'elementor_canvas');
        }

        // Book Visit & Medical Intake Page (/book-visit/)
        $book_page = get_page_by_path('book-visit');
        if (!$book_page) {
            $book_id = wp_insert_post([
                'post_title' => 'Book Appointment & Medical Intake',
                'post_name' => 'book-visit',
                'post_content' => '[dior_book_visit_page]',
                'post_status' => 'publish',
                'post_type' => 'page'
            ]);
        } else {
            $book_id = $book_page->ID;
            if (strpos($book_page->post_content, 'dior_book_visit_page') === false) {
                wp_update_post([
                    'ID' => $book_id,
                    'post_content' => '[dior_book_visit_page]'
                ]);
            }
        }
        if (!empty($book_id) && !is_wp_error($book_id)) {
            update_post_meta($book_id, '_wp_page_template', 'elementor_canvas');
        }

        // New DocBooker Integration Page (/docbooker-booking/)
        $docbooker_page = get_page_by_path('docbooker-booking');
        if (!$docbooker_page) {
            $docbooker_id = wp_insert_post([
                'post_title' => 'DocBooker Booking',
                'post_name' => 'docbooker-booking',
                'post_content' => '[wpddb_doctor_booking_form]',
                'post_status' => 'publish',
                'post_type' => 'page'
            ]);
        } else {
            $docbooker_id = $docbooker_page->ID;
            if (strpos($docbooker_page->post_content, 'wpddb_doctor_booking_form') === false) {
                wp_update_post([
                    'ID' => $docbooker_id,
                    'post_content' => '[wpddb_doctor_booking_form]'
                ]);
            }
        }
        if (!empty($docbooker_id) && !is_wp_error($docbooker_id)) {
            update_post_meta($docbooker_id, '_wp_page_template', 'elementor_canvas');
        }
    }

    /**
     * Override Page Template to Elementor Canvas (or built-in full-screen canvas)
     */
    public static function override_page_template($template)
    {
        if (is_admin()) {
            return $template;
        }

        $is_portal = false;
        if (is_page(['patient-dashboard', 'diro-login', 'diro-registration', 'patient-portal', 'book-visit'])) {
            $is_portal = true;
        } else if (is_singular('page')) {
            global $post;
            if (
                $post && (
                    has_shortcode($post->post_content, 'dior_patient_dashboard') ||
                    has_shortcode($post->post_content, 'dior_login_form') ||
                    has_shortcode($post->post_content, 'dior_registration_form') ||
                    has_shortcode($post->post_content, 'dior_book_visit_page') ||
                    in_array($post->post_name, ['patient-dashboard', 'diro-login', 'diro-registration', 'patient-portal', 'book-visit'])
                )
            ) {
                $is_portal = true;
            }
        }

        if ($is_portal) {
            // 1. Elementor Canvas Template if available
            if (defined('ELEMENTOR_PATH')) {
                $canvas = ELEMENTOR_PATH . 'modules/page-templates/templates/canvas.php';
                if (file_exists($canvas)) {
                    return $canvas;
                }
            }
            // 2. Built-in Canvas Template
            $custom_canvas = DIOR_PORTAL_PATH . 'templates/canvas-template.php';
            if (file_exists($custom_canvas)) {
                return $custom_canvas;
            }
        }

        return $template;
    }

    /**
     * Shortcode: [dior_book_visit_page]
     * Dedicated Luxury Full-Page Medical Intake & Booking Page with HIPAAtizer Form
     */
    public static function render_book_visit_page($atts = [])
    {
        $logo_url = self::get_logo_url();
        $user_id = get_current_user_id();
        $profile = is_user_logged_in() ? Dior_Patient_Portal_Data::get_patient_profile($user_id) : null;
        $dashboard_url = home_url('/patient-dashboard/');

        ob_start();
        ?>
        <div class="dior-book-page-wrap" id="dior-book-page-app">
            <!-- Top Navigation Header -->
            <header class="dior-book-topbar">
                <div class="dior-book-topbar-inner">
                    <div class="dior-book-brand-side">
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="dior-book-logo-link">
                            <img src="<?php echo esc_url($logo_url); ?>" alt="Dior Medical" class="dior-book-logo">
                        </a>
                        <span class="dior-book-divider">|</span>
                        <span class="dior-book-badge"><i class="fa-solid fa-shield-halved"></i> HIPAA Verified Intake</span>
                    </div>

                    <div class="dior-book-user-side">
                        <?php if (is_user_logged_in() && $profile): ?>
                            <div class="dior-book-patient-info">
                                <span class="dior-book-patient-name"><i class="fa-regular fa-user"></i>
                                    <?php echo esc_html($profile['full_name']); ?></span>
                                <span class="dior-book-patient-id"><?php echo esc_html($profile['patient_id']); ?></span>
                            </div>
                        <?php endif; ?>
                        <a href="<?php echo esc_url($dashboard_url); ?>" class="dior-btn-back-dashboard">
                            <i class="fa-solid fa-arrow-left"></i> <span>Back to Dashboard</span>
                        </a>
                    </div>
                </div>
            </header>

            <!-- Main Booking Container -->
            <main class="dior-book-main">
                <div class="dior-book-container">
                    <!-- Page Breadcrumbs & Intro Header -->
                    <div class="dior-book-header-box">
                        <div class="dior-book-title-row">
                            <div>
                                <h1>Schedule Telehealth Consultation</h1>
                                <p>Complete your HIPAA medical intake form below to connect with a board-certified physician.
                                </p>
                            </div>
                            <div class="dior-book-security-badge">
                                <i class="fa-solid fa-lock"></i> 256-Bit Encrypted &amp; HIPAA Compliant
                            </div>
                        </div>
                    </div>

                    <!-- Main Form Card -->
                    <div class="dior-book-card">
                        <div id="dior-custom-booking-wizard">
                            <div class="booking-step" id="step-1-treatment">
                                <h3>Select Treatment / Service</h3>
                                <div id="treatments-list" class="dior-grid-options">
                                    <p>Loading treatments...</p>
                                </div>
                            </div>

                            <div class="booking-step" id="step-2-doctor" style="display:none;">
                                <h3>Select Your Doctor</h3>
                                <button type="button" class="dior-btn-back-step" onclick="diorBookingGoToStep(1)">&larr; Back to
                                    Treatments</button>
                                <div id="doctors-list" class="dior-grid-options" style="margin-top:15px;"></div>
                            </div>

                            <div class="booking-step" id="step-3-time" style="display:none;">
                                <h3>Select Date & Time</h3>
                                <button type="button" class="dior-btn-back-step" onclick="diorBookingGoToStep(2)">&larr; Back to
                                    Doctors</button>
                                <div class="dior-date-selector" style="margin-top:15px;">
                                    <input type="date" id="booking-date" class="dior-form-input"
                                        min="<?php echo date('Y-m-d'); ?>" onchange="diorFetchAvailability()">
                                </div>
                                <div id="time-slots-list" class="dior-grid-options" style="margin-top:15px;"></div>
                            </div>

                            <div class="booking-step" id="step-4-confirm" style="display:none;">
                                <h3>Confirm Your Appointment</h3>
                                <button type="button" class="dior-btn-back-step" onclick="diorBookingGoToStep(3)">&larr; Back to
                                    Time Selection</button>
                                <div id="booking-summary"
                                    style="margin-top:15px; padding: 15px; background: #f8fafc; border-radius: 8px;"></div>
                                <div style="margin-top:20px;">
                                    <button type="button" class="dior-btn-auth-primary" id="btn-confirm-booking"
                                        onclick="diorSubmitBooking()">Confirm & Book</button>
                                </div>
                                <div id="booking-message" style="margin-top:15px; font-weight:bold;"></div>
                            </div>
                        </div>
                    </div>


                    <!-- Footer Help & Info Note -->
                    <div class="dior-book-footer-note">
                        <div class="note-item"><i class="fa-solid fa-headset"></i> Need assistance? Our clinical care team is
                            available 24/7.</div>
                        <div class="note-item"><i class="fa-solid fa-prescription-bottle-medical"></i> Prescriptions are routed
                            electronically to your preferred pharmacy immediately following consultation.</div>
                    </div>
                </div>
            </main>
        </div>
        </div>

        <?php $current_user = wp_get_current_user(); ?>
        <script>
            let diorBookingState = {
                departmentId: null,
                departmentName: null,
                doctorId: null,
                doctorName: null,
                date: null,
                day: null,
                clinicId: null,
                time: null,
                patient: {
                    name: "<?php echo esc_js($profile ? $profile['full_name'] : ''); ?>",
                    email: "<?php echo esc_js($current_user->user_email); ?>",
                    phone: "<?php echo esc_js($profile ? $profile['phone'] : ''); ?>",
                    notes: ""
                }
            };

            const diorRestUrl = "<?php echo esc_url_raw(rest_url()); ?>";
            const diorAjaxUrl = "<?php echo esc_url(admin_url('admin-ajax.php')); ?>";
            const diorRestNonce = "<?php echo wp_create_nonce('wp_rest'); ?>";
            const diorPortalNonce = "<?php echo wp_create_nonce('dior_portal_nonce'); ?>";

            document.addEventListener('DOMContentLoaded', function () {
                diorFetchTreatments();
            });

            function diorBookingGoToStep(step) {
                document.querySelectorAll('.booking-step').forEach(el => el.style.display = 'none');
                document.getElementById('step-' + step + (step === 1 ? '-treatment' : (step === 2 ? '-doctor' : (step === 3 ? '-time' : '-confirm')))).style.display = 'block';
            }

            function diorFetchTreatments() {
                fetch(diorRestUrl + 'get-doctor/v1/departments')
                    .then(res => res.json())
                    .then(data => {
                        let html = '';
                        if (data && data.length) {
                            data.forEach(dept => {
                                html += `<button type="button" class="dior-grid-btn" onclick="diorSelectTreatment(${dept.id}, '${dept.name.replace(/'/g, "\\'")}')">${dept.name}</button>`;
                            });
                        } else {
                            html = '<button type="button" class="dior-grid-btn" onclick="diorSelectTreatment(1, \'Urgent Care Telehealth\')">Urgent Care Telehealth</button><button type="button" class="dior-grid-btn" onclick="diorSelectTreatment(2, \'Primary Care & General Medicine\')">Primary Care</button>';
                        }
                        document.getElementById('treatments-list').innerHTML = html;
                    })
                    .catch(() => {
                        document.getElementById('treatments-list').innerHTML = '<button type="button" class="dior-grid-btn" onclick="diorSelectTreatment(1, \'Urgent Care Telehealth\')">Urgent Care Telehealth</button><button type="button" class="dior-grid-btn" onclick="diorSelectTreatment(2, \'Primary Care & General Medicine\')">Primary Care</button>';
                    });
            }

            function diorSelectTreatment(id, name) {
                diorBookingState.departmentId = id;
                diorBookingState.departmentName = name;
                document.getElementById('doctors-list').innerHTML = '<p>Loading doctors...</p>';
                diorBookingGoToStep(2);

                fetch(diorRestUrl + 'get-doctor-by-departments/v1/' + id)
                    .then(res => res.json())
                    .then(data => {
                        let html = '';
                        if (data && data.length) {
                            data.forEach(doc => {
                                html += `<div class="dior-doctor-card-select" onclick="diorSelectDoctor(${doc.id}, '${doc.name.replace(/'/g, "\\'")}')">
                                            <h4>${doc.name}</h4>
                                            <p>${doc.speciality}</p>
                                        </div>`;
                            });
                        } else {
                            html = `<div class="dior-doctor-card-select" onclick="diorSelectDoctor(1695, 'Dr. James Chen, DO')">
                                        <h4>Dr. James Chen, DO</h4>
                                        <p>Primary Care & Urgent Care</p>
                                    </div>
                                    <div class="dior-doctor-card-select" onclick="diorSelectDoctor(1693, 'Dr. Marcus Sterling, DO')">
                                        <h4>Dr. Marcus Sterling, DO</h4>
                                        <p>Urgent Care Physician</p>
                                    </div>`;
                        }
                        document.getElementById('doctors-list').innerHTML = html;
                    })
                    .catch(() => {
                        document.getElementById('doctors-list').innerHTML = `
                            <div class="dior-doctor-card-select" onclick="diorSelectDoctor(1695, 'Dr. James Chen, DO')">
                                <h4>Dr. James Chen, DO</h4>
                                <p>Primary Care & Urgent Care</p>
                            </div>
                            <div class="dior-doctor-card-select" onclick="diorSelectDoctor(1693, 'Dr. Marcus Sterling, DO')">
                                <h4>Dr. Marcus Sterling, DO</h4>
                                <p>Urgent Care Physician</p>
                            </div>`;
                    });
            }

            function diorSelectDoctor(id, name) {
                diorBookingState.doctorId = id;
                diorBookingState.doctorName = name;
                document.getElementById('time-slots-list').innerHTML = '';
                document.getElementById('booking-date').value = '';
                diorBookingGoToStep(3);
            }

            function diorFetchAvailability() {
                let dateStr = document.getElementById('booking-date').value;
                if (!dateStr) return;

                document.getElementById('time-slots-list').innerHTML = '<p>Loading availability...</p>';
                diorBookingState.date = dateStr;

                function renderDefaultTimes() {
                    const defaultTimes = ['09:00 AM', '10:30 AM', '01:00 PM', '02:30 PM', '04:00 PM', '05:30 PM'];
                    let h = '<h4>Available Telehealth Slots</h4><div class="dior-time-grid">';
                    defaultTimes.forEach(t => {
                        h += `<button type="button" class="dior-time-btn" onclick="diorSelectTime(1, '${t}')">${t}</button>`;
                    });
                    h += '</div>';
                    document.getElementById('time-slots-list').innerHTML = h;
                }

                fetch(diorRestUrl + `doctor-details-booking/v1/doctors/${diorBookingState.doctorId}/availability?date=${dateStr}`, {
                    headers: { 'X-WP-Nonce': diorRestNonce }
                })
                    .then(res => res.json())
                    .then(data => {
                        let html = '';
                        if (data && data.clinics && data.clinics.length > 0) {
                            diorBookingState.day = data.day;
                            data.clinics.forEach(clinic => {
                                if (!clinic.is_on_holiday && clinic.timings && clinic.timings.length > 0) {
                                    html += `<h4>${clinic.name}</h4><div class="dior-time-grid">`;
                                    clinic.timings.forEach(timing => {
                                        if (timing.is_available) {
                                            html += `<button type="button" class="dior-time-btn" onclick="diorSelectTime(${clinic.id}, '${timing.time}')">${timing.time}</button>`;
                                        } else {
                                            html += `<button type="button" class="dior-time-btn disabled" disabled>${timing.time}</button>`;
                                        }
                                    });
                                    html += `</div>`;
                                }
                            });
                        }
                        if (html) {
                            document.getElementById('time-slots-list').innerHTML = html;
                        } else {
                            renderDefaultTimes();
                        }
                    })
                    .catch(() => {
                        renderDefaultTimes();
                    });
            }

            function diorSelectTime(clinicId, time) {
                diorBookingState.clinicId = clinicId;
                diorBookingState.time = time;

                document.getElementById('booking-summary').innerHTML = `
                    <p><strong>Treatment:</strong> ${diorBookingState.departmentName || 'Telehealth Urgent Care'}</p>
                    <p><strong>Doctor:</strong> ${diorBookingState.doctorName || 'Attending Physician'}</p>
                    <p><strong>Date:</strong> ${diorBookingState.date}</p>
                    <p><strong>Time:</strong> ${diorBookingState.time}</p>
                    <p><strong>Patient:</strong> ${diorBookingState.patient.name || 'Verified Patient'}</p>
                `;
                diorBookingGoToStep(4);
            }

            function diorSubmitBooking() {
                let btn = document.getElementById('btn-confirm-booking');
                let msg = document.getElementById('booking-message');
                btn.disabled = true;
                btn.innerText = 'Booking Consultation...';

                const formData = new FormData();
                formData.append('action', 'dior_patient_book_appointment');
                formData.append('nonce', diorPortalNonce);
                formData.append('doctorId', diorBookingState.doctorId || 1695);
                formData.append('doctor_name', diorBookingState.doctorName || 'Doctor');
                formData.append('date', diorBookingState.date || '');
                formData.append('time', diorBookingState.time || '');
                formData.append('condition', diorBookingState.departmentName || 'Telehealth Consultation');
                formData.append('name', diorBookingState.patient.name || '');
                formData.append('email', diorBookingState.patient.email || '');
                formData.append('phone', diorBookingState.patient.phone || '');

                fetch(diorAjaxUrl, {
                    method: 'POST',
                    body: formData
                })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            msg.style.color = '#059669';
                            msg.innerText = 'Appointment booked successfully! Redirecting to your dashboard...';
                            setTimeout(() => {
                                window.location.href = "<?php echo esc_js($dashboard_url); ?>";
                            }, 1500);
                        } else {
                            msg.style.color = '#DC2626';
                            msg.innerText = (data.data && data.data.message) || data.message || 'Failed to book appointment.';
                            btn.disabled = false;
                            btn.innerText = 'Confirm & Book';
                        }
                    })
                    .catch(err => {
                        msg.style.color = '#DC2626';
                        msg.innerText = 'An error occurred while booking. Please try again.';
                        btn.disabled = false;
                        btn.innerText = 'Confirm & Book';
                    });
            }
</script>

<style>
    .dior-grid-options {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }

    .dior-grid-btn {
        padding: 12px 20px;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.2s;
        font-size: 15px;
    }

    .dior-grid-btn:hover {
        border-color: #0f172a;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }

    .dior-btn-back-step {
        background: none;
        border: none;
        color: #64748b;
        font-size: 14px;
        cursor: pointer;
        padding: 0;
        margin-bottom: 15px;
    }

    .dior-btn-back-step:hover {
        color: #0f172a;
        text-decoration: underline;
    }

    .dior-doctor-card-select {
        padding: 15px;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        cursor: pointer;
        width: calc(50% - 10px);
    }

    .dior-doctor-card-select:hover {
        border-color: #0f172a;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }

    .dior-doctor-card-select h4 {
        margin: 0 0 5px 0;
        font-size: 16px;
        color: #0f172a;
    }

    .dior-doctor-card-select p {
        margin: 0;
        font-size: 14px;
        color: #64748b;
    }

    .dior-time-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 10px;
        margin-bottom: 20px;
    }

    .dior-time-btn {
        padding: 10px 15px;
        background: #fff;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
    }

    .dior-time-btn:hover:not(.disabled) {
        background: #0f172a;
        color: #fff;
        border-color: #0f172a;
    }

    .dior-time-btn.disabled {
        opacity: 0.5;
        cursor: not-allowed;
        background: #f1f5f9;
    }
</style>
<?php
                return ob_get_clean();
    }

    /**
     * Get Site Logo URL
     */
    public static function get_logo_url()
    {
        $custom_logo_id = get_theme_mod('custom_logo');
        if ($custom_logo_id) {
            $logo = wp_get_attachment_image_url($custom_logo_id, 'full');
            if ($logo)
                return $logo;
        }
        return DIOR_AUTH_URL . 'assets/images/logo-web.png';
    }

    /**
     * Shortcode: [dior_login_form]
     */
    public static function render_login_form($atts)
    {
        $logo_url = self::get_logo_url();
        $redirect_to = isset($_GET['redirect_to']) ? esc_url($_GET['redirect_to']) : home_url('/patient-dashboard/');

        ob_start();
        ?>
<div class="dior-auth-wrap">
    <div class="dior-auth-card">

        <!-- TOP: SITE LOGO -->
        <div class="dior-auth-logo-box">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"
                    class="dior-site-logo">
            </a>
        </div>

        <?php if (is_user_logged_in()):
            $current_user = wp_get_current_user();
            $is_doc = in_array('doctor', (array)$current_user->roles) || in_array('administrator', (array)$current_user->roles) || in_array($current_user->user_login, ['docter', 'admin', 'doctor', 'jameschen', 'evelynvance', 'marcussterling', 'jon']);
            $dash_url = $is_doc ? home_url('/doctor-dashboard/') : home_url('/patient-dashboard/');
            $dash_label = $is_doc ? 'Go to Doctor Dashboard &rarr;' : 'Go to Patient Dashboard &rarr;';
            ?>
        <div class="dior-logged-in-box">
            <div class="dior-user-badge-circle">
                <?php echo esc_html(strtoupper(substr($current_user->display_name ?: 'P', 0, 2))); ?>
            </div>
            <div class="dior-user-info-text">
                <strong><?php echo esc_html($current_user->display_name); ?></strong>
                <span><?php echo esc_html($current_user->user_email); ?></span>
            </div>
        </div>

        <div class="dior-auth-actions" style="margin-top: 20px; display: flex; flex-direction: column; gap: 10px;">
            <a href="<?php echo esc_url($dash_url); ?>" class="dior-btn-auth-primary"><i
                    class="fa-solid fa-gauge-high"></i> <?php echo esc_html($dash_label); ?></a>
            <a href="<?php echo esc_url(wp_logout_url(home_url('/diro-login/'))); ?>"
                class="dior-btn-auth-secondary">Sign Out</a>
        </div>

        <?php else: ?>

        <div class="dior-portal-header-note">
            <h3>Patient Portal Sign In</h3>
            <p>Access your appointments, prescriptions, intake forms, and records.</p>
        </div>

        <form id="dior-login-form" class="dior-auth-form" novalidate>
            <div class="dior-auth-msg" id="dior-login-msg" style="display:none;"></div>

            <div class="dior-form-group">
                <label for="dior-login-username">Email or Username <span class="req">*</span></label>
                <input type="text" id="dior-login-username" name="username" placeholder="name@example.com" required
                    autocomplete="username">
            </div>

            <div class="dior-form-group">
                <div class="dior-label-row">
                    <label for="dior-login-password">Password <span class="req">*</span></label>
                    <a href="<?php echo esc_url(wp_lostpassword_url()); ?>" class="dior-forgot-link">Forgot
                        password?</a>
                </div>
                <div class="dior-input-pwd-wrap" style="position:relative;">
                    <input type="password" id="dior-login-password" name="password" placeholder="Enter your password"
                        required autocomplete="current-password">
                    <button type="button" class="dior-pwd-toggle" id="dior-toggle-login-pwd"
                        aria-label="Toggle password visibility">
                        <svg class="dior-eye-svg" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                    </button>
                </div>
            </div>

            <div class="dior-form-check-row">
                <label class="dior-custom-checkbox">
                    <input type="checkbox" name="rememberme" value="forever" checked>
                    <span class="dior-checkmark"></span>
                    <span class="dior-check-text">Remember me on this device</span>
                </label>
            </div>

            <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect_to); ?>">

            <div class="dior-form-submit">
                <button type="submit" class="dior-btn-auth-primary" id="dior-login-submit-btn">
                    <span>Sign In to Dashboard &rarr;</span>
                </button>
            </div>
        </form>

        <!-- BOTTOM: SWITCH LINK TO REGISTRATION -->
        <div class="dior-auth-bottom-link">
            <p>First time visiting? <a href="<?php echo esc_url(home_url('/diro-registration/')); ?>">Create Patient
                    Account</a></p>
        </div>

        <?php endif; ?>

    </div>
</div>
<?php
                return ob_get_clean();
    }

    /**
     * Shortcode: [dior_registration_form]
     */
    public static function render_registration_form($atts)
    {
        $logo_url = self::get_logo_url();

        ob_start();
        ?>
<div class="dior-auth-wrap">
    <div class="dior-auth-card dior-register-card">

        <!-- TOP: SITE LOGO -->
        <div class="dior-auth-logo-box">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"
                    class="dior-site-logo">
            </a>
        </div>

        <?php if (is_user_logged_in()): ?>
        <div class="dior-logged-in-box">
            <p style="margin:0; text-align:center; width:100%;">You are currently signed in.</p>
        </div>
        <div class="dior-auth-actions" style="margin-top: 20px; display: flex; flex-direction: column; gap: 10px;">
            <a href="<?php echo esc_url(home_url('/patient-dashboard/')); ?>" class="dior-btn-auth-primary"><i
                    class="fa-solid fa-gauge-high"></i> Go to Patient Dashboard &rarr;</a>
            <a href="<?php echo esc_url(wp_logout_url(home_url('/diro-registration/'))); ?>"
                class="dior-btn-auth-secondary">Sign Out / Switch Account</a>
        </div>
        <?php else: ?>

        <div class="dior-portal-header-note">
            <h3>New Patient Registration</h3>
            <p>Complete your intake profile to book consultations and access telehealth care.</p>
        </div>

        <form id="dior-register-form" class="dior-auth-form" novalidate>
            <div class="dior-auth-msg" id="dior-register-msg" style="display:none;"></div>

            <!-- Full Name -->
            <div class="dior-form-row-2">
                <div class="dior-form-group">
                    <label for="dior-reg-first-name">First Name <span class="req">*</span></label>
                    <input type="text" id="dior-reg-first-name" name="first_name" placeholder="First Name" required>
                </div>
                <div class="dior-form-group">
                    <label for="dior-reg-last-name">Last Name <span class="req">*</span></label>
                    <input type="text" id="dior-reg-last-name" name="last_name" placeholder="Last Name" required>
                </div>
            </div>

            <!-- Email & Phone -->
            <div class="dior-form-row-2">
                <div class="dior-form-group">
                    <label for="dior-reg-email">Email Address <span class="req">*</span></label>
                    <input type="email" id="dior-reg-email" name="email" placeholder="name@example.com" required
                        autocomplete="email">
                </div>
                <div class="dior-form-group">
                    <label for="dior-reg-phone">Phone Number <span class="req">*</span></label>
                    <input type="tel" id="dior-reg-phone" name="phone" placeholder="(555) 000-0000" required
                        autocomplete="tel">
                </div>
            </div>

            <!-- Date of Birth & Gender -->
            <div class="dior-form-row-2">
                <div class="dior-form-group">
                    <label for="dior-reg-dob">Date of Birth <span class="req">*</span></label>
                    <input type="date" id="dior-reg-dob" name="dob" required>
                </div>
                <div class="dior-form-group">
                    <label for="dior-reg-gender">Gender / Sex at Birth <span class="req">*</span></label>
                    <select id="dior-reg-gender" name="gender" required>
                        <option value="Female">Female</option>
                        <option value="Male">Male</option>
                        <option value="Other / Non-Binary">Other / Non-Binary</option>
                    </select>
                </div>
            </div>

            <!-- 18+ Eligibility Check -->
            <div class="dior-eligibility-box">
                <div class="dior-eligibility-title"><span class="req">*</span> Telehealth Eligibility & Age Verification
                </div>
                <label class="dior-radio-option">
                    <input type="radio" name="eligibility_check" value="yes" required checked>
                    <span>I confirm I am 18+ years of age and currently in an eligible telehealth state (CA).</span>
                </label>
                <label class="dior-radio-option">
                    <input type="radio" name="eligibility_check" value="no">
                    <span>No, I am under 18 years of age.</span>
                </label>
            </div>

            <!-- Password & Confirm -->
            <div class="dior-form-row-2">
                <div class="dior-form-group">
                    <label for="dior-reg-password">Password <span class="req">*</span></label>
                    <div class="dior-input-pwd-wrap" style="position:relative;">
                        <input type="password" id="dior-reg-password" name="password" placeholder="Min 6 characters"
                            required autocomplete="new-password">
                        <button type="button" class="dior-pwd-toggle" id="dior-toggle-reg-pwd"
                            aria-label="Toggle password visibility">
                            <svg class="dior-eye-svg" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        </button>
                    </div>
                </div>
                <div class="dior-form-group">
                    <label for="dior-reg-confirm-password">Confirm Password <span class="req">*</span></label>
                    <div class="dior-input-pwd-wrap" style="position:relative;">
                        <input type="password" id="dior-reg-confirm-password" name="confirm_password"
                            placeholder="Confirm password" required autocomplete="new-password">
                        <button type="button" class="dior-pwd-toggle" id="dior-toggle-reg-confirm-pwd"
                            aria-label="Toggle password visibility">
                            <svg class="dior-eye-svg" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Terms & HIPAA Consent -->
            <div class="dior-form-check-row">
                <label class="dior-custom-checkbox">
                    <input type="checkbox" name="terms_consent" value="1" required checked>
                    <span class="dior-checkmark"></span>
                    <span class="dior-check-text">I agree to the <a
                            href="<?php echo esc_url(home_url('/about-dior-medical/')); ?>" target="_blank">Terms of
                            Care</a>, HIPAA Notice & Privacy Policy.</span>
                </label>
            </div>

            <div class="dior-form-submit">
                <button type="submit" class="dior-btn-auth-primary" id="dior-register-submit-btn">
                    <span>Create Patient Account &rarr;</span>
                </button>
            </div>
        </form>

        <!-- BOTTOM: SWITCH LINK TO LOGIN -->
        <div class="dior-auth-bottom-link">
            <p>Already have an account? <a href="<?php echo esc_url(home_url('/diro-login/')); ?>">Log in here</a></p>
        </div>

        <?php endif; ?>

    </div>
</div>
<?php
                return ob_get_clean();
    }

    /**
     * Redirect unauthenticated users from private patient and doctor dashboard pages to login
     */
    public static function check_dashboard_access_redirect()
    {
        if (is_user_logged_in()) {
            return;
        }

        $login_url = home_url('/diro-login/');

        global $post;
        $should_redirect = false;

        if (is_a($post, 'WP_Post')) {
            if (
                has_shortcode($post->post_content, 'dior_patient_dashboard') ||
                has_shortcode($post->post_content, 'dior_doctor_dashboard') ||
                has_shortcode($post->post_content, 'dior_book_visit_page')
            ) {
                $should_redirect = true;
            }
        }

        if (!$should_redirect && function_exists('is_page') && is_page(['patient-dashboard', 'doctor-dashboard', 'doctor-portal', 'dior-doctor-dashboard'])) {
            $should_redirect = true;
        }

        if (!$should_redirect && !empty($_SERVER['REQUEST_URI'])) {
            $uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
            if (
                strpos($uri, 'patient-dashboard') !== false ||
                strpos($uri, 'doctor-dashboard') !== false ||
                strpos($uri, 'doctor-portal') !== false
            ) {
                $should_redirect = true;
            }
        }

        if ($should_redirect) {
            wp_safe_redirect($login_url);
            exit;
        }
    }

    /**
     * Shortcode: [dior_patient_dashboard]
     * Complete luxury Patient Dashboard with all 6 modules
     */
    public static function render_patient_dashboard($atts)
    {
        // If not logged in, redirect directly to login page
        if (!is_user_logged_in()) {
            $login_url = home_url('/diro-login/');
            if (!headers_sent()) {
                wp_safe_redirect($login_url);
                exit;
            }
            return '<script>window.location.replace(' . json_encode($login_url) . ');</script><meta http-equiv="refresh" content="0;url=' . esc_url($login_url) . '">';
        }

        $logo_url = self::get_logo_url();
        $user_id = get_current_user_id();
        $current_user = wp_get_current_user();
        $profile = Dior_Patient_Portal_Data::get_patient_profile($user_id);
        $appointments = Dior_Patient_Portal_Data::get_patient_appointments($user_id);
        $prescriptions = Dior_Patient_Portal_Data::get_patient_prescriptions($user_id);
        $payments = Dior_Patient_Portal_Data::get_patient_payments($user_id);
        $documents = Dior_Patient_Portal_Data::get_patient_documents($user_id);
        $questionnaires = Dior_Patient_Portal_Data::get_patient_questionnaires($user_id);
        $notifications = Dior_Patient_Portal_Data::get_patient_notifications($user_id);
        $hipaa_intake = get_user_meta($user_id, 'dior_hipaa_intake', true); // HIPAAtizer submitted data

        // Calculate stats
        $next_appointment = null;
        $upcoming_list = [];
        $past_list = [];
        foreach ($appointments as $apt) {
            if ($apt['status'] === 'Confirmed' || $apt['status'] === 'Scheduled' || $apt['status'] === 'In-Queue') {
                if (!$next_appointment) {
                    $next_appointment = $apt;
                }
                $upcoming_list[] = $apt;
            } else {
                $past_list[] = $apt;
            }
        }

        $unread_count = 0;
        foreach ($notifications as $n) {
            if (!$n['is_read'])
                $unread_count++;
        }

        $pending_questionnaires = 0;
        foreach ($questionnaires as $q) {
            if ($q['status'] !== 'Submitted')
                $pending_questionnaires++;
        }

        $latest_rx = !empty($prescriptions) ? $prescriptions[0] : null;

        ob_start();
        ?>
<div class="dior-wrap dior-patient-portal-wrap" id="dior-patient-portal-app">

    <style>
        /* Active status pill & sidebar count badges critical styles */
        #dior-patient-portal-app .dior-user-pill .dior-pill-info {
            display: flex !important;
            align-items: center !important;
            gap: 8px !important;
        }

        #dior-patient-portal-app .dior-user-pill .dior-pill-name {
            font-size: 13px !important;
            font-weight: 700 !important;
            color: #0B1120 !important;
            margin: 0 !important;
        }

        #dior-patient-portal-app .dior-user-pill .dior-pill-status {
            display: inline-flex !important;
            align-items: center !important;
            gap: 5px !important;
            font-size: 10px !important;
            font-weight: 700 !important;
            color: #059669 !important;
            background: #ECFDF5 !important;
            padding: 2px 7px !important;
            border-radius: 12px !important;
            border: 1px solid #A7F3D0 !important;
            line-height: 1 !important;
            letter-spacing: 0.02em !important;
        }

        #dior-patient-portal-app .dior-user-pill .dior-pill-status i,
        #dior-patient-portal-app .dior-user-pill .dior-pill-status svg {
            color: #10B981 !important;
            fill: #10B981 !important;
            font-size: 6px !important;
            width: 6px !important;
            height: 6px !important;
            max-width: 6px !important;
            max-height: 6px !important;
            display: inline-block !important;
            margin: 0 !important;
            vertical-align: 0 !important;
        }

        #dior-patient-portal-app .dior-nav-btn .nav-label,
        #dior-patient-portal-app .dior-nav-btn>span:not(.nav-count-badge) {
            flex: 1 1 auto !important;
            text-align: left !important;
        }

        #dior-patient-portal-app .dior-nav-btn .nav-count-badge {
            flex: 0 0 auto !important;
            width: auto !important;
            min-width: 20px !important;
            max-width: 32px !important;
            height: 20px !important;
            padding: 0 6px !important;
            border-radius: 10px !important;
            font-size: 11px !important;
            font-weight: 700 !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            line-height: 1 !important;
            background: #2563EB !important;
            color: #FFFFFF !important;
            margin-left: auto !important;
            box-shadow: 0 1px 4px rgba(37, 99, 235, 0.4) !important;
        }

        #dior-patient-portal-app .dior-nav-btn .nav-count-badge.warning {
            background: #E11D48 !important;
            box-shadow: 0 1px 4px rgba(225, 29, 72, 0.4) !important;
        }

        /* Luxury Table & Card Edge Spacing */
        #dior-patient-portal-app .dior-table,
        .dior-table {
            width: 100% !important;
            border-collapse: collapse !important;
            table-layout: auto !important;
        }

        #dior-patient-portal-app .dior-table th,
        .dior-table th {
            padding: 14px 16px !important;
            white-space: nowrap !important;
            font-size: 11.5px !important;
            letter-spacing: 0.05em !important;
            text-transform: uppercase !important;
        }

        #dior-patient-portal-app .dior-table td,
        .dior-table td {
            padding: 16px 16px !important;
            vertical-align: middle !important;
        }

        #dior-patient-portal-app .dior-table th:first-child,
        #dior-patient-portal-app .dior-table td:first-child,
        #dior-patient-portal-app .dior-clean-table th:first-child,
        #dior-patient-portal-app .dior-clean-table td:first-child,
        .dior-table th:first-child,
        .dior-table td:first-child {
            padding-left: 24px !important;
        }

        #dior-patient-portal-app .dior-table th:last-child,
        #dior-patient-portal-app .dior-table td:last-child,
        #dior-patient-portal-app .dior-clean-table th:last-child,
        #dior-patient-portal-app .dior-clean-table td:last-child,
        .dior-table th:last-child,
        .dior-table td:last-child {
            padding-right: 24px !important;
        }

        #dior-patient-portal-app .dior-card-header,
        .dior-card-header {
            padding: 18px 24px !important;
        }

        #dior-patient-portal-app .dior-card,
        .dior-card {
            border-radius: 16px !important;
            overflow: hidden !important;
            box-shadow: 0 2px 10px rgba(11, 16, 48, 0.04) !important;
        }

        /* Table Universal Pagination */
        .dior-table-pagination {
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            padding: 14px 24px !important;
            background: #FFFFFF !important;
            border-top: 1px solid #EEF2F6 !important;
            flex-wrap: wrap !important;
            gap: 12px !important;
            font-family: 'DMSans', 'DM Sans', -apple-system, sans-serif !important;
        }

        .dior-pagination-info {
            font-size: 13px !important;
            color: #64748B !important;
            font-weight: 500 !important;
        }

        .dior-pagination-info strong {
            color: #0F172A !important;
            font-weight: 700 !important;
        }

        .dior-pagination-nav {
            display: flex !important;
            align-items: center !important;
            gap: 6px !important;
        }

        .dior-page-btn {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            min-width: 32px !important;
            height: 32px !important;
            padding: 0 10px !important;
            border-radius: 8px !important;
            font-size: 13px !important;
            font-weight: 600 !important;
            border: 1px solid #E2E8F0 !important;
            background: #FFFFFF !important;
            color: #475569 !important;
            cursor: pointer !important;
            transition: all 0.15s ease !important;
            font-family: inherit !important;
        }

        .dior-page-btn:hover:not(:disabled) {
            background: #F8FAFC !important;
            border-color: #CBD5E1 !important;
            color: #0F172A !important;
        }

        .dior-page-btn.active {
            background: linear-gradient(135deg, #2C6CB1 0%, #1A528E 100%) !important;
            color: #FFFFFF !important;
            border-color: transparent !important;
            box-shadow: 0 2px 6px rgba(44, 108, 177, 0.25) !important;
        }

        .dior-page-btn:disabled {
            opacity: 0.4 !important;
            cursor: not-allowed !important;
            background: #F8FAFC !important;
        }

        /* Patient Questionnaire Tab - Solid White Background */
        #tab-questionnaire,
        .dior-tab-panel#tab-questionnaire {
            max-width: 880px !important;
            margin: 0 auto 30px auto !important;
            background: #FFFFFF !important;
            background-color: #FFFFFF !important;
            border-radius: 16px !important;
            padding: 28px 32px !important;
            box-shadow: 0 4px 20px rgba(11, 16, 48, 0.05) !important;
            border: 1px solid #E2E8F0 !important;
        }

        #tab-questionnaire .dior-page-header-box {
            max-width: 100% !important;
            margin: 0 0 20px 0 !important;
            background: #FFFFFF !important;
            background-color: #FFFFFF !important;
        }

        #tab-questionnaire .dior-section-block,
        #tab-questionnaire .dior-section-header,
        #tab-questionnaire .dior-card,
        #tab-questionnaire .dior-hipaa-embed-card,
        #tab-questionnaire .dior-hipaa-embed-wrap,
        #tab-questionnaire .hipaa-form-container-box,
        #tab-questionnaire #hipaatizer-intake-iframe {
            background: #FFFFFF !important;
            background-color: #FFFFFF !important;
            border: none !important;
            box-shadow: none !important;
            width: 100% !important;
            max-width: 100% !important;
        }

        /* Luxury Receipt & Document Modals */
        .dior-modal-dialog {
            background: #FFFFFF !important;
            border-radius: 16px !important;
            box-shadow: 0 25px 60px -10px rgba(0, 0, 0, 0.3) !important;
            border: 1px solid #E2E8F0 !important;
            overflow: hidden !important;
            margin: 20px auto !important;
        }

        .dior-modal-footer {
            padding: 18px 24px 22px 24px !important;
            background: #FFFFFF !important;
            border-top: 1px solid #EEF2F6 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: flex-end !important;
            gap: 12px !important;
            margin-top: 0 !important;
        }

        .receipt-logo img {
            height: 68px !important;
            max-height: 72px !important;
            width: auto !important;
            object-fit: contain !important;
            display: inline-block !important;
        }
    </style>

    <!-- Mobile Drawer Backdrop -->
    <div class="dior-drawer-backdrop" id="dior-drawer-backdrop" onclick="diorCloseMobileDrawer()"></div>

    <div class="dior-app">

        <!-- ============================================================== -->
        <!-- SIDEBAR NAVIGATION -->
        <!-- ============================================================== -->
        <aside class="dior-side" id="dior-sidebar">
            <div class="dior-side-header">
                <div class="brand">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="brand-link">
                        <img src="<?php echo esc_url($logo_url); ?>" alt="Dior Medical" class="brand-logo">
                    </a>
                </div>
                <button type="button" class="dior-side-close" id="dior-side-close" onclick="diorCloseMobileDrawer()"
                    aria-label="Close sidebar">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <!-- Profile / Identity Card in Sidebar -->
            <div class="dior-side-org-card">
                <div class="org-icon-box">
                    <?php echo esc_html(strtoupper(substr($profile['first_name'] ?: 'P', 0, 1) . substr($profile['last_name'] ?: 'M', 0, 1))); ?>
                </div>
                <div class="org-info">
                    <strong><?php echo esc_html($profile['full_name']); ?></strong>
                    <span>Patient ID • <?php echo esc_html($profile['patient_id']); ?></span>
                </div>
                <i class="fa-solid fa-circle-check org-arrow" style="color:#059669;" title="Verified Patient"></i>
            </div>

            <!-- Navigation Links -->
            <nav class="dior-side-nav">
                <div class="grp">
                    <span class="grp-title">MAIN MENU</span>
                    <button type="button" class="dior-nav-btn active" data-tab="overview">
                        <i class="fa-solid fa-house-medical"></i>
                        <span class="nav-label">Home / Overview</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="appointments">
                        <i class="fa-solid fa-calendar-check"></i>
                        <span class="nav-label">Appointments</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="payments">
                        <i class="fa-solid fa-credit-card"></i>
                        <span class="nav-label">Payments &amp; Invoices</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="docs_meds">
                        <i class="fa-solid fa-prescription-bottle-medical"></i>
                        <span class="nav-label">Prescriptions &amp; Meds</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="questionnaire">
                        <i class="fa-solid fa-clipboard-question"></i>
                        <span class="nav-label">Medical Questionnaire</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="profile">
                        <i class="fa-solid fa-id-card-clip"></i>
                        <span class="nav-label">Profile &amp; Eligibility</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="notifications">
                        <i class="fa-solid fa-bell"></i>
                        <span class="nav-label">Notifications</span>
                    </button>
                </div>

                <!-- Sign Out Link -->
                <div class="dior-side-footer">
                    <a href="<?php echo esc_url(wp_logout_url(home_url('/diro-login/'))); ?>"
                        class="dior-side-logout-btn">
                        <i class="fa-solid fa-arrow-right-from-bracket"></i>
                        <span>Sign Out</span>
                    </a>
                </div>
            </nav>
        </aside>

        <!-- ============================================================== -->
        <!-- MAIN CONTENT AREA -->
        <!-- ============================================================== -->
        <main class="dior-main-content">

            <!-- Top Bar Header -->
            <header class="dior-topbar">
                <div class="dior-topbar-left">
                    <button type="button" class="dior-mobile-menu-toggle" id="dior-mobile-menu-toggle"
                        onclick="diorOpenMobileDrawer()" aria-label="Open navigation menu">
                        <i class="fa-solid fa-bars"></i>
                    </button>

                    <!-- Search Bar (Clean Reference UI) -->
                    <div class="dior-top-search">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input type="text" placeholder="Search appointments, prescriptions, records...">
                        <span class="search-kbd">⌘+K</span>
                    </div>
                </div>

                <div class="dior-topbar-right">
                    <!-- Notification Bell Dropdown -->
                    <div class="dior-notif-wrap" id="dior-notif-dropdown-wrap">
                        <button type="button" class="dior-notif-btn" onclick="diorToggleNotifDropdown(event)" aria-label="Notifications">
                            <i class="fa-regular fa-bell"></i>
                            <?php if ($unread_count > 0): ?>
                                <span class="dior-notif-indicator unread-badge-count"><?php echo $unread_count; ?></span>
                            <?php endif; ?>
                        </button>
                        <div class="dior-notif-dropdown" id="dior-notif-dropdown">
                            <div class="dior-notif-header">
                                <h4>Notifications</h4>
                                <button type="button" id="dior-quick-mark-read">Mark all read</button>
                            </div>
                            <div class="dior-notif-list">
                                <?php if (empty($notifications)): ?>
                                    <div style="padding: 24px; text-align: center; color: #94A3B8; font-size: 13px;">
                                        <i class="fa-regular fa-bell-slash" style="font-size: 20px; display: block; margin-bottom: 8px;"></i>
                                        No new notifications
                                    </div>
                                <?php else: ?>
                                    <?php foreach (array_slice($notifications, 0, 5) as $n): 
                                        $target_tab = !empty($n['action_url']) ? str_replace('#tab=', '', $n['action_url']) : 'notifications';
                                    ?>
                                        <div class="dior-notif-item <?php echo empty($n['is_read']) ? 'unread' : ''; ?>"
                                            data-notif-id="<?php echo esc_attr($n['id']); ?>"
                                            data-switch-tab="<?php echo esc_attr($target_tab); ?>"
                                            style="cursor:pointer;">
                                            <div class="notif-icon"><i class="fa-solid <?php echo esc_attr($n['icon'] ?? 'fa-bell'); ?>"></i></div>
                                            <div class="notif-body">
                                                <strong><?php echo esc_html($n['title']); ?></strong>
                                                <p><?php echo esc_html(mb_substr($n['message'], 0, 45) . (mb_strlen($n['message']) > 45 ? '...' : '')); ?></p>
                                                <span class="notif-time"><?php echo esc_html(dior_format_notification_time($n)); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <div class="dior-notif-footer">
                                <button type="button" data-switch-tab="notifications">View All &rarr;</button>
                            </div>
                        </div>
                    </div>

                    <!-- User Quick Profile Pill -->
                    <div class="dior-user-pill">
                        <div class="dior-pill-avatar"
                            style="background:linear-gradient(135deg,#2C6CB1,#1A528E);color:#FFFFFF;overflow:hidden;display:flex;align-items:center;justify-content:center;">
                            <?php if (!empty($profile['avatar_url'])): ?>
                            <img src="<?php echo esc_url($profile['avatar_url']); ?>"
                                alt="<?php echo esc_attr($profile['full_name']); ?>"
                                style="width:100%;height:100%;object-fit:cover;border-radius:50%;">
                            <?php elseif (!empty($profile['first_name'])): ?>
                            <?php echo esc_html(strtoupper(substr($profile['first_name'], 0, 1))); ?>
                            <?php else: ?>
                            <i class="fa-solid fa-user" style="font-size:14px;color:#FFFFFF;"></i>
                            <?php endif; ?>
                        </div>
                        <div class="dior-pill-info">
                            <span class="dior-pill-name"><?php echo esc_html($profile['full_name']); ?></span>
                            <span class="dior-pill-status"><i class="fa-solid fa-circle"></i> Active</span>
                        </div>
                    </div>
                </div>
            </header>

            <!-- TAB PANELS CONTAINER -->
            <div class="dior-tab-container">

                <!-- ============================================================== -->
                <!-- 0. HOME / OVERVIEW TAB (Real Functional Patient Data + Clean UI) -->
                <!-- ============================================================== -->
                <section class="dior-tab-panel active" id="tab-overview">

                    <!-- Sub-Header Bar: Page Title & Actions -->
                    <div class="dior-page-title-bar">
                        <div class="title-left">
                            <div class="title-icon-box">
                                <i class="fa-solid fa-border-all"></i>
                            </div>
                            <div>
                                <h2>Welcome back, <?php echo esc_html($profile['first_name'] ?: 'Patient'); ?></h2>
                                <p>Manage your telehealth visits, prescriptions, and medical records.</p>
                            </div>
                        </div>
                        <div class="title-right">
                            <div class="dior-date-picker-pill">
                                <i class="fa-regular fa-calendar"></i>
                                <span><?php echo current_time('j M Y'); ?></span>
                            </div>
                            <button type="button" class="dior-btn-head-cta" data-switch-tab="questionnaire">
                                <i class="fa-solid fa-plus"></i> Book New Visit
                            </button>
                        </div>
                    </div>
                    <!-- /dior-page-title-bar -->

                    <!-- Top Stat Cards Row (Clean White Cards) -->
                    <div class="dior-stats-cards-grid">
                        <!-- Card 1: Upcoming Consultations -->
                        <div class="dior-stat-card card-blue" data-switch-tab="appointments" style="cursor:pointer;" title="View all appointments">
                            <div class="card-content">
                                <div class="stat-header-row">
                                    <span class="stat-label">Upcoming Consultations</span>
                                </div>
                                <span class="stat-val"><?php echo count($upcoming_list); ?> Active</span>
                            </div>
                        </div>

                        <!-- Card 2: Active Prescriptions -->
                        <div class="dior-stat-card card-purple" data-switch-tab="docs_meds" style="cursor:pointer;" title="View all active prescriptions">
                            <div class="card-content">
                                <div class="stat-header-row">
                                    <span class="stat-label">Active Prescriptions</span>
                                </div>
                                <span class="stat-val"><?php echo count($prescriptions); ?> Records</span>
                            </div>
                        </div>

                        <!-- Card 3: Patient Eligibility & Coverage -->
                        <div class="dior-stat-card card-green">
                            <div class="card-content">
                                <div class="stat-header-row">
                                    <span class="stat-label">Eligibility &amp; Coverage</span>
                                </div>
                                <span class="stat-val">100% Verified</span>
                            </div>
                        </div>
                    </div>

                    <!-- Overview 2-Column Grid -->
                    <div class="dior-overview-grid">

                        <!-- LEFT COLUMN: Next Appointment Hero & Quick Actions -->
                        <div class="dior-overview-col-left">

                            <!-- Next Appointment Hero Card -->
                            <div class="dior-hero-appt-card">
                                <div class="hero-appt-header" style="justify-content:flex-end;">
                                    <span class="hero-live-pulse"><i class="fa-solid fa-circle"></i> Room Ready</span>
                                </div>

                                <?php if ($next_appointment): ?>
                                <div class="hero-appt-body">
                                    <div class="hero-appt-info">
                                        <h3 class="hero-condition">
                                            <?php echo esc_html($next_appointment['condition'] ?? 'Telehealth Consultation'); ?>
                                        </h3>
                                        <div class="hero-doctor">
                                            <i class="fa-solid fa-user-doctor"></i>
                                            <div>
                                                <strong><?php echo esc_html($next_appointment['provider'] ?? 'Attending Physician'); ?></strong>
                                                <span><?php echo esc_html($next_appointment['provider_spec'] ?? $next_appointment['provider_title'] ?? 'Physician'); ?></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="hero-appt-timebox">
                                        <div class="time-item">
                                            <span class="label">Date</span>
                                            <span class="val"><i class="fa-regular fa-calendar"></i>
                                                <?php echo esc_html($next_appointment['date'] ?? ''); ?></span>
                                        </div>
                                        <div class="time-item">
                                            <span class="label">Time</span>
                                            <span class="val"><i class="fa-regular fa-clock"></i>
                                                <?php echo esc_html($next_appointment['time'] ?? ''); ?></span>
                                        </div>
                                        <div class="time-item">
                                            <span class="label">Visit Type</span>
                                            <span class="val"><i class="fa-solid fa-headset"></i>
                                                <?php echo esc_html($next_appointment['type'] ?? 'Video Visit'); ?></span>
                                        </div>
                                    </div>

                                    <!-- Live Dynamic Countdown -->
                                    <?php
                                    $raw_appt_date = $next_appointment['raw_date'] ?? ($next_appointment['date'] ?? '');
                                    $raw_appt_time = $next_appointment['time'] ?? '';
                                    ?>
                                    <div class="hero-countdown-box" id="dior-live-hero-countdown"
                                        data-appt-date="<?php echo esc_attr($raw_appt_date); ?>"
                                        data-appt-time="<?php echo esc_attr($raw_appt_time); ?>">
                                        <div class="cd-title" id="dior-cd-status-text">Consultation window begins in:</div>
                                        <div class="cd-timers" id="dior-cd-timers-wrap">
                                            <div class="cd-slot" id="dior-cd-days-slot" style="display:none;"><span id="dior-cd-days">00</span><small>Days</small></div>
                                            <span class="cd-colon" id="dior-cd-days-colon" style="display:none;">:</span>
                                            <div class="cd-slot" id="dior-cd-hrs-slot"><span id="dior-cd-hrs">00</span><small>Hrs</small></div>
                                            <span class="cd-colon" id="dior-cd-hrs-colon">:</span>
                                            <div class="cd-slot"><span id="dior-cd-min">00</span><small>Min</small></div>
                                            <span class="cd-colon">:</span>
                                            <div class="cd-slot"><span id="dior-cd-sec">00</span><small>Sec</small></div>
                                        </div>
                                    </div>

                                    <!-- Join Action Buttons -->
                                    <div class="hero-appt-actions">
                                        <?php
                                        $hero_zoom_url = 'https://zoom.us/join';
                                        if (!empty($next_appointment['join_url']) && strpos($next_appointment['join_url'], 'doxy.me') === false) {
                                            $hero_zoom_url = $next_appointment['join_url'];
                                        } elseif (!empty($next_appointment['doctor_user_id'])) {
                                            $doc_zoom = get_user_meta($next_appointment['doctor_user_id'], 'doctor_zoom_link', true);
                                            if (!empty($doc_zoom)) {
                                                $hero_zoom_url = $doc_zoom;
                                            }
                                        }
                                        ?>
                                        <a href="<?php echo esc_url($hero_zoom_url); ?>" target="_blank"
                                            rel="noopener noreferrer" class="dior-btn-join-call">
                                            <i class="fa-solid fa-video"></i> Join Video Consultation Room &rarr;
                                        </a>
                                    </div>
                                </div>
                                <?php else: ?>
                                <div class="hero-empty-state">
                                    <i class="fa-solid fa-calendar-xmark"></i>
                                    <p>No upcoming appointments scheduled right now.</p>
                                    <button type="button" class="dior-btn-gold-primary" data-switch-tab="questionnaire">
                                        <i class="fa-solid fa-plus"></i> Schedule Urgent Care Visit
                                    </button>
                                </div>
                                <?php endif; ?>
                            </div>

                            <!-- Quick Actions Grid -->
                            <div class="dior-quick-actions-box">
                                <h3 class="section-title"><i class="fa-solid fa-bolt"></i> Quick Actions</h3>
                                <div class="quick-actions-grid">
                                    <button type="button" class="qa-card" data-switch-tab="questionnaire">
                                        <div class="qa-icon gold"><i class="fa-solid fa-calendar-plus"></i></div>
                                        <div class="qa-meta">
                                            <strong>Book New Visit</strong>
                                            <span>Instant doctor consult</span>
                                        </div>
                                    </button>

                                    <button type="button" class="qa-card" data-switch-tab="docs_meds">
                                        <div class="qa-icon blue"><i
                                                class="fa-solid fa-prescription-bottle-medical"></i></div>
                                        <div class="qa-meta">
                                            <strong>View Prescriptions</strong>
                                            <span>Pharmacy &amp; refill status</span>
                                        </div>
                                    </button>

                                    <button type="button" class="qa-card" data-switch-tab="questionnaire">
                                        <div class="qa-icon green"><i class="fa-solid fa-clipboard-list"></i></div>
                                        <div class="qa-meta">
                                            <strong>Medical Intake Form</strong>
                                            <span>Update symptoms &amp; meds</span>
                                        </div>
                                    </button>

                                    <button type="button" class="qa-card" data-switch-tab="payments">
                                        <div class="qa-icon purple"><i class="fa-solid fa-file-invoice-dollar"></i>
                                        </div>
                                        <div class="qa-meta">
                                            <strong>Billing &amp; Receipts</strong>
                                            <span>View Stripe statements</span>
                                        </div>
                                    </button>
                                </div>
                            </div>

                        </div>

                        <!-- RIGHT COLUMN: Mini Upcoming List & Latest Prescription -->
                        <div class="dior-overview-col-right">

                            <!-- Upcoming Appointments Mini List -->
                            <div class="dior-card dior-mini-card">
                                <div class="dior-card-header">
                                    <h3><i class="fa-solid fa-calendar-days"></i> Upcoming Visits</h3>
                                    <button type="button" class="dior-link-action" data-switch-tab="appointments">View
                                        All
                                        &rarr;</button>
                                </div>
                                <div class="dior-card-body">
                                    <?php if (!empty($upcoming_list)): ?>
                                    <div class="mini-appt-list">
                                        <?php foreach ($upcoming_list as $apt): 
                                            $apt_date_raw = $apt['date'] ?? ($apt['appt_date'] ?? '');
                                            $apt_time_ts = !empty($apt_date_raw) ? strtotime($apt_date_raw) : 0;
                                            $apt_day = $apt_time_ts ? date('d', $apt_time_ts) : date('d');
                                            $apt_mon = $apt_time_ts ? date('M', $apt_time_ts) : date('M');
                                            $apt_status = $apt['status'] ?? ($apt['appt_status'] ?? 'Confirmed');
                                        ?>
                                        <div class="mini-appt-item">
                                            <div class="mini-appt-date">
                                                <span class="m-day"><?php echo esc_html($apt_day); ?></span>
                                                <span class="m-month"><?php echo esc_html($apt_mon); ?></span>
                                            </div>
                                            <div class="mini-appt-info">
                                                <strong><?php echo esc_html($apt['condition'] ?? ($apt['condition_name'] ?? 'Telehealth Consultation')); ?></strong>
                                                <span><i class="fa-regular fa-clock"></i>
                                                    <?php echo esc_html($apt['time'] ?? ($apt['appt_time'] ?? '')); ?>
                                                    &bull;
                                                    <?php echo esc_html($apt['type'] ?? ($apt['visit_type'] ?? 'Video Visit')); ?></span>
                                            </div>
                                            <div class="mini-appt-badge">
                                                <span class="dior-st ok"><?php echo esc_html($apt_status); ?></span>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <?php else: ?>
                                    <p class="empty-text">No other upcoming visits scheduled.</p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Latest Prescription & Pharmacy Status Card -->
                            <div class="dior-card dior-mini-card">
                                <div class="dior-card-header">
                                    <h3><i class="fa-solid fa-pills"></i> Latest Prescription</h3>
                                    <button type="button" class="dior-link-action" data-switch-tab="docs_meds">Details
                                        &rarr;</button>
                                </div>
                                <div class="dior-card-body">
                                    <?php if ($latest_rx): ?>
                                    <div class="mini-rx-box">
                                        <div class="rx-header-row">
                                            <div class="rx-name-block">
                                                <div class="rx-icon"><i class="fa-solid fa-capsules"></i></div>
                                                <div>
                                                    <h4><?php echo esc_html($latest_rx['medication']); ?></h4>
                                                    <span class="rx-date">Prescribed:
                                                        <?php echo esc_html($latest_rx['date_prescribed']); ?></span>
                                                </div>
                                            </div>
                                            <span
                                                class="rx-routing-pill <?php echo esc_attr($latest_rx['status_class']); ?>">
                                                <i class="fa-solid fa-truck-medical"></i>
                                                <?php echo esc_html($latest_rx['routing_status']); ?>
                                            </span>
                                        </div>

                                        <div class="rx-dosage-note">
                                            <i class="fa-solid fa-circle-info"></i>
                                            <?php echo esc_html($latest_rx['dosage']); ?>
                                        </div>

                                        <div class="rx-pharmacy-footer">
                                            <span><i class="fa-solid fa-store"></i> <strong>Routing:</strong>
                                                <?php echo esc_html($profile['pharmacy_name']); ?></span>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <p class="empty-text">No active prescriptions on file.</p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Pharmacy Preference Quick Box -->
                            <div class="dior-card dior-pharmacy-widget">
                                <div class="pharmacy-widget-head">
                                    <div>
                                        <span class="widget-subtitle">Preferred Pharmacy</span>
                                        <h4 id="dior-disp-pharm-name">
                                            <?php echo esc_html(!empty($profile['pharmacy_name']) ? $profile['pharmacy_name'] : 'None selected'); ?>
                                        </h4>
                                    </div>
                                    <button type="button" class="dior-btn-change-pharmacy"
                                        onclick="diorOpenModal('modal-change-pharmacy')">
                                        <i class="fa-solid fa-pen-to-square"></i> Change
                                    </button>
                                </div>
                                <div class="pharmacy-widget-body">
                                    <p><i class="fa-solid fa-location-dot"></i>
                                        <span
                                            id="dior-disp-pharm-addr"><?php echo esc_html(!empty($profile['pharmacy_address']) ? $profile['pharmacy_address'] : 'No pharmacy address on file'); ?></span>
                                    </p>
                                    <p><i class="fa-solid fa-phone"></i>
                                        <span
                                            id="dior-disp-pharm-phone"><?php echo esc_html(!empty($profile['pharmacy_phone']) ? $profile['pharmacy_phone'] : '—'); ?></span>
                                    </p>
                                </div>
                            </div>

                        </div>

                    </div>

                </section>


                <!-- ============================================================== -->
                <!-- 1. PROFILE & ELIGIBILITY TAB -->
                <!-- ============================================================== -->
                <section class="dior-tab-panel" id="tab-profile">
                    <div class="dior-page-header-box">
                        <div>
                            <h2>Patient Profile & Account Settings</h2>
                            <p>Manage your contact details, emergency contacts, preferred pharmacy, and account
                                security.
                            </p>
                        </div>
                        <div class="dior-eligibility-badge-pill">
                            <i class="fa-solid fa-shield-check"></i> Verified 18+ Telehealth Patient
                        </div>
                    </div>

                    <div class="dior-grid-2-1">

                        <!-- Left: Profile Edit Form -->
                        <div class="dior-card">
                            <div class="dior-card-header">
                                <h3><i class="fa-regular fa-user"></i> Personal Information</h3>
                            </div>
                            <div class="dior-card-body">
                                <form id="dior-form-patient-profile" class="dior-portal-form">

                                    <div class="dior-form-row-2">
                                        <div class="dior-form-group">
                                            <label for="prof_first_name">First Name <span class="req">*</span></label>
                                            <input type="text" id="prof_first_name" name="first_name"
                                                value="<?php echo esc_attr($profile['first_name']); ?>" required>
                                        </div>
                                        <div class="dior-form-group">
                                            <label for="prof_last_name">Last Name <span class="req">*</span></label>
                                            <input type="text" id="prof_last_name" name="last_name"
                                                value="<?php echo esc_attr($profile['last_name']); ?>" required>
                                        </div>
                                    </div>

                                    <div class="dior-form-row-2">
                                        <div class="dior-form-group">
                                            <label for="prof_email">Email Address <span class="req">*</span></label>
                                            <input type="email" id="prof_email" name="email"
                                                value="<?php echo esc_attr($profile['email']); ?>" required>
                                        </div>
                                        <div class="dior-form-group">
                                            <label for="prof_phone">Phone Number <span class="req">*</span></label>
                                            <input type="tel" id="prof_phone" name="phone"
                                                value="<?php echo esc_attr($profile['phone']); ?>" required>
                                        </div>
                                    </div>

                                    <div class="dior-form-row-2">
                                        <div class="dior-form-group">
                                            <label for="prof_dob">Date of Birth <span class="req">*</span></label>
                                            <input type="date" id="prof_dob" name="dob"
                                                value="<?php echo esc_attr($profile['dob']); ?>" required>
                                        </div>
                                        <div class="dior-form-group">
                                            <label for="prof_gender">Gender / Sex at Birth <span
                                                    class="req">*</span></label>
                                            <select id="prof_gender" name="gender" required>
                                                <option value="Female" <?php selected($profile['gender'], 'Female'); ?>>
                                                    Female</option>
                                                <option value="Male" <?php selected($profile['gender'], 'Male'); ?>>Male
                                                </option>
                                                <option value="Other / Non-Binary" <?php selected($profile['gender'], 'Other / Non-Binary'); ?>>Other / Non-Binary</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="dior-form-group">
                                        <label for="prof_address">Mailing / Physical Address <span
                                                class="req">*</span></label>
                                        <input type="text" id="prof_address" name="address"
                                            value="<?php echo esc_attr($profile['address']); ?>"
                                            placeholder="Street, City, State, ZIP" required>
                                    </div>

                                    <!-- Emergency Contact Section -->
                                    <div class="dior-form-divider">
                                        <h4><i class="fa-solid fa-phone-volume"></i> Emergency Contact</h4>
                                    </div>

                                    <div class="dior-form-row-3">
                                        <div class="dior-form-group">
                                            <label for="prof_em_name">Contact Name</label>
                                            <input type="text" id="prof_em_name" name="emergency_name"
                                                value="<?php echo esc_attr($profile['emergency_name']); ?>">
                                        </div>
                                        <div class="dior-form-group">
                                            <label for="prof_em_rel">Relationship</label>
                                            <input type="text" id="prof_em_rel" name="emergency_relation"
                                                value="<?php echo esc_attr($profile['emergency_relation']); ?>"
                                                placeholder="e.g. Spouse, Parent">
                                        </div>
                                        <div class="dior-form-group">
                                            <label for="prof_em_phone">Emergency Phone</label>
                                            <input type="tel" id="prof_em_phone" name="emergency_phone"
                                                value="<?php echo esc_attr($profile['emergency_phone']); ?>">
                                        </div>
                                    </div>

                                    <!-- Preferred Pharmacy Section -->
                                    <div class="dior-form-divider">
                                        <h4><i class="fa-solid fa-store"></i> Preferred Local Pharmacy</h4>
                                    </div>

                                    <div class="dior-form-row-2">
                                        <div class="dior-form-group">
                                            <label for="prof_pharmacy_name">Pharmacy Name</label>
                                            <input type="text" id="prof_pharmacy_name" name="pharmacy_name"
                                                value="<?php echo esc_attr($profile['pharmacy_name']); ?>">
                                        </div>
                                        <div class="dior-form-group">
                                            <label for="prof_pharmacy_phone">Pharmacy Phone</label>
                                            <input type="tel" id="prof_pharmacy_phone" name="pharmacy_phone"
                                                value="<?php echo esc_attr($profile['pharmacy_phone']); ?>">
                                        </div>
                                    </div>
                                    <div class="dior-form-group">
                                        <label for="prof_pharmacy_address">Pharmacy Address</label>
                                        <input type="text" id="prof_pharmacy_address" name="pharmacy_address"
                                            value="<?php echo esc_attr($profile['pharmacy_address']); ?>">
                                    </div>

                                    <div class="dior-form-submit-row">
                                        <button type="submit" class="dior-btn-gold-primary" id="dior-save-profile-btn">
                                            <i class="fa-solid fa-floppy-disk"></i> Save Profile Changes
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <!-- Right: Read-Only Eligibility Snapshot & Security -->
                        <div class="dior-profile-sidebar-col">

                            <!-- Eligibility Snapshot Card (Read Only Display) -->
                            <div class="dior-card dior-eligibility-snapshot-card">
                                <div class="dior-card-header">
                                    <h3><i class="fa-solid fa-shield-halved"></i> Telehealth Eligibility Snapshot</h3>
                                </div>
                                <div class="dior-card-body">
                                    <div class="snapshot-notice">
                                        <i class="fa-solid fa-lock"></i>
                                        <span>This verified eligibility snapshot is locked for medical & legal
                                            compliance.</span>
                                    </div>

                                    <div class="snapshot-list">
                                        <div class="snapshot-item">
                                            <div class="snap-icon ok"><i class="fa-solid fa-check"></i></div>
                                            <div class="snap-info">
                                                <strong>Age Requirement</strong>
                                                <span>18+ Years Old (Adult Care Verified)</span>
                                            </div>
                                        </div>

                                        <div class="snapshot-item">
                                            <div class="snap-icon ok"><i class="fa-solid fa-check"></i></div>
                                            <div class="snap-info">
                                                <strong>Pregnancy Status</strong>
                                                <span><?php echo esc_html($profile['pregnancy_status']); ?></span>
                                            </div>
                                        </div>

                                        <div class="snapshot-item">
                                            <div class="snap-icon ok"><i class="fa-solid fa-check"></i></div>
                                            <div class="snap-info">
                                                <strong>Jurisdiction & Service Area</strong>
                                                <span><?php echo esc_html($profile['state_eligible']); ?></span>
                                            </div>
                                        </div>

                                        <div class="snapshot-item">
                                            <div class="snap-icon ok"><i class="fa-solid fa-check"></i></div>
                                            <div class="snap-info">
                                                <strong>HIPAA Consent Status</strong>
                                                <span>Active Electronic Agreement Signed</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Account Security Card -->
                            <div class="dior-card">
                                <div class="dior-card-header">
                                    <h3><i class="fa-solid fa-key"></i> Account Security</h3>
                                </div>
                                <div class="dior-card-body">
                                    <form id="dior-form-change-password" class="dior-portal-form">
                                        <div class="dior-form-group">
                                            <label for="sec_current_pwd">Current Password</label>
                                            <input type="password" id="sec_current_pwd" name="current_password"
                                                placeholder="Enter current password" required>
                                        </div>
                                        <div class="dior-form-group">
                                            <label for="sec_new_pwd">New Password</label>
                                            <input type="password" id="sec_new_pwd" name="new_password"
                                                placeholder="Min 6 characters" required>
                                        </div>
                                        <div class="dior-form-group">
                                            <label for="sec_confirm_pwd">Confirm New Password</label>
                                            <input type="password" id="sec_confirm_pwd" name="confirm_password"
                                                placeholder="Repeat new password" required>
                                        </div>
                                        <button type="submit" class="dior-btn-gold-secondary" style="width:100%;">
                                            <i class="fa-solid fa-lock"></i> Update Password
                                        </button>
                                    </form>
                                </div>
                            </div>

                        </div>

                    </div>
                </section>


                <!-- ============================================================== -->
                <!-- 2. APPOINTMENTS TAB -->
                <!-- ============================================================== -->
                <section class="dior-tab-panel" id="tab-appointments">

                    <div class="dior-page-header-box">
                        <div>
                            <h2>Your Telehealth Appointments</h2>
                            <p>Schedule new visits, join live virtual exam rooms (Zoom Video), and review past
                                clinical
                                visits.</p>
                        </div>
                        <button type="button" class="dior-btn-gold-primary" data-switch-tab="questionnaire">
                            <i class="fa-solid fa-plus"></i> Book New Appointment
                        </button>
                    </div>

                    <!-- Appointments Filter Bar -->
                    <div class="dior-filter-toolbar">
                        <div class="filter-tab-pills">
                            <button type="button" class="dior-filter-tab active" data-filter-status="all">All
                                Appointments</button>
                            <button type="button" class="dior-filter-tab" data-filter-status="upcoming">Upcoming &
                                Live</button>
                            <button type="button" class="dior-filter-tab" data-filter-status="completed">Past
                                History</button>
                        </div>
                        <div class="filter-search-box">
                            <i class="fa-solid fa-magnifying-glass"></i>
                            <input type="text" id="dior-search-appointments-input"
                                placeholder="Search visits, symptoms, doctor...">
                        </div>
                    </div>

                    <!-- Appointments List Card -->
                    <div class="dior-card">
                        <div class="dior-card-body p-0">
                            <div class="dior-table-responsive">
                                <table class="dior-table" id="dior-patient-appointments-table"
                                    style="width:100%;border-collapse:collapse;">
                                    <thead>
                                        <tr>
                                            <th style="padding-left:24px !important;">Date & Time</th>
                                            <th>Condition / Reason</th>
                                            <th>Assigned Provider</th>
                                            <th>Visit Mode</th>
                                            <th>Status</th>
                                            <th style="padding-right:24px !important;text-align:right;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($appointments as $apt):
                                            $apt_st = $apt['status'] ?? ($apt['appt_status'] ?? 'Confirmed');
                                            $is_upcoming = in_array($apt_st, ['Confirmed', 'Scheduled', 'In-Queue']);
                                            $status_class = $apt_st === 'Confirmed' || $apt_st === 'Completed' ? 'ok' : ($apt_st === 'Cancelled' ? 'ca' : 'up');
                                            $apt_id = $apt['id'] ?? ($apt['appt_uid'] ?? '');
                                            $apt_date = $apt['date'] ?? ($apt['appt_date'] ?? '');
                                            $apt_time = $apt['time'] ?? ($apt['appt_time'] ?? '');
                                            $apt_cond = $apt['condition'] ?? ($apt['condition_name'] ?? 'Telehealth Consultation');
                                            $apt_prov = $apt['provider'] ?? ($apt['doctor_name'] ?? 'Attending Physician');
                                            $apt_type = $apt['type'] ?? ($apt['visit_type'] ?? 'Video Visit');
                                            ?>
                                        <tr class="dior-appt-row"
                                            data-status="<?php echo $is_upcoming ? 'upcoming' : 'completed'; ?>"
                                            data-id="<?php echo esc_attr($apt_id); ?>">
                                            <td style="padding-left:24px !important;">
                                                <div class="table-date-cell">
                                                    <strong><?php echo esc_html($apt_date); ?></strong>
                                                    <span><i class="fa-regular fa-clock"></i>
                                                        <?php echo esc_html($apt_time); ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="table-condition-cell">
                                                    <strong><?php echo esc_html($apt_cond); ?></strong>
                                                    <?php if (!empty($apt['notes'])): ?>
                                                    <span
                                                        class="table-subtext"><?php echo esc_html(wp_trim_words($apt['notes'], 8)); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="table-provider-cell">
                                                    <strong><?php echo esc_html($apt_prov); ?></strong>
                                                    <span><?php echo esc_html($apt['provider_spec'] ?? 'Urgent Care Physician'); ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="table-mode-pill">
                                                    <i
                                                        class="fa-solid <?php echo strpos($apt_type, 'Video') !== false ? 'fa-video' : 'fa-phone'; ?>"></i>
                                                    <?php echo esc_html($apt_type); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="dior-st <?php echo esc_attr($status_class); ?>">
                                                    <?php echo esc_html($apt_st); ?>
                                                </span>
                                            </td>
                                            <td style="padding-right:24px !important;text-align:right;">
                                                <div class="table-actions-cell" style="justify-content:flex-end; gap:6px; flex-wrap:nowrap;">
                                                    <button type="button" class="dior-btn-table-icon"
                                                        title="View Appointment Detail"
                                                        style="display:inline-flex;align-items:center;gap:5px;padding:6px 12px;height:28px;box-sizing:border-box;background:#1A528E;color:#FFFFFF;border-radius:6px;border:none;cursor:pointer;font-weight:600;font-size:11.5px;white-space:nowrap;line-height:1;transition:all 0.15s ease;"
                                                        onclick="diorViewAppointmentDetails('<?php echo esc_js($apt['id'] ?? $apt_id); ?>')">
                                                        <i class="fa-solid fa-file-waveform"></i> Detail
                                                    </button>
                                                    <?php if ($is_upcoming):
                                                        $apt_zoom_url = 'https://zoom.us/join';
                                                        if (!empty($apt['join_url']) && strpos($apt['join_url'], 'doxy.me') === false) {
                                                            $apt_zoom_url = $apt['join_url'];
                                                        } elseif (!empty($apt['doctor_user_id'])) {
                                                            $doc_zoom = get_user_meta($apt['doctor_user_id'], 'doctor_zoom_link', true);
                                                            if (!empty($doc_zoom)) {
                                                                $apt_zoom_url = $doc_zoom;
                                                            }
                                                        }
                                                        ?>
                                                    <a href="<?php echo esc_url($apt_zoom_url); ?>" target="_blank"
                                                        rel="noopener noreferrer" class="dior-btn-table-join"
                                                        title="Join Zoom Video Visit">
                                                        <i class="fa-solid fa-video"></i> Join Visit
                                                    </a>
                                                    <button type="button" class="dior-btn-table-icon"
                                                        title="Reschedule Visit"
                                                        onclick="diorOpenRescheduleModal('<?php echo esc_js($apt['id']); ?>')">
                                                        <i class="fa-regular fa-calendar-days"></i>
                                                    </button>
                                                    <button type="button" class="dior-btn-table-icon danger"
                                                        title="Cancel Visit"
                                                        onclick="diorOpenCancelModal('<?php echo esc_js($apt['id']); ?>')">
                                                        <i class="fa-solid fa-xmark"></i>
                                                    </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </section>


                <!-- ============================================================== -->
                <!-- 3. PAYMENTS & INVOICES TAB -->
                <!-- ============================================================== -->
                <section class="dior-tab-panel" id="tab-payments">
                    <div class="dior-page-header-box">
                        <div>
                            <h2>Billing, Invoices & Payment History</h2>
                            <p>Secure transparent telehealth billing with Stripe. Download itemized PDF receipts and
                                manage
                                cards on file.</p>
                        </div>
                        <div class="stripe-badge-secure">
                            <i class="fa-brands fa-stripe"></i> Powered by Stripe 256-Bit SSL
                        </div>
                    </div>

                    <!-- Billing Stats Summary Grid -->
                    <div class="dior-stats-grid">
                        <div class="dior-stat-card">
                            <div class="stat-icon gold"><i class="fa-solid fa-receipt"></i></div>
                            <div class="stat-info">
                                <span class="stat-label">Total Visits Settled</span>
                                <strong class="stat-value"><?php echo count($payments); ?> Invoices</strong>
                            </div>
                        </div>

                        <div class="dior-stat-card">
                            <div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div>
                            <div class="stat-info">
                                <span class="stat-label">Outstanding Balance</span>
                                <strong class="stat-value">$0.00</strong>
                            </div>
                        </div>

                        <div class="dior-stat-card">
                            <div class="stat-icon blue"><i class="fa-solid fa-credit-card"></i></div>
                            <div class="stat-info">
                                <span class="stat-label">Default Card on File</span>
                                <strong class="stat-value">Visa •••• 4242</strong>
                            </div>
                        </div>
                    </div>

                    <!-- Payment History Table -->
                    <div class="dior-card">
                        <div class="dior-card-header">
                            <h3><i class="fa-solid fa-clock-rotate-left"></i> Payment & Receipt History</h3>
                        </div>
                        <div class="dior-card-body p-0">
                            <div class="dior-table-responsive">
                                <table class="dior-table" style="width:100%;border-collapse:collapse;">
                                    <thead>
                                        <tr>
                                            <th style="padding-left:24px !important;">Invoice #</th>
                                            <th>Date</th>
                                            <th>Service Description</th>
                                            <th>Provider</th>
                                            <th>Amount</th>
                                            <th>Payment Method</th>
                                            <th>Status</th>
                                            <th style="padding-right:24px !important;text-align:right;">Receipt</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($payments as $pay): ?>
                                        <tr>
                                            <td style="padding-left:24px !important;">
                                                <strong><?php echo esc_html($pay['id']); ?></strong></td>
                                            <td><?php echo esc_html($pay['date']); ?></td>
                                            <td><?php echo esc_html($pay['service']); ?></td>
                                            <td><?php echo esc_html($pay['provider']); ?></td>
                                            <td><strong
                                                    class="amount-text"><?php echo esc_html($pay['amount']); ?></strong>
                                            </td>
                                            <td><span class="card-pill"><i class="fa-brands fa-cc-visa"></i>
                                                    <?php echo esc_html($pay['method']); ?></span></td>
                                            <td><span class="dior-st ok"><?php echo esc_html($pay['status']); ?></span>
                                            </td>
                                            <td style="padding-right:24px !important;text-align:right;">
                                                <button type="button" class="dior-btn-table-icon" title="View Receipt"
                                                    onclick="diorViewReceipt('<?php echo esc_js($pay['id']); ?>', '<?php echo esc_js($pay['amount']); ?>', '<?php echo esc_js($pay['service']); ?>', '<?php echo esc_js($pay['date']); ?>')">
                                                    <i class="fa-solid fa-download"></i> Receipt
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </section>


                <!-- ============================================================== -->
                <!-- 4. DOCS & MEDS (Documents + Prescriptions) TAB -->
                <!-- ============================================================== -->
                <section class="dior-tab-panel" id="tab-docs_meds">
                    <div class="dior-page-header-box">
                        <div>
                            <h2>Medical Documents & Active Prescriptions</h2>
                        </div>
                        <div class="dior-header-action-group">
                            <button type="button" class="dior-btn-gold-secondary"
                                onclick="diorOpenModal('modal-change-pharmacy')">
                                <i class="fa-solid fa-store"></i> Update Pharmacy Preference
                            </button>
                        </div>
                    </div>

                    <!-- Prescriptions Section -->
                    <div class="dior-section-block">
                        <div class="dior-section-header">
                            <div class="sec-title-flex">
                                <h3><i class="fa-solid fa-prescription"></i> Electronic Prescriptions (Rx)</h3>
                                <span class="section-subtext">Directly routed to your preferred pharmacy</span>
                            </div>
                        </div>

                        <div class="dior-card">
                            <div class="dior-card-body p-0">
                                <div class="dior-table-responsive">
                                    <table class="dior-table"
                                        style="width:100%;table-layout:fixed;border-collapse:collapse;">
                                        <thead>
                                            <tr>
                                                <th style="padding-left:24px !important;width:24%;">Medication / Rx #
                                                </th>
                                                <th style="width:22%;">Directions &amp; Dispense</th>
                                                <th style="width:16%;">Prescriber &amp; Date</th>
                                                <th style="width:15%;">Pharmacy Routing</th>
                                                <th style="width:11%;">Status</th>
                                                <th style="padding-right:24px !important;width:12%;text-align:right;">
                                                    Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($prescriptions as $rx):
                                                $med_name = $rx['medication'] ?? $rx['name'] ?? 'Medication';
                                                $dosage_val = $rx['dosage'] ?? $rx['dose'] ?? 'As directed by physician';
                                                $routing_st = $rx['routing_status'] ?? 'Sent to Pharmacy';
                                                $status_cl = !empty($rx['status_class']) ? $rx['status_class'] : 'status-success';
                                                $qty_val = !empty($rx['quantity']) ? $rx['quantity'] : 'As Prescribed';
                                                $refills_val = !empty($rx['refills']) ? $rx['refills'] : '0 Refills Remaining';
                                                $date_val = !empty($rx['date_prescribed']) ? $rx['date_prescribed'] : (!empty($rx['date']) ? $rx['date'] : current_time('M j, Y'));

                                                $doc_val = $rx['prescribed_by'] ?? '';
                                                if (empty($doc_val) || is_numeric($doc_val)) {
                                                    $doc_user = !empty($doc_val) ? get_userdata((int) $doc_val) : null;
                                                    $doc_val = $doc_user ? ('Dr. ' . trim($doc_user->first_name . ' ' . $doc_user->last_name)) : 'Attending Physician';
                                                }

                                                $pharmacy_val = !empty($rx['pharmacy']) ? $rx['pharmacy'] : (!empty($profile['pharmacy_name']) ? $profile['pharmacy_name'] : 'None on file');

                                                $st_lower = strtolower($routing_st);
                                                if (strpos($st_lower, 'ready') !== false || strpos($st_lower, 'pickup') !== false) {
                                                    $badge_icon = 'fa-solid fa-circle-check';
                                                    $badge_bg = '#ECFDF5';
                                                    $badge_color = '#059669';
                                                    $badge_border = '#A7F3D0';
                                                } elseif (strpos($st_lower, 'complete') !== false || strpos($st_lower, 'picked') !== false) {
                                                    $badge_icon = 'fa-solid fa-check-double';
                                                    $badge_bg = '#F1F5F9';
                                                    $badge_color = '#475569';
                                                    $badge_border = '#E2E8F0';
                                                } else {
                                                    $badge_icon = 'fa-solid fa-paper-plane';
                                                    $badge_bg = '#EFF6FF';
                                                    $badge_color = '#2563EB';
                                                    $badge_border = '#BFDBFE';
                                                }
                                                ?>
                                            <tr>
                                                <td style="padding-left:24px !important;">
                                                    <div class="table-doc-cell">
                                                        <div class="doc-icon-badge"
                                                            style="background:#EFF6FF;color:#2C6CB1;">
                                                            <i class="fa-solid fa-prescription-bottle-medical"></i>
                                                        </div>
                                                        <div>
                                                            <strong
                                                                style="color:#0F172A;font-size:13.5px;"><?php echo esc_html($med_name); ?></strong>
                                                            <span
                                                                style="display:inline-block;margin-top:2px;font-size:11.5px;color:#2C6CB1;font-weight:600;">Rx
                                                                #<?php echo esc_html($rx['id']); ?></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div style="font-size:12.5px;color:#334155;line-height:1.4;margin-bottom:4px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;"
                                                        title="<?php echo esc_attr($dosage_val); ?>">
                                                        <?php echo esc_html($dosage_val); ?>
                                                    </div>
                                                    <div
                                                        style="display:flex;align-items:center;gap:8px;font-size:11.5px;">
                                                        <span style="font-weight:600;color:#1E293B;"><i
                                                                class="fa-solid fa-pills"
                                                                style="color:#94A3B8;margin-right:3px;"></i><?php echo esc_html($qty_val); ?></span>
                                                        <span
                                                            style="color:<?php echo (intval($refills_val) > 0 || stripos($refills_val, '1') !== false) ? '#059669' : '#64748B'; ?>;font-weight:600;">
                                                            <i class="fa-solid fa-arrows-rotate"
                                                                style="font-size:10px;margin-right:2px;"></i><?php echo esc_html($refills_val); ?>
                                                        </span>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div style="display:flex;flex-direction:column;gap:2px;">
                                                        <span class="doc-date-val" style="font-size:12.5px;"><i
                                                                class="fa-regular fa-calendar"
                                                                style="margin-right:4px;"></i>
                                                            <?php echo esc_html($date_val); ?></span>
                                                        <span class="doc-author-val"
                                                            style="font-size:12px;color:#64748B;"><i
                                                                class="fa-solid fa-user-doctor"
                                                                style="margin-right:4px;"></i>
                                                            <?php echo esc_html($doc_val); ?></span>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div style="display:flex;flex-direction:column;gap:2px;">
                                                        <span
                                                            style="font-size:12.5px;font-weight:600;color:#1E293B;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:160px;"
                                                            title="<?php echo esc_attr($pharmacy_val); ?>">
                                                            <i class="fa-solid fa-store"
                                                                style="color:#2C6CB1;margin-right:4px;"></i>
                                                            <?php echo esc_html($pharmacy_val); ?>
                                                        </span>
                                                        <span style="font-size:11px;color:#059669;font-weight:600;">
                                                            <i class="fa-solid fa-circle-check"
                                                                style="font-size:10px;"></i> Direct e-Transmit
                                                        </span>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span
                                                        style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:12px;font-size:11px;font-weight:700;background:<?php echo $badge_bg; ?>;color:<?php echo $badge_color; ?>;border:1px solid <?php echo $badge_border; ?>;white-space:nowrap;line-height:1.2;">
                                                        <i class="<?php echo esc_attr($badge_icon); ?>"
                                                            style="font-size:10px;"></i>
                                                        <span><?php echo esc_html($routing_st); ?></span>
                                                    </span>
                                                </td>
                                                <td style="padding-right:24px !important;text-align:right;">
                                                    <div
                                                        style="display:inline-flex;gap:5px;align-items:center;justify-content:flex-end;white-space:nowrap;">
                                                        <button type="button" class="dior-btn-table-icon"
                                                            title="View Complete Prescription Details"
                                                            onclick="diorViewRxDetails('<?php echo esc_js($rx['id']); ?>')">
                                                            <i class="fa-solid fa-file-waveform"></i> Detail
                                                        </button>
                                                        <button type="button" class="dior-btn-table-icon"
                                                            title="Download Official PDF"
                                                            onclick="diorDownloadRxPdf('<?php echo esc_js($rx['id']); ?>')">
                                                            <i class="fa-solid fa-file-arrow-down"></i> PDF
                                                        </button>
                                                        <button type="button" class="dior-btn-table-icon"
                                                            title="Request Refill"
                                                            onclick="diorRequestRefill('<?php echo esc_js($rx['id']); ?>')">
                                                            <i class="fa-solid fa-arrows-rotate"></i>
                                                        </button>
                                                    </div>

                                                    <!-- Hidden template for Professional Medical PDF Generation -->
                                                    <div id="rx-pdf-template-<?php echo esc_attr($rx['id']); ?>"
                                                        style="display:none;text-align:left;background:#FFFFFF;color:#0F172A;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;box-sizing:border-box;">
                                                        <div
                                                            style="padding:32px 36px;border:2px solid #2C6CB1;border-radius:12px;background:#FFFFFF;box-sizing:border-box;">

                                                            <!-- HEADER TABLE: CLINIC & LOGO -->
                                                            <table
                                                                style="width:100%;border-collapse:collapse;margin-bottom:20px;border-bottom:2px solid #2C6CB1;padding-bottom:16px;">
                                                                <tr>
                                                                    <td
                                                                        style="width:55%;vertical-align:middle;padding-bottom:16px;">
                                                                        <?php if (!empty($logo_url)): ?>
                                                                        <img src="<?php echo esc_url($logo_url); ?>"
                                                                            alt="Dior Medical"
                                                                            style="max-height:48px;max-width:180px;object-fit:contain;display:block;margin-bottom:6px;">
                                                                        <?php endif; ?>
                                                                        <div
                                                                            style="font-size:18px;font-weight:800;color:#0B1030;letter-spacing:-0.02em;">
                                                                            Dior Medical Telehealth &amp; Urgent Care
                                                                        </div>
                                                                        <div
                                                                            style="font-size:11.5px;color:#64748B;margin-top:2px;">
                                                                            Official Electronic Prescription Document
                                                                            (e-Rx) &bull; Licensure Verified</div>
                                                                    </td>
                                                                    <td
                                                                        style="width:45%;vertical-align:middle;text-align:right;font-size:11px;color:#475569;line-height:1.5;padding-bottom:16px;">
                                                                        <strong
                                                                            style="color:#2C6CB1;font-size:12px;">DEA
                                                                            &bull; NPI Registered Practice</strong><br>
                                                                        Telehealth Service: 24/7 Virtual Clinic<br>
                                                                        Tel: (800) 555-DIOR &bull; Web:
                                                                        www.diormedical.com<br>
                                                                        <span
                                                                            style="display:inline-block;margin-top:4px;padding:2px 8px;background:#ECFDF5;color:#059669;border:1px solid #A7F3D0;border-radius:10px;font-weight:700;font-size:10px;">
                                                                            &check; Surescripts Certified E-Prescription
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                            </table>

                                                            <!-- PATIENT & PRESCRIBER DETAILS TABLE -->
                                                            <table
                                                                style="width:100%;border-collapse:collapse;margin-bottom:20px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;">
                                                                <tr>
                                                                    <!-- Left: Patient Details -->
                                                                    <td
                                                                        style="width:50%;vertical-align:top;padding:14px 16px;border-right:1px solid #E2E8F0;">
                                                                        <div
                                                                            style="font-size:11px;font-weight:800;text-transform:uppercase;color:#2C6CB1;letter-spacing:0.05em;margin-bottom:8px;border-bottom:1px solid #E2E8F0;padding-bottom:4px;">
                                                                            Patient Information
                                                                        </div>
                                                                        <table
                                                                            style="width:100%;border-collapse:collapse;font-size:12px;line-height:1.6;">
                                                                            <tr>
                                                                                <td
                                                                                    style="width:35%;color:#64748B;font-weight:600;">
                                                                                    Full Name:</td>
                                                                                <td
                                                                                    style="color:#0F172A;font-weight:700;">
                                                                                    <?php echo esc_html($profile['full_name']); ?>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td
                                                                                    style="color:#64748B;font-weight:600;">
                                                                                    Patient ID:</td>
                                                                                <td
                                                                                    style="color:#0F172A;font-weight:700;">
                                                                                    <?php echo esc_html($profile['patient_id']); ?>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td
                                                                                    style="color:#64748B;font-weight:600;">
                                                                                    DOB / Age:</td>
                                                                                <td style="color:#0F172A;">
                                                                                    <?php echo !empty($profile['dob']) ? esc_html($profile['dob']) : '10/14/1988'; ?>
                                                                                    (Adult)</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td
                                                                                    style="color:#64748B;font-weight:600;">
                                                                                    Phone:</td>
                                                                                <td style="color:#0F172A;">
                                                                                    <?php echo !empty($profile['phone']) ? esc_html($profile['phone']) : '(555) 392-8192'; ?>
                                                                                </td>
                                                                            </tr>
                                                                        </table>
                                                                    </td>

                                                                    <!-- Right: Prescriber & Rx Details -->
                                                                    <td
                                                                        style="width:50%;vertical-align:top;padding:14px 16px;">
                                                                        <div
                                                                            style="font-size:11px;font-weight:800;text-transform:uppercase;color:#2C6CB1;letter-spacing:0.05em;margin-bottom:8px;border-bottom:1px solid #E2E8F0;padding-bottom:4px;">
                                                                            Prescriber &amp; Rx Order
                                                                        </div>
                                                                        <table
                                                                            style="width:100%;border-collapse:collapse;font-size:12px;line-height:1.6;">
                                                                            <tr>
                                                                                <td
                                                                                    style="width:40%;color:#64748B;font-weight:600;">
                                                                                    Physician:</td>
                                                                                <td
                                                                                    style="color:#0F172A;font-weight:700;">
                                                                                    <?php echo esc_html($doc_val); ?>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td
                                                                                    style="color:#64748B;font-weight:600;">
                                                                                    NPI / DEA:</td>
                                                                                <td style="color:#0F172A;">NPI:
                                                                                    1849201948 &bull; DEA: MV8492019
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td
                                                                                    style="color:#64748B;font-weight:600;">
                                                                                    Rx Number:</td>
                                                                                <td
                                                                                    style="color:#2C6CB1;font-weight:800;">
                                                                                    Rx
                                                                                    #<?php echo esc_html($rx['id']); ?>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td
                                                                                    style="color:#64748B;font-weight:600;">
                                                                                    Date Issued:</td>
                                                                                <td
                                                                                    style="color:#0F172A;font-weight:700;">
                                                                                    <?php echo esc_html($date_val); ?>
                                                                                </td>
                                                                            </tr>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </table>

                                                            <!-- PRESCRIPTION MEDICATION TABLE -->
                                                            <div
                                                                style="font-size:12px;font-weight:800;color:#0B1030;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px;">
                                                                <span
                                                                    style="font-size:16px;color:#2C6CB1;font-style:italic;margin-right:4px;">&rx;</span>
                                                                Prescribed Medication Details
                                                            </div>
                                                            <table
                                                                style="width:100%;border-collapse:collapse;margin-bottom:20px;border:1px solid #CBD5E1;">
                                                                <thead>
                                                                    <tr
                                                                        style="background:#2C6CB1;color:#FFFFFF;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;">
                                                                        <th style="padding:10px 12px;width:35%;">
                                                                            Medication &amp; Strength</th>
                                                                        <th style="padding:10px 12px;width:35%;">
                                                                            Directions / Sig</th>
                                                                        <th style="padding:10px 12px;width:15%;">
                                                                            Quantity</th>
                                                                        <th style="padding:10px 12px;width:15%;">Refills
                                                                        </th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <tr
                                                                        style="background:#FFFFFF;border-bottom:1px solid #E2E8F0;font-size:12.5px;">
                                                                        <td style="padding:12px;vertical-align:top;">
                                                                            <strong
                                                                                style="color:#0F172A;font-size:14px;display:block;"><?php echo esc_html($med_name); ?></strong>
                                                                            <span
                                                                                style="font-size:11px;color:#64748B;">Oral
                                                                                Medication &bull; Brand / Generic
                                                                                Equivalent</span>
                                                                        </td>
                                                                        <td
                                                                            style="padding:12px;vertical-align:top;color:#334155;line-height:1.4;">
                                                                            <strong><?php echo esc_html($dosage_val); ?></strong>
                                                                        </td>
                                                                        <td
                                                                            style="padding:12px;vertical-align:top;font-weight:700;color:#0F172A;">
                                                                            <?php echo esc_html($qty_val); ?>
                                                                        </td>
                                                                        <td
                                                                            style="padding:12px;vertical-align:top;font-weight:700;color:#059669;">
                                                                            <?php echo esc_html($refills_val); ?>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                            <!-- PHARMACY ROUTING BOX TABLE -->
                                                            <table
                                                                style="width:100%;border-collapse:collapse;margin-bottom:24px;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;">
                                                                <tr>
                                                                    <td
                                                                        style="padding:12px 16px;vertical-align:middle;">
                                                                        <strong
                                                                            style="color:#1E40AF;font-size:12px;display:block;margin-bottom:2px;">Designated
                                                                            Dispensing Pharmacy:</strong>
                                                                        <span
                                                                            style="color:#0F172A;font-size:13px;font-weight:700;"><?php echo esc_html($pharmacy_val); ?></span>
                                                                        <span
                                                                            style="display:inline-block;margin-left:8px;font-size:11px;color:#059669;font-weight:600;">&bull;
                                                                            Direct Electronic NCPDP Dispatch</span>
                                                                    </td>
                                                                    <td
                                                                        style="padding:12px 16px;text-align:right;vertical-align:middle;font-size:11px;color:#1E40AF;font-weight:700;">
                                                                        Substitution Permissible (DAW-0)
                                                                    </td>
                                                                </tr>
                                                            </table>

                                                            <!-- PHYSICIAN SIGNATURE & FOOTER TABLE -->
                                                            <table
                                                                style="width:100%;border-collapse:collapse;margin-top:16px;padding-top:14px;border-top:1px solid #E2E8F0;">
                                                                <tr>
                                                                    <td
                                                                        style="width:60%;vertical-align:bottom;font-size:10.5px;color:#64748B;line-height:1.4;">
                                                                        <strong>Legal E-Prescribing Notice:</strong><br>
                                                                        This prescription was electronically verified,
                                                                        generated, and digitally signed in compliance
                                                                        with DEA 21 CFR Part 1311 and state telemedicine
                                                                        medical board requirements.
                                                                    </td>
                                                                    <td
                                                                        style="width:40%;vertical-align:bottom;text-align:right;">
                                                                        <div
                                                                            style="font-family:'Courier New',Courier,monospace;font-size:14px;color:#0F172A;font-weight:700;border-bottom:1px solid #0F172A;display:inline-block;padding-bottom:2px;margin-bottom:4px;">
                                                                            /s/ <?php echo esc_html($doc_val); ?>
                                                                        </div>
                                                                        <div
                                                                            style="font-size:11px;color:#64748B;font-weight:600;">
                                                                            Digitally Verified Telehealth Signature
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            </table>

                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Medical Documents Section -->
                    <div class="dior-section-block">
                        <div class="dior-section-header">
                            <div class="sec-title-flex">
                                <h3><i class="fa-solid fa-folder-open"></i> Clinical Records & E-Signed Files</h3>
                                <span class="section-subtext">Downloadable PDFs for work/school excuses and
                                    summaries</span>
                            </div>
                        </div>

                        <div class="dior-card">
                            <div class="dior-card-body p-0">
                                <div class="dior-table-responsive">
                                    <table class="dior-table" style="width:100%;border-collapse:collapse;">
                                        <thead>
                                            <tr>
                                                <th
                                                    style="padding-left:28px !important;padding-top:14px !important;padding-bottom:14px !important;">
                                                    Document Name</th>
                                                <th style="padding:14px 16px !important;">Category</th>
                                                <th style="padding:14px 16px !important;">Date Issued</th>
                                                <th style="padding:14px 16px !important;">Issued By</th>
                                                <th style="padding:14px 16px !important;">File Format</th>
                                                <th
                                                    style="padding-right:28px !important;padding-top:14px !important;padding-bottom:14px !important;text-align:right;">
                                                    Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($documents as $doc): ?>
                                            <tr>
                                                <td
                                                    style="padding-left:28px !important;padding-top:16px !important;padding-bottom:16px !important;">
                                                    <div class="table-doc-cell">
                                                        <div class="doc-icon-badge"
                                                            style="background:#FEF2F2;color:#DC2626;">
                                                            <i class="fa-regular fa-file-pdf"></i>
                                                        </div>
                                                        <div>
                                                            <strong
                                                                style="color:#0F172A;font-size:13.5px;"><?php echo esc_html($doc['title']); ?></strong>
                                                            <span
                                                                style="display:inline-block;margin-top:2px;font-size:11.5px;color:#64748B;">Doc
                                                                ID: <?php echo esc_html($doc['id']); ?></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td style="padding:16px 16px !important;"><span
                                                        class="doc-cat-pill"><?php echo esc_html($doc['category']); ?></span>
                                                </td>
                                                <td style="padding:16px 16px !important;"><span class="doc-date-val"><i
                                                            class="fa-regular fa-calendar"></i>
                                                        <?php echo esc_html($doc['date']); ?></span></td>
                                                <td style="padding:16px 16px !important;"><span
                                                        class="doc-author-val"><i class="fa-solid fa-user-doctor"></i>
                                                        <?php echo esc_html($doc['author']); ?></span></td>
                                                <td style="padding:16px 16px !important;"><strong
                                                        class="doc-format-badge"><?php echo esc_html($doc['file_type']); ?>
                                                        (<?php echo esc_html($doc['size']); ?>)</strong></td>
                                                <td
                                                    style="padding-right:28px !important;padding-top:16px !important;padding-bottom:16px !important;text-align:right;">
                                                    <button type="button" class="dior-btn-table-icon"
                                                        title="View Document"
                                                        onclick="diorViewDocumentModal('<?php echo esc_js($doc['title']); ?>', '<?php echo esc_js($doc['category']); ?>', '<?php echo esc_js($doc['author']); ?>', '<?php echo esc_js($doc['date']); ?>', '<?php echo esc_js($doc['id'] ?? 'DOC-88219'); ?>')">
                                                        <i class="fa-solid fa-eye"></i> View PDF
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </section>


                <!-- ============================================================== -->
                <!-- 5. MEDICAL QUESTIONNAIRE TAB -->
                <!-- ============================================================== -->
                <section class="dior-tab-panel" id="tab-questionnaire">
                    <div class="dior-page-header-box">
                        <div>
                            <h2>Clinical Intake & Medical Questionnaires</h2>
                        </div>
                                  <!-- Official HIPAAtizer Questionnaire Embed Card -->
                    <div class="dior-section-block" style="margin-bottom: 28px;">
                        <?php 
                        $has_intake = !empty($hipaa_intake) && is_array($hipaa_intake);
                        ?>

                        <?php if ($has_intake): ?>
                        <!-- ✅ Top Status Banner When Intake is Completed -->
                        <div class="dior-intake-completed-notice" id="dior-intake-completed-notice" style="background:#ECFDF5; border:1.5px solid #A7F3D0; border-radius:12px; padding:16px 20px; margin-bottom:20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:14px; box-shadow:0 4px 12px rgba(5,150,105,0.08);">
                            <div style="display:flex; align-items:center; gap:14px;">
                                <div style="width:42px; height:42px; border-radius:50%; background:#059669; color:#fff; display:flex; align-items:center; justify-content:center; font-size:18px;">
                                    <i class="fa-solid fa-circle-check"></i>
                                </div>
                                <div>
                                    <strong style="color:#065F46; font-size:15px; display:block;">Clinical Intake Questionnaire Completed</strong>
                                    <span style="color:#047857; font-size:13px;">Submitted on <?php echo esc_html(date('M j, Y g:i A', strtotime($hipaa_intake['submitted_at'] ?? 'now'))); ?> &bull; Data verified &amp; ready for physician review</span>
                                </div>
                            </div>
                            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                                <button type="button" class="dior-btn-gold-secondary" onclick="diorToggleIntakeReview()" style="font-size:12.5px; padding:7px 14px; background:#FFFFFF; border:1px solid #CBD5E1; color:#1E293B;">
                                    <i class="fa-solid fa-file-medical"></i> <span id="toggle-intake-btn-text">View Submitted Answers</span>
                                </button>
                                <button type="button" class="dior-btn-gold-secondary" onclick="diorReopenHipaaForm()" style="font-size:12.5px; padding:7px 14px; background:#FFFFFF; border:1px solid #CBD5E1; color:#1E293B;">
                                    <i class="fa-solid fa-arrows-rotate"></i> Re-open Questionnaire
                                </button>
                            </div>
                        </div>
                        <?php else: ?>
                        <!-- ℹ️ Step 1 Guidance Banner When Intake Is NOT Yet Completed -->
                        <div class="dior-intake-step-notice" id="dior-intake-step-notice" style="background:#EFF6FF; border:1.5px solid #BFDBFE; border-radius:12px; padding:16px 20px; margin-bottom:20px; display:flex; align-items:center; gap:14px; box-shadow:0 4px 12px rgba(44,108,177,0.08);">
                            <div style="width:42px; height:42px; border-radius:50%; background:#2C6CB1; color:#fff; display:flex; align-items:center; justify-content:center; font-size:18px;">
                                <i class="fa-solid fa-clipboard-question"></i>
                            </div>
                            <div>
                                <strong style="color:#1E3A8A; font-size:15px; display:block;">Step 1 of 2: Complete Your Clinical Intake Questionnaire</strong>
                                <span style="color:#3B82F6; font-size:13px;">Please complete the medical questionnaire below. Once you submit, your <strong>Doctor Scheduling Calendar</strong> will automatically unlock on this page!</span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if ($has_intake): ?>
                        <!-- ✅ Submitted Intake Data Card (Collapsible) -->
                        <div class="dior-card" id="dior-intake-review-card" style="margin-bottom: 24px; border-left: 4px solid #059669; display:none;">
                            <div class="dior-card-header" style="background: #ECFDF5; border-radius: 12px 12px 0 0;">
                                <h3 style="color: #059669;"><i class="fa-solid fa-circle-check"></i> HIPAA Intake Form — Submitted</h3>
                                <span class="dior-st ok"><i class="fa-solid fa-calendar"></i> <?php echo esc_html(date('M j, Y g:i A', strtotime($hipaa_intake['submitted_at']))); ?></span>
                            </div>            </div>
                            <div class="dior-card-body">
                                <div class="dior-form-row-2" style="margin-bottom:12px;">
                                    <div class="dior-profile-field-box">
                                        <span class="pf-label"><i class="fa-solid fa-user"></i> Full Name</span>
                                        <span
                                            class="pf-value"><?php echo esc_html(trim($hipaa_intake['first_name'] . ' ' . $hipaa_intake['last_name'])) ?: '—'; ?></span>
                                    </div>
                                    <div class="dior-profile-field-box">
                                        <span class="pf-label"><i class="fa-solid fa-cake-candles"></i> Date of
                                            Birth</span>
                                        <span
                                            class="pf-value"><?php echo esc_html($hipaa_intake['dob']) ?: '—'; ?></span>
                                    </div>
                                </div>
                                <div class="dior-form-row-2" style="margin-bottom:12px;">
                                    <div class="dior-profile-field-box">
                                        <span class="pf-label"><i class="fa-solid fa-phone"></i> Phone</span>
                                        <span
                                            class="pf-value"><?php echo esc_html($hipaa_intake['phone']) ?: '—'; ?></span>
                                    </div>
                                    <div class="dior-profile-field-box">
                                        <span class="pf-label"><i class="fa-solid fa-envelope"></i> Email</span>
                                        <span
                                            class="pf-value"><?php echo esc_html($hipaa_intake['email']) ?: '—'; ?></span>
                                    </div>
                                </div>
                                <?php if (!empty($hipaa_intake['address'])): ?>
                                <div class="dior-profile-field-box" style="margin-bottom:12px;">
                                    <span class="pf-label"><i class="fa-solid fa-location-dot"></i> Address</span>
                                    <span
                                        class="pf-value"><?php echo esc_html(trim($hipaa_intake['address'] . ' ' . $hipaa_intake['city'] . ' ' . $hipaa_intake['state'] . ' ' . $hipaa_intake['zip'])); ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($hipaa_intake['symptoms'])): ?>
                                <div
                                    style="grid-column:1 / -1;background:#FFFFFF;padding:10px 14px;border-radius:8px;border:1px solid #E2E8F0;margin-bottom:12px;">
                                    <strong style="color:#065F46;display:block;margin-bottom:4px;"><i
                                            class="fa-solid fa-stethoscope"></i> Chief Symptoms / Complaint:</strong>
                                    <span><?php echo nl2br(esc_html($hipaa_intake['symptoms'])); ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($hipaa_intake['allergies'])): ?>
                                <div
                                    style="background:#FFFFFF;padding:10px 14px;border-radius:8px;border:1px solid #E2E8F0;margin-bottom:12px;">
                                    <strong style="color:#DC2626;display:block;margin-bottom:4px;"><i
                                            class="fa-solid fa-triangle-exclamation"></i> Known Allergies:</strong>
                                    <span><?php echo esc_html($hipaa_intake['allergies']); ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($hipaa_intake['medications'])): ?>
                                <div
                                    style="background:#FFFFFF;padding:10px 14px;border-radius:8px;border:1px solid #E2E8F0;margin-bottom:12px;">
                                    <strong style="color:#2563EB;display:block;margin-bottom:4px;"><i
                                            class="fa-solid fa-pills"></i> Current Medications (Legacy):</strong>
                                    <span><?php echo esc_html($hipaa_intake['medications']); ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($hipaa_intake['medical_history'])): ?>
                                <div
                                    style="background:#FFFFFF;padding:10px 14px;border-radius:8px;border:1px solid #E2E8F0;">
                                    <strong style="color:#4B5563;display:block;margin-bottom:4px;"><i
                                            class="fa-solid fa-notes-medical"></i> Medical History (Legacy):</strong>
                                    <span><?php echo nl2br(esc_html($hipaa_intake['medical_history'])); ?></span>
                                </div>
                                <?php endif; ?>

                                <!-- New comprehensive display -->
                                <?php if (!empty($hipaa_intake['service_condition'])): ?>
                                <div class="dior-profile-field-box" style="margin-bottom:12px;">
                                    <span class="pf-label"><i class="fa-solid fa-stethoscope"></i> Service
                                        Condition</span>
                                    <span
                                        class="pf-value"><?php echo esc_html($hipaa_intake['service_condition']); ?></span>
                                </div>
                                <?php endif; ?>

                                <div class="dior-form-row-2" style="margin-bottom:12px;">
                                    <?php if (!empty($hipaa_intake['is_18_plus'])): ?>
                                    <div class="dior-profile-field-box">
                                        <span class="pf-label"><i class="fa-solid fa-user-shield"></i> 18+
                                            Verified</span>
                                        <span
                                            class="pf-value"><?php echo esc_html($hipaa_intake['is_18_plus']); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    <?php if (!empty($hipaa_intake['is_pregnant'])): ?>
                                    <div class="dior-profile-field-box">
                                        <span class="pf-label"><i class="fa-solid fa-baby"></i> Pregnancy Status</span>
                                        <span
                                            class="pf-value"><?php echo esc_html($hipaa_intake['is_pregnant']); ?></span>
                                    </div>
                                    <?php endif; ?>
                                </div>

                                <?php if (!empty($hipaa_intake['symptoms_description'])): ?>
                                <div
                                    style="grid-column:1 / -1;background:#FFFFFF;padding:10px 14px;border-radius:8px;border:1px solid #E2E8F0;margin-bottom:12px;">
                                    <strong style="color:#065F46;display:block;margin-bottom:4px;"><i
                                            class="fa-solid fa-stethoscope"></i> Symptoms Description:</strong>
                                    <span><?php echo nl2br(esc_html($hipaa_intake['symptoms_description'])); ?></span>
                                </div>
                                <?php endif; ?>

                                <div class="dior-form-row-2" style="margin-bottom:12px;">
                                    <?php if (!empty($hipaa_intake['symptom_duration'])): ?>
                                    <div class="dior-profile-field-box">
                                        <span class="pf-label"><i class="fa-solid fa-clock"></i> Duration</span>
                                        <span
                                            class="pf-value"><?php echo esc_html($hipaa_intake['symptom_duration']); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    <?php if (!empty($hipaa_intake['symptom_severity'])): ?>
                                    <div class="dior-profile-field-box">
                                        <span class="pf-label"><i class="fa-solid fa-exclamation-triangle"></i>
                                            Severity</span>
                                        <span
                                            class="pf-value"><?php echo esc_html($hipaa_intake['symptom_severity']); ?></span>
                                    </div>
                                    <?php endif; ?>
                                </div>

                                <?php if (!empty($hipaa_intake['uti_burning_pain']) || !empty($hipaa_intake['uti_frequency'])): ?>
                                <div
                                    style="background:#FEF3C7;border:1px solid #FDE68A;border-radius:8px;padding:12px;margin-bottom:12px;">
                                    <h5 style="margin:0 0 8px;color:#92400E;font-size:14px;"><i
                                            class="fa-solid fa-droplet"></i> UTI Details</h5>
                                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:13px;">
                                        <?php if (!empty($hipaa_intake['uti_burning_pain'])): ?>
                                        <div><strong>Burning/Pain:</strong>
                                            <?php echo esc_html($hipaa_intake['uti_burning_pain']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['uti_frequency'])): ?>
                                        <div><strong>Frequency:</strong>
                                            <?php echo esc_html($hipaa_intake['uti_frequency']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['uti_appearance'])): ?>
                                        <div><strong>Urine Appearance:</strong>
                                            <?php echo esc_html($hipaa_intake['uti_appearance']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['uti_blood'])): ?>
                                        <div><strong>Blood in Urine:</strong>
                                            <?php echo esc_html($hipaa_intake['uti_blood']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['uti_previous'])): ?>
                                        <div><strong>Previous UTI:</strong>
                                            <?php echo esc_html($hipaa_intake['uti_previous']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['uti_last_date'])): ?>
                                        <div style="grid-column:1 / -1;"><strong>Last UTI Date:</strong>
                                            <?php echo esc_html($hipaa_intake['uti_last_date']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($hipaa_intake['allergy_symptoms']) || !empty($hipaa_intake['allergy_triggers'])): ?>
                                <div
                                    style="background:#FEE2E2;border:1px solid #FECACA;border-radius:8px;padding:12px;margin-bottom:12px;">
                                    <h5 style="margin:0 0 8px;color:#991B1B;font-size:14px;"><i
                                            class="fa-solid fa-allergies"></i> Allergy Details</h5>
                                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:13px;">
                                        <?php if (!empty($hipaa_intake['allergy_symptoms'])): ?>
                                        <div style="grid-column:1 / -1;"><strong>Symptoms:</strong>
                                            <?php echo esc_html($hipaa_intake['allergy_symptoms']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['allergy_seasonal'])): ?>
                                        <div><strong>Pattern:</strong>
                                            <?php echo esc_html($hipaa_intake['allergy_seasonal']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['allergy_triggers'])): ?>
                                        <div><strong>Triggers:</strong>
                                            <?php echo esc_html($hipaa_intake['allergy_triggers']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['allergy_medication_taken'])): ?>
                                        <div><strong>Medication Taken:</strong>
                                            <?php echo esc_html($hipaa_intake['allergy_medication_taken']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['allergy_medication_name'])): ?>
                                        <div style="grid-column:1 / -1;"><strong>Medication Name:</strong>
                                            <?php echo esc_html($hipaa_intake['allergy_medication_name']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($hipaa_intake['diagnosed_conditions']) || !empty($hipaa_intake['other_conditions'])): ?>
                                <div
                                    style="background:#DBEAFE;border:1px solid #BFDBFE;border-radius:8px;padding:12px;margin-bottom:12px;">
                                    <h5 style="margin:0 0 8px;color:#1E40AF;font-size:14px;"><i
                                            class="fa-solid fa-notes-medical"></i> Medical History</h5>
                                    <?php if (!empty($hipaa_intake['diagnosed_conditions'])): ?>
                                    <div style="margin-bottom:8px;font-size:13px;"><strong>Diagnosed
                                            Conditions:</strong>
                                        <?php echo esc_html($hipaa_intake['diagnosed_conditions']); ?></div>
                                    <?php endif; ?>
                                    <?php if (!empty($hipaa_intake['other_conditions'])): ?>
                                    <div style="font-size:13px;"><strong>Other Conditions:</strong>
                                        <?php echo nl2br(esc_html($hipaa_intake['other_conditions'])); ?></div>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($hipaa_intake['taking_medications']) || !empty($hipaa_intake['medications_list'])): ?>
                                <div
                                    style="background:#E0E7FF;border:1px solid #C7D2FE;border-radius:8px;padding:12px;margin-bottom:12px;">
                                    <h5 style="margin:0 0 8px;color:#3730A3;font-size:14px;"><i
                                            class="fa-solid fa-pills"></i> Current Medications</h5>
                                    <?php if (!empty($hipaa_intake['taking_medications'])): ?>
                                    <div style="margin-bottom:8px;font-size:13px;"><strong>Taking Medications:</strong>
                                        <?php echo esc_html($hipaa_intake['taking_medications']); ?></div>
                                    <?php endif; ?>
                                    <?php if (!empty($hipaa_intake['medications_list'])): ?>
                                    <div style="font-size:13px;"><strong>Medication List:</strong>
                                        <?php echo nl2br(esc_html($hipaa_intake['medications_list'])); ?></div>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($hipaa_intake['drug_allergies']) || !empty($hipaa_intake['drug_allergies_list'])): ?>
                                <div
                                    style="background:#FEE2E2;border:1px solid #FECACA;border-radius:8px;padding:12px;margin-bottom:12px;">
                                    <h5 style="margin:0 0 8px;color:#991B1B;font-size:14px;"><i
                                            class="fa-solid fa-triangle-exclamation"></i> Drug Allergies</h5>
                                    <?php if (!empty($hipaa_intake['drug_allergies'])): ?>
                                    <div style="margin-bottom:8px;font-size:13px;"><strong>Has Drug Allergies:</strong>
                                        <?php echo esc_html($hipaa_intake['drug_allergies']); ?></div>
                                    <?php endif; ?>
                                    <?php if (!empty($hipaa_intake['drug_allergies_list'])): ?>
                                    <div style="font-size:13px;"><strong>Allergy Details:</strong>
                                        <?php echo nl2br(esc_html($hipaa_intake['drug_allergies_list'])); ?></div>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($hipaa_intake['appointment_type']) || !empty($hipaa_intake['preferred_date'])): ?>
                                <div
                                    style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;padding:12px;margin-bottom:12px;">
                                    <h5 style="margin:0 0 8px;color:#065F46;font-size:14px;"><i
                                            class="fa-solid fa-calendar"></i> Appointment Preferences</h5>
                                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:13px;">
                                        <?php if (!empty($hipaa_intake['appointment_type'])): ?>
                                        <div><strong>Type:</strong>
                                            <?php echo esc_html($hipaa_intake['appointment_type']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['preferred_date'])): ?>
                                        <div><strong>Date:</strong>
                                            <?php echo esc_html($hipaa_intake['preferred_date']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['preferred_time'])): ?>
                                        <div><strong>Time:</strong>
                                            <?php echo esc_html($hipaa_intake['preferred_time']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($hipaa_intake['telemedicine_consent']) || !empty($hipaa_intake['legal_acknowledgement'])): ?>
                                <div
                                    style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:12px;">
                                    <h5 style="margin:0 0 8px;color:#475569;font-size:14px;"><i
                                            class="fa-solid fa-file-signature"></i> Consent & Signature</h5>
                                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:13px;">
                                        <?php if (!empty($hipaa_intake['telemedicine_consent'])): ?>
                                        <div><strong>Telemedicine Consent:</strong>
                                            <?php echo esc_html($hipaa_intake['telemedicine_consent']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['legal_acknowledgement'])): ?>
                                        <div><strong>Legal Acknowledgement:</strong>
                                            <?php echo esc_html($hipaa_intake['legal_acknowledgement']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['full_legal_name'])): ?>
                                        <div style="grid-column:1 / -1;"><strong>Legal Name:</strong>
                                            <?php echo esc_html($hipaa_intake['full_legal_name']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($hipaa_intake['signature_date'])): ?>
                                        <div><strong>Signature Date:</strong>
                                            <?php echo esc_html($hipaa_intake['signature_date']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="dior-hipaa-embed-wrap" id="dior-hipaa-form-container"
                            style="max-width: 100%; margin: 0 auto; background: #FFFFFF; <?php echo $has_intake ? 'display:none;' : ''; ?>">
                            <div class="hipaa-form-container-box"
                                style="background: #FFFFFF; border: none; box-shadow: none; padding: 0; margin: 0;">
                                <iframe id="hipaatizer-intake-iframe"
                                    src="https://app.hipaatizer.com/workflow/01a07aa2-d931-728d-bfe9-8d7b3bc0389d"
                                    style="width: 100%; min-height: 720px; height: 85vh; border: 0; display: block; margin: 0 auto; background: #FFFFFF;"
                                    allow="microphone; camera; payment"
                                    title="HIPAAtizer Clinical Intake &amp; Questionnaire Form">
                                </iframe>
                                <div style="display:none;">
                                    <?php
                                    // Render HIPAAtizer official form if plugin is active
                                    echo do_shortcode('[hipaatizer id="01a065c9-fa38-7265-814c-33216e2a3eda"]');
                                    echo do_shortcode('[hipaatizer id="01a07aa2-d931-728d-bfe9-8d7b3bc0389d"]');
                                    ?>
                                </div>
                            </div>
                        </div>

                        <!-- Step-by-Step Embedded Appointment Booking Wizard (Unlocks automatically after Intake is completed) -->
                        <div class="dior-card dior-in-dashboard-booking-card" id="dior-dashboard-booking-section" style="margin-top:20px; border: 1.5px solid #2C6CB1; box-shadow: 0 10px 32px rgba(44, 108, 177, 0.12); border-radius:14px; overflow:hidden; <?php echo !$has_intake ? 'display:none;' : ''; ?>">
                            <div class="dior-card-header" style="background: linear-gradient(135deg, #0F172A, #1E293B); color: #FFFFFF; padding: 20px 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap:wrap; gap:12px;">
                                <div>
                                    <h3 style="color:#FFFFFF; margin:0; font-size:17px; font-weight:700; display:flex; align-items:center; gap:10px;">
                                        <i class="fa-solid fa-calendar-check" style="color:#D4AF37;"></i>
                                        <span>Step 2: Schedule Telehealth Consultation with Physician</span>
                                    </h3>
                                    <p style="color:#94A3B8; margin:4px 0 0; font-size:13px;">Pre-filled from your intake form. Select your physician &amp; appointment time slot.</p>
                                </div>
                                <span class="dior-badge-luxury" style="background:rgba(212,175,55,0.18); color:#D4AF37; border:1px solid #D4AF37; padding:5px 14px; border-radius:20px; font-size:12px; font-weight:700;">
                                    <i class="fa-solid fa-shield-halved"></i> Intake Data Verified
                                </span>
                            </div>

                            <div class="dior-card-body" style="padding: 24px;">
                                <!-- Wizard Step Pills -->
                                <div class="dior-wizard-steps-indicator" style="display:flex; justify-content:space-between; margin-bottom:24px; position:relative; gap:12px;">
                                    <div class="dior-step-node active" id="wizard-node-1" style="flex:1; background:#F1F5F9; padding:10px 14px; border-radius:8px; display:flex; align-items:center; gap:10px; border-left:3px solid #2C6CB1;">
                                        <span class="step-num" style="width:24px; height:24px; border-radius:50%; background:#2C6CB1; color:#fff; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:700;">1</span>
                                        <span class="step-lbl" style="font-weight:700; font-size:13px; color:#0F172A;">Select Physician</span>
                                    </div>
                                    <div class="dior-step-node" id="wizard-node-2" style="flex:1; background:#F8FAFC; padding:10px 14px; border-radius:8px; display:flex; align-items:center; gap:10px; border:1px solid #E2E8F0;">
                                        <span class="step-num" style="width:24px; height:24px; border-radius:50%; background:#E2E8F0; color:#64748B; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:700;">2</span>
                                        <span class="step-lbl" style="font-weight:600; font-size:13px; color:#64748B;">Date &amp; Time Slot</span>
                                    </div>
                                    <div class="dior-step-node" id="wizard-node-3" style="flex:1; background:#F8FAFC; padding:10px 14px; border-radius:8px; display:flex; align-items:center; gap:10px; border:1px solid #E2E8F0;">
                                        <span class="step-num" style="width:24px; height:24px; border-radius:50%; background:#E2E8F0; color:#64748B; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:700;">3</span>
                                        <span class="step-lbl" style="font-weight:600; font-size:13px; color:#64748B;">Confirm &amp; Book</span>
                                    </div>
                                </div>

                                <!-- Pre-filled Patient Intake Summary Banner -->
                                <?php
                                $pat_name = !empty($profile['full_name']) ? $profile['full_name'] : ($current_user && !empty($current_user->display_name) ? $current_user->display_name : 'Patient');
                                $pat_email = !empty($profile['email']) ? $profile['email'] : ($current_user && !empty($current_user->user_email) ? $current_user->user_email : '');
                                $pat_phone = !empty($profile['phone']) ? $profile['phone'] : ($hipaa_intake['phone'] ?? 'Phone on file');
                                $pat_service = !empty($hipaa_intake['service_condition']) ? $hipaa_intake['service_condition'] : (!empty($hipaa_intake['symptoms']) ? $hipaa_intake['symptoms'] : 'Telehealth Urgent Care');
                                ?>
                                <div class="dior-intake-prefill-banner" style="background:#F8FAFC; border:1px solid #CBD5E1; border-radius:12px; padding:16px 20px; margin-bottom:24px; display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:16px;">
                                    <div style="display:flex; align-items:center; gap:14px;">
                                        <div style="width:44px; height:44px; border-radius:12px; background:linear-gradient(135deg, #1A528E 0%, #2C6CB1 100%); color:#ffffff; display:flex; align-items:center; justify-content:center; font-size:18px; flex-shrink:0; box-shadow:0 4px 12px rgba(26,82,142,0.2);">
                                            <i class="fa-solid fa-user-check"></i>
                                        </div>
                                        <div>
                                            <strong style="color:#0F172A; font-size:15px; font-weight:700; display:block; line-height:1.3;"><?php echo esc_html($pat_name); ?></strong>
                                            <span style="color:#64748B; font-size:13px; line-height:1.4; display:block; margin-top:2px;">
                                                <?php if (!empty($pat_email)): ?>
                                                    <?php echo esc_html($pat_email); ?> &bull; 
                                                <?php endif; ?>
                                                <?php echo esc_html($pat_phone); ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div style="background:#FFFFFF; border:1.5px solid #E2E8F0; padding:8px 16px; border-radius:10px; font-size:13px; color:#0F172A; display:flex; align-items:center; gap:10px; box-shadow:0 2px 6px rgba(15,23,42,0.04);">
                                        <div style="width:32px; height:32px; border-radius:8px; background:#EFF6FF; color:#2C6CB1; display:flex; align-items:center; justify-content:center; font-size:14px; flex-shrink:0;">
                                            <i class="fa-solid fa-stethoscope"></i>
                                        </div>
                                        <div>
                                            <span style="color:#64748B; font-size:11px; display:block; text-transform:uppercase; font-weight:700; letter-spacing:0.04em;">Service / Reason</span>
                                            <strong style="color:#0F172A; font-size:13.5px;"><?php echo esc_html($pat_service); ?></strong>
                                        </div>
                                    </div>
                                </div>

                                <!-- WIZARD STEP 1: SELECT DOCTOR -->
                                <div class="dior-in-booking-step" id="in-step-doctor">
                                    <h4 style="margin:0 0 16px; color:#0F172A; font-size:15px; font-weight:700;">
                                        <i class="fa-solid fa-user-doctor" style="color:#2C6CB1;"></i> Available Telehealth Physicians:
                                    </h4>
                                    <div id="in-dashboard-doctors-grid" class="dior-doctors-grid-cards" style="display:grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap:16px;">
                                        <?php 
                                        $docbooker_doctors = get_posts([
                                            'post_type'   => 'wpddb_doctor',
                                            'post_status' => 'publish',
                                            'numberposts' => -1,
                                            'orderby'     => 'title',
                                            'order'       => 'ASC'
                                        ]);

                                        if (!empty($docbooker_doctors)):
                                            foreach ($docbooker_doctors as $doc_item):
                                                $d_id = $doc_item->ID;
                                                $d_name = $doc_item->post_title;
                                                $d_spec = get_post_meta($d_id, 'wpddb_doctor_speciality', true) ?: 'Telehealth Physician';
                                        ?>
                                        <div class="dior-doc-select-card" data-doc-id="<?php echo (int)$d_id; ?>" data-doc-name="<?php echo esc_attr($d_name); ?>" data-doc-spec="<?php echo esc_attr($d_spec); ?>" onclick="diorInSelectDoctor(<?php echo (int)$d_id; ?>, '<?php echo esc_js($d_name); ?>', '<?php echo esc_js($d_spec); ?>')" style="background:#FFFFFF; border:1.5px solid #E2E8F0; border-radius:12px; padding:18px; cursor:pointer; transition:all 0.2s ease; position:relative;">
                                            <div style="display:flex; align-items:center; gap:12px; margin-bottom:10px;">
                                                <div style="width:44px; height:44px; border-radius:50%; background:#EFF6FF; color:#2C6CB1; display:flex; align-items:center; justify-content:center; font-size:18px; font-weight:700;">
                                                    <i class="fa-solid fa-user-md"></i>
                                                </div>
                                                <div>
                                                    <h5 style="margin:0; font-size:14.5px; font-weight:700; color:#0F172A;"><?php echo esc_html($d_name); ?></h5>
                                                    <span style="font-size:12px; color:#2C6CB1; font-weight:600;"><?php echo esc_html($d_spec); ?></span>
                                                </div>
                                            </div>
                                            <div style="font-size:12px; color:#64748B; display:flex; justify-content:space-between; align-items:center; border-top:1px solid #F1F5F9; padding-top:10px; margin-top:8px;">
                                                <span><i class="fa-regular fa-clock"></i> Available via DocBooker</span>
                                                <span style="color:#059669; font-weight:700;">Select &rarr;</span>
                                            </div>
                                        </div>
                                        <?php 
                                            endforeach;
                                        else: 
                                        ?>
                                        <div class="dior-doc-select-card" data-doc-id="1695" data-doc-name="Dr. James Chen, DO" data-doc-spec="Primary Care &amp; Urgent Care" onclick="diorInSelectDoctor(1695, 'Dr. James Chen, DO', 'Primary Care &amp; Urgent Care')" style="background:#FFFFFF; border:1.5px solid #E2E8F0; border-radius:12px; padding:18px; cursor:pointer; transition:all 0.2s ease; position:relative;">
                                            <div style="display:flex; align-items:center; gap:12px; margin-bottom:10px;">
                                                <div style="width:44px; height:44px; border-radius:50%; background:#EFF6FF; color:#2C6CB1; display:flex; align-items:center; justify-content:center; font-size:18px; font-weight:700;">
                                                    <i class="fa-solid fa-user-md"></i>
                                                </div>
                                                <div>
                                                    <h5 style="margin:0; font-size:14.5px; font-weight:700; color:#0F172A;">Dr. James Chen, DO</h5>
                                                    <span style="font-size:12px; color:#2C6CB1; font-weight:600;">Primary Care &amp; Urgent Care</span>
                                                </div>
                                            </div>
                                            <div style="font-size:12px; color:#64748B; display:flex; justify-content:space-between; align-items:center; border-top:1px solid #F1F5F9; padding-top:10px; margin-top:8px;">
                                                <span><i class="fa-regular fa-clock"></i> Next Available: Today</span>
                                                <span style="color:#059669; font-weight:700;">Select &rarr;</span>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- WIZARD STEP 2: SELECT DATE & TIME -->
                                <div class="dior-in-booking-step" id="in-step-time" style="display:none;">
                                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
                                        <h4 style="margin:0; color:#0F172A; font-size:15px; font-weight:700;">
                                            <i class="fa-solid fa-calendar-day" style="color:#2C6CB1;"></i> Select Consultation Date &amp; Time Slot:
                                        </h4>
                                        <button type="button" class="dior-btn-text-back" onclick="diorInBookingGoToStep('doctor')" style="background:none; border:none; color:#2C6CB1; font-weight:700; cursor:pointer; font-size:13px;">
                                            &larr; Switch Physician
                                        </button>
                                    </div>
                                    <div style="display:grid; grid-template-columns: 1fr 1.6fr; gap:20px; align-items:start;" class="dior-schedule-pick-row">
                                        <div style="background:#F8FAFC; border:1.5px solid #E2E8F0; border-radius:12px; padding:18px;">
                                            <label style="display:block; font-size:12.5px; font-weight:700; color:#475569; margin-bottom:8px; text-transform:uppercase;">
                                                <i class="fa-regular fa-calendar"></i> Select Date:
                                            </label>
                                            <input type="date" id="in-booking-date" class="dior-form-input" min="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" onchange="diorInFetchAvailability()" style="width:100%; padding:11px 14px; border-radius:8px; border:1.5px solid #CBD5E1; font-size:14px; background:#fff;">
                                            <div id="in-selected-doctor-summary-pill" style="margin-top:14px; padding:12px; background:#FFFFFF; border-radius:8px; border:1px solid #E2E8F0; font-size:13px;">
                                                <!-- Doctor Details -->
                                            </div>
                                        </div>
                                        <div>
                                            <label style="display:block; font-size:12.5px; font-weight:700; color:#475569; margin-bottom:8px; text-transform:uppercase;">
                                                <i class="fa-regular fa-clock"></i> Available Video Consultation Slots:
                                            </label>
                                            <div id="in-time-slots-container" style="min-height:140px;">
                                                <p style="color:#64748B;">Please select a physician to view live availability slots.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- WIZARD STEP 3: CONFIRMATION -->
                                <div class="dior-in-booking-step" id="in-step-confirm" style="display:none;">
                                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
                                        <h4 style="margin:0; color:#0F172A; font-size:15px; font-weight:700;">
                                            <i class="fa-solid fa-clipboard-check" style="color:#059669;"></i> Review &amp; Confirm Consultation:
                                        </h4>
                                        <button type="button" class="dior-btn-text-back" onclick="diorInBookingGoToStep('time')" style="background:none; border:none; color:#2C6CB1; font-weight:700; cursor:pointer; font-size:13px;">
                                            &larr; Change Time
                                        </button>
                                    </div>
                                    
                                    <div id="in-booking-confirm-summary" style="background:#F8FAFC; border:1.5px solid #E2E8F0; border-radius:12px; padding:20px; margin-bottom:20px;">
                                        <!-- Summary generated dynamically -->
                                    </div>

                                    <div style="display:flex; gap:14px; align-items:center; flex-wrap:wrap;">
                                        <button type="button" class="dior-btn-gold-primary" id="btn-in-confirm-booking" onclick="diorInSubmitBooking()" style="padding:14px 30px; font-size:15px; font-weight:700; display:inline-flex; align-items:center; gap:8px;">
                                            <i class="fa-solid fa-video"></i> Confirm &amp; Schedule Telehealth Visit
                                        </button>
                                        <span style="font-size:12.5px; color:#64748B;"><i class="fa-solid fa-lock" style="color:#059669;"></i> Instant Zoom room link &amp; notifications will be generated for you &amp; your doctor.</span>
                                    </div>

                                    <div id="in-booking-status-msg" style="margin-top:16px; display:none; padding:14px 18px; border-radius:10px; font-weight:600;"></div>
                                </div>

                            </div>
                        </div>

                </section>


                <!-- ============================================================== -->
                <!-- 6. NOTIFICATIONS TAB -->
                <!-- ============================================================== -->
                <section class="dior-tab-panel" id="tab-notifications">
                    <div class="dior-page-header-box">
                        <div>
                            <h2>Patient Notification Inbox</h2>
                            <p>Stay up to date with consultation reminders, prescription routing alerts, and billing
                                receipts.</p>
                        </div>
                        <button type="button" class="dior-btn-gold-secondary" id="dior-mark-all-notifications-btn">
                            <i class="fa-solid fa-check-double"></i> Mark All as Read
                        </button>
                    </div>

                    <div class="dior-card">
                        <div class="dior-card-body p-0">
                            <div class="dior-notifs-full-list" id="dior-notifications-full-container">
                                <?php if (empty($notifications)): ?>
                                <div
                                    style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:64px 24px;text-align:center;">
                                    <div
                                        style="width:64px;height:64px;border-radius:16px;background:#F1F5F9;display:flex;align-items:center;justify-content:center;margin-bottom:16px;">
                                        <i class="fa-regular fa-bell-slash" style="font-size:26px;color:#CBD5E1;"></i>
                                    </div>
                                    <p
                                        style="font-size:15px;color:#94A3B8;margin:0;font-weight:600;font-family:'DMSans','DM Sans',sans-serif;">
                                        No notifications yet</p>
                                    <p style="font-size:13px;color:#CBD5E1;margin:6px 0 0;">You'll see consultation
                                        reminders, prescription routing alerts, and billing receipts here.</p>
                                </div>
                                <?php else: ?>
                                <?php foreach ($notifications as $notif): ?>
                                <div class="dior-full-notif-item <?php echo !$notif['is_read'] ? 'unread' : ''; ?>"
                                    data-notif-id="<?php echo esc_attr($notif['id']); ?>" <?php if (!empty($notif['action_url'])): ?>
                                    onclick="window.location.href='<?php echo esc_js($notif['action_url']); ?>'"
                                    style="cursor: pointer;" <?php endif; ?>>
                                    <div class="notif-type-icon <?php echo esc_attr($notif['type'] ?? 'system'); ?>">
                                        <i class="fa-solid <?php echo esc_attr($notif['icon'] ?? 'fa-bell'); ?>"></i>
                                    </div>
                                    <div class="notif-full-body">
                                        <div class="notif-full-top">
                                            <h4><?php echo esc_html($notif['title']); ?></h4>
                                            <span class="notif-full-time"><?php echo esc_html(dior_format_notification_time($notif)); ?></span>
                                        </div>
                                        <p><?php echo esc_html($notif['message']); ?></p>
                                        <?php if (!empty($notif['action_url'])): ?>
                                        <span style="color: #2C6CB1; font-size: 12px; font-weight: 600;">
                                            <i class="fa-solid fa-arrow-up-right-from-square"></i> Click to view details
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="notif-full-actions">
                                        <?php if (!$notif['is_read']): ?>
                                        <button type="button" class="dior-btn-table-icon dior-mark-single-read"
                                            title="Mark as Read">
                                            <i class="fa-solid fa-check"></i>
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </section>

            </div> <!-- /.dior-tab-container -->

        </main>
    </div> <!-- /.dior-app -->


    <!-- ============================================================== -->
    <!-- MODALS -->
    <!-- ============================================================== -->

    <!-- 1. BOOK NEW APPOINTMENT MODAL (HIPAAtizer Form Integrated) -->
    <div class="dior-modal-overlay" id="modal-book-appointment">
        <div class="dior-modal-dialog dior-modal-lg"
            style="max-width: 820px; width: 95%; max-height: 92vh; display: flex; flex-direction: column;">
            <div class="dior-modal-header" style="flex-shrink: 0;">
                <div>
                    <h3 style="margin: 0 0 4px;"><i class="fa-solid fa-calendar-plus"></i> Book New Visit</h3>
                    <span style="font-size: 11.5px; color: var(--dior-text-muted);"><i class="fa-solid fa-shield-halved"
                            style="color: var(--dior-success);"></i> HIPAA-Compliant Medical Intake &amp; Booking</span>
                </div>
                <button type="button" class="dior-modal-close"
                    onclick="diorCloseModal('modal-book-appointment')">&times;</button>
            </div>
            <div class="dior-modal-body"
                style="padding: 10px; flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch; min-height: 580px;">
                <iframe id="hipaatizer-book-visit-iframe"
                    src="https://app.hipaatizer.com/workflow/01a07aa2-d931-728d-bfe9-8d7b3bc0389d"
                    style="width: 100%; min-height: 580px; height: 75vh; border: 0; border-radius: 8px; display: block;"
                    allow="microphone; camera; payment" title="HIPAAtizer Booking Form">
                </iframe>
                <div style="display:none;">
                    <?php echo do_shortcode('[hipaatizer id="01a07aa2-d931-728d-bfe9-8d7b3bc0389d"]'); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- 2. RESCHEDULE MODAL -->
    <div class="dior-modal-overlay" id="modal-reschedule-appointment">
        <div class="dior-modal-dialog">
            <div class="dior-modal-header">
                <h3><i class="fa-regular fa-calendar-days"></i> Reschedule Consultation</h3>
                <button type="button" class="dior-modal-close"
                    onclick="diorCloseModal('modal-reschedule-appointment')">&times;</button>
            </div>
            <div class="dior-modal-body">
                <form id="dior-form-reschedule-appt">
                    <input type="hidden" id="resched_appt_id" name="appt_id" value="">

                    <p class="modal-intro-text">Select a new date and time slot for your appointment:</p>

                    <div class="dior-form-row-2">
                        <div class="dior-form-group">
                            <label for="resched_date">New Date <span class="req">*</span></label>
                            <input type="date" id="resched_date" name="date"
                                value="<?php echo current_time('Y-m-d'); ?>" required>
                        </div>
                        <div class="dior-form-group">
                            <label for="resched_time">New Time Slot <span class="req">*</span></label>
                            <select id="resched_time" name="time" required>
                                <option value="09:00 AM PST">09:00 AM PST</option>
                                <option value="11:30 AM PST">11:30 AM PST</option>
                                <option value="02:00 PM PST">02:00 PM PST</option>
                                <option value="04:30 PM PST">04:30 PM PST</option>
                                <option value="06:00 PM PST">06:00 PM PST</option>
                            </select>
                        </div>
                    </div>

                    <div class="dior-modal-footer">
                        <button type="button" class="dior-btn-gold-secondary"
                            onclick="diorCloseModal('modal-reschedule-appointment')">Keep Current Time</button>
                        <button type="submit" class="dior-btn-gold-primary">Save New Time Slot</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 3. CANCEL APPOINTMENT MODAL -->
    <div class="dior-modal-overlay" id="modal-cancel-appointment">
        <div class="dior-modal-dialog">
            <div class="dior-modal-header">
                <h3><i class="fa-solid fa-triangle-exclamation"></i> Cancel Consultation</h3>
                <button type="button" class="dior-modal-close"
                    onclick="diorCloseModal('modal-cancel-appointment')">&times;</button>
            </div>
            <div class="dior-modal-body">
                <form id="dior-form-cancel-appt">
                    <input type="hidden" id="cancel_appt_id" name="appt_id" value="">

                    <p>Are you sure you wish to cancel this consultation? You can reschedule at no penalty or request a
                        refund.</p>

                    <div class="dior-form-group">
                        <label for="cancel_reason">Reason for Cancellation (Optional)</label>
                        <select id="cancel_reason" name="reason">
                            <option value="Symptoms resolved">Symptoms resolved</option>
                            <option value="Schedule conflict">Schedule conflict</option>
                            <option value="Went to in-person clinic">Went to in-person clinic</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="dior-modal-footer">
                        <button type="button" class="dior-btn-gold-secondary"
                            onclick="diorCloseModal('modal-cancel-appointment')">Keep Appointment</button>
                        <button type="submit" class="dior-btn-danger">Confirm Cancellation</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 4. QUESTIONNAIRE & INTAKE MODAL (With E-Sign) -->
    <div class="dior-modal-overlay" id="modal-questionnaire-intake">
        <div class="dior-modal-dialog dior-modal-lg">
            <div class="dior-modal-header">
                <h3 id="modal-qn-title"><i class="fa-solid fa-clipboard-question"></i> Clinical Intake & E-Sign</h3>
                <button type="button" class="dior-modal-close"
                    onclick="diorCloseModal('modal-questionnaire-intake')">&times;</button>
            </div>
            <div class="dior-modal-body">
                <form id="dior-form-submit-intake" class="dior-portal-form">
                    <input type="hidden" id="qn_input_id" name="qn_id" value="">
                    <input type="hidden" id="qn_input_condition" name="condition" value="">

                    <div class="dior-form-group">
                        <label for="qn_input_symptoms">Describe Your Symptoms & Duration <span
                                class="req">*</span></label>
                        <textarea id="qn_input_symptoms" name="symptoms" rows="3"
                            placeholder="When did symptoms start? Rate severity (mild/moderate/severe)..."
                            required></textarea>
                    </div>

                    <div class="dior-form-row-2">
                        <div class="dior-form-group">
                            <label for="qn_input_allergies">Known Drug Allergies</label>
                            <input type="text" id="qn_input_allergies" name="allergies"
                                placeholder="e.g. Penicillin, Sulfa, None known">
                        </div>
                        <div class="dior-form-group">
                            <label for="qn_input_meds">Current Medications / Supplements</label>
                            <input type="text" id="qn_input_meds" name="current_meds"
                                placeholder="e.g. Lisinopril 10mg, Multivitamin">
                        </div>
                    </div>

                    <div class="dior-form-group">
                        <label for="qn_input_history">Relevant Medical Conditions</label>
                        <input type="text" id="qn_input_history" name="medical_history"
                            placeholder="e.g. Asthma, High Blood Pressure, Diabetes, None">
                    </div>

                    <!-- Document / Photo Upload -->
                    <div class="dior-form-group">
                        <label>Upload Supporting Images / Documents (e.g. Photo of Rash, Previous Lab Test)</label>
                        <div class="dior-upload-dropzone" id="dior-upload-dropzone">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                            <span>Click to upload or drag and drop image (JPG, PNG, PDF up to 10MB)</span>
                            <input type="file" id="qn_file_upload" name="file_upload" accept="image/*,application/pdf"
                                style="display:none;">
                        </div>
                        <div id="dior-upload-preview"
                            style="display:none; margin-top:8px; font-size:13px; color:#2C6CB1; font-weight:600;"></div>
                    </div>

                    <!-- HIPAA Telemedicine Consent & E-Sign Pad -->
                    <div class="dior-esign-section">
                        <h4><i class="fa-solid fa-signature"></i> Telemedicine & HIPAA Consent Agreement</h4>
                        <div class="esign-text-box">
                            <p>By typing your legal name or signing below, you consent to receive telehealth medical
                                evaluations from licensed clinicians at Dior Medical, acknowledge our HIPAA Privacy
                                Practices, and certify that all clinical information provided is true and accurate.</p>
                        </div>

                        <div class="dior-form-row-2">
                            <div class="dior-form-group">
                                <label for="esign_name">Type Full Legal Name (Electronic Signature) <span
                                        class="req">*</span></label>
                                <input type="text" id="esign_name" name="esign_name"
                                    value="<?php echo esc_attr($profile['full_name']); ?>" required>
                            </div>
                            <div class="dior-form-group">
                                <label for="esign_date">Date of Signature</label>
                                <input type="text" id="esign_date" name="esign_date"
                                    value="<?php echo current_time('M j, Y'); ?>" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="dior-modal-footer">
                        <button type="button" class="dior-btn-gold-secondary"
                            onclick="diorCloseModal('modal-questionnaire-intake')">Cancel</button>
                        <button type="submit" class="dior-btn-gold-primary" id="dior-submit-intake-btn">
                            <i class="fa-solid fa-paper-plane"></i> Submit Clinical Intake to Doctor &rarr;
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 5. CHANGE PHARMACY MODAL -->
    <div class="dior-modal-overlay" id="modal-change-pharmacy">
        <div class="dior-modal-dialog">
            <div class="dior-modal-header">
                <h3><i class="fa-solid fa-store"></i> Update Preferred Pharmacy</h3>
                <button type="button" class="dior-modal-close"
                    onclick="diorCloseModal('modal-change-pharmacy')">&times;</button>
            </div>
            <div class="dior-modal-body">
                <form id="dior-form-quick-pharmacy">
                    <div class="dior-form-group">
                        <label for="quick_pharmacy_select">Select Local Pharmacy or Enter Custom</label>
                        <select id="quick_pharmacy_select" onchange="diorOnPharmacySelectChange(this)">
                            <option value="custom">-- Enter Custom Pharmacy Details --</option>
                            <option value="CVS Pharmacy #4829|9045 Wilshire Blvd, Beverly Hills, CA|(310) 555-0199">CVS
                                Pharmacy #4829 - Beverly Hills</option>
                            <option value="Walgreens Pharmacy #1034|300 N Canon Dr, Beverly Hills, CA|(310) 555-0244">
                                Walgreens Pharmacy #1034 - Beverly Hills</option>
                            <option
                                value="Rite Aid Pharmacy #5411|8440 Santa Monica Blvd, West Hollywood, CA|(323) 555-0188">
                                Rite Aid Pharmacy - West Hollywood</option>
                            <option
                                value="Capsule Digital Delivery Pharmacy|Direct Delivery to Doorstep|(888) 910-1212">
                                Capsule Direct Delivery Pharmacy</option>
                        </select>
                    </div>

                    <div class="dior-form-group">
                        <label for="q_pharm_name">Pharmacy Name <span class="req">*</span></label>
                        <input type="text" id="q_pharm_name" name="pharmacy_name"
                            value="<?php echo esc_attr($profile['pharmacy_name']); ?>" required>
                    </div>
                    <div class="dior-form-group">
                        <label for="q_pharm_address">Pharmacy Address <span class="req">*</span></label>
                        <input type="text" id="q_pharm_address" name="pharmacy_address"
                            value="<?php echo esc_attr($profile['pharmacy_address']); ?>" required>
                    </div>
                    <div class="dior-form-group">
                        <label for="q_pharm_phone">Pharmacy Phone</label>
                        <input type="tel" id="q_pharm_phone" name="pharmacy_phone"
                            value="<?php echo esc_attr($profile['pharmacy_phone']); ?>">
                    </div>

                    <div class="dior-modal-footer">
                        <button type="button" class="dior-btn-gold-secondary"
                            onclick="diorCloseModal('modal-change-pharmacy')">Cancel</button>
                        <button type="submit" class="dior-btn-gold-primary">Save Pharmacy</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 6. VIEW RECEIPT MODAL -->
    <div class="dior-modal-overlay" id="modal-view-receipt" style="display:none;">
        <div class="dior-modal-dialog"
            style="max-width: 580px; width: 92%; border-radius: 16px; overflow: hidden; background: #FFFFFF; box-shadow: 0 20px 50px rgba(11,16,48,0.25);">
            <div class="dior-modal-header"
                style="padding: 18px 24px; border-bottom: 1px solid #EEF2F6; background: #FFFFFF; display: flex; align-items: center; justify-content: space-between;">
                <h3
                    style="margin: 0; font-size: 17px; font-weight: 700; color: #0F172A; display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-receipt" style="color:#2C6CB1;"></i> Telehealth Itemized Receipt
                </h3>
                <button type="button" class="dior-modal-close" onclick="diorCloseModal('modal-view-receipt')"
                    style="font-size: 24px; line-height: 1; color: #94A3B8; background: none; border: none; cursor: pointer; padding: 4px 8px; border-radius: 6px;">&times;</button>
            </div>

            <div class="dior-modal-body" id="modal-receipt-content" style="padding: 24px 28px; background: #F8FAFC;">
                <div class="receipt-printable-box"
                    style="padding: 28px 24px; border: 1px solid #E2E8F0; border-radius: 12px; background: #FFFFFF; box-shadow: 0 2px 10px rgba(11,16,48,0.04);">
                    <div class="receipt-logo" style="text-align: center; margin-bottom: 16px;">
                        <img src="<?php echo esc_url($logo_url); ?>" alt="Dior Medical"
                            style="height: 68px; max-height: 72px; width: auto; object-fit: contain; display: inline-block;">
                    </div>

                    <div class="receipt-title"
                        style="font-size: 17px; font-weight: 700; color: #0F172A; text-align: center; margin-bottom: 20px; font-family: 'Montserrat', sans-serif;">
                        Official Medical Statement &amp; Receipt
                    </div>

                    <table class="receipt-info-table"
                        style="width: 100%; border-collapse: collapse; border: 1px solid #E2E8F0; border-radius: 8px; overflow: hidden; margin-bottom: 20px; font-size: 13px;">
                        <tr style="border-bottom: 1px solid #F1F5F9;">
                            <td
                                style="padding: 12px 16px; background: #F8FAFC; width: 38%; color: #64748B; font-weight: 700;">
                                Invoice #:</td>
                            <td style="padding: 12px 16px; color: #0F172A; font-weight: 700;" id="rec-inv-id">INV-8829
                            </td>
                        </tr>
                        <tr style="border-bottom: 1px solid #F1F5F9;">
                            <td style="padding: 12px 16px; background: #F8FAFC; color: #64748B; font-weight: 700;">Date:
                            </td>
                            <td style="padding: 12px 16px; color: #0F172A; font-weight: 600;" id="rec-date">Sept 4, 2026
                            </td>
                        </tr>
                        <tr style="border-bottom: 1px solid #F1F5F9;">
                            <td style="padding: 12px 16px; background: #F8FAFC; color: #64748B; font-weight: 700;">
                                Patient:</td>
                            <td style="padding: 12px 16px; color: #0F172A; font-weight: 600;" id="rec-patient-info">
                                <?php echo esc_html($profile['full_name']); ?>
                                (<?php echo esc_html($profile['patient_id']); ?>)</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #F1F5F9;">
                            <td style="padding: 12px 16px; background: #F8FAFC; color: #64748B; font-weight: 700;">
                                Service:</td>
                            <td style="padding: 12px 16px; color: #0F172A; font-weight: 600;" id="rec-service">Urgent
                                Care Telehealth Consultation</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #F1F5F9;">
                            <td style="padding: 12px 16px; background: #F8FAFC; color: #64748B; font-weight: 700;">
                                Payment Method:</td>
                            <td style="padding: 12px 16px; color: #0F172A; font-weight: 600;">Stripe (Credit Card /
                                Apple Pay)</td>
                        </tr>
                        <tr class="total-row" style="background: #EFF6FF;">
                            <td style="padding: 14px 16px; color: #1E40AF; font-weight: 800; font-size: 14px;">Total
                                Paid:</td>
                            <td style="padding: 14px 16px; color: #1E40AF; font-weight: 800; font-size: 16px;"
                                id="rec-amount">$49.00</td>
                        </tr>
                    </table>

                    <div class="receipt-footer-note"
                        style="padding: 12px 16px; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; font-size: 11.5px; color: #64748B; text-align: center; line-height: 1.5;">
                        <i class="fa-solid fa-shield-halved" style="color:#059669; margin-right: 4px;"></i>
                        <span>Dior Medical Telehealth &amp; Urgent Care &bull; Tax ID / NPI Verified &bull; Eligible for
                            HSA/FSA Reimbursement</span>
                    </div>
                </div>
            </div>

            <div class="dior-modal-footer"
                style="padding: 18px 28px 24px 28px; background: #FFFFFF; border-top: 1px solid #EEF2F6; display: flex; align-items: center; justify-content: flex-end; gap: 12px;">
                <button type="button" class="dior-btn-gold-secondary" onclick="diorCloseModal('modal-view-receipt')"
                    style="padding: 9px 18px; border-radius: 8px; font-weight: 600; font-size: 13.5px;">Close</button>
                <button type="button" class="dior-btn-gold-secondary" onclick="diorPrintReceiptModal()"
                    style="padding: 9px 18px; border-radius: 8px; font-weight: 600; font-size: 13.5px; display: inline-flex; align-items: center; gap: 6px;">
                    <i class="fa-solid fa-print"></i> Print
                </button>
                <button type="button" class="dior-btn-gold-primary" onclick="diorDownloadReceiptPdf()"
                    style="padding: 9px 20px; border-radius: 8px; font-weight: 600; font-size: 13.5px; display: inline-flex; align-items: center; gap: 8px; background: linear-gradient(135deg, #2C6CB1 0%, #1A528E 100%); color: #FFFFFF; border: none; cursor: pointer; box-shadow: 0 2px 6px rgba(44,108,177,0.3);">
                    <i class="fa-solid fa-file-arrow-down"></i> Download PDF
                </button>
            </div>
        </div>
    </div>

    <!-- 7. VIEW DOCUMENT MODAL -->
    <div class="dior-modal-overlay" id="modal-view-document" style="display:none;">
        <div class="dior-modal-dialog"
            style="max-width: 600px; width: 92%; border-radius: 16px; overflow: hidden; background: #FFFFFF; box-shadow: 0 20px 50px rgba(11,16,48,0.25);">
            <div class="dior-modal-header"
                style="padding: 18px 24px; border-bottom: 1px solid #EEF2F6; background: #FFFFFF; display: flex; align-items: center; justify-content: space-between;">
                <h3 id="doc-modal-header-title"
                    style="margin: 0; font-size: 17px; font-weight: 700; color: #0F172A; display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-file-shield" style="color:#2C6CB1;"></i> Certified Medical Document
                </h3>
                <button type="button" class="dior-modal-close" onclick="diorCloseModal('modal-view-document')"
                    style="font-size: 24px; line-height: 1; color: #94A3B8; background: none; border: none; cursor: pointer; padding: 4px 8px; border-radius: 6px;">&times;</button>
            </div>

            <div class="dior-modal-body" style="padding: 24px; background: #F8FAFC;">
                <div class="doc-preview-card"
                    style="padding: 24px 20px; border: 1px solid #E2E8F0; border-radius: 12px; background: #FFFFFF; text-align: center; box-shadow: 0 2px 8px rgba(11,16,48,0.04);">

                    <div class="doc-icon-large" style="font-size: 40px; color: #DC2626; margin-bottom: 12px;">
                        <i class="fa-solid fa-file-pdf"></i>
                    </div>

                    <h4 id="doc-preview-title"
                        style="margin: 0 0 10px 0; font-size: 17px; color: #0F172A; font-weight: 700; line-height: 1.35;">
                        Document Title</h4>

                    <div style="margin-bottom: 18px;">
                        <span id="doc-preview-category"
                            style="display: inline-flex; align-items: center; justify-content: center; padding: 4px 14px; background: #EFF6FF; color: #2563EB; border-radius: 20px; font-size: 12px; font-weight: 600; border: 1px solid #BFDBFE;">Category</span>
                    </div>

                    <div class="doc-details-grid"
                        style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; text-align: left; background: #F8FAFC; padding: 14px 16px; border-radius: 10px; border: 1px solid #E2E8F0; margin-bottom: 18px; font-size: 12.5px;">
                        <div>
                            <strong
                                style="color: #64748B; display: block; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 3px;">Document
                                ID:</strong>
                            <span id="doc-preview-id"
                                style="color: #0F172A; font-weight: 700; font-size: 13px;">DOC-88219</span>
                        </div>
                        <div>
                            <strong
                                style="color: #64748B; display: block; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 3px;">Date
                                Issued:</strong>
                            <span id="doc-preview-date" style="color: #0F172A; font-weight: 700; font-size: 13px;">Sept
                                4, 2026</span>
                        </div>
                        <div>
                            <strong
                                style="color: #64748B; display: block; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 3px;">Issued
                                By / Provider:</strong>
                            <span id="doc-preview-author"
                                style="color: #0F172A; font-weight: 700; font-size: 13px;">Dior Medical Clinical
                                Team</span>
                        </div>
                        <div>
                            <strong
                                style="color: #64748B; display: block; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 3px;">Patient:</strong>
                            <span id="doc-preview-patient"
                                style="color: #0F172A; font-weight: 700; font-size: 13px;"><?php echo esc_html($profile['full_name']); ?></span>
                        </div>
                    </div>

                    <div class="doc-seal"
                        style="font-size: 12px; color: #059669; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 9px 12px; background: #ECFDF5; border: 1px solid #A7F3D0; border-radius: 8px;">
                        <i class="fa-solid fa-shield-halved" style="color: #059669; font-size: 14px;"></i>
                        <span>Digitally Certified &amp; E-Signed by Dior Medical Telehealth System</span>
                    </div>
                </div>
            </div>

            <div class="dior-modal-footer"
                style="padding: 16px 24px; background: #FFFFFF; border-top: 1px solid #EEF2F6; display: flex; align-items: center; justify-content: flex-end; gap: 12px;">
                <button type="button" class="dior-btn-gold-secondary" onclick="diorCloseModal('modal-view-document')"
                    style="padding: 9px 18px; border-radius: 8px; font-weight: 600; font-size: 13.5px;">Close</button>
                <button type="button" class="dior-btn-gold-primary" onclick="diorDownloadCurrentDocumentPdf()"
                    style="padding: 9px 20px; border-radius: 8px; font-weight: 600; font-size: 13.5px; display: inline-flex; align-items: center; gap: 8px; background: linear-gradient(135deg, #2C6CB1 0%, #1A528E 100%); color: #FFFFFF; border: none; cursor: pointer; box-shadow: 0 2px 6px rgba(44,108,177,0.3);">
                    <i class="fa-solid fa-file-arrow-down"></i> Print / Download PDF
                </button>
            </div>
        </div>
    </div> <!-- /#modal-view-document -->

    <!-- 8. APPOINTMENT DETAIL MODAL (PATIENT PORTAL) -->
    <div class="dior-modal-overlay" id="modal-view-appointment-detail" style="display:none;">
        <div class="dior-modal-dialog"
            style="max-width: 650px; width: 92%; border-radius: 16px; overflow: hidden; background: #FFFFFF; box-shadow: 0 25px 60px rgba(15,23,42,0.25); border: 1px solid #E2E8F0;">
            <div class="dior-modal-header"
                style="padding: 16px 24px; border-bottom: 1px solid #EEF2F6; background: #FFFFFF; display: flex; align-items: center; justify-content: space-between;">
                <h3 style="margin: 0; font-size: 16px; font-weight: 700; color: #0F172A; display: flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-calendar-check" style="color:#2C6CB1;"></i> Appointment Details
                </h3>
                <button type="button" class="dior-modal-close" onclick="diorCloseModal('modal-view-appointment-detail')"
                    style="font-size: 22px; line-height: 1; color: #94A3B8; background: none; border: none; cursor: pointer; padding: 4px 8px; border-radius: 6px;">&times;</button>
            </div>

            <div class="dior-modal-body" style="padding: 24px; background: #F8FAFC; max-height: 75vh; overflow-y: auto;">
                <!-- Hero Info Card -->
                <div style="background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 12px; padding: 20px; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(15,23,42,0.04);">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:12px; margin-bottom:14px;">
                        <div>
                            <span id="pat-modal-appt-id" style="display:inline-block; font-family:monospace; font-weight:700; font-size:12px; background:#EFF6FF; color:#1D4ED8; padding:3px 10px; border-radius:6px; border:1px solid #BFDBFE; margin-bottom:6px;">APPT-ID</span>
                            <h4 id="pat-modal-appt-provider" style="margin:0; font-size:17px; font-weight:700; color:#0F172A;">Attending Physician</h4>
                            <span id="pat-modal-appt-spec" style="font-size:13px; color:#64748B;">Telehealth Urgent Care</span>
                        </div>
                        <span id="pat-modal-appt-status-badge" class="dior-st ok" style="font-size:12px; padding:5px 12px; border-radius:20px;">Confirmed</span>
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px; background:#F8FAFC; border:1px solid #E2E8F0; border-radius:10px; padding:14px 16px; font-size:13px;">
                        <div>
                            <strong style="color:#64748B; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; display:block; margin-bottom:2px;">Date &amp; Time</strong>
                            <span id="pat-modal-appt-datetime" style="color:#0F172A; font-weight:700;">—</span>
                        </div>
                        <div>
                            <strong style="color:#64748B; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; display:block; margin-bottom:2px;">Consultation Mode</strong>
                            <span id="pat-modal-appt-mode" style="color:#0F172A; font-weight:700;"><i class="fa-solid fa-video" style="color:#2C6CB1;"></i> Video Visit</span>
                        </div>
                        <div style="grid-column: 1 / -1;">
                            <strong style="color:#64748B; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; display:block; margin-bottom:2px;">Service / Clinical Reason</strong>
                            <span id="pat-modal-appt-condition" style="color:#0F172A; font-weight:600;">Telehealth Urgent Care</span>
                        </div>
                    </div>
                </div>

                <!-- Live Zoom Link Strip (if available) -->
                <div id="pat-modal-zoom-wrap" style="background:#EFF6FF; border:1.5px solid #BFDBFE; border-radius:12px; padding:16px; margin-bottom:16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <div style="width:36px; height:36px; border-radius:8px; background:#2563EB; color:#fff; display:flex; align-items:center; justify-content:center; font-size:15px; flex-shrink:0;">
                            <i class="fa-solid fa-video"></i>
                        </div>
                        <div>
                            <strong style="color:#1E40AF; font-size:13.5px; display:block;">Live Virtual Consultation Room</strong>
                            <span style="color:#3B82F6; font-size:12px;">Join physician on secure Zoom Video</span>
                        </div>
                    </div>
                    <a id="pat-modal-zoom-link" href="#" target="_blank" rel="noopener noreferrer"
                        style="padding:8px 18px; background:#2563EB; color:#FFFFFF; border-radius:8px; font-weight:700; font-size:13px; text-decoration:none; display:inline-flex; align-items:center; gap:6px; box-shadow:0 2px 8px rgba(37,99,235,0.3);">
                        <i class="fa-solid fa-video"></i> Join Video Call &rarr;
                    </a>
                </div>

                <!-- Patient & Clinical Notes Card -->
                <div style="background:#FFFFFF; border:1px solid #E2E8F0; border-radius:12px; padding:18px; margin-bottom:16px;">
                    <h5 style="margin:0 0 10px; font-size:13px; text-transform:uppercase; letter-spacing:0.05em; color:#475569; font-weight:700;">
                        <i class="fa-solid fa-notes-medical" style="color:#2C6CB1;"></i> Clinical Notes &amp; Instructions
                    </h5>
                    <p id="pat-modal-appt-notes" style="margin:0; font-size:13px; color:#334155; line-height:1.5; background:#F8FAFC; padding:12px; border-radius:8px; border:1px solid #E2E8F0;">
                        Standard telehealth clinical consultation scheduled. All submitted medical intake questionnaires are pre-verified.
                    </p>
                </div>

                <div style="font-size: 12px; color: #059669; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 9px 12px; background: #ECFDF5; border: 1px solid #A7F3D0; border-radius: 8px;">
                    <i class="fa-solid fa-shield-halved" style="color: #059669; font-size: 14px;"></i>
                    <span>HIPAA Compliant &bull; Verified Dior Medical Telehealth Record</span>
                </div>
            </div>

            <div class="dior-modal-footer"
                style="padding: 14px 24px; background: #FFFFFF; border-top: 1px solid #EEF2F6; display: flex; align-items: center; justify-content: flex-end; gap: 10px;">
                <button type="button" class="dior-btn-gold-secondary" onclick="diorCloseModal('modal-view-appointment-detail')"
                    style="padding: 8px 18px; border-radius: 8px; font-weight: 600; font-size: 13px;">Close</button>
            </div>
        </div>
    </div> <!-- /#modal-view-appointment-detail -->

    <!-- 9. PRESCRIPTION DETAIL MODAL (PATIENT PORTAL) -->
    <div class="dior-modal-overlay" id="modal-view-rx-detail" style="display:none;">
        <div class="dior-modal-dialog"
            style="max-width: 650px; width: 92%; border-radius: 16px; overflow: hidden; background: #FFFFFF; box-shadow: 0 25px 60px rgba(15,23,42,0.25); border: 1px solid #E2E8F0;">
            <div class="dior-modal-header"
                style="padding: 16px 24px; border-bottom: 1px solid #EEF2F6; background: #FFFFFF; display: flex; align-items: center; justify-content: space-between;">
                <h3 style="margin: 0; font-size: 16px; font-weight: 700; color: #0F172A; display: flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-prescription-bottle-medical" style="color:#2C6CB1;"></i> Prescription &amp; Pharmacy Details
                </h3>
                <button type="button" class="dior-modal-close" onclick="diorCloseModal('modal-view-rx-detail')"
                    style="font-size: 22px; line-height: 1; color: #94A3B8; background: none; border: none; cursor: pointer; padding: 4px 8px; border-radius: 6px;">&times;</button>
            </div>

            <div class="dior-modal-body" style="padding: 24px; background: #F8FAFC; max-height: 75vh; overflow-y: auto;">
                <!-- Hero Info Card -->
                <div style="background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 12px; padding: 20px; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(15,23,42,0.04);">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:12px; margin-bottom:14px;">
                        <div>
                            <span id="pat-modal-rx-id" style="display:inline-block; font-family:monospace; font-weight:700; font-size:12px; background:#EFF6FF; color:#1D4ED8; padding:3px 10px; border-radius:6px; border:1px solid #BFDBFE; margin-bottom:6px;">Rx #ORDER</span>
                            <h4 id="pat-modal-rx-name" style="margin:0; font-size:18px; font-weight:700; color:#0F172A;">Medication Name</h4>
                            <span style="font-size:13px; color:#64748B;">Prescribed by <strong id="pat-modal-rx-doc" style="color:#334155;">Attending Physician</strong> on <span id="pat-modal-rx-date">—</span></span>
                        </div>
                        <span id="pat-modal-rx-status-badge" class="dior-st ok" style="font-size:12px; padding:5px 12px; border-radius:20px;">Sent to Pharmacy</span>
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px; background:#F8FAFC; border:1px solid #E2E8F0; border-radius:10px; padding:14px 16px; font-size:13px;">
                        <div>
                            <strong style="color:#64748B; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; display:block; margin-bottom:2px;">Dosage &amp; Strength</strong>
                            <span id="pat-modal-rx-dosage" style="color:#0F172A; font-weight:700;">As directed</span>
                        </div>
                        <div>
                            <strong style="color:#64748B; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; display:block; margin-bottom:2px;">Quantity Dispensed</strong>
                            <span id="pat-modal-rx-qty" style="color:#0F172A; font-weight:700;">As Prescribed</span>
                        </div>
                        <div>
                            <strong style="color:#64748B; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; display:block; margin-bottom:2px;">Authorized Refills</strong>
                            <span id="pat-modal-rx-refills" style="color:#059669; font-weight:700;">0 Refills Remaining</span>
                        </div>
                        <div>
                            <strong style="color:#64748B; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; display:block; margin-bottom:2px;">Transmission Status</strong>
                            <span id="pat-modal-rx-routing" style="color:#2563EB; font-weight:700;"><i class="fa-solid fa-circle-check" style="color:#059669;"></i> e-Transmitted</span>
                        </div>
                    </div>
                </div>

                <!-- Clinical Instructions Box -->
                <div style="background:#FFFFFF; border:1px solid #E2E8F0; border-radius:12px; padding:18px; margin-bottom:16px;">
                    <h5 style="margin:0 0 10px; font-size:13px; text-transform:uppercase; letter-spacing:0.05em; color:#475569; font-weight:700;">
                        <i class="fa-solid fa-circle-info" style="color:#2C6CB1;"></i> Patient Usage Instructions (SIG)
                    </h5>
                    <p id="pat-modal-rx-instructions" style="margin:0; font-size:13.5px; color:#334155; line-height:1.5; background:#F8FAFC; padding:14px; border-radius:8px; border:1px solid #E2E8F0;">
                        Take as directed by your prescribing physician.
                    </p>
                </div>

                <!-- Pharmacy Routing Card -->
                <div style="background:#EFF6FF; border:1px solid #BFDBFE; border-radius:12px; padding:16px; margin-bottom:16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                    <div style="display:flex; align-items:center; gap:12px;">
                        <div style="width:38px; height:38px; border-radius:8px; background:#2563EB; color:#fff; display:flex; align-items:center; justify-content:center; font-size:16px; flex-shrink:0;">
                            <i class="fa-solid fa-store"></i>
                        </div>
                        <div>
                            <strong style="color:#1E40AF; font-size:13.5px; display:block;">Fulfillment Pharmacy</strong>
                            <span id="pat-modal-rx-pharm-name" style="color:#1E293B; font-size:12.5px; font-weight:600;"><?php echo esc_html(!empty($profile['pharmacy_name']) ? $profile['pharmacy_name'] : 'Preferred Pharmacy on File'); ?></span>
                        </div>
                    </div>
                    <span style="font-size:11.5px; color:#059669; font-weight:700; background:#ECFDF5; padding:3px 10px; border-radius:12px; border:1px solid #A7F3D0;">
                        <i class="fa-solid fa-check"></i> Routed Directly
                    </span>
                </div>

                <div style="font-size: 12px; color: #059669; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 9px 12px; background: #ECFDF5; border: 1px solid #A7F3D0; border-radius: 8px;">
                    <i class="fa-solid fa-shield-halved" style="color: #059669; font-size: 14px;"></i>
                    <span>Official E-Prescription Document &bull; Verified Dior Medical Telehealth</span>
                </div>
            </div>

            <div class="dior-modal-footer"
                style="padding: 14px 24px; background: #FFFFFF; border-top: 1px solid #EEF2F6; display: flex; align-items: center; justify-content: space-between; flex-wrap:wrap; gap: 10px;">
                <button type="button" id="pat-modal-rx-refill-btn" class="dior-btn-gold-secondary"
                    style="padding: 8px 16px; border-radius: 8px; font-weight: 600; font-size: 13px;">
                    <i class="fa-solid fa-arrows-rotate"></i> Request Refill
                </button>
                <div style="display:flex; gap:8px;">
                    <button type="button" id="pat-modal-rx-pdf-btn" class="dior-btn-gold"
                        style="padding: 8px 18px; border-radius: 8px; font-weight: 700; font-size: 13px;">
                        <i class="fa-solid fa-file-arrow-down"></i> Download Official PDF
                    </button>
                    <button type="button" class="dior-btn-gold-secondary" onclick="diorCloseModal('modal-view-rx-detail')"
                        style="padding: 8px 18px; border-radius: 8px; font-weight: 600; font-size: 13px;">Close</button>
                </div>
            </div>
        </div>
    </div> <!-- /#modal-view-rx-detail -->

    <script>
        window.dior_patient_appts_data = <?php echo wp_json_encode($appointments); ?>;
        window.dior_patient_rxs_data = <?php echo wp_json_encode($prescriptions); ?>;
        window.diorOpenModal = function (modalId) {
            var el = document.getElementById(modalId);
            if (el) {
                el.classList.add('open');
                el.style.display = 'flex';
                document.body.style.overflow = 'hidden';
            }
        };

        window.diorCloseModal = function (modalId) {
            var el = document.getElementById(modalId);
            if (el) {
                el.classList.remove('open');
                el.style.display = 'none';
                document.body.style.overflow = '';
            }
        };

        window.diorViewRxDetails = function (rxId, fallbackMed, fallbackInst) {
            var rxs = window.dior_patient_rxs_data || [];
            var found = null;
            if (rxs && rxs.length) {
                for (var i = 0; i < rxs.length; i++) {
                    if (String(rxs[i].id).trim().toLowerCase() === String(rxId).trim().toLowerCase()) {
                        found = rxs[i];
                        break;
                    }
                }
            }

            var idEl = document.getElementById('pat-modal-rx-id');
            var nameEl = document.getElementById('pat-modal-rx-name');
            var docEl = document.getElementById('pat-modal-rx-doc');
            var dateEl = document.getElementById('pat-modal-rx-date');
            var doseEl = document.getElementById('pat-modal-rx-dosage');
            var qtyEl = document.getElementById('pat-modal-rx-qty');
            var refillsEl = document.getElementById('pat-modal-rx-refills');
            var routingEl = document.getElementById('pat-modal-rx-routing');
            var statusBadge = document.getElementById('pat-modal-rx-status-badge');
            var instEl = document.getElementById('pat-modal-rx-instructions');
            var pharmNameEl = document.getElementById('pat-modal-rx-pharm-name');
            var pdfBtn = document.getElementById('pat-modal-rx-pdf-btn');
            var refillBtn = document.getElementById('pat-modal-rx-refill-btn');

            var actualId = found ? (found.id || rxId) : rxId;
            var actualName = found ? (found.medication || found.name || fallbackMed || 'Prescription') : (fallbackMed || 'Prescription');
            var actualDoc = found ? (found.prescribed_by || 'Attending Physician') : 'Attending Physician';
            var actualDate = found ? (found.date_prescribed || found.date || '—') : '—';
            var actualDose = found ? (found.dosage || found.dose || 'As directed by physician') : 'As directed by physician';
            var actualQty = found ? (found.quantity || 'As Prescribed') : 'As Prescribed';
            var actualRefills = found ? (found.refills || '0 Refills Remaining') : '0 Refills Remaining';
            var actualRouting = found ? (found.routing_status || 'Sent to Pharmacy') : 'Sent to Pharmacy';
            var actualInst = found ? (found.instructions || found.notes || fallbackInst || 'Take as directed by prescribing physician.') : (fallbackInst || 'Take as directed by prescribing physician.');
            var actualPharm = found ? (found.pharmacy || 'Preferred Pharmacy on File') : 'Preferred Pharmacy on File';

            if (idEl) idEl.textContent = 'Rx #' + actualId;
            if (nameEl) nameEl.textContent = actualName;
            if (docEl) docEl.textContent = actualDoc;
            if (dateEl) dateEl.textContent = actualDate;
            if (doseEl) doseEl.textContent = actualDose;
            if (qtyEl) qtyEl.textContent = actualQty;
            if (refillsEl) refillsEl.textContent = actualRefills;
            if (routingEl) routingEl.innerHTML = '<i class="fa-solid fa-circle-check" style="color:#059669;"></i> ' + actualRouting;
            if (statusBadge) statusBadge.textContent = actualRouting;
            if (instEl) instEl.textContent = actualInst;
            if (pharmNameEl) pharmNameEl.textContent = actualPharm;

            if (pdfBtn) {
                pdfBtn.onclick = function () { window.diorDownloadRxPdf(actualId); };
            }
            if (refillBtn) {
                refillBtn.onclick = function () { window.diorRequestRefill(actualId); };
            }

            window.diorOpenModal('modal-view-rx-detail');
        };

        window.diorRequestRefill = function (rxId) {
            if (typeof showToast === 'function') {
                showToast('Refill request submitted electronically to prescribing physician for Rx #' + rxId, false);
            } else {
                alert('Refill request submitted electronically to prescribing physician for Rx #' + rxId);
            }
        };

        window.diorViewDocumentModal = function (title, category, author, date, id) {
            var t = document.getElementById('doc-preview-title');
            var c = document.getElementById('doc-preview-category');
            var a = document.getElementById('doc-preview-author');
            var d = document.getElementById('doc-preview-date');
            var i = document.getElementById('doc-preview-id');
            if (t) t.textContent = title || 'Medical Record';
            if (c) c.textContent = category || 'Official Document';
            if (a) a.textContent = author || 'Dior Medical Urgent Care';
            if (d) d.textContent = date || '';
            if (i) i.textContent = id || 'DOC-88219';
            window.diorOpenModal('modal-view-document');
        };

        window.diorViewAppointmentDetails = function (apptId) {
            var appts = window.dior_patient_appts_data || [];
            var found = null;
            for (var i = 0; i < appts.length; i++) {
                if (String(appts[i].id) === String(apptId) || String(appts[i].appt_uid) === String(apptId)) {
                    found = appts[i];
                    break;
                }
            }

            var idEl = document.getElementById('pat-modal-appt-id');
            var provEl = document.getElementById('pat-modal-appt-provider');
            var specEl = document.getElementById('pat-modal-appt-spec');
            var statusBadge = document.getElementById('pat-modal-appt-status-badge');
            var dtEl = document.getElementById('pat-modal-appt-datetime');
            var modeEl = document.getElementById('pat-modal-appt-mode');
            var condEl = document.getElementById('pat-modal-appt-condition');
            var notesEl = document.getElementById('pat-modal-appt-notes');
            var zoomWrap = document.getElementById('pat-modal-zoom-wrap');
            var zoomLink = document.getElementById('pat-modal-zoom-link');

            if (found) {
                if (idEl) idEl.textContent = 'APPT #' + (found.id || found.appt_uid || apptId);
                if (provEl) provEl.textContent = found.provider || found.doctor_name || 'Attending Physician';
                if (specEl) specEl.textContent = found.provider_spec || found.provider_title || 'Telehealth Urgent Care';
                if (statusBadge) {
                    var st = found.status || found.appt_status || 'Confirmed';
                    statusBadge.textContent = st;
                    statusBadge.className = 'dior-st ' + (st === 'Confirmed' || st === 'Completed' ? 'ok' : (st === 'Cancelled' ? 'error' : 'pending'));
                }
                if (dtEl) dtEl.textContent = (found.date || found.appt_date || '') + ' ' + (found.time || found.appt_time || '');
                if (modeEl) modeEl.innerHTML = '<i class="fa-solid fa-video" style="color:#2C6CB1;"></i> ' + (found.type || found.visit_type || 'Video Visit');
                if (condEl) condEl.textContent = found.condition || found.condition_name || 'Telehealth Consultation';
                if (notesEl) notesEl.textContent = found.notes || 'Standard telehealth clinical consultation scheduled. All submitted medical intake questionnaires are pre-verified.';
                
                var joinUrl = found.join_url || 'https://zoom.us/join';
                var isLive = (found.status === 'Confirmed' || found.status === 'Scheduled' || found.status === 'In-Queue');
                if (zoomWrap) {
                    zoomWrap.style.display = isLive ? 'flex' : 'none';
                    if (zoomLink) zoomLink.href = joinUrl;
                }
            } else if (idEl) {
                idEl.textContent = 'APPT #' + apptId;
            }

            window.diorOpenModal('modal-view-appointment-detail');
        };

        window.diorDownloadCurrentDocumentPdf = function () {
            var title = (document.getElementById('doc-preview-title') && document.getElementById('doc-preview-title').textContent) || 'Medical Record';
            var docId = (document.getElementById('doc-preview-id') && document.getElementById('doc-preview-id').textContent) || 'DOC-88219';
            var cat = (document.getElementById('doc-preview-category') && document.getElementById('doc-preview-category').textContent) || 'Official Document';
            var author = (document.getElementById('doc-preview-author') && document.getElementById('doc-preview-author').textContent) || 'Dior Medical Urgent Care';
            var date = (document.getElementById('doc-preview-date') && document.getElementById('doc-preview-date').textContent) || 'Sept 4, 2026';
            var patientName = (document.getElementById('doc-preview-patient') && document.getElementById('doc-preview-patient').textContent) || 'Verified Patient';

            var cleanFileName = 'Dior-' + title.replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';

            var printContent = '<div style="max-width:760px;margin:0 auto;padding:36px;font-family:Arial,Helvetica,sans-serif;color:#0F172A;background:#FFFFFF;border:2px solid #2C6CB1;border-radius:12px;">' +
                '<div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #2C6CB1;padding-bottom:18px;margin-bottom:24px;">' +
                '<div>' +
                '<h1 style="margin:0;font-size:22px;color:#0B1030;font-weight:800;letter-spacing:0.02em;">DIOR MEDICAL TELEHEALTH</h1>' +
                '<p style="margin:4px 0 0 0;font-size:12px;color:#64748B;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">Official Certified Clinical Record &amp; Medical Certificate</p>' +
                '</div>' +
                '<div style="text-align:right;">' +
                '<div style="display:inline-block;padding:5px 12px;background:#EFF6FF;color:#2C6CB1;border:1px solid #BFDBFE;border-radius:20px;font-size:11.5px;font-weight:700;">' +
                '&#10003; HIPAA Certified' +
                '</div>' +
                '<p style="margin:6px 0 0 0;font-size:11px;color:#64748B;">Doc Ref: <strong>' + docId + '</strong></p>' +
                '</div>' +
                '</div>' +

                '<div style="text-align:center;padding:16px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;margin-bottom:24px;">' +
                '<span style="display:inline-block;padding:3px 12px;background:#EFF6FF;color:#2563EB;border-radius:12px;font-size:11.5px;font-weight:700;text-transform:uppercase;margin-bottom:8px;">' + cat + '</span>' +
                '<h2 style="margin:0;font-size:19px;color:#0F172A;font-weight:800;">' + title + '</h2>' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;margin-bottom:24px;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:8px;">' +
                '<tr style="background:#F1F5F9;border-bottom:1px solid #CBD5E1;">' +
                '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;width:25%;">Patient Name:</td>' +
                '<td style="padding:10px 14px;font-size:13px;color:#0F172A;font-weight:700;width:25%;">' + patientName + '</td>' +
                '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;width:25%;">Date Issued:</td>' +
                '<td style="padding:10px 14px;font-size:13px;color:#0F172A;font-weight:700;width:25%;">' + date + '</td>' +
                '</tr>' +
                '<tr>' +
                '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;">Issuing Authority:</td>' +
                '<td style="padding:10px 14px;font-size:13px;color:#0F172A;font-weight:600;">' + author + '</td>' +
                '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;">Document Status:</td>' +
                '<td style="padding:10px 14px;font-size:13px;color:#059669;font-weight:700;">Verified &amp; Active</td>' +
                '</tr>' +
                '</table>' +

                '<div style="padding:18px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;font-size:13px;line-height:1.6;color:#334155;margin-bottom:24px;">' +
                '<p style="margin:0 0 10px 0;"><strong>Official Record Statement:</strong></p>' +
                '<p style="margin:0;">This certified document confirms that the individual designated above has satisfactorily completed all medical intake verifications, clinical evaluations, and electronic consent protocols via the Dior Medical Telehealth system. All records are maintained in strict accordance with 45 CFR Parts 160 and 164 (HIPAA Security &amp; Privacy Rules) and DEA Title 21 telemedicine provisions.</p>' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;border-top:2px solid #E2E8F0;padding-top:16px;margin-top:16px;">' +
                '<tr>' +
                '<td style="width:60%;vertical-align:bottom;font-size:11px;color:#64748B;line-height:1.5;">' +
                '<strong style="color:#059669;">&#10003; Cryptographically Certified Electronic Record</strong><br>' +
                'Security Hash: SHA-256 Verified &bull; Federal ESIGN &amp; UETA Act Compliant' +
                '</td>' +
                '<td style="width:40%;vertical-align:bottom;text-align:right;">' +
                '<div style="font-family:\'Courier New\',Courier,monospace;font-size:15px;color:#0F172A;font-weight:700;border-bottom:1px solid #0F172A;display:inline-block;padding-bottom:2px;margin-bottom:4px;">' +
                '/s/ Dior Medical Clinical Directorate' +
                '</div>' +
                '<div style="font-size:11px;color:#64748B;font-weight:600;">' +
                'Authorized Telehealth Certification' +
                '</div>' +
                '</td>' +
                '</tr>' +
                '</table>' +
                '</div>';

            var tempContainer = document.createElement('div');
            tempContainer.style.position = 'fixed';
            tempContainer.style.left = '-9999px';
            tempContainer.style.top = '0';
            tempContainer.style.width = '800px';
            tempContainer.innerHTML = printContent;
            document.body.appendChild(tempContainer);

            if (typeof html2pdf !== 'undefined') {
                var opt = {
                    margin: [10, 10, 10, 10],
                    filename: cleanFileName,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: { scale: 2, useCORS: true, logging: false },
                    jsPDF: { unit: 'mm', format: 'letter', orientation: 'portrait' }
                };
                html2pdf().set(opt).from(tempContainer.firstElementChild).save().then(function () {
                    document.body.removeChild(tempContainer);
                }).catch(function (err) {
                    console.error('PDF export error:', err);
                    document.body.removeChild(tempContainer);
                    fallbackPrintWindow(printContent, title);
                });
            } else {
                document.body.removeChild(tempContainer);
                fallbackPrintWindow(printContent, title);
            }
        };

        function fallbackPrintWindow(htmlContent, title) {
            var printWindow = window.open('', '_blank');
            if (printWindow) {
                printWindow.document.write('<html><head><title>' + title + '</title><style>@page{size:auto;margin:15mm;} body{margin:0;padding:20px;font-family:Arial,sans-serif;}</style></head><body>' + htmlContent + '</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(function () { printWindow.print(); }, 250);
            } else {
                window.print();
            }
        }

        window.diorDownloadReceiptPdf = function () {
            var invId = (document.getElementById('rec-inv-id') && document.getElementById('rec-inv-id').textContent) || 'INV-8829';
            var date = (document.getElementById('rec-date') && document.getElementById('rec-date').textContent) || 'Sept 4, 2026';
            var patientInfo = (document.getElementById('rec-patient-info') && document.getElementById('rec-patient-info').textContent) || 'Patient';
            var service = (document.getElementById('rec-service') && document.getElementById('rec-service').textContent) || 'Urgent Care Telehealth Consultation';
            var amount = (document.getElementById('rec-amount') && document.getElementById('rec-amount').textContent) || '$49.00';
            var logoUrl = '<?php echo esc_js($logo_url); ?>';

            var cleanFileName = 'Dior-Receipt-' + invId.replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';

            var printContent = '<div style="max-width:720px;margin:0 auto;padding:36px;font-family:Arial,Helvetica,sans-serif;color:#0F172A;background:#FFFFFF;border:2px solid #2C6CB1;border-radius:12px;">' +
                '<div style="text-align:center;margin-bottom:20px;border-bottom:3px solid #2C6CB1;padding-bottom:18px;">' +
                '<img src="' + logoUrl + '" alt="Dior Medical" style="height:70px;max-height:75px;object-fit:contain;margin-bottom:8px;">' +
                '<h1 style="margin:0;font-size:22px;color:#0B1030;font-weight:800;letter-spacing:0.02em;">DIOR MEDICAL TELEHEALTH</h1>' +
                '<p style="margin:4px 0 0 0;font-size:12px;color:#64748B;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">Official Medical Statement &amp; Itemized Receipt</p>' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;margin-bottom:24px;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:8px;">' +
                '<tr style="background:#F1F5F9;border-bottom:1px solid #CBD5E1;">' +
                '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;width:35%;">Invoice #:</td>' +
                '<td style="padding:12px 16px;font-size:14px;color:#0F172A;font-weight:800;">' + invId + '</td>' +
                '</tr>' +
                '<tr style="border-bottom:1px solid #E2E8F0;">' +
                '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Date of Transaction:</td>' +
                '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">' + date + '</td>' +
                '</tr>' +
                '<tr style="border-bottom:1px solid #E2E8F0;">' +
                '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Patient Name &amp; ID:</td>' +
                '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">' + patientInfo + '</td>' +
                '</tr>' +
                '<tr style="border-bottom:1px solid #E2E8F0;">' +
                '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Service Description:</td>' +
                '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">' + service + '</td>' +
                '</tr>' +
                '<tr style="border-bottom:1px solid #E2E8F0;">' +
                '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Payment Method:</td>' +
                '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">Stripe (Credit Card / Apple Pay) &bull; Verified &bull; Paid in Full</td>' +
                '</tr>' +
                '<tr style="background:#EFF6FF;">' +
                '<td style="padding:14px 16px;font-weight:800;font-size:14px;color:#1E40AF;">Total Paid:</td>' +
                '<td style="padding:14px 16px;font-size:17px;color:#1E40AF;font-weight:800;">' + amount + '</td>' +
                '</tr>' +
                '</table>' +

                '<div style="padding:14px 18px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;font-size:12px;color:#64748B;text-align:center;line-height:1.5;margin-bottom:24px;">' +
                '<strong>Tax Compliance &amp; Insurance Reimbursement Notice:</strong><br>' +
                'Dior Medical Telehealth &amp; Urgent Care &bull; Tax ID / NPI Verified &bull; Eligible for HSA / FSA Flexible Spending Account Reimbursement' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;border-top:2px solid #E2E8F0;padding-top:16px;">' +
                '<tr>' +
                '<td style="width:60%;vertical-align:bottom;font-size:11px;color:#64748B;line-height:1.5;">' +
                '<strong style="color:#059669;">&#10003; Official Electronic Payment Receipt</strong><br>' +
                'Transaction ID: ' + invId + ' &bull; Status: Completed' +
                '</td>' +
                '<td style="width:40%;vertical-align:bottom;text-align:right;">' +
                '<div style="font-family:\'Courier New\',Courier,monospace;font-size:14px;color:#0F172A;font-weight:700;border-bottom:1px solid #0F172A;display:inline-block;padding-bottom:2px;margin-bottom:4px;">' +
                'Dior Billing Directorate' +
                '</div>' +
                '<div style="font-size:11px;color:#64748B;font-weight:600;">Authorized Financial Officer</div>' +
                '</td>' +
                '</tr>' +
                '</table>' +
                '</div>';

            var tempContainer = document.createElement('div');
            tempContainer.style.position = 'fixed';
            tempContainer.style.left = '-9999px';
            tempContainer.style.top = '0';
            tempContainer.style.width = '750px';
            tempContainer.innerHTML = printContent;
            document.body.appendChild(tempContainer);

            if (typeof html2pdf !== 'undefined') {
                var opt = {
                    margin: [10, 10, 10, 10],
                    filename: cleanFileName,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: { scale: 2, useCORS: true, logging: false },
                    jsPDF: { unit: 'mm', format: 'letter', orientation: 'portrait' }
                };
                html2pdf().set(opt).from(tempContainer.firstElementChild).save().then(function () {
                    document.body.removeChild(tempContainer);
                }).catch(function (err) {
                    console.error('PDF receipt export error:', err);
                    document.body.removeChild(tempContainer);
                    fallbackPrintWindow(printContent, invId);
                });
            } else {
                document.body.removeChild(tempContainer);
                fallbackPrintWindow(printContent, invId);
            }
        };

        window.diorPrintReceiptModal = function () {
            window.diorDownloadReceiptPdf();
        };

        window.diorDownloadRxPdf = function (rxId) {
            var element = document.getElementById('rx-pdf-template-' + rxId);
            if (!element) {
                var allTemplates = document.querySelectorAll('[id^="rx-pdf-template-"]');
                if (allTemplates && allTemplates.length > 0) {
                    for (var k = 0; k < allTemplates.length; k++) {
                        if (allTemplates[k].id.indexOf(rxId) !== -1) {
                            element = allTemplates[k];
                            break;
                        }
                    }
                }
            }
            if (!element) { alert('Prescription details not found for Rx #' + rxId); return; }

            var cleanFileName = 'Dior-Prescription-' + String(rxId).replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';
            var innerContent = element.innerHTML;

            var tempContainer = document.createElement('div');
            tempContainer.style.position = 'fixed';
            tempContainer.style.left = '-9999px';
            tempContainer.style.top = '0';
            tempContainer.style.width = '800px';
            tempContainer.style.background = '#FFFFFF';
            tempContainer.style.zIndex = '99999';
            tempContainer.innerHTML = innerContent;
            document.body.appendChild(tempContainer);

            if (typeof html2pdf !== 'undefined') {
                var opt = {
                    margin: [8, 8, 8, 8],
                    filename: cleanFileName,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: { scale: 2, useCORS: true, logging: false },
                    jsPDF: { unit: 'mm', format: 'letter', orientation: 'portrait' }
                };
                html2pdf().set(opt).from(tempContainer).save().then(function () {
                    if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                }).catch(function (err) {
                    console.error('PDF export error:', err);
                    if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                    fallbackPrintWindow(innerContent, 'Prescription #' + rxId);
                });
            } else {
                if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                fallbackPrintWindow(innerContent, 'Prescription #' + rxId);
            }
        };

        function diorInitThemeMode() {
            localStorage.removeItem('dior_theme_mode');
            var portal = document.getElementById('dior-patient-portal-app') || document.body;
            if (portal) {
                portal.classList.remove('dior-dark-theme');
            }
        }

        if (typeof window.diorInitTablePagination !== 'function') {
            window.diorInitTablePagination = function (tableEl, pageSize) {
                if (!tableEl) return;
                pageSize = pageSize || 5;
                var tbody = tableEl.querySelector('tbody');
                if (!tbody) return;

                var parent = tableEl.parentElement;
                var paginationWrap = parent.querySelector(':scope > .dior-table-pagination') || (parent.parentElement ? parent.parentElement.querySelector(':scope > .dior-table-pagination') : null);

                if (!paginationWrap) {
                    paginationWrap = document.createElement('div');
                    paginationWrap.className = 'dior-table-pagination';
                    if (parent.classList.contains('dior-table-responsive') || parent.classList.contains('dior-card-body') || parent.style.overflowX === 'auto' || parent.style.overflow === 'auto') {
                        parent.after(paginationWrap);
                    } else {
                        parent.appendChild(paginationWrap);
                    }
                }

                var currentPage = 1;

                function renderPage(page) {
                    currentPage = page || 1;
                    var allRows = Array.from(tbody.querySelectorAll('tr')).filter(function (tr) {
                        return !tr.classList.contains('dior-no-data-row') && tr.querySelectorAll('td').length > 1;
                    });

                    if (allRows.length === 0) {
                        paginationWrap.style.display = 'none';
                        return;
                    }

                    var activeRows = allRows.filter(function (tr) {
                        return tr.getAttribute('data-filter-hidden') !== 'true';
                    });
                    var total = activeRows.length;
                    var totalPages = Math.max(1, Math.ceil(total / pageSize));

                    if (currentPage > totalPages) currentPage = totalPages;
                    if (currentPage < 1) currentPage = 1;

                    var startIndex = (currentPage - 1) * pageSize;
                    var endIndex = startIndex + pageSize;

                    allRows.forEach(function (tr) {
                        if (tr.getAttribute('data-filter-hidden') === 'true') {
                            tr.style.display = 'none';
                        }
                    });

                    activeRows.forEach(function (tr, index) {
                        if (index >= startIndex && index < endIndex) {
                            tr.style.display = '';
                        } else {
                            tr.style.display = 'none';
                        }
                    });

                    if (totalPages <= 1) {
                        paginationWrap.style.display = 'none';
                        return;
                    }

                    var fromItem = total === 0 ? 0 : startIndex + 1;
                    var toItem = Math.min(endIndex, total);

                    var navHtml = '';
                    if (totalPages > 1) {
                        navHtml += '<button type="button" class="dior-page-btn" ' + (currentPage === 1 ? 'disabled' : '') + ' data-page="' + (currentPage - 1) + '" title="Previous Page"><i class="fa-solid fa-chevron-left" style="font-size:11px;"></i></button>';

                        for (var i = 1; i <= totalPages; i++) {
                            if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
                                navHtml += '<button type="button" class="dior-page-btn ' + (i === currentPage ? 'active' : '') + '" data-page="' + i + '">' + i + '</button>';
                            } else if (i === currentPage - 2 || i === currentPage + 2) {
                                navHtml += '<span style="padding: 0 4px; color: #94A3B8; font-size:12px;">...</span>';
                            }
                        }

                        navHtml += '<button type="button" class="dior-page-btn" ' + (currentPage === totalPages ? 'disabled' : '') + ' data-page="' + (currentPage + 1) + '" title="Next Page"><i class="fa-solid fa-chevron-right" style="font-size:11px;"></i></button>';
                    }

                    paginationWrap.style.display = 'flex';
                    paginationWrap.innerHTML = '<div class="dior-pagination-info">Showing <strong>' + fromItem + '</strong> to <strong>' + toItem + '</strong> of <strong>' + total + '</strong> entries</div><div class="dior-pagination-nav">' + navHtml + '</div>';

                    paginationWrap.querySelectorAll('.dior-page-btn[data-page]').forEach(function (btn) {
                        btn.onclick = function (e) {
                            e.preventDefault();
                            var p = parseInt(this.getAttribute('data-page'), 10);
                            if (!isNaN(p)) renderPage(p);
                        };
                    });
                }

                tableEl._diorRenderPage = renderPage;
                renderPage(1);
            };
        }

        function initAllDiorTablePaginations() {
            diorInitThemeMode();
            document.querySelectorAll('.dior-table, .dior-clean-table, .dior-doc-table').forEach(function (table) {
                if (typeof window.diorInitTablePagination === 'function') {
                    window.diorInitTablePagination(table, 5);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', initAllDiorTablePaginations);
        if (document.readyState === 'interactive' || document.readyState === 'complete') {
            initAllDiorTablePaginations();
        }
    </script>
</div> <!-- /#dior-patient-portal-app -->
<?php
                return ob_get_clean();
    }

    /**
     * AJAX Login Handler
     */
    public static function handle_login()
    {
        check_ajax_referer('dior_auth_nonce', 'nonce');

        $raw_username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = !empty($_POST['rememberme']);
        $redirect_to = !empty($_POST['redirect_to']) ? esc_url_raw($_POST['redirect_to']) : '';

        if (empty($raw_username) || empty($password)) {
            wp_send_json_error(['message' => 'Please enter both your email/username and password.']);
        }

        $username = $raw_username;
        if (is_email($raw_username)) {
            $user_obj = get_user_by('email', $raw_username);
            if ($user_obj) {
                $username = $user_obj->user_login;
            }
        } else {
            $username = sanitize_user($raw_username);
        }

        $creds = [
            'user_login' => $username,
            'user_password' => $password,
            'remember' => $remember
        ];

        $user = wp_signon($creds, is_ssl());

        if (is_wp_error($user)) {
            wp_send_json_error(['message' => 'Invalid email or password. Please try again.']);
        }

        // Get user roles after successful login
        $user_id = $user->ID;
        $user_data = get_userdata($user_id);
        $roles = (array) $user_data->roles;

        // Check user roles
        $user_id = $user->ID;
        $user_data = get_userdata($user_id);
        $roles = (array) $user_data->roles;
        $is_doctor = in_array('doctor', $roles) || in_array('administrator', $roles) || in_array($user_data->user_login, ['docter', 'admin', 'doctor', 'jameschen', 'evelynvance', 'marcussterling', 'jon']);

        if ($is_doctor) {
            $redirect = home_url('/doctor-dashboard/');
        } elseif (!empty($redirect_to) && strpos($redirect_to, 'diro-login') === false && strpos($redirect_to, 'diro-registration') === false && strpos($redirect_to, 'doctor-dashboard') === false) {
            $redirect = $redirect_to;
        } else {
            $redirect = home_url('/patient-dashboard/');
        }

        wp_send_json_success([
            'message' => 'Login successful! Redirecting to dashboard...',
            'redirect' => $redirect
        ]);
    }

    /**
     * Role-based Login Redirect Filter for standard WP login
     */
    public static function custom_login_redirect($redirect_to, $requested_redirect_to, $user)
    {
        if ($user instanceof \WP_User && isset($user->roles) && is_array($user->roles)) {
            $is_doctor = in_array('doctor', $user->roles) || in_array('administrator', $user->roles) || in_array($user->user_login, ['docter', 'admin', 'doctor', 'jameschen', 'evelynvance', 'marcussterling', 'jon']);
            if ($is_doctor) {
                return home_url('/doctor-dashboard/');
            }
            return home_url('/patient-dashboard/');
        }
        return $redirect_to;
    }

    /**
     * AJAX Register Handler
     */
    public static function handle_register()
    {
        check_ajax_referer('dior_auth_nonce', 'nonce');

        $first_name = sanitize_text_field($_POST['first_name'] ?? '');
        $last_name = sanitize_text_field($_POST['last_name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $dob = sanitize_text_field($_POST['dob'] ?? '');
        $gender = sanitize_text_field($_POST['gender'] ?? 'Female');
        $eligibility = sanitize_text_field($_POST['eligibility_check'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_pwd = $_POST['confirm_password'] ?? '';
        $terms = !empty($_POST['terms_consent']);

        if (empty($first_name) || empty($last_name)) {
            wp_send_json_error(['message' => 'Please provide your full legal name.']);
        }

        if (empty($email) || !is_email($email)) {
            wp_send_json_error(['message' => 'Please enter a valid email address.']);
        }

        if (email_exists($email)) {
            wp_send_json_error(['message' => 'An account with this email already exists. Please log in.']);
        }

        if ($eligibility !== 'yes') {
            wp_send_json_error(['message' => 'You must be 18 years of age or older to create an account and receive care.']);
        }

        if (strlen($password) < 6) {
            wp_send_json_error(['message' => 'Password must be at least 6 characters long.']);
        }

        if ($password !== $confirm_pwd) {
            wp_send_json_error(['message' => 'Passwords do not match. Please re-enter.']);
        }

        if (!$terms) {
            wp_send_json_error(['message' => 'You must accept the Telehealth Terms of Care and Privacy Policy.']);
        }

        // Generate clean username from email
        $email_parts = explode('@', $email);
        $username_base = sanitize_user(current($email_parts));
        if (empty($username_base)) {
            $username_base = 'patient';
        }
        $username = $username_base;
        $i = 1;
        while (username_exists($username)) {
            $username = $username_base . $i;
            $i++;
        }

        $user_id = wp_create_user($username, $password, $email);

        if (is_wp_error($user_id)) {
            wp_send_json_error(['message' => $user_id->get_error_message()]);
        }

        // Set user details
        wp_update_user([
            'ID' => $user_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'display_name' => $first_name . ' ' . $last_name,
            'role' => 'subscriber'
        ]);

        update_user_meta($user_id, 'phone', $phone);
        update_user_meta($user_id, 'dob', $dob);
        update_user_meta($user_id, 'gender', $gender);
        update_user_meta($user_id, 'is_18_verified', 'yes');
        update_user_meta($user_id, 'patient_id', 'DM-' . rand(10000, 99999));

        // Auto log in new user
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);

        wp_send_json_success([
            'message' => 'Account created successfully! Redirecting to your dashboard...',
            'redirect' => home_url('/patient-dashboard/')
        ]);
    }

    /**
     * AJAX Logout Handler
     */
    public static function handle_logout()
    {
        wp_logout();
        wp_send_json_success([
            'redirect' => home_url('/diro-login/')
        ]);
    }

    /**
     * AJAX Save Patient Profile
     */
    public static function ajax_save_profile()
    {
        check_ajax_referer('dior_portal_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(['message' => 'Authentication required.']);
        }

        $first_name = sanitize_text_field($_POST['first_name'] ?? '');
        $last_name = sanitize_text_field($_POST['last_name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $dob = sanitize_text_field($_POST['dob'] ?? '');
        $gender = sanitize_text_field($_POST['gender'] ?? 'Female');
        $address = sanitize_text_field($_POST['address'] ?? '');

        // Emergency contact
        $em_name = sanitize_text_field($_POST['emergency_name'] ?? '');
        $em_rel = sanitize_text_field($_POST['emergency_relation'] ?? '');
        $em_phone = sanitize_text_field($_POST['emergency_phone'] ?? '');

        // Preferred Pharmacy
        $pharm_name = sanitize_text_field($_POST['pharmacy_name'] ?? '');
        $pharm_address = sanitize_text_field($_POST['pharmacy_address'] ?? '');
        $pharm_phone = sanitize_text_field($_POST['pharmacy_phone'] ?? '');

        if (!empty($first_name) || !empty($last_name)) {
            wp_update_user([
                'ID' => $user_id,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'display_name' => trim($first_name . ' ' . $last_name)
            ]);
        }

        if (!empty($email) && is_email($email)) {
            wp_update_user(['ID' => $user_id, 'user_email' => $email]);
        }

        update_user_meta($user_id, 'phone', $phone);
        update_user_meta($user_id, 'dob', $dob);
        update_user_meta($user_id, 'gender', $gender);
        update_user_meta($user_id, 'address', $address);
        update_user_meta($user_id, 'emergency_name', $em_name);
        update_user_meta($user_id, 'emergency_relation', $em_rel);
        update_user_meta($user_id, 'emergency_phone', $em_phone);
        update_user_meta($user_id, 'preferred_pharmacy_name', $pharm_name);
        update_user_meta($user_id, 'preferred_pharmacy_address', $pharm_address);
        update_user_meta($user_id, 'preferred_pharmacy_phone', $pharm_phone);

        wp_send_json_success(['message' => 'Profile updated successfully!']);
    }

    /**
     * AJAX Check Intake Status (For real-time unlock after HIPAAtizer submission)
     */
    public static function ajax_check_intake_status()
    {
        check_ajax_referer('dior_portal_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(['message' => 'Authentication required.']);
        }

        $hipaa_intake = get_user_meta($user_id, 'dior_hipaa_intake', true);
        if (!empty($hipaa_intake) && is_array($hipaa_intake)) {
            wp_send_json_success([
                'has_intake' => true,
                'hipaa_intake' => $hipaa_intake
            ]);
        } else {
            wp_send_json_success([
                'has_intake' => false
            ]);
        }
    }

    /**
     * AJAX Change Password (Real Backend Security)
     */
    public static function ajax_change_password()
    {
        check_ajax_referer('dior_portal_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(['message' => 'Authentication required.']);
        }

        $current_pwd = $_POST['current_password'] ?? '';
        $new_pwd = $_POST['new_password'] ?? '';
        $confirm_pwd = $_POST['confirm_password'] ?? '';

        if (empty($current_pwd) || empty($new_pwd)) {
            wp_send_json_error(['message' => 'Please fill in all password fields.']);
        }

        if ($new_pwd !== $confirm_pwd) {
            wp_send_json_error(['message' => 'New passwords do not match.']);
        }

        if (strlen($new_pwd) < 6) {
            wp_send_json_error(['message' => 'New password must be at least 6 characters long.']);
        }

        $user = get_userdata($user_id);
        if (!$user || !wp_check_password($current_pwd, $user->user_pass, $user_id)) {
            wp_send_json_error(['message' => 'Current password is incorrect.']);
        }

        wp_set_password($new_pwd, $user_id);
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);

        wp_send_json_success(['message' => 'Password updated successfully!']);
    }

    /**
     * AJAX Book Patient Appointment (Integrated with DocBooker & Multi-Doctor Routing)
     */
    public static function ajax_book_appointment()
    {
        // Accept nonce from either dashboard, auth, or forms
        if (isset($_POST['nonce'])) {
            Dior_Auth_Service::verify_ajax_nonce(['dior_portal_nonce', 'dior_auth_nonce', 'dior_doctor_nonce']);
        }

        $user_id = Dior_Auth_Service::get_current_user_id();
        
        // If guest booking (e.g. from public wizard), handle patient email
        $patient_email = sanitize_email($_POST['email'] ?? ($_POST['patient_email'] ?? ''));
        $patient_name = sanitize_text_field($_POST['name'] ?? ($_POST['patient_name'] ?? ($_POST['full_name'] ?? '')));
        $patient_phone = sanitize_text_field($_POST['phone'] ?? ($_POST['patient_phone'] ?? ''));

        if (!$user_id) {
            if ($patient_email && is_email($patient_email)) {
                $existing_user = get_user_by('email', $patient_email);
                if ($existing_user) {
                    $user_id = $existing_user->ID;
                } else {
                    $login = sanitize_user(current(explode('@', $patient_email)));
                    if (username_exists($login)) $login .= '_' . rand(100, 999);
                    $new_pid = wp_insert_user([
                        'user_login'   => $login,
                        'user_email'   => $patient_email,
                        'user_pass'    => wp_generate_password(12, true),
                        'display_name' => $patient_name ?: $login,
                        'role'         => 'subscriber'
                    ]);
                    if (!is_wp_error($new_pid)) {
                        $user_id = $new_pid;
                        if ($patient_phone) update_user_meta($new_pid, 'phone', $patient_phone);
                    }
                }
            }
        }

        if (!$user_id) {
            wp_send_json_error(['message' => 'Please sign in or provide a valid email address to complete booking.'], 401);
        }

        $condition = sanitize_text_field($_POST['condition'] ?? ($_POST['treatment'] ?? 'Urgent Care Telehealth'));
        $type = sanitize_text_field($_POST['type'] ?? 'Video Visit (HD)');
        $provider_raw = sanitize_text_field($_POST['provider'] ?? ($_POST['doctor'] ?? ($_POST['doctor_name'] ?? '')));
        $doctor_id_raw = intval($_POST['doctorId'] ?? ($_POST['doctor_id'] ?? 0));
        $date = sanitize_text_field($_POST['date'] ?? ($_POST['bookingDate'] ?? current_time('Y-m-d')));
        $time = sanitize_text_field($_POST['time'] ?? 'Today - ASAP');
        $notes = sanitize_textarea_field($_POST['notes'] ?? ($_POST['patient_note'] ?? ''));

        // Resolve Doctor WP User ID & Name
        $doctor_user_id = 0;
        $doctor_name = $provider_raw ?: 'Dr. Dior Specialist';

        if (class_exists('Dior_Doctor_Resolver')) {
            $doctor_user_id = Dior_Doctor_Resolver::resolve_doctor_user_id($doctor_id_raw ?: $provider_raw);
        }

        if ($doctor_id_raw && is_numeric($doctor_id_raw)) {
            $doc_post = get_post($doctor_id_raw);
            if ($doc_post && $doc_post->post_type === 'wpddb_doctor') {
                $doctor_name = $doc_post->post_title;
            }
        } elseif ($doctor_user_id) {
            $du = get_userdata($doctor_user_id);
            if ($du) $doctor_name = $du->display_name;
        }

        $new_apt = Dior_Appointment_Service::book_appointment([
            'patient_id'     => $user_id,
            'doctor_id'      => $doctor_id_raw ?: ($doctor_user_id ?: 1),
            'doctor_user_id' => $doctor_user_id,
            'provider'       => $doctor_name,
            'condition'      => $condition,
            'visit_type'     => $type,
            'appt_date'      => $date,
            'appt_time'      => $time,
            'join_url'       => 'https://zoom.us/join',
            'payment_status' => 'Paid',
            'notes'          => $notes
        ]);

        if (is_wp_error($new_apt)) {
            wp_send_json_error(['message' => $new_apt->get_error_message()]);
        }

        // Synchronize with DocBooker database tables if present
        global $wpdb;
        $table_bookings = $wpdb->prefix . 'wpddb_bookings';
        $table_patients = $wpdb->prefix . 'wpddb_patients';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_bookings'") == $table_bookings) {
            $user_obj = get_userdata($user_id);
            $patient_row = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table_patients WHERE email = %s LIMIT 1", $user_obj->user_email));
            $docbooker_patient_id = $patient_row ? $patient_row->id : 0;
            if (!$docbooker_patient_id && $wpdb->get_var("SHOW TABLES LIKE '$table_patients'") == $table_patients) {
                $wpdb->insert($table_patients, [
                    'full_name' => $user_obj->display_name,
                    'email' => $user_obj->user_email,
                    'phone' => get_user_meta($user_id, 'phone', true) ?: '(555) 000-0000',
                    'dob' => get_user_meta($user_id, 'dob', true) ?: '1992-05-14',
                    'patient_code' => 'DM-' . (10000 + ($user_id % 90000))
                ]);
                $docbooker_patient_id = $wpdb->insert_id;
            }
            $wpdb->insert($table_bookings, [
                'booking_id' => 'BK-' . rand(100000, 999999),
                'patient_id' => $docbooker_patient_id ?: $user_id,
                'doctor_id' => $doctor_id_raw ?: 1,
                'clinic_id' => 1,
                'amount_paid' => 49.00,
                'payment_status' => 'Paid',
                'payment_by' => 'Stripe',
                'booking_present_status' => 'upcoming',
                'booking_date' => $date,
                'day' => date('l', strtotime($date)),
                'time' => $time,
                'patient_note' => $notes ?: $condition,
                'status' => 'approved'
            ]);
        }

        // 1. Instant Patient Notification
        $notifications = Dior_Patient_Portal_Data::get_patient_notifications($user_id);
        array_unshift($notifications, [
            'id' => 'NOTIF-' . time() . '-' . rand(100, 999),
            'type' => 'appointment',
            'icon' => 'fa-calendar-check',
            'title' => 'Appointment Confirmed (' . $condition . ')',
            'message' => 'Your visit with ' . $doctor_name . ' is confirmed for ' . $date . ' at ' . $time . '. Click to join when ready.',
            'time' => 'Just now',
            'timestamp' => time(),
            'created_at' => current_time('mysql'),
            'is_read' => false,
            'action_url' => '#tab=appointments'
        ]);
        update_user_meta($user_id, 'dior_notifications', $notifications);

        // 2. Targeted Doctor Notification
        $patient_obj = get_userdata($user_id);
        $pname = $patient_obj ? $patient_obj->display_name : 'Patient';
        
        $notify_doctor_ids = [];
        if ($doctor_user_id) {
            $notify_doctor_ids[] = $doctor_user_id;
        }
        $default_doc_id = class_exists('Dior_Doctor_Resolver') ? Dior_Doctor_Resolver::get_default_doctor_id() : 0;
        if ($default_doc_id && !in_array($default_doc_id, $notify_doctor_ids)) {
            $notify_doctor_ids[] = $default_doc_id;
        }

        foreach (array_unique($notify_doctor_ids) as $du_id) {
            $dnotifs = get_user_meta($du_id, 'dior_doctor_notifications', true);
            if (!is_array($dnotifs)) $dnotifs = [];
            array_unshift($dnotifs, [
                'id' => 'DN-APT-' . time() . '-' . rand(10, 99),
                'type' => 'appointment',
                'icon' => 'fa-calendar-check',
                'title' => 'New Appointment Scheduled (' . $doctor_name . ')',
                'message' => $pname . ' scheduled a visit (' . $condition . ') for ' . $date . ' at ' . $time . '.',
                'time' => 'Just now',
                'timestamp' => time(),
                'created_at' => current_time('mysql'),
                'is_read' => false,
                'action_url' => '#tab=doc-appointments'
            ]);
            update_user_meta($du_id, 'dior_doctor_notifications', $dnotifs);
        }

        // --- EMAIL NOTIFICATIONS ---
        $patient_email = $patient_obj ? $patient_obj->user_email : '';
        $doctor_email = get_option('admin_email');
        if ($doctor_user_id) {
            $doc_user_obj = get_userdata($doctor_user_id);
            if ($doc_user_obj && $doc_user_obj->user_email) $doctor_email = $doc_user_obj->user_email;
        }

        $headers = ['Content-Type: text/html; charset=UTF-8'];

        if ($patient_email) {
            $patient_subject = "Appointment Confirmed & Payment Receipt - Dior Medical";
            $patient_msg = "
            <div style='font-family:sans-serif;max-width:600px;margin:0 auto;border:1px solid #e2e8f0;border-radius:8px;padding:20px;'>
                <h2 style='color:#059669;'>Appointment Confirmed!</h2>
                <p>Hello " . esc_html($patient_obj->display_name) . ",</p>
                <p>Your telehealth appointment has been successfully booked and confirmed.</p>
                <table style='width:100%;border-collapse:collapse;margin:20px 0;'>
                    <tr><td style='padding:8px;border-bottom:1px solid #e2e8f0;'><strong>Date & Time:</strong></td><td style='padding:8px;border-bottom:1px solid #e2e8f0;'>" . esc_html($date . " " . $time) . "</td></tr>
                    <tr><td style='padding:8px;border-bottom:1px solid #e2e8f0;'><strong>Condition:</strong></td><td style='padding:8px;border-bottom:1px solid #e2e8f0;'>" . esc_html($condition) . "</td></tr>
                    <tr><td style='padding:8px;border-bottom:1px solid #e2e8f0;'><strong>Provider:</strong></td><td style='padding:8px;border-bottom:1px solid #e2e8f0;'>" . esc_html($doctor_name) . "</td></tr>
                </table>
                <p>You can view your consultation details and join the video room directly from your <a href='" . home_url('/patient-dashboard/') . "'>Patient Dashboard</a>.</p>
                <p>Thank you,<br><strong>Dior Medical Telehealth Team</strong></p>
            </div>";
            wp_mail($patient_email, $patient_subject, $patient_msg, $headers);
        }

        if ($doctor_email) {
            $doc_subject = "New Telehealth Appointment Alert (" . $doctor_name . ")";
            $doc_msg = "
            <div style='font-family:sans-serif;max-width:600px;margin:0 auto;border:1px solid #e2e8f0;border-radius:8px;padding:20px;'>
                <h2 style='color:#2C6CB1;'>New Appointment Booked</h2>
                <p>A new telehealth appointment has been scheduled by <strong>" . esc_html($pname) . "</strong> with <strong>" . esc_html($doctor_name) . "</strong>.</p>
                <ul>
                    <li><strong>Date:</strong> " . esc_html($date) . "</li>
                    <li><strong>Time:</strong> " . esc_html($time) . "</li>
                    <li><strong>Condition:</strong> " . esc_html($condition) . "</li>
                    <li><strong>Notes:</strong> " . esc_html($notes) . "</li>
                </ul>
                <p>Please review the patient's chart in your <a href='" . home_url('/doctor-dashboard/') . "'>Doctor Dashboard</a> prior to the visit.</p>
            </div>";
            wp_mail($doctor_email, $doc_subject, $doc_msg, $headers);
        }

        $dashboard_url = home_url('/patient-dashboard/#tab=appointments');

        wp_send_json_success([
            'message'      => 'Appointment booked successfully! Redirecting to Patient Dashboard...',
            'redirect_url' => $dashboard_url,
            'appointment'  => $new_apt
        ]);
    }

    /**
     * DocBooker Hook: Handles bookings created via DocBooker REST API / Booking form
     */
    public static function on_docbooker_booking_created($booking)
    {
        if (empty($booking) || !is_array($booking)) return;

        $booking_id = $booking['booking_id'] ?? ('BK-' . time());
        $patient_email = $booking['patient_email'] ?? '';
        $patient_name = $booking['patient_name'] ?? 'Patient';
        $docbooker_doctor_id = $booking['doctor_id'] ?? 0;
        $date = $booking['booking_date'] ?? current_time('Y-m-d');
        $time = $booking['time'] ?? 'ASAP';
        $notes = $booking['notes'] ?? ($booking['patient_note'] ?? 'Telehealth Consultation');

        // Resolve Patient User ID
        $patient_user_id = 0;
        if (!empty($patient_email) && is_email($patient_email)) {
            $puser = get_user_by('email', $patient_email);
            if ($puser) {
                $patient_user_id = $puser->ID;
            } else {
                $login = sanitize_user(current(explode('@', $patient_email)));
                if (username_exists($login)) $login .= '_' . rand(100, 999);
                $new_pid = wp_insert_user([
                    'user_login'   => $login,
                    'user_email'   => $patient_email,
                    'user_pass'    => wp_generate_password(12, true),
                    'display_name' => $patient_name,
                    'role'         => 'subscriber'
                ]);
                if (!is_wp_error($new_pid)) {
                    $patient_user_id = $new_pid;
                    if (!empty($booking['patient_phone'])) {
                        update_user_meta($new_pid, 'phone', $booking['patient_phone']);
                    }
                }
            }
        }

        if (!$patient_user_id) {
            $patient_user_id = get_current_user_id();
        }

        // Resolve Doctor WP User ID & Name
        $doctor_user_id = 0;
        $doctor_name = 'Dr. Dior Specialist';
        if (class_exists('Dior_Doctor_Resolver')) {
            $doctor_user_id = Dior_Doctor_Resolver::resolve_doctor_user_id($docbooker_doctor_id);
        }
        if ($docbooker_doctor_id && is_numeric($docbooker_doctor_id)) {
            $doc_post = get_post($docbooker_doctor_id);
            if ($doc_post) $doctor_name = $doc_post->post_title;
        } elseif ($doctor_user_id) {
            $du = get_userdata($doctor_user_id);
            if ($du) $doctor_name = $du->display_name;
        }

        // 1. Add to Patient Appointments ledger
        if ($patient_user_id) {
            Dior_Appointment_Service::book_appointment([
                'patient_id'     => $patient_user_id,
                'doctor_id'      => $docbooker_doctor_id ?: $doctor_user_id,
                'doctor_user_id' => $doctor_user_id,
                'provider'       => $doctor_name,
                'condition'      => $notes ?: 'General Telehealth Consultation',
                'visit_type'     => 'Video Visit (HD)',
                'appt_date'      => $date,
                'appt_time'      => $time,
                'join_url'       => 'https://zoom.us/join',
                'payment_status' => 'Paid',
                'notes'          => $notes,
                'booking_id'     => $booking_id
            ]);

            // 2. Add Patient Notification
            $p_notifs = Dior_Patient_Portal_Data::get_patient_notifications($patient_user_id);
            array_unshift($p_notifs, [
                'id' => 'NOTIF-' . time() . '-' . rand(100, 999),
                'type' => 'appointment',
                'icon' => 'fa-calendar-check',
                'title' => 'Appointment Booked Successfully',
                'message' => 'Your visit with ' . $doctor_name . ' is confirmed for ' . $date . ' at ' . $time . '.',
                'time' => 'Just now',
                'timestamp' => time(),
                'created_at' => current_time('mysql'),
                'is_read' => false,
                'action_url' => '#tab=appointments'
            ]);
            update_user_meta($patient_user_id, 'dior_notifications', $p_notifs);
        }

        // 3. Add Doctor Notification to the targeted Doctor
        $notify_doctor_ids = [];
        if ($doctor_user_id) {
            $notify_doctor_ids[] = $doctor_user_id;
        }
        $default_doc_id = class_exists('Dior_Doctor_Resolver') ? Dior_Doctor_Resolver::get_default_doctor_id() : 0;
        if ($default_doc_id && !in_array($default_doc_id, $notify_doctor_ids)) {
            $notify_doctor_ids[] = $default_doc_id;
        }

        foreach (array_unique($notify_doctor_ids) as $doc_uid) {
            $dnotifs = get_user_meta($doc_uid, 'dior_doctor_notifications', true);
            if (!is_array($dnotifs)) $dnotifs = [];
            array_unshift($dnotifs, [
                'id' => 'DN-APT-' . time() . '-' . rand(10, 99),
                'type' => 'appointment',
                'icon' => 'fa-calendar-check',
                'title' => 'New Appointment Scheduled (' . $doctor_name . ')',
                'message' => $patient_name . ' scheduled a visit for ' . $date . ' at ' . $time . ' (' . ($notes ?: 'Telehealth') . ').',
                'time' => 'Just now',
                'timestamp' => time(),
                'created_at' => current_time('mysql'),
                'is_read' => false,
                'action_url' => '#tab=doc-appointments'
            ]);
            update_user_meta($doc_uid, 'dior_doctor_notifications', $dnotifs);
        }
    }

    /**
     * AJAX Reschedule Appointment
     */
    public static function ajax_reschedule_appointment()
    {
        check_ajax_referer('dior_portal_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id)
            wp_send_json_error(['message' => 'Authentication required.']);

        $appt_id = sanitize_text_field($_POST['appt_id'] ?? '');
        $new_date = sanitize_text_field($_POST['date'] ?? '');
        $new_time = sanitize_text_field($_POST['time'] ?? '');

        $appointments = Dior_Patient_Portal_Data::get_patient_appointments($user_id);
        $updated = false;

        foreach ($appointments as &$apt) {
            if ($apt['id'] === $appt_id) {
                $apt['date'] = $new_date;
                $apt['time'] = $new_time;
                $apt['status'] = 'Confirmed';
                $updated = true;
                break;
            }
        }

        if ($updated) {
            update_user_meta($user_id, 'dior_appointments', $appointments);
            wp_send_json_success(['message' => 'Appointment rescheduled to ' . $new_date . ' at ' . $new_time . '.']);
        } else {
            wp_send_json_error(['message' => 'Appointment not found.']);
        }
    }

    /**
     * AJAX Cancel Appointment
     */
    public static function ajax_cancel_appointment()
    {
        check_ajax_referer('dior_portal_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id)
            wp_send_json_error(['message' => 'Authentication required.']);

        $appt_id = sanitize_text_field($_POST['appt_id'] ?? '');
        $reason = sanitize_text_field($_POST['reason'] ?? 'Cancelled by patient');

        $appointments = Dior_Patient_Portal_Data::get_patient_appointments($user_id);
        $updated = false;

        foreach ($appointments as &$apt) {
            if ($apt['id'] === $appt_id) {
                $apt['status'] = 'Cancelled';
                $apt['can_join'] = false;
                $updated = true;
                break;
            }
        }

        if ($updated) {
            update_user_meta($user_id, 'dior_appointments', $appointments);
            wp_send_json_success(['message' => 'Appointment cancelled successfully.']);
        } else {
            wp_send_json_error(['message' => 'Appointment not found.']);
        }
    }

    /**
     * AJAX Submit Questionnaire (with E-Sign & Doctor Dashboard sharing)
     */
    public static function ajax_submit_questionnaire()
    {
        check_ajax_referer('dior_portal_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id)
            wp_send_json_error(['message' => 'Authentication required.']);

        $qn_id = sanitize_text_field($_POST['qn_id'] ?? '');
        $condition = sanitize_text_field($_POST['condition'] ?? 'General Urgent Care');
        $symptoms = sanitize_textarea_field($_POST['symptoms'] ?? '');
        $allergies = sanitize_text_field($_POST['allergies'] ?? '');
        $meds = sanitize_text_field($_POST['current_meds'] ?? '');
        $history = sanitize_text_field($_POST['medical_history'] ?? '');
        $esign = sanitize_text_field($_POST['esign_name'] ?? '');

        $questionnaires = Dior_Patient_Portal_Data::get_patient_questionnaires($user_id);
        $updated = false;

        foreach ($questionnaires as &$qn) {
            if ($qn['id'] === $qn_id) {
                $qn['status'] = 'Submitted';
                $qn['status_class'] = 'status-success';
                $qn['symptoms'] = $symptoms;
                $qn['allergies'] = $allergies;
                $qn['current_meds'] = $meds;
                $qn['last_updated'] = current_time('M j, Y');
                $qn['consent_signed'] = true;
                $updated = true;
                break;
            }
        }

        if ($updated) {
            update_user_meta($user_id, 'dior_questionnaires', $questionnaires);

            // Store in central Doctor Dashboard queryable format
            $all_intakes = get_user_meta($user_id, 'dior_patient_intakes', true) ?: [];
            $all_intakes[] = [
                'intake_id' => 'INTAKE-' . rand(10000, 99999),
                'qn_id' => $qn_id,
                'condition' => $condition,
                'symptoms' => $symptoms,
                'allergies' => $allergies,
                'current_meds' => $meds,
                'medical_history' => $history,
                'esign_name' => $esign,
                'submitted_at' => current_time('mysql'),
                'status' => 'Transmitted to Doctor Dashboard'
            ];
            update_user_meta($user_id, 'dior_patient_intakes', $all_intakes);

            // Add notification
            $notifications = Dior_Patient_Portal_Data::get_patient_notifications($user_id);
            array_unshift($notifications, [
                'id' => 'NOTIF-' . time() . '-' . rand(100, 999),
                'type' => 'system',
                'icon' => 'fa-clipboard-check',
                'title' => 'Clinical Intake Received & Transmitted',
                'message' => 'Your symptoms intake form has been submitted and transmitted to the Doctor Dashboard.',
                'time' => 'Just now',
                'timestamp' => time(),
                'created_at' => current_time('mysql'),
                'is_read' => false,
                'action_url' => '#tab=questionnaire'
            ]);
            update_user_meta($user_id, 'dior_notifications', $notifications);

            wp_send_json_success(['message' => 'Intake questionnaire & e-signed consent submitted successfully to Doctor Dashboard!']);
        } else {
            wp_send_json_error(['message' => 'Questionnaire not found.']);
        }
    }

    /**
     * AJAX Pay Invoice
     */
    public static function ajax_pay_invoice()
    {
        check_ajax_referer('dior_portal_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id)
            wp_send_json_error(['message' => 'Authentication required.']);

        $inv_id = sanitize_text_field($_POST['inv_id'] ?? '');
        $payments = Dior_Patient_Portal_Data::get_patient_payments($user_id);

        foreach ($payments as &$pay) {
            if ($pay['id'] === $inv_id) {
                $pay['status'] = 'Paid';
                $pay['status_class'] = 'status-paid';
                break;
            }
        }

        update_user_meta($user_id, 'dior_payments', $payments);
        wp_send_json_success(['message' => 'Payment processed successfully via Stripe! Receipt issued.']);
    }

    /**
     * AJAX Mark Single Notification Read
     */
    public static function ajax_mark_notification_read()
    {
        check_ajax_referer('dior_portal_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id)
            wp_send_json_error(['message' => 'Authentication required.']);

        $notif_id = sanitize_text_field($_POST['notif_id'] ?? '');
        $notifications = Dior_Patient_Portal_Data::get_patient_notifications($user_id);

        foreach ($notifications as &$n) {
            if ($n['id'] === $notif_id) {
                $n['is_read'] = true;
                break;
            }
        }

        update_user_meta($user_id, 'dior_notifications', $notifications);
        wp_send_json_success(['message' => 'Notification marked as read.']);
    }

    /**
     * AJAX Mark All Notifications Read
     */
    public static function ajax_mark_all_notifications_read()
    {
        check_ajax_referer('dior_portal_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id)
            wp_send_json_error(['message' => 'Authentication required.']);

        $notifications = Dior_Patient_Portal_Data::get_patient_notifications($user_id);
        foreach ($notifications as &$n) {
            $n['is_read'] = true;
        }

        update_user_meta($user_id, 'dior_notifications', $notifications);
        wp_send_json_success(['message' => 'All notifications marked as read.']);
    }

    /**
     * AJAX Update Pharmacy
     */
    public static function ajax_update_pharmacy()
    {
        check_ajax_referer('dior_portal_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (!$user_id)
            wp_send_json_error(['message' => 'Authentication required.']);

        $pharm_name = sanitize_text_field($_POST['pharmacy_name'] ?? '');
        $pharm_address = sanitize_text_field($_POST['pharmacy_address'] ?? '');
        $pharm_phone = sanitize_text_field($_POST['pharmacy_phone'] ?? '');

        update_user_meta($user_id, 'preferred_pharmacy_name', $pharm_name);
        update_user_meta($user_id, 'preferred_pharmacy_address', $pharm_address);
        update_user_meta($user_id, 'preferred_pharmacy_phone', $pharm_phone);

        wp_send_json_success(['message' => 'Preferred pharmacy updated successfully!']);
    }

    /**
     * HIPAAtizer Webhook — AJAX handler (wp-admin/admin-ajax.php)
     * Set this in HIPAAtizer: Action URL = /wp-admin/admin-ajax.php?action=dior_hipaa_webhook
     */
    public static function ajax_hipaa_webhook()
    {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        if (!$data) {
            $data = $_POST;
        }
        self::save_hipaa_intake($data);
        wp_send_json_success(['message' => 'Intake received.']);
    }

    /**
     * HIPAAtizer Webhook — REST API handler
     * Webhook URL: /wp-json/dior/v1/hipaa-webhook
     */
    public static function rest_hipaa_webhook(\WP_REST_Request $request)
    {
        $data = $request->get_json_params();
        if (empty($data)) {
            $data = $request->get_body_params();
        }
        self::save_hipaa_intake($data);
        return new \WP_REST_Response(['message' => 'Intake received.'], 200);
    }

    /**
     * Save HIPAAtizer intake data to user meta by email match or user_id
     */
    public static function save_hipaa_intake($data)
    {
        if (empty($data))
            return;

        // Try to find user by user_id first
        $user_id = 0;
        if (!empty($data['user_id'])) {
            $user_id = (int) $data['user_id'];
        } elseif (!empty($_POST['user_id'])) {
            $user_id = (int) $_POST['user_id'];
        } elseif (is_user_logged_in()) {
            $user_id = get_current_user_id();
        }

        // Try to find user by email from form data
        $email = '';
        $email_keys = ['email', 'Email', 'email_address', 'patient_email', 'submitter_email'];
        foreach ($email_keys as $k) {
            if (!empty($data[$k])) {
                $email = sanitize_email($data[$k]);
                break;
            }
        }

        if (!$user_id && $email) {
            $user = get_user_by('email', $email);
            if ($user)
                $user_id = $user->ID;
        }

        if ($user_id && empty($email)) {
            $u_obj = get_userdata($user_id);
            if ($u_obj)
                $email = $u_obj->user_email;
        }

        $first_name = sanitize_text_field($data['first_name'] ?? $data['First Name'] ?? $data['firstname'] ?? '');
        $last_name = sanitize_text_field($data['last_name'] ?? $data['Last Name'] ?? $data['lastname'] ?? '');
        if ($user_id && empty($first_name)) {
            $first_name = get_user_meta($user_id, 'first_name', true) ?: '';
            $last_name = get_user_meta($user_id, 'last_name', true) ?: '';
        }

        // Build clean intake record with all 39 fields
        $intake = [
            'submitted_at' => current_time('Y-m-d H:i:s'),

            // Step 1: Service Selection
            'service_condition' => sanitize_text_field($data['service_condition'] ?? $data['service'] ?? $data['Which service or condition do you need care for today'] ?? ''),

            // Step 2: Eligibility Checks
            'is_18_plus' => sanitize_text_field($data['is_18_plus'] ?? $data['Are you 18 years or older'] ?? ''),
            'is_pregnant' => sanitize_text_field($data['is_pregnant'] ?? $data['Are you currently pregnant'] ?? ''),

            // Step 3: Patient Information
            'first_name' => $first_name,
            'last_name' => $last_name,
            'dob' => sanitize_text_field($data['dob'] ?? $data['date_of_birth'] ?? $data['Date of Birth'] ?? ''),
            'gender' => sanitize_text_field($data['gender'] ?? $data['Gender'] ?? $data['biological_sex'] ?? $data['Biological Sex'] ?? $data['Sex'] ?? $data['sex'] ?? ''),
            'email' => $email,
            'phone' => sanitize_text_field($data['phone'] ?? $data['Phone'] ?? $data['phone_number'] ?? ''),
            'address' => sanitize_text_field($data['address'] ?? $data['Address'] ?? $data['street_address'] ?? $data['Street Address'] ?? ''),
            'city' => sanitize_text_field($data['city'] ?? $data['City'] ?? ''),
            'state' => sanitize_text_field($data['state'] ?? $data['State'] ?? $data['service_state'] ?? ''),
            'zip' => sanitize_text_field($data['zip'] ?? $data['Zip'] ?? $data['postal_code'] ?? $data['ZIP Code'] ?? ''),

            // Step 4: Symptoms Description
            'symptoms_description' => sanitize_textarea_field($data['symptoms_description'] ?? $data['Describe your symptoms'] ?? ''),
            'symptom_duration' => sanitize_text_field($data['symptom_duration'] ?? $data['How long have you had these symptoms'] ?? ''),
            'symptom_severity' => sanitize_text_field($data['symptom_severity'] ?? $data['How severe are your symptoms'] ?? ''),

            // Step 5: Conditional Questions - UTI
            'uti_burning_pain' => sanitize_text_field($data['uti_burning_pain'] ?? $data['Do you have burning or pain when urinating'] ?? ''),
            'uti_frequency' => sanitize_text_field($data['uti_frequency'] ?? $data['Do you need to urinate more frequently or urgently'] ?? ''),
            'uti_appearance' => sanitize_text_field($data['uti_appearance'] ?? $data['Is your urine cloudy, dark or foul smelling'] ?? ''),
            'uti_blood' => sanitize_text_field($data['uti_blood'] ?? $data['Have you seen blood in your urine'] ?? ''),
            'uti_previous' => sanitize_text_field($data['uti_previous'] ?? $data['Have you had a urinary tract infection before'] ?? ''),
            'uti_last_date' => sanitize_text_field($data['uti_last_date'] ?? $data['When was your last urinary tract infection'] ?? ''),

            // Step 5: Conditional Questions - Allergies
            'allergy_symptoms' => is_array($data['allergy_symptoms'] ?? $data['Which allergy symptoms do you have']) ?
                implode(', ', array_map('sanitize_text_field', (array) ($data['allergy_symptoms'] ?? $data['Which allergy symptoms do you have']))) :
                sanitize_text_field($data['allergy_symptoms'] ?? $data['Which allergy symptoms do you have'] ?? ''),
            'allergy_seasonal' => sanitize_text_field($data['allergy_seasonal'] ?? $data['Are your allergy symptoms seasonal or year round'] ?? ''),
            'allergy_triggers' => sanitize_text_field($data['allergy_triggers'] ?? $data['What triggers your allergy symptoms'] ?? ''),
            'allergy_medication_taken' => sanitize_text_field($data['allergy_medication_taken'] ?? $data['Have you taken any allergy medication for this'] ?? ''),
            'allergy_medication_name' => sanitize_text_field($data['allergy_medication_name'] ?? $data['Which allergy medication did you take'] ?? ''),

            // Step 6: Medical History
            'diagnosed_conditions' => is_array($data['diagnosed_conditions'] ?? $data['Have you been diagnosed with any of the following']) ?
                implode(', ', array_map('sanitize_text_field', (array) ($data['diagnosed_conditions'] ?? $data['Have you been diagnosed with any of the following']))) :
                sanitize_text_field($data['diagnosed_conditions'] ?? $data['Have you been diagnosed with any of the following'] ?? ''),
            'other_conditions' => sanitize_textarea_field($data['other_conditions'] ?? $data['Other medical conditions'] ?? ''),
            'taking_medications' => sanitize_text_field($data['taking_medications'] ?? $data['Are you currently taking any medications'] ?? ''),
            'medications_list' => sanitize_textarea_field($data['medications_list'] ?? $data['List your current medications and dosage'] ?? ''),
            'drug_allergies' => sanitize_text_field($data['drug_allergies'] ?? $data['Do you have any drug allergies'] ?? ''),
            'drug_allergies_list' => sanitize_textarea_field($data['drug_allergies_list'] ?? $data['List your drug allergies and the reaction'] ?? ''),

            // Step 7: Documents & Appointment
            'photo_id' => sanitize_text_field($data['photo_id'] ?? $data['Photo identification'] ?? ''),
            'insurance_card' => sanitize_text_field($data['insurance_card'] ?? $data['Insurance card'] ?? ''),
            'affected_area_photo' => sanitize_text_field($data['affected_area_photo'] ?? $data['Photo of affected area'] ?? ''),
            'lab_results' => sanitize_text_field($data['lab_results'] ?? $data['Lab or test results'] ?? ''),
            'appointment_type' => sanitize_text_field($data['appointment_type'] ?? $data['Which type of appointment do you prefer'] ?? ''),
            'preferred_date' => sanitize_text_field($data['preferred_date'] ?? $data['Preferred Date'] ?? ''),
            'preferred_time' => sanitize_text_field($data['preferred_time'] ?? $data['Preferred Time'] ?? ''),

            // Step 8: Consent & Signature
            'telemedicine_consent' => sanitize_text_field($data['telemedicine_consent'] ?? $data['I consent to receive care through telemedicine'] ?? ''),
            'legal_acknowledgement' => sanitize_text_field($data['legal_acknowledgement'] ?? $data['I acknowledge and confirm the above'] ?? ''),
            'full_legal_name' => sanitize_text_field($data['full_legal_name'] ?? $data['Full Legal Name'] ?? ''),
            'signature' => sanitize_text_field($data['signature'] ?? $data['Signature'] ?? ''),
            'signature_date' => sanitize_text_field($data['signature_date'] ?? $data['Date'] ?? ''),

            // Legacy field names for compatibility
            'symptoms' => sanitize_textarea_field($data['symptoms_description'] ?? $data['symptoms'] ?? $data['Symptoms'] ?? $data['chief_complaint'] ?? $data['condition'] ?? ''),
            'allergies' => sanitize_text_field($data['allergy_symptoms'] ?? $data['allergies'] ?? $data['Allergies'] ?? ''),
            'medications' => sanitize_text_field($data['medications_list'] ?? $data['medications'] ?? $data['current_medications'] ?? $data['Medications'] ?? ''),
            'medical_history' => sanitize_textarea_field($data['other_conditions'] ?? $data['medical_history'] ?? $data['Medical History'] ?? ''),

            'raw_data' => $data, // keep full payload
        ];

        if ($user_id) {
            // Save to matched user
            update_user_meta($user_id, 'dior_hipaa_intake', $intake);
            update_user_meta($user_id, 'dior_hipaa_intake_submitted', '1');

            // Update user profile fields from HIPAAtizer data
            if (!empty($first_name)) {
                update_user_meta($user_id, 'first_name', $first_name);
            }
            if (!empty($last_name)) {
                update_user_meta($user_id, 'last_name', $last_name);
            }
            if (!empty($intake['phone'])) {
                update_user_meta($user_id, 'phone', $intake['phone']);
            }
            if (!empty($intake['gender'])) {
                update_user_meta($user_id, 'gender', $intake['gender']);
            }
            if (!empty($intake['dob'])) {
                update_user_meta($user_id, 'dob', $intake['dob']);
            }
            if (!empty($intake['address'])) {
                update_user_meta($user_id, 'street_address', $intake['address']);
            }
            if (!empty($intake['city'])) {
                update_user_meta($user_id, 'city', $intake['city']);
            }
            if (!empty($intake['state'])) {
                update_user_meta($user_id, 'state', $intake['state']);
            }
            if (!empty($intake['zip'])) {
                update_user_meta($user_id, 'zip', $intake['zip']);
            }
            if (!empty($intake['address']) || !empty($intake['city']) || !empty($intake['state'])) {
                $full_address = trim(($intake['address'] ?? '') . ' ' . ($intake['city'] ?? '') . ', ' . ($intake['state'] ?? '') . ' ' . ($intake['zip'] ?? ''));
                update_user_meta($user_id, 'address', $full_address);
            }

            // Create initial appointment from HIPAAtizer intake
            $appointments = get_user_meta($user_id, 'dior_appointments', true);
            if (!is_array($appointments)) {
                $appointments = [];
            }

            // Check if HIPAAtizer appointment already exists
            $has_hipaa_appt = false;
            foreach ($appointments as $appt) {
                if (isset($appt['from_hipaa']) && $appt['from_hipaa'] === true) {
                    $has_hipaa_appt = true;
                    break;
                }
            }

            // Only create appointment if no HIPAAtizer appointment exists
            if (!$has_hipaa_appt) {
                $new_appt = [
                    'id' => 'APT-HIPAA-' . time(),
                    'date' => current_time('Y-m-d'),
                    'time' => 'Pending',
                    'condition' => $intake['symptoms'] ?: 'Medical Consultation',
                    'provider' => 'Available Provider',
                    'provider_spec' => 'Board Certified Physician',
                    'type' => 'Video Visit (HD)',
                    'status' => 'Scheduled',
                    'join_url' => '',
                    'payment_status' => 'Pending',
                    'notes' => 'Appointment created from HIPAAtizer intake form.',
                    'can_join' => false,
                    'from_hipaa' => true
                ];
                $appointments[] = $new_appt;
                update_user_meta($user_id, 'dior_appointments', $appointments);
            }

            // Add a notification for Patient
            $notifications = get_user_meta($user_id, 'dior_notifications', true);
            if (!is_array($notifications))
                $notifications = [];
            array_unshift($notifications, [
                'id' => 'NOTIF-HIPAA-' . time(),
                'type' => 'intake',
                'icon' => 'fa-file-shield',
                'title' => 'Medical Intake Form Submitted',
                'message' => 'Your HIPAA medical intake form has been received and shared with your physician.',
                'time' => 'Just now',
                'timestamp' => time(),
                'created_at' => current_time('mysql'),
                'is_read' => false,
                'action_url' => '#tab=questionnaire',
            ]);
            update_user_meta($user_id, 'dior_notifications', $notifications);

            // Add notification to Doctors / Admin
            $patient_name = trim($first_name . ' ' . $last_name);
            if (empty($patient_name)) {
                $u_info = get_userdata($user_id);
                $patient_name = $u_info ? $u_info->display_name : 'Patient #' . $user_id;
            }
            $doctors = get_users(['role__in' => ['doctor', 'administrator']]);
            foreach ($doctors as $doc) {
                $doc_notifs = get_user_meta($doc->ID, 'dior_doctor_notifications', true);
                if (!is_array($doc_notifs))
                    $doc_notifs = [];
                array_unshift($doc_notifs, [
                    'id' => 'DN-INTAKE-' . time() . '-' . rand(10, 99),
                    'type' => 'intake',
                    'icon' => 'fa-file-shield',
                    'title' => 'New Medical Intake: ' . $patient_name,
                    'message' => $patient_name . ' submitted their HIPAA medical intake questionnaire.',
                    'time' => 'Just now',
                    'timestamp' => time(),
                    'created_at' => current_time('mysql'),
                    'is_read' => false,
                    'action_url' => '#tab=doc-intake',
                ]);
                update_user_meta($doc->ID, 'dior_doctor_notifications', $doc_notifs);
            }
        } elseif ($email) {
            // Store by email as key for later matching (when user logs in)
            $pending_key = 'dior_hipaa_pending_' . md5($email);
            update_option($pending_key, $intake, false);
        }
    }
}

/**
 * Helper to match a DocBooker doctor post / name to a WordPress doctor user ID
 */
function dior_find_doctor_user_id($docbooker_doctor_id = 0, $doctor_name = '')
{
    if ($docbooker_doctor_id) {
        $linked_uid = get_post_meta($docbooker_doctor_id, '_doctor_user_id', true);
        if ($linked_uid && get_userdata($linked_uid)) {
            return (int) $linked_uid;
        }
        $post = get_post($docbooker_doctor_id);
        if ($post && $post->post_author > 0) {
            $author = get_userdata($post->post_author);
            if ($author && (in_array('doctor', $author->roles) || in_array('administrator', $author->roles))) {
                return (int) $post->post_author;
            }
        }
    }

    // Search doctor users by name or linked meta
    $doc_users = get_users(['role__in' => ['doctor', 'administrator']]);
    if ($docbooker_doctor_id) {
        foreach ($doc_users as $u) {
            $u_linked = get_user_meta($u->ID, '_docbooker_doctor_id', true);
            if ($u_linked && (int) $u_linked === (int) $docbooker_doctor_id) {
                return $u->ID;
            }
        }
    }

    // Name matching
    if (!empty($doctor_name)) {
        $clean_doc_name = strtolower(trim(preg_replace('/^(dr\.?|doctor)\s+/i', '', $doctor_name)));
        $clean_doc_name = preg_replace('/,\s*(md|do|mbbs|np|pa|phd).*$/i', '', $clean_doc_name);
        $clean_doc_name = trim($clean_doc_name);

        foreach ($doc_users as $u) {
            $u_first = strtolower(get_user_meta($u->ID, 'first_name', true) ?: $u->first_name);
            $u_last = strtolower(get_user_meta($u->ID, 'last_name', true) ?: $u->last_name);
            $u_disp = strtolower($u->display_name);
            $u_full = trim($u_first . ' ' . $u_last);

            if ($clean_doc_name && ($clean_doc_name === $u_full || $clean_doc_name === $u_disp || strpos($doctor_name, $u->display_name) !== false)) {
                return $u->ID;
            }
            if ($u_last && strlen($u_last) >= 3 && stripos($doctor_name, $u_last) !== false) {
                return $u->ID;
            }
        }
    }

    // If there is only one doctor role user on site, route to that doctor
    $only_doctors = get_users(['role' => 'doctor']);
    if (count($only_doctors) === 1) {
        return $only_doctors[0]->ID;
    }

    return 0;
}

/**
 * Synchronize DocBooker bookings to Dior Medical Dashboard
 */
add_action('wpddb_booking_created', 'dior_sync_docbooker_appointment', 10, 1);
function dior_sync_docbooker_appointment($booking_data)
{
    if (empty($booking_data['patient_email']))
        return;

    $user = get_user_by('email', $booking_data['patient_email']);
    if (!$user)
        return; // if user not found, we can't sync it to patient dashboard

    $user_id = $user->ID;

    // Get existing appointments
    $appointments = get_user_meta($user_id, 'dior_appointments', true);
    if (!is_array($appointments)) {
        $appointments = [];
    }

    // Create new appointment record
    $doctor = get_post($booking_data['doctor_id']);
    $doctor_name = $doctor ? $doctor->post_title : 'Doctor';
    $spec = get_post_meta($booking_data['doctor_id'], 'wpddb_doctor_speciality', true);
    $matched_doc_uid = dior_find_doctor_user_id($booking_data['doctor_id'], $doctor_name);

    $new_appointment = [
        'id' => $booking_data['booking_id'],
        'date' => !empty($booking_data['booking_date']) ? date('M d, Y', strtotime($booking_data['booking_date'])) : $booking_data['day'],
        'time' => $booking_data['time'],
        'condition' => 'Telehealth Consultation',
        'type' => 'Telehealth Video Visit',
        'provider' => $doctor_name,
        'provider_spec' => $spec ?: 'General Practice & Telehealth',
        'provider_title' => $spec ?: 'General Practice & Telehealth',
        'status' => 'Confirmed',
        'join_url' => (!empty($matched_doc_uid) && ($doc_zoom = get_user_meta($matched_doc_uid, 'doctor_zoom_link', true))) ? $doc_zoom : 'https://zoom.us/join',
        'raw_date' => !empty($booking_data['booking_date']) ? $booking_data['booking_date'] : '',
        'doctor_id' => $booking_data['doctor_id'] ?? 0,
        'doctor_name' => $doctor_name,
        'doctor_user_id' => $matched_doc_uid,
        'patient_name' => !empty($booking_data['patient_name']) ? $booking_data['patient_name'] : $user->display_name,
        'patient_email' => $booking_data['patient_email'],
        'patient_phone' => $booking_data['patient_phone'] ?? '',
        'patient_user_id' => $user_id,
    ];

    // add to beginning of array
    array_unshift($appointments, $new_appointment);

    update_user_meta($user_id, 'dior_appointments', $appointments);

    // 1. Add notification for Patient
    $pnotifs = Dior_Patient_Portal_Data::get_patient_notifications($user_id);
    array_unshift($pnotifs, [
        'id' => 'NOTIF-APT-' . time() . '-' . rand(10, 99),
        'type' => 'appointment',
        'icon' => 'fa-calendar-check',
        'title' => 'Appointment Confirmed: ' . $doctor_name,
        'message' => 'Your consultation with ' . $doctor_name . ' has been booked for ' . $new_appointment['date'] . ' at ' . $new_appointment['time'] . '.',
        'time' => 'Just now',
        'timestamp' => time(),
        'created_at' => current_time('mysql'),
        'is_read' => false,
        'action_url' => '#tab=appointments'
    ]);
    update_user_meta($user_id, 'dior_notifications', $pnotifs);

    // 2. Add notification ONLY for the specific Doctor (and Admins)
    $target_doc_ids = [];
    if ($matched_doc_uid) {
        $target_doc_ids[] = $matched_doc_uid;
    } else {
        $only_docs = get_users(['role' => 'doctor']);
        foreach ($only_docs as $od) {
            $target_doc_ids[] = $od->ID;
        }
    }

    // Also include administrators so admin can supervise
    $admins = get_users(['role' => 'administrator']);
    foreach ($admins as $ad) {
        if (!in_array($ad->ID, $target_doc_ids)) {
            $target_doc_ids[] = $ad->ID;
        }
    }

    $pname = !empty($booking_data['patient_name']) ? $booking_data['patient_name'] : ($user ? $user->display_name : 'A patient');
    foreach ($target_doc_ids as $doc_uid) {
        $dnotifs = get_user_meta($doc_uid, 'dior_doctor_notifications', true);
        if (!is_array($dnotifs))
            $dnotifs = [];
        array_unshift($dnotifs, [
            'id' => 'DN-APT-' . time() . '-' . rand(10, 99),
            'type' => 'appointment',
            'icon' => 'fa-calendar-check',
            'title' => 'New Appointment Booked',
            'message' => $pname . ' booked a visit with ' . $doctor_name . ' for ' . $new_appointment['date'] . ' at ' . $new_appointment['time'] . '.',
            'time' => 'Just now',
            'timestamp' => time(),
            'created_at' => current_time('mysql'),
            'is_read' => false,
            'action_url' => '#tab=doc-appointments'
        ]);
        update_user_meta($doc_uid, 'dior_doctor_notifications', $dnotifs);
    }
}

require_once DIOR_PORTAL_PATH . 'dior-doctor-dashboard.php';

Dior_Medical_Auth::init();
