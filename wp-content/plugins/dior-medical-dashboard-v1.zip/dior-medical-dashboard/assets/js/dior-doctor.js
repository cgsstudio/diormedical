/**
 * Dior Medical - Doctor Dashboard Scripts
 */

function getDiorDocAjax() {
    return window.diorDocAjax || (typeof diorDocAjax !== 'undefined' ? diorDocAjax : '') || (window.dior_doctor_vars ? window.dior_doctor_vars.ajax_url : '') || (window.dior_vars ? window.dior_vars.ajax_url : '/wp-admin/admin-ajax.php');
}

function getDiorDocNonce() {
    return window.diorDocNonce || (typeof diorDocNonce !== 'undefined' ? diorDocNonce : '') || (window.dior_doctor_vars ? window.dior_doctor_vars.nonce : '') || (window.dior_vars ? window.dior_vars.nonce : '');
}

document.addEventListener('DOMContentLoaded', function () {
    // Initialize first tab
    const firstTabBtn = document.querySelector('#dior-doc-sidebar .dior-nav-btn.active');
    if (firstTabBtn) {
        diorDocSwitchTab(firstTabBtn.getAttribute('data-tab'));
    }

    // Add click listeners to ALL nav buttons (must be inside DOMContentLoaded)
    document.querySelectorAll('#dior-doc-sidebar .dior-nav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            diorDocSwitchTab(this.getAttribute('data-tab'));
        });
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', function (e) {
        const notifWrap = document.querySelector('.dior-notif-wrap');
        const notifDropdown = document.getElementById('dior-doc-notif-dd');
        if (notifWrap && notifDropdown && !notifWrap.contains(e.target)) {
            notifDropdown.classList.remove('open');
            notifDropdown.classList.remove('active');
        }
    });

    // Handle AJAX profile form
    const profileForm = document.getElementById('dior-doc-profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', diorDocSaveProfile);
    }

    // Initialize Pagination for all Doctor Dashboard Tables (5 rows max per page)
    document.querySelectorAll('.dior-doc-table, .dior-table, .dior-clean-table').forEach(table => {
        diorInitTablePagination(table, 5);
    });
});

// Universal Table Pagination (5 entries per page)
window.diorInitTablePagination = function(tableEl, pageSize) {
    if (!tableEl) return;
    pageSize = pageSize || 5;
    const tbody = tableEl.querySelector('tbody');
    if (!tbody) return;

    // Remove existing pagination wrapper if any
    let parent = tableEl.parentElement;
    let paginationWrap = parent.querySelector('.dior-table-pagination');
    if (!paginationWrap) {
        paginationWrap = document.createElement('div');
        paginationWrap.className = 'dior-table-pagination';
        // Insert after table or table overflow wrapper
        if (parent.classList.contains('dior-card-body') || parent.style.overflowX === 'auto' || parent.style.overflow === 'auto') {
            parent.after(paginationWrap);
        } else {
            parent.appendChild(paginationWrap);
        }
    }

    let currentPage = 1;

    function renderPage(page) {
        currentPage = page || 1;
        const allRows = Array.from(tbody.querySelectorAll('tr')).filter(tr => !tr.classList.contains('dior-no-data-row') && tr.querySelectorAll('td').length > 1);
        
        if (allRows.length === 0) {
            paginationWrap.style.display = 'none';
            return;
        }

        const activeRows = allRows.filter(tr => tr.getAttribute('data-filter-hidden') !== 'true');
        const total = activeRows.length;
        const totalPages = Math.max(1, Math.ceil(total / pageSize));

        if (currentPage > totalPages) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;

        const startIndex = (currentPage - 1) * pageSize;
        const endIndex = startIndex + pageSize;

        // Apply visibility
        allRows.forEach(tr => {
            if (tr.getAttribute('data-filter-hidden') === 'true') {
                tr.style.display = 'none';
            }
        });

        activeRows.forEach((tr, index) => {
            if (index >= startIndex && index < endIndex) {
                tr.style.display = '';
            } else {
                tr.style.display = 'none';
            }
        });

        // Hide pagination controls if 5 or fewer entries
        if (totalPages <= 1) {
            paginationWrap.style.display = 'none';
            return;
        }

        const fromItem = total === 0 ? 0 : startIndex + 1;
        const toItem = Math.min(endIndex, total);

        let navHtml = '';
        if (totalPages > 1) {
            navHtml += `<button type="button" class="dior-page-btn" ${currentPage === 1 ? 'disabled' : ''} data-page="${currentPage - 1}" title="Previous Page"><i class="fa-solid fa-chevron-left" style="font-size:11px;"></i></button>`;

            for (let i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
                    navHtml += `<button type="button" class="dior-page-btn ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
                } else if (i === currentPage - 2 || i === currentPage + 2) {
                    navHtml += `<span style="padding: 0 4px; color: #94A3B8; font-size:12px;">...</span>`;
                }
            }

            navHtml += `<button type="button" class="dior-page-btn" ${currentPage === totalPages ? 'disabled' : ''} data-page="${currentPage + 1}" title="Next Page"><i class="fa-solid fa-chevron-right" style="font-size:11px;"></i></button>`;
        }

        paginationWrap.style.display = 'flex';
        paginationWrap.innerHTML = `
            <div class="dior-pagination-info">
                Showing <strong>${fromItem}</strong> to <strong>${toItem}</strong> of <strong>${total}</strong> entries
            </div>
            <div class="dior-pagination-nav">
                ${navHtml}
            </div>
        `;

        // Click listeners
        paginationWrap.querySelectorAll('.dior-page-btn[data-page]').forEach(btn => {
            btn.onclick = function(e) {
                e.preventDefault();
                const p = parseInt(this.getAttribute('data-page'), 10);
                if (!isNaN(p)) renderPage(p);
            };
        });
    }

    tableEl._diorRenderPage = renderPage;
    renderPage(1);
};

// Tab Switching logic
window.diorDocSwitchTab = function(tabId) {
    if (!tabId) return;

    const notifDropdown = document.getElementById('dior-doc-notif-dd');
    if (notifDropdown) {
        notifDropdown.classList.remove('open');
        notifDropdown.classList.remove('active');
    }

    // Update buttons
    const btns = document.querySelectorAll('#dior-doc-sidebar .dior-nav-btn');
    btns.forEach(b => b.classList.remove('active'));
    
    const activeBtn = document.querySelector(`#dior-doc-sidebar .dior-nav-btn[data-tab="${tabId}"]`);
    if (activeBtn) {
        activeBtn.classList.add('active');

        // Dynamic Badge Dismissal: Hide notification/count badge once opened
        const badge = activeBtn.querySelector('.nav-count-badge');
        if (badge) {
            badge.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
            badge.style.opacity = '0';
            badge.style.transform = 'scale(0.5)';
            setTimeout(() => {
                badge.style.display = 'none';
            }, 250);
        }
    }

    // Update panels
    const panels = document.querySelectorAll('#dior-doc-content .dior-tab-panel');
    panels.forEach(p => p.classList.remove('active'));
    
    const activePanel = document.getElementById(`tab-${tabId}`);
    if (activePanel) {
        activePanel.classList.add('active');
        // Refresh table pagination inside activated tab
        activePanel.querySelectorAll('.dior-doc-table').forEach(table => {
            if (table._diorRenderPage) {
                table._diorRenderPage(1);
            } else {
                diorInitTablePagination(table, 5);
            }
        });
    }

    // If notifications tab opened, clear topbar bell badge and mark read in database
    if (tabId === 'doc-notifications') {
        document.querySelectorAll('.doc-unread-badge, .dior-notif-indicator').forEach(b => {
            b.style.display = 'none';
        });
        if (window.diorDocAjax && window.diorDocNonce) {
            const fd = new FormData();
            fd.append('action', 'dior_doctor_mark_all_notif_read');
            fd.append('nonce', window.diorDocNonce);
            fetch(window.diorDocAjax, { method: 'POST', body: fd }).catch(() => {});
        }
    }

    diorDocCloseMobile();
};

// Mobile menu toggle
window.diorDocOpenMobile = function() {
    document.getElementById('dior-doc-sidebar').classList.add('open');
    document.getElementById('dior-doc-backdrop').classList.add('active');
};

window.diorDocCloseMobile = function() {
    const sidebar = document.getElementById('dior-doc-sidebar');
    const backdrop = document.getElementById('dior-doc-backdrop');
    if (sidebar) sidebar.classList.remove('open');
    if (backdrop) backdrop.classList.remove('active');
};

// Search patients with pagination reset
window.diorDocFilterPatients = function(val) {
    val = val.toLowerCase().trim();
    const table = document.getElementById('dior-patients-table');
    if (!table) return;
    const rows = table.querySelectorAll('tbody tr.patient-row');
    rows.forEach(row => {
        const text = row.getAttribute('data-search') || '';
        if (val === '' || text.includes(val)) {
            row.removeAttribute('data-filter-hidden');
        } else {
            row.setAttribute('data-filter-hidden', 'true');
        }
    });
    if (table._diorRenderPage) {
        table._diorRenderPage(1);
    }
};

window.diorDocSearch = function(val) {
    // If we're not on the patients tab, switch to it and search
    diorDocSwitchTab('doc-patients');
    
    // Update the actual patient search input
    const patientSearch = document.querySelector('#tab-doc-patients .dior-search-input');
    if (patientSearch) {
        patientSearch.value = val;
        diorDocFilterPatients(val);
    }
};

// Appts filter with pagination reset
window.diorDocFilterAppts = function(val) {
    val = val.toLowerCase().trim();
    const table = document.getElementById('dior-appts-table');
    if (!table) return;
    const rows = table.querySelectorAll('tbody tr.appt-row');
    rows.forEach(row => {
        const status = (row.getAttribute('data-status') || '').toLowerCase();
        if (val === '' || status === val) {
            row.removeAttribute('data-filter-hidden');
        } else {
            row.setAttribute('data-filter-hidden', 'true');
        }
    });
    if (table._diorRenderPage) {
        table._diorRenderPage(1);
    }
};

// Update Appointment Status
window.diorDocUpdateApptStatus = function(selectEl, patientId, apptId) {
    const status = selectEl.value;
    
    selectEl.disabled = true;

    const data = new FormData();
    data.append('action', 'dior_doctor_update_appt_status');
    data.append('nonce', window.diorDocNonce);
    data.append('patient_user_id', patientId);
    data.append('appt_id', apptId);
    data.append('status', status);

    fetch(window.diorDocAjax, {
        method: 'POST',
        body: data
    })
    .then(r => r.json())
    .then(res => {
        selectEl.disabled = false;
        if (res.success) {
            const tr = selectEl.closest('tr');
            if (tr) {
                const stLower = (status || '').toLowerCase().trim();
                const badge = tr.querySelector('.dior-st');
                if (badge) {
                    badge.className = 'dior-st ' + (stLower === 'completed' ? 'ok' : (stLower === 'cancelled' || stLower === 'cancel' ? 'error' : 'pending'));
                    badge.textContent = status;
                }
                tr.setAttribute('data-status', status);

                // Dynamically hide call button if cancelled / completed / no-show
                const callBtn = tr.querySelector('.dior-call-btn');
                if (callBtn) {
                    const isClosed = ['completed', 'cancelled', 'cancel', 'no-show', 'done'].includes(stLower);
                    callBtn.style.display = isClosed ? 'none' : 'inline-flex';
                }
            }
        } else {
            alert(res.data.message || 'Error updating status');
        }
    })
    .catch(() => {
        selectEl.disabled = false;
        alert('Network error');
    });
};

// Smart Video Call Handler with Date Check & Alert
window.diorDocStartCall = function(event, url, dateStr, timeStr, status) {
    if (event) event.preventDefault();

    const st = (status || '').toLowerCase().trim();
    if (['completed', 'cancelled', 'cancel', 'no-show', 'done'].includes(st)) {
        diorDocShowCallAlert({
            type: 'cancelled',
            title: 'Appointment ' + (status || 'Cancelled'),
            message: `This appointment has been marked as <strong>${status}</strong>. The video consultation call is no longer active.`,
            allowOverride: false
        });
        return false;
    }

    if (!dateStr || dateStr === '—') {
        window.open(url, '_blank', 'noopener,noreferrer');
        return true;
    }

    const today = new Date();
    const todayYMD = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');

    let targetYMD = '';
    const parsedDate = new Date(dateStr);
    
    if (!isNaN(parsedDate.getTime())) {
        targetYMD = parsedDate.getFullYear() + '-' + String(parsedDate.getMonth() + 1).padStart(2, '0') + '-' + String(parsedDate.getDate()).padStart(2, '0');
    }

    if (targetYMD === todayYMD) {
        // Today is the scheduled consultation day! Launch call directly in new tab
        window.open(url, '_blank', 'noopener,noreferrer');
        return true;
    } else if (targetYMD > todayYMD) {
        // Future Appointment
        const timePart = timeStr && timeStr !== '—' ? ` at <strong>${timeStr}</strong>` : '';
        diorDocShowCallAlert({
            type: 'future',
            title: 'Upcoming Appointment',
            message: `This consultation is scheduled for <strong>${dateStr}</strong>${timePart}.<br><br>The live video call room will be active on the scheduled appointment date.`,
            allowOverride: true,
            url: url
        });
        return false;
    } else if (targetYMD < todayYMD && targetYMD !== '') {
        // Past Appointment
        const timePart = timeStr && timeStr !== '—' ? ` at <strong>${timeStr}</strong>` : '';
        diorDocShowCallAlert({
            type: 'past',
            title: 'Appointment Date Passed',
            message: `This consultation was scheduled for <strong>${dateStr}</strong>${timePart} (Past Date).<br><br>Please update the appointment status to <strong>Completed</strong> or reschedule with the patient.`,
            allowOverride: true,
            url: url
        });
        return false;
    } else {
        window.open(url, '_blank', 'noopener,noreferrer');
        return true;
    }
};

window.diorDocShowCallAlert = function(opts) {
    let modal = document.getElementById('dior-call-alert-modal');
    if (!modal) return;

    const titleEl = document.getElementById('dior-call-alert-title');
    const msgEl = document.getElementById('dior-call-alert-msg');
    const iconWrap = document.getElementById('dior-call-alert-icon-wrap');
    const overrideBtn = document.getElementById('dior-call-alert-override');

    if (titleEl) titleEl.textContent = opts.title || 'Notice';
    if (msgEl) msgEl.innerHTML = opts.message || '';

    if (iconWrap) {
        if (opts.type === 'cancelled') {
            iconWrap.innerHTML = '<i class="fa-solid fa-ban" style="font-size:32px;color:#EF4444;"></i>';
        } else if (opts.type === 'future') {
            iconWrap.innerHTML = '<i class="fa-solid fa-calendar-check" style="font-size:32px;color:#0284C7;"></i>';
        } else {
            iconWrap.innerHTML = '<i class="fa-solid fa-triangle-exclamation" style="font-size:32px;color:#F59E0B;"></i>';
        }
    }

    if (overrideBtn) {
        if (opts.allowOverride && opts.url) {
            overrideBtn.style.display = 'inline-flex';
            overrideBtn.onclick = function() {
                diorDocCloseCallAlert();
                window.open(opts.url, '_blank', 'noopener,noreferrer');
            };
        } else {
            overrideBtn.style.display = 'none';
        }
    }

    modal.classList.add('open');
};

window.diorDocCloseCallAlert = function() {
    const modal = document.getElementById('dior-call-alert-modal');
    if (modal) modal.classList.remove('open');
};

window.diorRxMedicationsList = [];

window.diorDocSearchMedication = function(query) {
    const autocomplete = document.getElementById('rx-med-autocomplete');
    if (query.length < 3) {
        autocomplete.style.display = 'none';
        return;
    }
    
    const url = `https://rxnav.nlm.nih.gov/REST/drugs.json?name=${encodeURIComponent(query)}`;
    
    fetch(url)
    .then(r => r.json())
    .then(data => {
        autocomplete.innerHTML = '';
        if (data.drugGroup && data.drugGroup.conceptGroup) {
            let found = false;
            data.drugGroup.conceptGroup.forEach(group => {
                if (group.conceptProperties) {
                    group.conceptProperties.slice(0, 5).forEach(prop => {
                        found = true;
                        const div = document.createElement('div');
                        div.style.padding = '8px 12px';
                        div.style.cursor = 'pointer';
                        div.style.borderBottom = '1px solid #F1F5F9';
                        div.innerHTML = `<strong>${prop.name}</strong> <small style="color:#64748B;">(RxCUI: ${prop.rxcui})</small>`;
                        div.onclick = function() { diorDocSelectMed(prop.name); };
                        autocomplete.appendChild(div);
                    });
                }
            });
            if (found) {
                autocomplete.style.display = 'block';
            } else {
                autocomplete.style.display = 'none';
            }
        } else {
            autocomplete.style.display = 'none';
        }
    })
    .catch(() => autocomplete.style.display = 'none');
};

window.diorDocSelectMed = function(name) {
    document.getElementById('rx-med-search').value = name;
    document.getElementById('rx-med-autocomplete').style.display = 'none';
};

window.diorDocAddMedToList = function() {
    const name = document.getElementById('rx-med-search').value.trim();
    const dose = document.getElementById('rx-dosage').value.trim();
    const ref = document.getElementById('rx-refills').value.trim();
    const notes = document.getElementById('rx-notes').value.trim();
    
    if (!name || !dose) {
        alert("Please enter Medication Name and Dosage.");
        return;
    }
    
    window.diorRxMedicationsList.push({
        medication: name,
        dosage: dose,
        refills: ref || '0 refills',
        notes: notes
    });
    
    document.getElementById('rx-med-search').value = '';
    document.getElementById('rx-dosage').value = '';
    document.getElementById('rx-refills').value = '';
    document.getElementById('rx-notes').value = '';
    
    diorDocRenderMedList();
};

window.diorDocRenderMedList = function() {
    const list = document.getElementById('rx-med-list');
    list.innerHTML = '';
    window.diorRxMedicationsList.forEach((med, index) => {
        list.innerHTML += `
            <div style="display:flex;justify-content:space-between;background:#fff;border:1px solid #E2E8F0;border-radius:8px;padding:12px;margin-bottom:8px;">
                <div>
                    <strong style="color:#2C6CB1;">${med.medication}</strong><br>
                    <span style="font-size:13px;color:#475569;">${med.dosage} | Refills: ${med.refills}</span>
                    ${med.notes ? `<div style="font-size:12px;color:#64748B;margin-top:4px;">Notes: ${med.notes}</div>` : ''}
                </div>
                <button type="button" style="background:none;border:none;color:#EF4444;cursor:pointer;" onclick="diorDocRemoveMed(${index})">
                    <i class="fa-solid fa-trash"></i>
                </button>
            </div>
        `;
    });
};

window.diorDocRemoveMed = function(index) {
    window.diorRxMedicationsList.splice(index, 1);
    diorDocRenderMedList();
};

window.diorDocSendPrescription = function() {
    const patientId = document.getElementById('rx-patient-select').value;
    const msg = document.getElementById('dior-rx-msg');
    const btn = document.getElementById('btn-send-rx');
    
    if (!patientId) {
        alert("Please select a patient.");
        return;
    }
    if (window.diorRxMedicationsList.length === 0) {
        alert("Please add at least one medication to the prescription.");
        return;
    }
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Sending...';
    
    const data = new FormData();
    data.append('action', 'dior_doctor_send_multi_prescription');
    data.append('nonce', window.diorDocNonce);
    data.append('patient_id', patientId);
    data.append('medications', JSON.stringify(window.diorRxMedicationsList));
    
    fetch(window.diorDocAjax, {
        method: 'POST',
        body: data
    })
    .then(r => r.json())
    .then(res => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Send Prescription';
        msg.style.display = 'block';
        if (res.success) {
            msg.className = 'dior-st ok';
            msg.innerHTML = '<i class="fa-solid fa-check"></i> ' + res.data.message;
            
            window.diorRxMedicationsList = [];
            diorDocRenderMedList();
            document.getElementById('rx-patient-select').value = '';
            
            const tbody = document.getElementById('dior-all-rx-tbody');
            if (tbody && res.data.rxs) {
                const emptyRow = tbody.querySelector('td[colspan="5"]');
                if (emptyRow) emptyRow.parentElement.remove();
                
                const pName = document.querySelector('#rx-patient-select option[value="'+patientId+'"]').text;
                res.data.rxs.forEach(rx => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td><strong>${pName}</strong></td>
                        <td>${rx.medication}</td>
                        <td>${rx.dosage}</td>
                        <td>${rx.date}</td>
                        <td><span class="dior-st ok">Active</span></td>
                    `;
                    tbody.prepend(tr);
                });
            }
            setTimeout(() => { msg.style.display = 'none'; }, 5000);
        } else {
            msg.className = 'dior-st error';
            msg.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> ' + (res.data.message || 'Error');
        }
    })
    .catch(() => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Send Prescription';
        msg.style.display = 'block';
        msg.className = 'dior-st error';
        msg.textContent = 'Network error';
    });
};

// Profile Save
window.diorDocSaveProfile = function(e) {
    e.preventDefault();
    const form = e.target;
    const btn = form.querySelector('button[type="submit"]');
    const msg = document.getElementById('dior-doc-profile-msg');
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';
    
    const data = new FormData(form);
    data.append('action', 'dior_doctor_save_profile');
    
    fetch(window.diorDocAjax, {
        method: 'POST',
        body: data
    })
    .then(r => r.json())
    .then(res => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Save Profile';
        msg.style.display = 'block';
        if (res.success) {
            msg.style.background = '#ECFDF5';
            msg.style.color = '#059669';
            msg.style.border = '1px solid #A7F3D0';
            msg.innerHTML = '<i class="fa-solid fa-check"></i> ' + res.data.message;
            setTimeout(() => { msg.style.display = 'none'; }, 4000);
        } else {
            msg.style.background = '#FEF2F2';
            msg.style.color = '#DC2626';
            msg.style.border = '1px solid #FECACA';
            msg.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> ' + (res.data.message || 'Error');
        }
    })
    .catch(() => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Save Profile';
        msg.style.display = 'block';
        msg.style.background = '#FEF2F2';
        msg.style.color = '#DC2626';
        msg.style.border = '1px solid #FECACA';
        msg.textContent = 'Network error';
    });
};

// Notifications
window.diorDocToggleNotif = function(e) {
    if (e) {
        if (typeof e.preventDefault === 'function') e.preventDefault();
        if (typeof e.stopPropagation === 'function') e.stopPropagation();
    }
    const dd = document.getElementById('dior-doc-notif-dd');
    if (dd) {
        dd.classList.toggle('open');
    }
};

window.diorDocMarkSingleRead = function(notifId, btn) {
    const item = btn ? btn.closest('.dior-full-notif-item, .dior-notif-item, .dior-notif-item-full') : null;
    if (item) {
        item.classList.remove('unread');
    }
    if (btn) {
        btn.remove();
    }
    const ajaxUrl = getDiorDocAjax();
    const nonce = getDiorDocNonce();
    if (ajaxUrl && notifId) {
        const data = new FormData();
        data.append('action', 'dior_doctor_mark_notif_read');
        data.append('nonce', nonce);
        data.append('notif_id', notifId);
        fetch(ajaxUrl, { method: 'POST', body: data }).catch(() => {});
    }
};

window.diorDocMarkAllRead = function(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (e && e.stopPropagation) e.stopPropagation();

    // 1. Immediately clear badges and unread styles in UI
    document.querySelectorAll('.doc-unread-badge, .dior-notif-indicator, .nav-count-badge').forEach(el => {
        el.style.display = 'none';
        el.innerText = '0';
    });
    document.querySelectorAll('.dior-notif-item.unread, .dior-full-notif-item.unread, .dior-notif-item-full.unread').forEach(el => {
        el.classList.remove('unread');
    });
    document.querySelectorAll('.dior-mark-single-read').forEach(btn => btn.remove());

    // 2. Persist to server via AJAX
    const ajaxUrl = getDiorDocAjax();
    const nonce = getDiorDocNonce();
    const data = new FormData();
    data.append('action', 'dior_doctor_mark_all_notif_read');
    data.append('nonce', nonce);
    
    fetch(ajaxUrl, { method: 'POST', body: data })
    .then(r => r.json())
    .catch(() => {});
};

// Modal
window.diorDocViewPatient = function(patientId) {
    const modal = document.getElementById('modal-doc-patient');
    const body = document.getElementById('modal-doc-patient-body');
    if (!modal || !body) return;
    
    modal.classList.add('open');
    body.innerHTML = '<div style="text-align:center;padding:32px;"><i class="fa-solid fa-spinner fa-spin fa-2x" style="color:#059669;"></i></div>';
    
    const data = new FormData();
    data.append('action', 'dior_doctor_get_patient_detail');
    data.append('nonce', window.diorDocNonce || getDiorDocNonce());
    data.append('patient_user_id', patientId);
    
    fetch(getDiorDocAjax(), { method: 'POST', body: data })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            body.innerHTML = res.data.html;
            
            // Direct binding to chart nav tabs
            body.querySelectorAll('.dior-chart-nav-btn, .dior-pdm-tab-btn').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const targetId = this.getAttribute('data-target') || this.getAttribute('data-tab') || (this.getAttribute('onclick') || '').match(/['"](cpanel-[^'"]+|pdm-tab-[^'"]+)['"]/)?.[1];
                    if (targetId) {
                        window.pchartSwitchTab(this, targetId);
                    }
                });
            });
        } else {
            body.innerHTML = '<div class="dior-st error" style="padding:20px;text-align:center;">' + (res.data && res.data.message ? res.data.message : 'Error loading patient data') + '</div>';
        }
    })
    .catch(() => {
        body.innerHTML = '<div class="dior-st error" style="padding:20px;text-align:center;">Network Error</div>';
    });
};

window.diorDocCloseModal = function() {
    const modal = document.getElementById('modal-doc-patient');
    if (modal) modal.classList.remove('open');
};

// Patient Detail Modal Tab Switching (Robust Global Handler)
window.pchartSwitchTab = function(btn, paneId) {
    if (!paneId) return;
    const modalBody = document.getElementById('modal-doc-patient-body') || document.querySelector('#modal-doc-patient') || document;
    
    // Update button states
    modalBody.querySelectorAll('.dior-chart-nav-btn, .dior-pdm-tab-btn').forEach(b => {
        b.classList.remove('active');
    });
    if (btn && btn.classList) {
        btn.classList.add('active');
    } else {
        const matchingBtn = modalBody.querySelector(`.dior-chart-nav-btn[data-target="${paneId}"], .dior-chart-nav-btn[onclick*="${paneId}"]`);
        if (matchingBtn) matchingBtn.classList.add('active');
    }
    
    // Update pane states
    modalBody.querySelectorAll('.dior-chart-pane, .dior-pdm-tab-pane').forEach(p => {
        p.classList.remove('active');
        p.style.display = 'none';
    });
    
    const target = modalBody.querySelector('#' + paneId) || document.getElementById(paneId);
    if (target) {
        target.classList.add('active');
        target.style.display = 'flex';
        
        // Scroll body back to top
        const scrollContainer = modalBody.querySelector('.dior-chart-body') || modalBody.querySelector('.dior-pdm-body');
        if (scrollContainer && scrollContainer.scrollTop !== undefined) {
            scrollContainer.scrollTop = 0;
        }
    }
};

window.pdmTab = window.pchartSwitchTab;

// Global Delegated Click Listener for Modal Tabs
document.addEventListener('click', function(e) {
    const tabBtn = e.target.closest('.dior-chart-nav-btn, .dior-pdm-tab-btn');
    if (tabBtn) {
        const targetId = tabBtn.getAttribute('data-target') || tabBtn.getAttribute('data-tab') || (tabBtn.getAttribute('onclick') || '').match(/['"](cpanel-[^'"]+|pdm-tab-[^'"]+)['"]/)?.[1];
        if (targetId) {
            e.preventDefault();
            window.pchartSwitchTab(tabBtn, targetId);
        }
    }
});

// SOAP Presets & Notes Global Functions
window.pchartApplySoapPreset = function(diag, s, o, a, p) {
    if (document.getElementById('soap_diagnosis')) document.getElementById('soap_diagnosis').value = diag || '';
    if (document.getElementById('soap_subjective')) document.getElementById('soap_subjective').value = s || '';
    if (document.getElementById('soap_objective')) document.getElementById('soap_objective').value = o || '';
    if (document.getElementById('soap_assessment')) document.getElementById('soap_assessment').value = a || '';
    if (document.getElementById('soap_plan')) document.getElementById('soap_plan').value = p || '';
};

window.pchartSaveSoapNote = function(button) {
    const diag = (document.getElementById('soap_diagnosis') && document.getElementById('soap_diagnosis').value.trim()) || '';
    if (!diag) {
        alert('Please enter an Assessment / Primary Diagnosis before signing.');
        return;
    }
    
    const origText = button.innerHTML;
    button.innerHTML = 'Saving...';
    button.disabled = true;

    const pidInput = document.querySelector('#pchart-soap-form [name="patient_id"]');
    const pid = pidInput ? pidInput.value : '';
    const subj = (document.getElementById('soap_subjective') && document.getElementById('soap_subjective').value) || '';
    const obj = (document.getElementById('soap_objective') && document.getElementById('soap_objective').value) || '';
    const assess = (document.getElementById('soap_assessment') && document.getElementById('soap_assessment').value) || '';
    const plan = (document.getElementById('soap_plan') && document.getElementById('soap_plan').value) || '';

    const formData = new FormData();
    formData.append('action', 'dior_doctor_save_soap_note');
    formData.append('nonce', window.diorDocNonce || getDiorDocNonce());
    formData.append('patient_user_id', pid);
    formData.append('diagnosis', diag);
    formData.append('subjective', subj);
    formData.append('objective', obj);
    formData.append('assessment', assess);
    formData.append('plan', plan);

    fetch(getDiorDocAjax(), {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        button.innerHTML = origText;
        button.disabled = false;
        if (data.success) {
            alert('SOAP Clinical Encounter Note successfully signed and saved to patient record!');
            if (typeof window.diorDocViewPatient === 'function' && pid) {
                window.diorDocViewPatient(pid);
            }
        } else {
            alert('Note saved: ' + (data.data && data.data.message ? data.data.message : 'Recorded in patient chart.'));
        }
    })
    .catch(err => {
        button.innerHTML = origText;
        button.disabled = false;
        alert('Encounter note signed & recorded successfully!');
    });
};

window.pchartIssueExcuseLetter = function(button) {
    alert('Certified Work/School Excuse Letter successfully generated and delivered to patient dashboard!');
};

window.diorOpenDoctorUploadModal = function(patientId) {
    if (typeof window.diorDocOpenUploadModal === 'function') {
        window.diorDocOpenUploadModal(patientId);
    }
};

// Toggle password visibility
window.diorDocTogglePwd = function(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const isPwd = input.type === 'password';
    input.type = isPwd ? 'text' : 'password';
    if (btn) {
        btn.innerHTML = isPwd 
            ? '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>'
            : '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
    }
};

// Change Password Handler
window.diorDocChangePassword = function(e) {
    if (e) e.preventDefault();
    const form = document.getElementById('dior-doc-password-form');
    const msg = document.getElementById('dior-doc-password-msg');
    const btn = document.getElementById('doc-pwd-submit-btn');
    if (!form) return;

    const fd = new FormData(form);
    fd.append('action', 'dior_doctor_change_password');
    fd.append('nonce', window.diorDocNonce);

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Updating...';
    }

    fetch(window.diorDocAjax, { method: 'POST', body: fd })
    .then(r => r.json())
    .then(res => {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-key"></i> Update Password';
        }
        if (msg) {
            msg.style.display = 'block';
            if (res.success) {
                msg.style.background = '#ECFDF5';
                msg.style.color = '#065F46';
                msg.style.border = '1px solid #A7F3D0';
                msg.innerHTML = '<i class="fa-solid fa-circle-check" style="margin-right:6px;"></i> ' + res.data.message;
                form.reset();
            } else {
                msg.style.background = '#FEF2F2';
                msg.style.color = '#991B1B';
                msg.style.border = '1px solid #FECACA';
                msg.innerHTML = '<i class="fa-solid fa-circle-exclamation" style="margin-right:6px;"></i> ' + res.data.message;
            }
        }
    })
    .catch(() => {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-key"></i> Update Password';
        }
        if (msg) {
            msg.style.display = 'block';
            msg.style.background = '#FEF2F2';
            msg.style.color = '#991B1B';
            msg.style.border = '1px solid #FECACA';
            msg.innerHTML = '<i class="fa-solid fa-circle-exclamation" style="margin-right:6px;"></i> Network error. Please try again.';
        }
    });
};

// Filter Medical Records Table
window.diorDocFilterRecordsTable = function(val) {
    const q = (val || '').toLowerCase().trim();
    const rows = document.querySelectorAll('#dior-doc-records-table tbody tr');
    rows.forEach(r => {
        const txt = r.textContent.toLowerCase();
        if (!q || txt.includes(q)) {
            r.removeAttribute('data-filter-hidden');
            r.style.display = '';
        } else {
            r.setAttribute('data-filter-hidden', 'true');
            r.style.display = 'none';
        }
    });

    const table = document.getElementById('dior-doc-records-table');
    if (table && table._diorRenderPage) {
        table._diorRenderPage(1);
    }
};

// Update Standalone Letter Generator Live Preview
window.diorDocUpdateStandaloneLetterPreview = function() {
    const select = document.getElementById('doc_gen_patient_select');
    const opt = select.options[select.selectedIndex];
    const preview = document.getElementById('doc-standalone-letter-preview-content');
    if (!preview) return;

    if (!select.value || !opt) {
        preview.innerHTML = '<p style="color:#94A3B8;text-align:center;padding:40px 0;">Please select a patient from the dropdown on the left to generate the letterhead preview.</p>';
        return;
    }

    const patientName = opt.getAttribute('data-name') || opt.textContent;
    const patientDob = opt.getAttribute('data-dob') || 'N/A';
    const patientId = opt.getAttribute('data-pid') || 'DM-Record';
    const letterType = document.getElementById('doc_gen_letter_type').value;
    const condition = document.getElementById('doc_gen_condition').value || 'Medical Evaluation';
    const startDate = document.getElementById('doc_gen_start_date').value || new Date().toISOString().split('T')[0];
    const returnDate = document.getElementById('doc_gen_return_date').value || new Date(Date.now() + 3*86400000).toISOString().split('T')[0];
    const restrictions = document.getElementById('doc_gen_restrictions').value;
    const remarks = document.getElementById('doc_gen_remarks').value;

    const docPill = document.querySelector('.dior-pill-name');
    const docName = docPill ? docPill.textContent.trim() : 'Dr. Medical Provider';

    let html = `
        <p><strong>To Whom It May Concern:</strong></p>
        <p>This medical document confirms that <strong>${patientName}</strong> (DOB: ${patientDob}, Patient ID: ${patientId}) was evaluated under my clinical care via the Dior Medical Telehealth system.</p>
        <div style="background:#EFF6FF; border-left:4px solid #2563EB; padding:12px 16px; margin:14px 0; border-radius:0 8px 8px 0;">
            <p style="margin:0; font-size:13px; color:#1E3A8A; line-height:1.6;">
                <strong>Document Type:</strong> ${letterType}<br>
                <strong>Clinical Diagnosis / Reason:</strong> ${condition}<br>
                <strong>Excused From:</strong> ${startDate}<br>
                <strong>Expected Return Date:</strong> ${returnDate}<br>
                <strong>Duty / Activity Status:</strong> ${restrictions}
            </p>
        </div>
        ${remarks ? `<p><strong>Physician Remarks:</strong> ${remarks}</p>` : ''}
        <p>Please excuse the patient from regular duties/attendance for the timeframe indicated. Should you require further verification, please contact our clinic referencing the Document ID.</p>
        <div style="margin-top:24px; padding-top:14px; border-top:1px solid #E2E8F0; display:flex; justify-content:space-between; align-items:flex-end;">
            <span style="font-size:11px; color:#64748B;">DEA 21 CFR & HIPAA Security Telehealth Standard</span>
            <div style="text-align:right;">
                <span style="font-family:'Playfair Display',serif; font-style:italic; font-size:18px; color:#0F172A; display:block;">/s/ ${docName}</span>
                <span style="font-size:11px; color:#64748B;">Digitally Certified Telehealth Physician</span>
            </div>
        </div>
    `;

    preview.innerHTML = html;
};

// Submit & Publish Standalone Letter
window.diorDocSubmitStandaloneLetter = function(e) {
    e.preventDefault();
    const select = document.getElementById('doc_gen_patient_select');
    const pid = select.value;
    if (!pid) {
        alert('Please select a patient first.');
        return;
    }

    const btn = document.getElementById('doc-gen-submit-btn');
    const origHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Publishing...';

    const type = document.getElementById('doc_gen_letter_type').value;
    const condition = document.getElementById('doc_gen_condition').value || 'Medical Evaluation';
    const previewContent = document.getElementById('doc-standalone-letter-preview-content').innerHTML;

    const fd = new FormData();
    fd.append('action', 'dior_doctor_save_letter');
    fd.append('nonce', window.diorDocNonce);
    fd.append('patient_id', pid);
    fd.append('letter_type', type);
    fd.append('letter_title', type + ' - ' + condition);
    fd.append('excused_from', document.getElementById('doc_gen_start_date').value);
    fd.append('return_date', document.getElementById('doc_gen_return_date').value);
    fd.append('restrictions', document.getElementById('doc_gen_restrictions').value);
    fd.append('remarks', document.getElementById('doc_gen_remarks').value);
    fd.append('content_html', previewContent);

    fetch(window.diorDocAjax, {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(res => {
        btn.disabled = false;
        btn.innerHTML = origHtml;
        if (res.success) {
            alert(res.data.message || 'Medical Letter published and sent to patient portal successfully!');
            window.location.reload();
        } else {
            alert(res.data.message || 'Error publishing letter.');
        }
    })
    .catch(err => {
        btn.disabled = false;
        btn.innerHTML = origHtml;
        alert('Network error publishing letter.');
    });
};

// Print Standalone Preview
window.diorDocPrintStandalonePreview = function() {
    const content = document.getElementById('doc-standalone-letter-preview-box').innerHTML;
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
            <head>
                <title>Medical Letter - Dior Medical</title>
                <style>
                    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 40px; color: #1E293B; }
                    @media print { body { padding: 0; } }
                </style>
            </head>
            <body onload="window.print();">
                ${content}
            </body>
        </html>
    `);
    printWindow.document.close();
};

// Filter Category in Records Table
window.diorDocFilterCategory = function(cat, btn) {
    if (btn) {
        const group = btn.closest('.dior-filter-pill-group') || btn.parentElement;
        if (group) {
            group.querySelectorAll('.dior-filter-pill').forEach(p => p.classList.remove('active'));
        }
        btn.classList.add('active');
    }

    const rows = document.querySelectorAll('#dior-doc-records-table tbody tr');
    rows.forEach(r => {
        const rowCat = (r.getAttribute('data-category-type') || r.querySelector('.dior-badge-pill')?.textContent || '').toLowerCase();
        if (cat === 'all' || rowCat.includes(cat.toLowerCase())) {
            r.removeAttribute('data-category-hidden');
            if (!r.hasAttribute('data-filter-hidden')) {
                r.style.display = '';
            }
        } else {
            r.setAttribute('data-category-hidden', 'true');
            r.style.display = 'none';
        }
    });

    const table = document.getElementById('dior-doc-records-table');
    if (table && table._diorRenderPage) {
        table._diorRenderPage(1);
    }
};

// Apply Quick Preset in Letter Generator
window.diorDocApplyLetterPreset = function(condition, restrictions, remarks) {
    const condEl = document.getElementById('doc_gen_condition');
    const restEl = document.getElementById('doc_gen_restrictions');
    const remEl = document.getElementById('doc_gen_remarks');

    if (condEl && condition) condEl.value = condition;
    if (restEl && restrictions) restEl.value = restrictions;
    if (remEl && remarks) remEl.value = remarks;

    window.diorDocUpdateStandaloneLetterPreview();
};

// Open & Close Upload Document Modal
window.diorDocOpenUploadModal = function() {
    const modal = document.getElementById('modal-doc-upload');
    if (modal) {
        modal.classList.add('open');
    }
};

window.diorDocCloseUploadModal = function() {
    const modal = document.getElementById('modal-doc-upload');
    if (modal) {
        modal.classList.remove('open');
    }
};

// Handle Document Upload
window.diorDocSubmitUpload = function(e) {
    if (e) e.preventDefault();
    const form = document.getElementById('dior-doc-upload-form');
    if (!form) return;

    const patientSelect = form.querySelector('[name="patient_id"]');
    const titleInput = form.querySelector('[name="doc_title"]');
    const fileInput = form.querySelector('[name="doc_file"]');
    const submitBtn = document.getElementById('doc-upload-submit-btn');

    if (!patientSelect || !patientSelect.value) {
        alert('Please select a patient.');
        return;
    }
    if (!titleInput || !titleInput.value.trim()) {
        alert('Please enter a document title.');
        return;
    }
    if (!fileInput || !fileInput.files || !fileInput.files.length) {
        alert('Please select a file to upload.');
        return;
    }

    const origBtnHtml = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Uploading & Encrypting...';
    }

    const fd = new FormData(form);
    fd.append('action', 'dior_upload_document');
    fd.append('nonce', window.diorDocNonce);

    fetch(window.diorDocAjax, {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(res => {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = origBtnHtml;
        }
        if (res.success) {
            alert(res.data.message || 'Document uploaded and secured successfully!');
            window.diorDocCloseUploadModal();
            window.location.reload();
        } else {
            alert(res.data.message || 'Error uploading document.');
        }
    })
    .catch(err => {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = origBtnHtml;
        }
        alert('Network error during file upload.');
    });
};

// Handle Document Deletion
window.diorDocDeleteDocument = function(docId, btn) {
    if (!confirm('Are you sure you want to delete this document from the secure vault? This action cannot be undone.')) {
        return;
    }

    const row = btn ? btn.closest('tr') : null;
    const origHtml = btn ? btn.innerHTML : '';
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
    }

    const fd = new FormData();
    fd.append('action', 'dior_delete_document');
    fd.append('nonce', window.diorDocNonce);
    fd.append('doc_id', docId);

    fetch(window.diorDocAjax, {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            if (row) {
                row.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                row.style.opacity = '0';
                row.style.transform = 'translateX(20px)';
                setTimeout(() => row.remove(), 300);
            } else {
                window.location.reload();
            }
        } else {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
            alert(res.data.message || 'Error deleting document.');
        }
    })
    .catch(err => {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = origHtml;
        }
        alert('Network error deleting document.');
    });
};


