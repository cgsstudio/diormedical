/**
 * Dior Medical - Luxury Telehealth Patient Portal Interactive JS
 * Full State & AJAX Controller for Dashboard Modules, Modals, Forms & Widgets
 */

window.diorOnIntakeSubmitted = function(e) {
    if (e && typeof e.preventDefault === 'function') e.preventDefault();
    const hipaaWrap = document.getElementById('dior-hipaa-form-container');
    const bookingSec = document.getElementById('dior-dashboard-booking-section');
    const stepNotice = document.getElementById('dior-intake-step-notice');
    const compNotice = document.getElementById('dior-intake-completed-notice');

    if (hipaaWrap) {
        hipaaWrap.style.setProperty('display', 'none', 'important');
    }
    if (bookingSec) {
        bookingSec.style.setProperty('display', 'block', 'important');
        bookingSec.scrollIntoView({ behavior: 'smooth' });
    }
    if (stepNotice) {
        stepNotice.style.setProperty('display', 'none', 'important');
    }
    if (compNotice) {
        compNotice.style.setProperty('display', 'flex', 'important');
    }

    if (typeof window.diorInBookingGoToStep === 'function') {
        window.diorInBookingGoToStep('doctor');
    }

    if (typeof showToast === 'function') {
        showToast('Clinical Intake Submitted! Unlocking physician scheduling calendar...', false);
    }
};

// Automatic HIPAAtizer Embed Message Listener
window.addEventListener('message', function(event) {
    if (!event || !event.data) return;
    var data = event.data;
    var isSubmitted = false;

    if (typeof data === 'string') {
        try {
            data = JSON.parse(data);
        } catch(e) {}
    }

    if (data && typeof data === 'object') {
        if (data.type === 'hipaatizer-form-submitted' ||
            data.action === 'form_submitted' ||
            data.event === 'submit' ||
            data.event === 'form_submitted' ||
            data.status === 'completed' ||
            data.status === 'submitted' ||
            (data.source && String(data.source).indexOf('hipaatizer') !== -1 && (data.action === 'submit' || data.event === 'submit'))
        ) {
            isSubmitted = true;
        }
    } else if (typeof data === 'string' && (data.indexOf('hipaatizer') !== -1 && (data.indexOf('submitted') !== -1 || data.indexOf('completed') !== -1))) {
        isSubmitted = true;
    }

    if (isSubmitted) {
        if (typeof window.diorOnIntakeSubmitted === 'function') {
            window.diorOnIntakeSubmitted();
        }
    }
});

// Check URL parameters for direct redirect from HIPAAtizer settings
try {
    var urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('intake_completed') === '1' || urlParams.get('intake') === 'success' || urlParams.get('submitted') === '1' || window.location.hash.indexOf('booking') !== -1) {
        setTimeout(function() {
            if (typeof window.diorOnIntakeSubmitted === 'function') {
                window.diorOnIntakeSubmitted();
            }
        }, 500);
    }
} catch(e) {}

// Automatic Background Poller to detect intake webhook completion in real-time
(function initIntakeWatcher() {
    var checkTimer = null;
    function checkStatus() {
        var hipaaWrap = document.getElementById('dior-hipaa-form-container');
        if (!hipaaWrap || hipaaWrap.style.display === 'none') {
            if (checkTimer) clearInterval(checkTimer);
            return;
        }

        if (typeof jQuery !== 'undefined' && typeof dior_vars !== 'undefined' && dior_vars.ajax_url) {
            jQuery.ajax({
                url: dior_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'dior_patient_check_intake_status',
                    nonce: dior_vars.nonce
                },
                dataType: 'json',
                success: function(res) {
                    if (res && res.success && res.data && res.data.has_intake) {
                        if (checkTimer) clearInterval(checkTimer);
                        window.diorOnIntakeSubmitted();
                    }
                }
            });
        }
    }

    // Check every 5 seconds while intake form is active
    checkTimer = setInterval(checkStatus, 5000);
})();

window.diorToggleIntakeReview = function() {
    const card = document.getElementById('dior-intake-review-card');
    const btnText = document.getElementById('toggle-intake-btn-text');
    if (card) {
        if (card.style.display === 'none' || !card.style.display) {
            card.style.setProperty('display', 'block', 'important');
            if (btnText) btnText.textContent = 'Hide Submitted Answers';
            card.scrollIntoView({ behavior: 'smooth' });
        } else {
            card.style.setProperty('display', 'none', 'important');
            if (btnText) btnText.textContent = 'View Submitted Answers';
        }
    }
};

window.diorReopenHipaaForm = function() {
    const hipaaWrap = document.getElementById('dior-hipaa-form-container');
    const bookingSec = document.getElementById('dior-dashboard-booking-section');
    if (hipaaWrap) {
        hipaaWrap.style.setProperty('display', 'block', 'important');
        hipaaWrap.scrollIntoView({ behavior: 'smooth' });
    }
    if (bookingSec) {
        bookingSec.style.setProperty('display', 'none', 'important');
    }
};

// =========================================================================
// IN-DASHBOARD APPOINTMENT BOOKING & INTAKE STATE MACHINE
// =========================================================================
window.diorInBookingState = {
    step: 1,
    doctorId: 1695,
    doctorName: 'Dr. James Chen, DO',
    doctorSpeciality: 'Primary Care & Urgent Care',
    date: new Date().toISOString().split('T')[0],
    day: new Date().toLocaleDateString('en-US', { weekday: 'long' }),
    clinicId: 1,
    time: null,
    patient: {
        name: (typeof dior_vars !== 'undefined' && dior_vars.patient_profile && dior_vars.patient_profile.full_name) || '',
        email: (typeof dior_vars !== 'undefined' && dior_vars.patient_profile && dior_vars.patient_profile.email) || '',
        phone: (typeof dior_vars !== 'undefined' && dior_vars.patient_profile && dior_vars.patient_profile.phone) || '',
        service: (typeof dior_vars !== 'undefined' && dior_vars.hipaa_intake && (dior_vars.hipaa_intake.service_condition || dior_vars.hipaa_intake.symptoms)) || 'Telehealth Medical Care',
        notes: (typeof dior_vars !== 'undefined' && dior_vars.hipaa_intake && dior_vars.hipaa_intake.symptoms) || ''
    }
};

window.diorInBookingGoToStep = function(stepName) {
    const stepDoctor = document.getElementById('in-step-doctor');
    const stepTime = document.getElementById('in-step-time');
    const stepConfirm = document.getElementById('in-step-confirm');

    const node1 = document.getElementById('wizard-node-1');
    const node2 = document.getElementById('wizard-node-2');
    const node3 = document.getElementById('wizard-node-3');

    if (stepDoctor) stepDoctor.style.setProperty('display', 'none', 'important');
    if (stepTime) stepTime.style.setProperty('display', 'none', 'important');
    if (stepConfirm) stepConfirm.style.setProperty('display', 'none', 'important');

    if (node1) { node1.style.background = '#F8FAFC'; node1.style.border = '1px solid #E2E8F0'; }
    if (node2) { node2.style.background = '#F8FAFC'; node2.style.border = '1px solid #E2E8F0'; }
    if (node3) { node3.style.background = '#F8FAFC'; node3.style.border = '1px solid #E2E8F0'; }

    if (stepName === 'doctor' || stepName === 1) {
        if (stepDoctor) stepDoctor.style.setProperty('display', 'block', 'important');
        if (node1) { node1.style.background = '#EFF6FF'; node1.style.border = '1.5px solid #2C6CB1'; }
    } else if (stepName === 'time' || stepName === 2) {
        if (stepTime) stepTime.style.setProperty('display', 'block', 'important');
        if (node2) { node2.style.background = '#EFF6FF'; node2.style.border = '1.5px solid #2C6CB1'; }
        window.diorInFetchAvailability();
    } else if (stepName === 'confirm' || stepName === 3) {
        if (stepConfirm) stepConfirm.style.setProperty('display', 'block', 'important');
        if (node3) { node3.style.background = '#EFF6FF'; node3.style.border = '1.5px solid #2C6CB1'; }
    }
};

window.diorInSelectDoctor = function(docId, docName, spec) {
    if (!window.diorInBookingState) {
        window.diorInBookingState = { patient: {} };
    }
    window.diorInBookingState.doctorId = docId || 1695;
    window.diorInBookingState.doctorName = docName || 'Doctor';
    window.diorInBookingState.doctorSpeciality = spec || 'Telehealth Physician';

    const summaryPill = document.getElementById('in-selected-doctor-summary-pill');
    if (summaryPill) {
        summaryPill.innerHTML = `
            <div style="display:flex; align-items:center; gap:10px;">
                <div style="width:36px; height:36px; border-radius:50%; background:#EFF6FF; color:#2C6CB1; display:flex; align-items:center; justify-content:center; font-weight:700;">
                    <i class="fa-solid fa-user-md"></i>
                </div>
                <div>
                    <strong style="color:#0F172A; display:block;">${docName}</strong>
                    <span style="color:#2C6CB1; font-size:12px;">${spec}</span>
                </div>
            </div>
        `;
    }

    document.querySelectorAll('.dior-doc-select-card').forEach(c => c.classList.remove('selected'));
    const sc = document.querySelector(`.dior-doc-select-card[data-doc-id="${docId}"]`);
    if (sc) sc.classList.add('selected');

    window.diorInBookingGoToStep('time');
};

window.diorInFetchAvailability = function() {
    const dateInput = document.getElementById('in-booking-date');
    const container = document.getElementById('in-time-slots-container');
    if (!container) return;

    let dateVal = dateInput ? dateInput.value : (window.diorInBookingState && window.diorInBookingState.date);
    if (!dateVal) dateVal = new Date().toISOString().split('T')[0];
    if (window.diorInBookingState) window.diorInBookingState.date = dateVal;

    const dateObj = new Date(dateVal + 'T00:00:00');
    const dayName = dateObj.toLocaleDateString('en-US', { weekday: 'long' });
    if (window.diorInBookingState) window.diorInBookingState.day = dayName;

    function renderSlots(slots, label) {
        let html = `<div style="font-size:12.5px; font-weight:700; color:#475569; margin-bottom:8px;">${label || 'Available Consultation Slots'} (${dayName}):</div>`;
        html += `<div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(110px, 1fr)); gap:8px;">`;
        slots.forEach(slot => {
            const timeText = typeof slot === 'object' ? slot.time : slot;
            const isAvail = typeof slot === 'object' ? slot.is_available : true;
            if (isAvail) {
                html += `<button type="button" class="dior-time-btn" onclick="diorInSelectTime(1, '${timeText}')" style="padding:10px 12px; border:1.5px solid #CBD5E1; border-radius:8px; background:#FFFFFF; color:#0F172A; font-weight:700; cursor:pointer; font-size:13px; transition:all 0.15s ease;">${timeText}</button>`;
            } else {
                html += `<button type="button" disabled style="padding:10px 12px; border:1px solid #E2E8F0; border-radius:8px; background:#F1F5F9; color:#94A3B8; font-weight:500; cursor:not-allowed; font-size:13px;">${timeText}</button>`;
            }
        });
        html += `</div>`;
        container.innerHTML = html;
    }

    const defaultSlots = ['09:00 AM', '10:00 AM', '11:30 AM', '01:00 PM', '02:30 PM', '04:00 PM', '05:30 PM'];
    renderSlots(defaultSlots, 'Virtual Consultation Schedule');

    const restUrl = (typeof dior_vars !== 'undefined' && dior_vars.rest_url) || '/diormedical/wp-json/';
    const restNonce = (typeof dior_vars !== 'undefined' && dior_vars.rest_nonce) || '';
    const docId = window.diorInBookingState ? window.diorInBookingState.doctorId : 1695;

    fetch(`${restUrl}doctor-details-booking/v1/doctors/${docId}/availability?date=${dateVal}`, {
        headers: { 'X-WP-Nonce': restNonce }
    })
    .then(r => r.json())
    .then(data => {
        if (data && data.clinics && data.clinics.length > 0) {
            let clinicSlots = [];
            data.clinics.forEach(clinic => {
                if (!clinic.is_on_holiday && clinic.timings && clinic.timings.length > 0) {
                    clinic.timings.forEach(t => clinicSlots.push(t));
                }
            });
            if (clinicSlots.length > 0) {
                renderSlots(clinicSlots, 'DocBooker Live Clinic Timings');
            }
        }
    })
    .catch(() => {});
};

window.diorInSelectTime = function(clinicId, timeStr) {
    if (!window.diorInBookingState) window.diorInBookingState = {};
    window.diorInBookingState.clinicId = clinicId;
    window.diorInBookingState.time = timeStr;

    const confirmSummary = document.getElementById('in-booking-confirm-summary');
    if (confirmSummary) {
        const formattedDate = new Date(window.diorInBookingState.date + 'T00:00:00').toLocaleDateString('en-US', {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
        });

        const pName = (window.diorInBookingState.patient && window.diorInBookingState.patient.name) || (typeof dior_vars !== 'undefined' && dior_vars.patient_profile && dior_vars.patient_profile.full_name) || 'Patient';
        const pEmail = (window.diorInBookingState.patient && window.diorInBookingState.patient.email) || (typeof dior_vars !== 'undefined' && dior_vars.patient_profile && dior_vars.patient_profile.email) || '';
        const pPhone = (window.diorInBookingState.patient && window.diorInBookingState.patient.phone) || (typeof dior_vars !== 'undefined' && dior_vars.patient_profile && dior_vars.patient_profile.phone) || '';
        const pService = (window.diorInBookingState.patient && window.diorInBookingState.patient.service) || 'Telehealth Medical Care';

        confirmSummary.innerHTML = `
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
                <div>
                    <span style="font-size:12px; color:#64748B; text-transform:uppercase; font-weight:700; display:block;">Attending Physician:</span>
                    <strong style="font-size:15px; color:#0F172A;">${window.diorInBookingState.doctorName}</strong>
                    <span style="font-size:12.5px; color:#2C6CB1; display:block;">${window.diorInBookingState.doctorSpeciality}</span>
                </div>
                <div>
                    <span style="font-size:12px; color:#64748B; text-transform:uppercase; font-weight:700; display:block;">Appointment Date & Time:</span>
                    <strong style="font-size:15px; color:#0F172A;">${formattedDate}</strong>
                    <span style="font-size:13px; color:#059669; font-weight:700; display:block;"><i class="fa-regular fa-clock"></i> ${timeStr} (Video Visit)</span>
                </div>
                <div style="grid-column: 1 / -1; border-top:1px solid #E2E8F0; padding-top:12px; margin-top:4px;">
                    <span style="font-size:12px; color:#64748B; text-transform:uppercase; font-weight:700; display:block;">Intake Profile & Patient Details:</span>
                    <strong style="font-size:14px; color:#0F172A;">${pName}</strong> &bull;
                    <span style="font-size:13px; color:#475569;">${pEmail} &bull; ${pPhone}</span>
                    <div style="margin-top:6px; font-size:12.5px; color:#64748B;"><strong>Reason:</strong> ${pService}</div>
                </div>
            </div>
        `;
    }

    window.diorInBookingGoToStep('confirm');
};

window.diorInSubmitBooking = function() {
    const btn = document.getElementById('btn-in-confirm-booking');
    const msg = document.getElementById('in-booking-status-msg');

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Scheduling Consultation & Syncing...';
    }

    if (msg) {
        msg.style.display = 'none';
    }

    const payload = {
        action: 'dior_patient_book_appointment',
        nonce: (typeof dior_vars !== 'undefined' && dior_vars.nonce) || '',
        doctorId: (window.diorInBookingState && window.diorInBookingState.doctorId) || 1695,
        doctor_name: (window.diorInBookingState && window.diorInBookingState.doctorName) || 'Doctor',
        date: (window.diorInBookingState && window.diorInBookingState.date) || '',
        time: (window.diorInBookingState && window.diorInBookingState.time) || '',
        condition: (window.diorInBookingState && window.diorInBookingState.patient && window.diorInBookingState.patient.service) || 'Telehealth Consultation',
        notes: (window.diorInBookingState && window.diorInBookingState.patient && window.diorInBookingState.patient.notes) || '',
        name: (window.diorInBookingState && window.diorInBookingState.patient && window.diorInBookingState.patient.name) || '',
        email: (window.diorInBookingState && window.diorInBookingState.patient && window.diorInBookingState.patient.email) || '',
        phone: (window.diorInBookingState && window.diorInBookingState.patient && window.diorInBookingState.patient.phone) || ''
    };

    const formData = new FormData();
    for (let k in payload) {
        formData.append(k, payload[k]);
    }

    fetch((typeof dior_vars !== 'undefined' && dior_vars.ajax_url) || '/wp-admin/admin-ajax.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            if (msg) {
                msg.style.display = 'block';
                msg.style.background = '#ECFDF5';
                msg.style.border = '1px solid #A7F3D0';
                msg.style.color = '#065F46';
                msg.innerHTML = '<i class="fa-solid fa-circle-check"></i> ' + (res.data.message || 'Appointment booked successfully! Doctor & Patient notifications sent.');
            }
            if (btn) {
                btn.innerHTML = '<i class="fa-solid fa-check"></i> Booked Successfully';
            }

            if (window.diorUpdateCountdown) {
                window.diorUpdateCountdown(window.diorInBookingState.date, window.diorInBookingState.time);
            }

            setTimeout(() => {
                window.location.hash = '#tab=appointments';
                window.location.reload();
            }, 1500);
        } else {
            if (msg) {
                msg.style.display = 'block';
                msg.style.background = '#FEF2F2';
                msg.style.border = '1px solid #FECACA';
                msg.style.color = '#991B1B';
                msg.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> ' + ((res.data && res.data.message) || 'Failed to book appointment.');
            }
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-video"></i> Confirm & Schedule Telehealth Visit';
            }
        }
    })
    .catch(err => {
        console.error('Booking error:', err);
        if (msg) {
            msg.style.display = 'block';
            msg.style.background = '#FEF2F2';
            msg.style.border = '1px solid #FECACA';
            msg.style.color = '#991B1B';
            msg.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> An error occurred while booking.';
        }
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-video"></i> Confirm & Schedule Telehealth Visit';
        }
    });
};

document.addEventListener('click', function(e) {
    const card = e.target.closest('.dior-doc-select-card');
    if (card) {
        if (typeof e.preventDefault === 'function') e.preventDefault();
        const docId = card.getAttribute('data-doc-id');
        const docName = card.getAttribute('data-doc-name') || (card.querySelector('h5') && card.querySelector('h5').innerText) || 'Doctor';
        const docSpec = card.getAttribute('data-doc-spec') || (card.querySelector('span') && card.querySelector('span').innerText) || 'Telehealth Physician';
        window.diorInSelectDoctor(docId, docName, docSpec);
    }
});

window.diorToggleNotifDropdown = function(e) {
    if (e) {
        if (typeof e.preventDefault === 'function') e.preventDefault();
        if (typeof e.stopPropagation === 'function') e.stopPropagation();
    }
    const dropdown = document.getElementById('dior-notif-dropdown');
    if (dropdown) {
        dropdown.classList.toggle('open');
    }
};

document.addEventListener('click', function(e) {
    const wrap = document.getElementById('dior-notif-dropdown-wrap');
    const dropdown = document.getElementById('dior-notif-dropdown');
    if (dropdown && dropdown.classList.contains('open')) {
        if (!wrap || !wrap.contains(e.target)) {
            dropdown.classList.remove('open');
        }
    }
});

// Universal Table Pagination (5 entries per page)
window.diorInitTablePagination = function(tableEl, pageSize) {
    if (!tableEl) return;
    pageSize = pageSize || 5;
    const tbody = tableEl.querySelector('tbody');
    if (!tbody) return;

    // Find parent container to attach pagination bar
    let parent = tableEl.parentElement;
    let paginationWrap = parent.querySelector(':scope > .dior-table-pagination') || (parent.parentElement ? parent.parentElement.querySelector(':scope > .dior-table-pagination') : null);
    
    if (!paginationWrap) {
        paginationWrap = document.createElement('div');
        paginationWrap.className = 'dior-table-pagination';
        // If wrapped inside a responsive container, put it outside/after the responsive container
        if (parent.classList.contains('dior-table-responsive') || parent.classList.contains('dior-card-body') || parent.style.overflowX === 'auto' || parent.style.overflow === 'auto') {
            parent.after(paginationWrap);
        } else {
            parent.appendChild(paginationWrap);
        }
    }

    let currentPage = 1;

    function renderPage(page) {
        currentPage = page || 1;
        const allRows = Array.from(tbody.querySelectorAll('tr')).filter(tr => !tr.classList.contains('dior-no-data-row') && tr.querySelectorAll('td').length > 1);
        
        if (allRows.length === 0) {
            paginationWrap.style.display = 'none';
            return;
        }

        const activeRows = allRows.filter(tr => tr.getAttribute('data-filter-hidden') !== 'true');
        const total = activeRows.length;
        const totalPages = Math.max(1, Math.ceil(total / pageSize));

        if (currentPage > totalPages) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;

        const startIndex = (currentPage - 1) * pageSize;
        const endIndex = startIndex + pageSize;

        // Apply visibility
        allRows.forEach(tr => {
            if (tr.getAttribute('data-filter-hidden') === 'true') {
                tr.style.display = 'none';
            }
        });

        activeRows.forEach((tr, index) => {
            if (index >= startIndex && index < endIndex) {
                tr.style.display = '';
            } else {
                tr.style.display = 'none';
            }
        });

        // Hide pagination controls if 5 or fewer entries
        if (totalPages <= 1) {
            paginationWrap.style.display = 'none';
            return;
        }

        const fromItem = total === 0 ? 0 : startIndex + 1;
        const toItem = Math.min(endIndex, total);

        let navHtml = '';
        if (totalPages > 1) {
            navHtml += `<button type="button" class="dior-page-btn" ${currentPage === 1 ? 'disabled' : ''} data-page="${currentPage - 1}" title="Previous Page"><i class="fa-solid fa-chevron-left" style="font-size:11px;"></i></button>`;

            for (let i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
                    navHtml += `<button type="button" class="dior-page-btn ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
                } else if (i === currentPage - 2 || i === currentPage + 2) {
                    navHtml += `<span style="padding: 0 4px; color: #94A3B8; font-size:12px;">...</span>`;
                }
            }

            navHtml += `<button type="button" class="dior-page-btn" ${currentPage === totalPages ? 'disabled' : ''} data-page="${currentPage + 1}" title="Next Page"><i class="fa-solid fa-chevron-right" style="font-size:11px;"></i></button>`;
        }

        paginationWrap.style.display = 'flex';
        paginationWrap.innerHTML = `
            <div class="dior-pagination-info">
                Showing <strong>${fromItem}</strong> to <strong>${toItem}</strong> of <strong>${total}</strong> entries
            </div>
            <div class="dior-pagination-nav">
                ${navHtml}
            </div>
        `;

        // Click listeners
        paginationWrap.querySelectorAll('.dior-page-btn[data-page]').forEach(btn => {
            btn.onclick = function(e) {
                e.preventDefault();
                const p = parseInt(this.getAttribute('data-page'), 10);
                if (!isNaN(p)) renderPage(p);
            };
        });
    }

    tableEl._diorRenderPage = renderPage;
    renderPage(1);
};

(function($) {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        const appWrap = document.getElementById('dior-patient-portal-app');
        if (!appWrap) {
            return;
        }

        // Initialize Pagination for all Patient Dashboard Tables (5 rows max per page)
        document.querySelectorAll('.dior-table, .dior-clean-table, .dior-doc-table').forEach(table => {
            diorInitTablePagination(table, 5);
        });

        // =========================================================================
        // 1. TOAST NOTIFICATION HELPER
        // =========================================================================
        function showToast(message, isError = false) {
            let toast = document.getElementById('dior-toast-alert');
            if (!toast) {
                toast = document.createElement('div');
                toast.id = 'dior-toast-alert';
                toast.className = 'dior-toast';
                document.body.appendChild(toast);
            }
            toast.textContent = message;
            toast.style.display = 'block';
            toast.style.borderLeftColor = isError ? 'var(--dior-danger)' : 'var(--dior-gold-500)';

            setTimeout(() => {
                toast.style.display = 'none';
            }, 4500);
        }

        // =========================================================================
        // 2. AJAX SENDER HELPER
        // =========================================================================
        function sendAjax(action, data, successCallback, errorCallback) {
            const formData = new FormData();
            formData.append('action', action);
            formData.append('nonce', dior_vars.nonce || '');

            for (let key in data) {
                formData.append(key, data[key]);
            }

            fetch(dior_vars.ajax_url, {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(response => {
                if (response.success) {
                    showToast(response.data.message || 'Action completed successfully.');
                    if (successCallback) successCallback(response.data);
                } else {
                    showToast((response.data && response.data.message) ? response.data.message : 'Error processing request.', true);
                    if (errorCallback) errorCallback(response.data);
                }
            })
            .catch(err => {
                showToast('Network error or server connection failed.', true);
                if (errorCallback) errorCallback(err);
            });
        }

        // =========================================================================
        // 3. TAB NAVIGATION & URL HASH SYNCHRONIZATION
        // =========================================================================
        const navButtons = document.querySelectorAll('.dior-nav-btn');
        const tabPanels = document.querySelectorAll('.dior-tab-panel');
        const pageTitleEl = document.getElementById('dior-current-page-title');

        const tabTitles = {
            'overview': 'Patient Overview',
            'profile': 'Profile & Telehealth Eligibility',
            'appointments': 'Telehealth Appointments',
            'payments': 'Billing & Payment Statements',
            'docs_meds': 'Medical Docs & Prescriptions',
            'questionnaire': 'Clinical Intake Questionnaires',
            'notifications': 'Notification Inbox'
        };

        function switchTab(tabId) {
            if (!document.getElementById('tab-' + tabId)) {
                tabId = 'overview';
            }

            navButtons.forEach(btn => {
                if (btn.getAttribute('data-tab') === tabId) {
                    btn.classList.add('active');
                    // Dynamic Badge Dismissal: Hide notification/count badge once opened
                    const activeBadge = btn.querySelector('.nav-count-badge');
                    if (activeBadge) {
                        activeBadge.style.display = 'none';
                        try {
                            sessionStorage.setItem('dior_dismissed_badge_' + tabId, '1');
                        } catch(e) {}
                    }
                } else {
                    btn.classList.remove('active');
                }
            });

            tabPanels.forEach(panel => {
                if (panel.id === 'tab-' + tabId) {
                    panel.classList.add('active');
                } else {
                    panel.classList.remove('active');
                }
            });

            if (pageTitleEl && tabTitles[tabId]) {
                pageTitleEl.textContent = tabTitles[tabId];
            }

            if (history.pushState) {
                history.pushState(null, null, '#tab=' + tabId);
            } else {
                location.hash = '#tab=' + tabId;
            }

            if (tabId === 'notifications') {
                document.querySelectorAll('.unread-badge-count, .dior-notif-indicator').forEach(b => {
                    b.style.display = 'none';
                });
                sendAjax('dior_patient_mark_all_notifications_read', {});
            }

            // Refresh table pagination inside activated tab
            const activePanel = document.getElementById('tab-' + tabId);
            if (activePanel) {
                activePanel.querySelectorAll('.dior-table, .dior-clean-table, .dior-doc-table').forEach(table => {
                    if (table._diorRenderPage) {
                        table._diorRenderPage(1);
                    } else {
                        diorInitTablePagination(table, 5);
                    }
                });
            }

            closeMobileDrawer();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        // Restore previously dismissed badges from session
        navButtons.forEach(btn => {
            const tab = btn.getAttribute('data-tab');
            if (tab) {
                try {
                    if (sessionStorage.getItem('dior_dismissed_badge_' + tab) === '1') {
                        const badge = btn.querySelector('.nav-count-badge');
                        if (badge) badge.style.display = 'none';
                    }
                } catch(e) {}
            }
        });

        navButtons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const tabId = this.getAttribute('data-tab');
                switchTab(tabId);
            });
        });

        // Delegate switch buttons across the dashboard
        document.addEventListener('click', function(e) {
            const target = e.target.closest('[data-switch-tab]');
            if (target) {
                e.preventDefault();
                const tabId = target.getAttribute('data-switch-tab');
                switchTab(tabId);
                // Also close notif dropdown if open
                const notifDropdown = document.getElementById('dior-notif-dropdown');
                if (notifDropdown) notifDropdown.classList.remove('open');
            }
        });

        window.diorSwitchTab = switchTab;

        // Deep linking via URL hash & hashchange listener
        function handleUrlHash() {
            if (window.location.hash && window.location.hash.startsWith('#tab=')) {
                const hashTab = window.location.hash.replace('#tab=', '');
                switchTab(hashTab);
            }
        }
        handleUrlHash();
        window.addEventListener('hashchange', handleUrlHash);

        // =========================================================================
        // 4. MOBILE DRAWER NAVIGATION
        // =========================================================================
        const mobileToggle = document.getElementById('dior-mobile-menu-toggle');
        const sideClose = document.getElementById('dior-side-close');
        const sidebar = document.getElementById('dior-sidebar');
        const drawerBackdrop = document.getElementById('dior-drawer-backdrop');

        window.diorOpenMobileDrawer = function() {
            const sb = document.getElementById('dior-sidebar');
            const bg = document.getElementById('dior-drawer-backdrop');
            if (sb) sb.classList.add('mobile-open');
            if (bg) bg.classList.add('active');
            document.body.style.overflow = 'hidden';
        };

        window.diorCloseMobileDrawer = function() {
            const sb = document.getElementById('dior-sidebar');
            const bg = document.getElementById('dior-drawer-backdrop');
            if (sb) sb.classList.remove('mobile-open');
            if (bg) bg.classList.remove('active');
            document.body.style.overflow = '';
        };

        function openMobileDrawer() {
            window.diorOpenMobileDrawer();
        }

        function closeMobileDrawer() {
            window.diorCloseMobileDrawer();
        }

        if (mobileToggle) mobileToggle.addEventListener('click', window.diorOpenMobileDrawer);
        if (sideClose) sideClose.addEventListener('click', window.diorCloseMobileDrawer);
        if (drawerBackdrop) drawerBackdrop.addEventListener('click', window.diorCloseMobileDrawer);

        // =========================================================================
        // 5. MODAL SYSTEM
        // =========================================================================
        window.diorOpenModal = function(modalId) {
            const overlay = document.getElementById(modalId);
            if (overlay) {
                overlay.classList.add('open');
                document.body.style.overflow = 'hidden';
            }
        };

        window.diorCloseModal = function(modalId) {
            const overlay = document.getElementById(modalId);
            if (overlay) {
                overlay.classList.remove('open');
                document.body.style.overflow = '';
            }
        };

        document.querySelectorAll('.dior-modal-close').forEach(btn => {
            btn.addEventListener('click', function() {
                const overlay = this.closest('.dior-modal-overlay');
                if (overlay) {
                    overlay.classList.remove('open');
                    document.body.style.overflow = '';
                }
            });
        });

        document.querySelectorAll('.dior-modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('open');
                    document.body.style.overflow = '';
                }
            });
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.dior-modal-overlay.open').forEach(o => {
                    o.classList.remove('open');
                });
                document.body.style.overflow = '';
                const notifDropdown = document.getElementById('dior-notif-dropdown');
                if (notifDropdown) notifDropdown.classList.remove('open');
            }
        });

        // =========================================================================
        // 6. NOTIFICATION DROPDOWN & ACTIONS
        // =========================================================================
        const notifDropdown = document.getElementById('dior-notif-dropdown');
        const markAllNotifsBtn = document.getElementById('dior-mark-all-notifications-btn');
        const quickMarkReadBtn = document.getElementById('dior-quick-mark-read');

        window.diorToggleNotifDropdown = function(e) {
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }
            const dropdown = document.getElementById('dior-notif-dropdown');
            if (dropdown) {
                dropdown.classList.toggle('open');
            }
        };

        document.addEventListener('click', function(e) {
            const wrap = document.getElementById('dior-notif-dropdown-wrap');
            const dropdown = document.getElementById('dior-notif-dropdown');
            if (dropdown && dropdown.classList.contains('open')) {
                if (!wrap || !wrap.contains(e.target)) {
                    dropdown.classList.remove('open');
                }
            }
        });

        function markAllNotificationsRead() {
            sendAjax('dior_patient_mark_all_notifications_read', {}, () => {
                document.querySelectorAll('.unread-badge-count').forEach(el => el.style.display = 'none');
                document.querySelectorAll('.dior-notif-item.unread, .dior-full-notif-item.unread').forEach(item => {
                    item.classList.remove('unread');
                });
                document.querySelectorAll('.dior-mark-single-read').forEach(btn => btn.remove());
            });
        }

        if (markAllNotifsBtn) markAllNotifsBtn.addEventListener('click', markAllNotificationsRead);
        if (quickMarkReadBtn) quickMarkReadBtn.addEventListener('click', markAllNotificationsRead);

        // Single mark read
        document.addEventListener('click', function(e) {
            const singleBtn = e.target.closest('.dior-mark-single-read');
            if (singleBtn) {
                const item = singleBtn.closest('.dior-full-notif-item');
                const notifId = item ? item.getAttribute('data-notif-id') : '';
                if (notifId) {
                    sendAjax('dior_patient_mark_notification_read', { notif_id: notifId }, () => {
                        if (item) item.classList.remove('unread');
                        singleBtn.remove();
                    });
                }
            }
        });

        // =========================================================================
        // 7. APPOINTMENTS CONTROLLER (Booking, Reschedule, Cancel, Filter)
        // =========================================================================
        
        // Book Appointment
        const bookForm = document.getElementById('dior-form-book-patient-appt');
        if (bookForm) {
            bookForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const submitBtn = document.getElementById('dior-submit-book-btn');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Processing Booking...';
                }

                const data = {
                    condition: this.condition.value,
                    type: this.type.value,
                    provider: this.provider.value,
                    date: this.date.value,
                    time: this.time.value,
                    notes: this.notes.value
                };

                sendAjax('dior_patient_book_appointment', data, () => {
                    diorCloseModal('modal-book-appointment');
                    setTimeout(() => window.location.reload(), 1200);
                }, () => {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = '<i class="fa-solid fa-lock"></i> Confirm & Book Consultation ($49.00)';
                    }
                });
            });
        }

        // Open Reschedule Modal
        window.diorOpenRescheduleModal = function(apptId) {
            const input = document.getElementById('resched_appt_id');
            if (input) input.value = apptId;
            diorOpenModal('modal-reschedule-appointment');
        };

        const reschedForm = document.getElementById('dior-form-reschedule-appt');
        if (reschedForm) {
            reschedForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const data = {
                    appt_id: this.appt_id.value,
                    date: this.date.value,
                    time: this.time.value
                };

                sendAjax('dior_patient_reschedule_appointment', data, () => {
                    diorCloseModal('modal-reschedule-appointment');
                    setTimeout(() => window.location.reload(), 1000);
                });
            });
        }

        // Open Cancel Modal
        window.diorOpenCancelModal = function(apptId) {
            const input = document.getElementById('cancel_appt_id');
            if (input) input.value = apptId;
            diorOpenModal('modal-cancel-appointment');
        };

        const cancelForm = document.getElementById('dior-form-cancel-appt');
        if (cancelForm) {
            cancelForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const data = {
                    appt_id: this.appt_id.value,
                    reason: this.reason.value
                };

                sendAjax('dior_patient_cancel_appointment', data, () => {
                    diorCloseModal('modal-cancel-appointment');
                    setTimeout(() => window.location.reload(), 1000);
                });
            });
        }

        // Appointments Table Filter
        const apptFilterTabs = document.querySelectorAll('.dior-filter-tab');
        const apptSearchInput = document.getElementById('dior-search-appointments-input');
        const apptRows = document.querySelectorAll('.dior-appt-row');

        function filterApptTable() {
            const activeTab = document.querySelector('.dior-filter-tab.active');
            const statusFilter = activeTab ? activeTab.getAttribute('data-filter-status') : 'all';
            const searchQuery = apptSearchInput ? apptSearchInput.value.toLowerCase().trim() : '';
            const apptTable = document.getElementById('dior-patient-appointments-table');

            apptRows.forEach(row => {
                const rowStatus = row.getAttribute('data-status');
                const rowText = row.textContent.toLowerCase();

                const matchesStatus = (statusFilter === 'all') || (rowStatus === statusFilter);
                const matchesSearch = !searchQuery || rowText.includes(searchQuery);

                if (matchesStatus && matchesSearch) {
                    row.setAttribute('data-filter-hidden', 'false');
                } else {
                    row.setAttribute('data-filter-hidden', 'true');
                }
            });

            if (apptTable && apptTable._diorRenderPage) {
                apptTable._diorRenderPage(1);
            }
        }

        apptFilterTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                apptFilterTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                filterApptTable();
            });
        });

        if (apptSearchInput) {
            apptSearchInput.addEventListener('input', filterApptTable);
        }

        // =========================================================================
        // REAL-TIME DYNAMIC APPOINTMENT COUNTDOWN CLOCK
        // =========================================================================
        let countdownTimerInterval = null;

        function parseAppointmentDate(dateStr, timeStr) {
            if (!dateStr) return null;
            dateStr = dateStr.trim();
            timeStr = (timeStr || '').trim();

            let targetDate = new Date(dateStr + (timeStr ? ' ' + timeStr : ''));
            if (!isNaN(targetDate.getTime())) {
                return targetDate.getTime();
            }

            let parsed = Date.parse(dateStr + ' ' + timeStr);
            if (!isNaN(parsed)) {
                return parsed;
            }

            let timeMatch = timeStr.match(/(\d+):(\d+)\s*(AM|PM)?/i);
            let dateMatch = dateStr.match(/(\d{4})-(\d{2})-(\d{2})/);
            if (dateMatch) {
                let year = parseInt(dateMatch[1], 10);
                let month = parseInt(dateMatch[2], 10) - 1;
                let day = parseInt(dateMatch[3], 10);
                let hours = 9;
                let mins = 0;
                if (timeMatch) {
                    hours = parseInt(timeMatch[1], 10);
                    mins = parseInt(timeMatch[2], 10);
                    let ampm = (timeMatch[3] || '').toUpperCase();
                    if (ampm === 'PM' && hours < 12) hours += 12;
                    if (ampm === 'AM' && hours === 12) hours = 0;
                }
                return new Date(year, month, day, hours, mins, 0).getTime();
            }

            return null;
        }

        function startLiveCountdown(targetTimestamp) {
            if (countdownTimerInterval) clearInterval(countdownTimerInterval);

            const countdownBox = document.getElementById('dior-live-hero-countdown');
            if (!countdownBox) return;

            const daysSlot = document.getElementById('dior-cd-days-slot');
            const daysColon = document.getElementById('dior-cd-days-colon');
            const daysEl = document.getElementById('dior-cd-days');
            const hrsEl = document.getElementById('dior-cd-hrs');
            const minEl = document.getElementById('dior-cd-min');
            const secEl = document.getElementById('dior-cd-sec');
            const statusText = document.getElementById('dior-cd-status-text');
            const joinBtn = document.querySelector('.hero-appt-actions .dior-btn-join-call');

            function updateTick() {
                const now = Date.now();
                const diffMs = targetTimestamp - now;

                if (diffMs > 0) {
                    const totalSecs = Math.floor(diffMs / 1000);
                    const days = Math.floor(totalSecs / 86400);
                    const hours = Math.floor((totalSecs % 86400) / 3600);
                    const minutes = Math.floor((totalSecs % 3600) / 60);
                    const seconds = totalSecs % 60;

                    if (daysEl) daysEl.textContent = String(days).padStart(2, '0');
                    if (hrsEl) hrsEl.textContent = String(hours).padStart(2, '0');
                    if (minEl) minEl.textContent = String(minutes).padStart(2, '0');
                    if (secEl) secEl.textContent = String(seconds).padStart(2, '0');

                    if (days > 0) {
                        if (daysSlot) daysSlot.style.display = 'flex';
                        if (daysColon) daysColon.style.display = 'inline';
                    } else {
                        if (daysSlot) daysSlot.style.display = 'none';
                        if (daysColon) daysColon.style.display = 'none';
                    }

                    if (diffMs <= 15 * 60 * 1000) {
                        if (statusText) statusText.innerHTML = '<span style="color:#059669; font-weight:700;"><i class="fa-solid fa-circle-dot fa-beat" style="color:#10B981;"></i> Consultation window is starting in:</span>';
                    } else {
                        if (statusText) statusText.textContent = 'Consultation window begins in:';
                    }
                } else if (diffMs <= 0 && diffMs >= -3600000) {
                    if (daysSlot) daysSlot.style.display = 'none';
                    if (daysColon) daysColon.style.display = 'none';
                    if (hrsEl) hrsEl.textContent = '00';
                    if (minEl) minEl.textContent = '00';
                    if (secEl) secEl.textContent = '00';
                    if (statusText) {
                        statusText.innerHTML = '<span style="color:#059669; font-weight:700; font-size:14px;"><i class="fa-solid fa-circle-play fa-beat" style="color:#10B981;"></i> CONSULTATION WINDOW IS LIVE NOW</span>';
                    }
                    if (joinBtn) {
                        joinBtn.style.animation = 'pulse 1.5s infinite';
                    }
                } else {
                    if (statusText) statusText.textContent = 'Scheduled Visit Completed';
                    if (daysSlot) daysSlot.style.display = 'none';
                    if (daysColon) daysColon.style.display = 'none';
                    if (hrsEl) hrsEl.textContent = '00';
                    if (minEl) minEl.textContent = '00';
                    if (secEl) secEl.textContent = '00';
                }
            }

            updateTick();
            countdownTimerInterval = setInterval(updateTick, 1000);
        }

        window.diorUpdateCountdown = function(dateStr, timeStr) {
            const countdownBox = document.getElementById('dior-live-hero-countdown');
            if (countdownBox) {
                countdownBox.setAttribute('data-appt-date', dateStr);
                countdownBox.setAttribute('data-appt-time', timeStr);
            }
            const ts = parseAppointmentDate(dateStr, timeStr);
            if (ts) {
                startLiveCountdown(ts);
            }
        };

        const initialCountdownEl = document.getElementById('dior-live-hero-countdown');
        if (initialCountdownEl) {
            const initDate = initialCountdownEl.getAttribute('data-appt-date');
            const initTime = initialCountdownEl.getAttribute('data-appt-time');
            const initTs = parseAppointmentDate(initDate, initTime);
            if (initTs) {
                startLiveCountdown(initTs);
            }
        }

        // =========================================================================
        // 8. PROFILE CONTROLLER
        // =========================================================================
        const profileForm = document.getElementById('dior-form-patient-profile');
        if (profileForm) {
            profileForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const btn = document.getElementById('dior-save-profile-btn');
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Saving...';
                }

                const formData = new FormData(this);
                const data = {};
                formData.forEach((val, key) => data[key] = val);

                sendAjax('dior_patient_save_profile', data, () => {
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Save Profile Changes';
                    }
                }, () => {
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Save Profile Changes';
                    }
                });
            });
        }

        // Real Password Change Handler
        const pwdForm = document.getElementById('dior-form-change-password');
        if (pwdForm) {
            pwdForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const cur = this.current_password.value;
                const np = this.new_password.value;
                const cp = this.confirm_password.value;

                if (!cur || !np) {
                    showToast('Please enter both current and new password.', true);
                    return;
                }
                if (np !== cp) {
                    showToast('New passwords do not match.', true);
                    return;
                }
                if (np.length < 6) {
                    showToast('New password must be at least 6 characters.', true);
                    return;
                }

                sendAjax('dior_patient_change_password', {
                    current_password: cur,
                    new_password: np,
                    confirm_password: cp
                }, () => {
                    pwdForm.reset();
                });
            });
        }

        // =========================================================================
        // 9. MEDICAL QUESTIONNAIRE & INTAKE MODAL (With E-Sign)
        // =========================================================================
        window.diorOpenQuestionnaireForm = function(qnId, condition, symptoms, allergies, meds) {
            const modal = document.getElementById('modal-questionnaire-intake');
            if (!modal) return;

            document.getElementById('modal-qn-title').innerHTML = '<i class="fa-solid fa-clipboard-question"></i> Intake: ' + condition;
            document.getElementById('qn_input_id').value = qnId;
            document.getElementById('qn_input_condition').value = condition;
            document.getElementById('qn_input_symptoms').value = symptoms || '';
            document.getElementById('qn_input_allergies').value = allergies || '';
            document.getElementById('qn_input_meds').value = meds || '';

            diorOpenModal('modal-questionnaire-intake');
        };

        // File dropzone click
        const dropzone = document.getElementById('dior-upload-dropzone');
        const fileInput = document.getElementById('qn_file_upload');
        const filePreview = document.getElementById('dior-upload-preview');

        if (dropzone && fileInput) {
            dropzone.addEventListener('click', () => fileInput.click());

            fileInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    if (filePreview) {
                        filePreview.style.display = 'block';
                        filePreview.innerHTML = '<i class="fa-solid fa-paperclip"></i> Selected file: ' + this.files[0].name;
                    }
                }
            });
        }

        // Submit Intake Form
        const intakeForm = document.getElementById('dior-form-submit-intake');
        if (intakeForm) {
            intakeForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const submitBtn = document.getElementById('dior-submit-intake-btn');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Submitting to Doctor...';
                }

                const data = {
                    qn_id: this.qn_id.value,
                    condition: this.condition.value,
                    symptoms: this.symptoms.value,
                    allergies: this.allergies.value,
                    current_meds: this.current_meds.value,
                    medical_history: this.medical_history.value,
                    esign_name: this.esign_name.value
                };

                sendAjax('dior_patient_submit_questionnaire', data, () => {
                    diorCloseModal('modal-questionnaire-intake');
                    setTimeout(() => window.location.reload(), 1200);
                }, () => {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Clinical Intake to Doctor &rarr;';
                    }
                });
            });
        }

        // =========================================================================
        // 10. PHARMACY PREFERENCE CONTROLLER
        // =========================================================================
        window.diorOnPharmacySelectChange = function(selectEl) {
            const val = selectEl.value;
            if (val === 'custom') {
                return;
            }
            const parts = val.split('|');
            if (parts.length >= 3) {
                document.getElementById('q_pharm_name').value = parts[0];
                document.getElementById('q_pharm_address').value = parts[1];
                document.getElementById('q_pharm_phone').value = parts[2];
            }
        };

        const quickPharmForm = document.getElementById('dior-form-quick-pharmacy');
        if (quickPharmForm) {
            quickPharmForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const data = {
                    pharmacy_name: this.pharmacy_name.value,
                    pharmacy_address: this.pharmacy_address.value,
                    pharmacy_phone: this.pharmacy_phone.value
                };

                sendAjax('dior_patient_update_pharmacy', data, () => {
                    diorCloseModal('modal-change-pharmacy');
                    setTimeout(() => window.location.reload(), 1000);
                });
            });
        }

        // =========================================================================
        // 11. RECEIPT, DOCUMENT & RX DETAIL VIEWERS
        // =========================================================================
        window.diorViewReceipt = function(id, amount, service, date) {
            document.getElementById('rec-inv-id').textContent = id;
            document.getElementById('rec-amount').textContent = amount;
            document.getElementById('rec-service').textContent = service;
            document.getElementById('rec-date').textContent = date;
            diorOpenModal('modal-view-receipt');
        };

        window.diorViewDocumentModal = function(title, category, author, date, id) {
            const titleEl = document.getElementById('doc-preview-title');
            const catEl = document.getElementById('doc-preview-category');
            const authorEl = document.getElementById('doc-preview-author');
            const dateEl = document.getElementById('doc-preview-date');
            const idEl = document.getElementById('doc-preview-id');
            if (titleEl) titleEl.textContent = title || 'Medical Record';
            if (catEl) catEl.textContent = category || 'Official Document';
            if (authorEl) authorEl.textContent = author || 'Dior Medical Urgent Care';
            if (dateEl) dateEl.textContent = date || '';
            if (idEl) idEl.textContent = id || 'DOC-88219';
            diorOpenModal('modal-view-document');
        };

        window.diorDownloadCurrentDocumentPdf = function() {
            var title = (document.getElementById('doc-preview-title') && document.getElementById('doc-preview-title').textContent) || 'Medical Record';
            var docId = (document.getElementById('doc-preview-id') && document.getElementById('doc-preview-id').textContent) || 'DOC-88219';
            var cat = (document.getElementById('doc-preview-category') && document.getElementById('doc-preview-category').textContent) || 'Official Document';
            var author = (document.getElementById('doc-preview-author') && document.getElementById('doc-preview-author').textContent) || 'Dior Medical Urgent Care';
            var date = (document.getElementById('doc-preview-date') && document.getElementById('doc-preview-date').textContent) || 'Sept 4, 2026';
            var patientName = (document.getElementById('doc-preview-patient') && document.getElementById('doc-preview-patient').textContent) || 'Verified Patient';

            var cleanFileName = 'Dior-' + title.replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';

            var printContent = '<div style="max-width:760px;margin:0 auto;padding:36px;font-family:Arial,Helvetica,sans-serif;color:#0F172A;background:#FFFFFF;border:2px solid #2C6CB1;border-radius:12px;">' +
                '<div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #2C6CB1;padding-bottom:18px;margin-bottom:24px;">' +
                    '<div>' +
                        '<h1 style="margin:0;font-size:22px;color:#0B1030;font-weight:800;letter-spacing:0.02em;">DIOR MEDICAL TELEHEALTH</h1>' +
                        '<p style="margin:4px 0 0 0;font-size:12px;color:#64748B;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">Official Certified Clinical Record &amp; Medical Certificate</p>' +
                    '</div>' +
                    '<div style="text-align:right;">' +
                        '<div style="display:inline-block;padding:5px 12px;background:#EFF6FF;color:#2C6CB1;border:1px solid #BFDBFE;border-radius:20px;font-size:11.5px;font-weight:700;">' +
                            '&#10003; HIPAA Certified' +
                        '</div>' +
                        '<p style="margin:6px 0 0 0;font-size:11px;color:#64748B;">Doc Ref: <strong>' + docId + '</strong></p>' +
                    '</div>' +
                '</div>' +

                '<div style="text-align:center;padding:16px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;margin-bottom:24px;">' +
                    '<span style="display:inline-block;padding:3px 12px;background:#EFF6FF;color:#2563EB;border-radius:12px;font-size:11.5px;font-weight:700;text-transform:uppercase;margin-bottom:8px;">' + cat + '</span>' +
                    '<h2 style="margin:0;font-size:19px;color:#0F172A;font-weight:800;">' + title + '</h2>' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;margin-bottom:24px;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:8px;">' +
                    '<tr style="background:#F1F5F9;border-bottom:1px solid #CBD5E1;">' +
                        '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;width:25%;">Patient Name:</td>' +
                        '<td style="padding:10px 14px;font-size:13px;color:#0F172A;font-weight:700;width:25%;">' + patientName + '</td>' +
                        '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;width:25%;">Date Issued:</td>' +
                        '<td style="padding:10px 14px;font-size:13px;color:#0F172A;font-weight:700;width:25%;">' + date + '</td>' +
                    '</tr>' +
                    '<tr>' +
                        '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;">Issuing Authority:</td>' +
                        '<td style="padding:10px 14px;font-size:13px;color:#0F172A;font-weight:600;">' + author + '</td>' +
                        '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;">Document Status:</td>' +
                        '<td style="padding:10px 14px;font-size:13px;color:#059669;font-weight:700;">Verified &amp; Active</td>' +
                    '</tr>' +
                '</table>' +

                '<div style="padding:18px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;font-size:13px;line-height:1.6;color:#334155;margin-bottom:24px;">' +
                    '<p style="margin:0 0 10px 0;"><strong>Official Record Statement:</strong></p>' +
                    '<p style="margin:0;">This certified document confirms that the individual designated above has satisfactorily completed all medical intake verifications, clinical evaluations, and electronic consent protocols via the Dior Medical Telehealth system. All records are maintained in strict accordance with 45 CFR Parts 160 and 164 (HIPAA Security &amp; Privacy Rules) and DEA Title 21 telemedicine provisions.</p>' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;border-top:2px solid #E2E8F0;padding-top:16px;margin-top:16px;">' +
                    '<tr>' +
                        '<td style="width:60%;vertical-align:bottom;font-size:11px;color:#64748B;line-height:1.5;">' +
                            '<strong style="color:#059669;">&#10003; Cryptographically Certified Electronic Record</strong><br>' +
                            'Security Hash: SHA-256 Verified &bull; Federal ESIGN &amp; UETA Act Compliant' +
                        '</td>' +
                        '<td style="width:40%;vertical-align:bottom;text-align:right;">' +
                            '<div style="font-family:\'Courier New\',Courier,monospace;font-size:15px;color:#0F172A;font-weight:700;border-bottom:1px solid #0F172A;display:inline-block;padding-bottom:2px;margin-bottom:4px;">' +
                                '/s/ Dior Medical Clinical Directorate' +
                            '</div>' +
                            '<div style="font-size:11px;color:#64748B;font-weight:600;">' +
                                'Authorized Telehealth Certification' +
                            '</div>' +
                        '</td>' +
                    '</tr>' +
                '</table>' +
            '</div>';

            var tempContainer = document.createElement('div');
            tempContainer.style.position = 'fixed';
            tempContainer.style.left = '-9999px';
            tempContainer.style.top = '0';
            tempContainer.style.width = '800px';
            tempContainer.innerHTML = printContent;
            document.body.appendChild(tempContainer);

            if (typeof html2pdf !== 'undefined') {
                var opt = {
                    margin:       [10, 10, 10, 10],
                    filename:     cleanFileName,
                    image:        { type: 'jpeg', quality: 0.98 },
                    html2canvas:  { scale: 2, useCORS: true, logging: false },
                    jsPDF:        { unit: 'mm', format: 'letter', orientation: 'portrait' }
                };
                html2pdf().set(opt).from(tempContainer.firstElementChild).save().then(function() {
                    document.body.removeChild(tempContainer);
                }).catch(function(err) {
                    console.error('PDF export error:', err);
                    document.body.removeChild(tempContainer);
                    fallbackPrintDoc(printContent, title);
                });
            } else {
                document.body.removeChild(tempContainer);
                fallbackPrintDoc(printContent, title);
            }
        };

        function fallbackPrintDoc(htmlContent, title) {
            var printWindow = window.open('', '_blank');
            if (printWindow) {
                printWindow.document.write('<html><head><title>' + title + '</title><style>@page{size:auto;margin:15mm;} body{margin:0;padding:20px;font-family:Arial,sans-serif;}</style></head><body>' + htmlContent + '</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(function() { printWindow.print(); }, 250);
            } else {
                window.print();
            }
        }

        window.diorDownloadReceiptPdf = function() {
            var invId = (document.getElementById('rec-inv-id') && document.getElementById('rec-inv-id').textContent) || 'INV-8829';
            var date = (document.getElementById('rec-date') && document.getElementById('rec-date').textContent) || 'Sept 4, 2026';
            var patientInfo = (document.getElementById('rec-patient-info') && document.getElementById('rec-patient-info').textContent) || 'Patient';
            var service = (document.getElementById('rec-service') && document.getElementById('rec-service').textContent) || 'Urgent Care Telehealth Consultation';
            var amount = (document.getElementById('rec-amount') && document.getElementById('rec-amount').textContent) || '$49.00';
            var logoImg = document.querySelector('.receipt-logo img');
            var logoUrl = logoImg ? logoImg.src : '';

            var cleanFileName = 'Dior-Receipt-' + invId.replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';

            var printContent = '<div style="max-width:720px;margin:0 auto;padding:36px;font-family:Arial,Helvetica,sans-serif;color:#0F172A;background:#FFFFFF;border:2px solid #2C6CB1;border-radius:12px;">' +
                '<div style="text-align:center;margin-bottom:20px;border-bottom:3px solid #2C6CB1;padding-bottom:18px;">' +
                    (logoUrl ? '<img src="' + logoUrl + '" alt="Dior Medical" style="height:70px;max-height:75px;object-fit:contain;margin-bottom:8px;">' : '') +
                    '<h1 style="margin:0;font-size:22px;color:#0B1030;font-weight:800;letter-spacing:0.02em;">DIOR MEDICAL TELEHEALTH</h1>' +
                    '<p style="margin:4px 0 0 0;font-size:12px;color:#64748B;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">Official Medical Statement &amp; Itemized Receipt</p>' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;margin-bottom:24px;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:8px;">' +
                    '<tr style="background:#F1F5F9;border-bottom:1px solid #CBD5E1;">' +
                        '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;width:35%;">Invoice #:</td>' +
                        '<td style="padding:12px 16px;font-size:14px;color:#0F172A;font-weight:800;">' + invId + '</td>' +
                    '</tr>' +
                    '<tr style="border-bottom:1px solid #E2E8F0;">' +
                        '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Date of Transaction:</td>' +
                        '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">' + date + '</td>' +
                    '</tr>' +
                    '<tr style="border-bottom:1px solid #E2E8F0;">' +
                        '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Patient Name &amp; ID:</td>' +
                        '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">' + patientInfo + '</td>' +
                    '</tr>' +
                    '<tr style="border-bottom:1px solid #E2E8F0;">' +
                        '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Service Description:</td>' +
                        '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">' + service + '</td>' +
                    '</tr>' +
                    '<tr style="border-bottom:1px solid #E2E8F0;">' +
                        '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Payment Method:</td>' +
                        '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">Stripe (Credit Card / Apple Pay) &bull; Verified &bull; Paid in Full</td>' +
                    '</tr>' +
                    '<tr style="background:#EFF6FF;">' +
                        '<td style="padding:14px 16px;font-weight:800;font-size:14px;color:#1E40AF;">Total Paid:</td>' +
                        '<td style="padding:14px 16px;font-size:17px;color:#1E40AF;font-weight:800;">' + amount + '</td>' +
                    '</tr>' +
                '</table>' +

                '<div style="padding:14px 18px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;font-size:12px;color:#64748B;text-align:center;line-height:1.5;margin-bottom:24px;">' +
                    '<strong>Tax Compliance &amp; Insurance Reimbursement Notice:</strong><br>' +
                    'Dior Medical Telehealth &amp; Urgent Care &bull; Tax ID / NPI Verified &bull; Eligible for HSA / FSA Flexible Spending Account Reimbursement' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;border-top:2px solid #E2E8F0;padding-top:16px;">' +
                    '<tr>' +
                        '<td style="width:60%;vertical-align:bottom;font-size:11px;color:#64748B;line-height:1.5;">' +
                            '<strong style="color:#059669;">&#10003; Official Electronic Payment Receipt</strong><br>' +
                            'Transaction ID: ' + invId + ' &bull; Status: Completed' +
                        '</td>' +
                        '<td style="width:40%;vertical-align:bottom;text-align:right;">' +
                            '<div style="font-family:\'Courier New\',Courier,monospace;font-size:14px;color:#0F172A;font-weight:700;border-bottom:1px solid #0F172A;display:inline-block;padding-bottom:2px;margin-bottom:4px;">' +
                                'Dior Billing Directorate' +
                            '</div>' +
                            '<div style="font-size:11px;color:#64748B;font-weight:600;">Authorized Financial Officer</div>' +
                        '</td>' +
                    '</tr>' +
                '</table>' +
            '</div>';

            var tempContainer = document.createElement('div');
            tempContainer.style.position = 'fixed';
            tempContainer.style.left = '-9999px';
            tempContainer.style.top = '0';
            tempContainer.style.width = '750px';
            tempContainer.innerHTML = printContent;
            document.body.appendChild(tempContainer);

            if (typeof html2pdf !== 'undefined') {
                var opt = {
                    margin:       [10, 10, 10, 10],
                    filename:     cleanFileName,
                    image:        { type: 'jpeg', quality: 0.98 },
                    html2canvas:  { scale: 2, useCORS: true, logging: false },
                    jsPDF:        { unit: 'mm', format: 'letter', orientation: 'portrait' }
                };
                html2pdf().set(opt).from(tempContainer.firstElementChild).save().then(function() {
                    document.body.removeChild(tempContainer);
                }).catch(function(err) {
                    console.error('PDF receipt export error:', err);
                    document.body.removeChild(tempContainer);
                    fallbackPrintDoc(printContent, invId);
                });
            } else {
                document.body.removeChild(tempContainer);
                fallbackPrintDoc(printContent, invId);
            }
        };

        window.diorPrintReceiptModal = function() {
            window.diorDownloadReceiptPdf();
        };

        window.diorViewRxDetails = function(rxId, fallbackMed, fallbackInst) {
            if (typeof window.diorOpenModal === 'function') {
                var rxs = window.dior_patient_rxs_data || [];
                var found = null;
                if (rxs && rxs.length) {
                    for (var i = 0; i < rxs.length; i++) {
                        if (String(rxs[i].id).trim().toLowerCase() === String(rxId).trim().toLowerCase()) {
                            found = rxs[i];
                            break;
                        }
                    }
                }

                var idEl = document.getElementById('pat-modal-rx-id');
                var nameEl = document.getElementById('pat-modal-rx-name');
                var docEl = document.getElementById('pat-modal-rx-doc');
                var dateEl = document.getElementById('pat-modal-rx-date');
                var doseEl = document.getElementById('pat-modal-rx-dosage');
                var qtyEl = document.getElementById('pat-modal-rx-qty');
                var refillsEl = document.getElementById('pat-modal-rx-refills');
                var routingEl = document.getElementById('pat-modal-rx-routing');
                var statusBadge = document.getElementById('pat-modal-rx-status-badge');
                var instEl = document.getElementById('pat-modal-rx-instructions');
                var pharmNameEl = document.getElementById('pat-modal-rx-pharm-name');
                var pdfBtn = document.getElementById('pat-modal-rx-pdf-btn');
                var refillBtn = document.getElementById('pat-modal-rx-refill-btn');

                var actualId = found ? (found.id || rxId) : rxId;
                var actualName = found ? (found.medication || found.name || fallbackMed || 'Prescription') : (fallbackMed || 'Prescription');
                var actualDoc = found ? (found.prescribed_by || 'Attending Physician') : 'Attending Physician';
                var actualDate = found ? (found.date_prescribed || found.date || '—') : '—';
                var actualDose = found ? (found.dosage || found.dose || 'As directed by physician') : 'As directed by physician';
                var actualQty = found ? (found.quantity || 'As Prescribed') : 'As Prescribed';
                var actualRefills = found ? (found.refills || '0 Refills Remaining') : '0 Refills Remaining';
                var actualRouting = found ? (found.routing_status || 'Sent to Pharmacy') : 'Sent to Pharmacy';
                var actualInst = found ? (found.instructions || found.notes || fallbackInst || 'Take as directed by prescribing physician.') : (fallbackInst || 'Take as directed by prescribing physician.');
                var actualPharm = found ? (found.pharmacy || 'Preferred Pharmacy on File') : 'Preferred Pharmacy on File';

                if (idEl) idEl.textContent = 'Rx #' + actualId;
                if (nameEl) nameEl.textContent = actualName;
                if (docEl) docEl.textContent = actualDoc;
                if (dateEl) dateEl.textContent = actualDate;
                if (doseEl) doseEl.textContent = actualDose;
                if (qtyEl) qtyEl.textContent = actualQty;
                if (refillsEl) refillsEl.textContent = actualRefills;
                if (routingEl) routingEl.innerHTML = '<i class="fa-solid fa-circle-check" style="color:#059669;"></i> ' + actualRouting;
                if (statusBadge) statusBadge.textContent = actualRouting;
                if (instEl) instEl.textContent = actualInst;
                if (pharmNameEl) pharmNameEl.textContent = actualPharm;

                if (pdfBtn) {
                    pdfBtn.onclick = function() { window.diorDownloadRxPdf(actualId); };
                }
                if (refillBtn) {
                    refillBtn.onclick = function() { window.diorRequestRefill(actualId); };
                }

                window.diorOpenModal('modal-view-rx-detail');
            } else {
                alert('Prescription #' + rxId);
            }
        };

        window.diorRequestRefill = function(rxId) {
            if (typeof showToast === 'function') {
                showToast('Refill request submitted electronically to prescribing physician for Rx #' + rxId, false);
            } else {
                alert('Refill request submitted electronically to prescribing physician for Rx #' + rxId);
            }
        };

        window.diorViewAppointmentDetails = function(apptId) {
            if (typeof window.diorOpenModal === 'function') {
                var appts = window.dior_patient_appts_data || [];
                var found = null;
                for (var i = 0; i < appts.length; i++) {
                    if (String(appts[i].id) === String(apptId) || String(appts[i].appt_uid) === String(apptId)) {
                        found = appts[i];
                        break;
                    }
                }

                var idEl = document.getElementById('pat-modal-appt-id');
                var provEl = document.getElementById('pat-modal-appt-provider');
                var specEl = document.getElementById('pat-modal-appt-spec');
                var statusBadge = document.getElementById('pat-modal-appt-status-badge');
                var dtEl = document.getElementById('pat-modal-appt-datetime');
                var modeEl = document.getElementById('pat-modal-appt-mode');
                var condEl = document.getElementById('pat-modal-appt-condition');
                var notesEl = document.getElementById('pat-modal-appt-notes');
                var zoomWrap = document.getElementById('pat-modal-zoom-wrap');
                var zoomLink = document.getElementById('pat-modal-zoom-link');

                if (found) {
                    if (idEl) idEl.textContent = 'APPT #' + (found.id || found.appt_uid || apptId);
                    if (provEl) provEl.textContent = found.provider || found.doctor_name || 'Attending Physician';
                    if (specEl) specEl.textContent = found.provider_spec || found.provider_title || 'Telehealth Urgent Care';
                    if (statusBadge) {
                        var st = found.status || found.appt_status || 'Confirmed';
                        statusBadge.textContent = st;
                        statusBadge.className = 'dior-st ' + (st === 'Confirmed' || st === 'Completed' ? 'ok' : (st === 'Cancelled' ? 'error' : 'pending'));
                    }
                    if (dtEl) dtEl.textContent = (found.date || found.appt_date || '') + ' ' + (found.time || found.appt_time || '');
                    if (modeEl) modeEl.innerHTML = '<i class="fa-solid fa-video" style="color:#2C6CB1;"></i> ' + (found.type || found.visit_type || 'Video Visit');
                    if (condEl) condEl.textContent = found.condition || found.condition_name || 'Telehealth Consultation';
                    if (notesEl) notesEl.textContent = found.notes || 'Standard telehealth clinical consultation scheduled. All submitted medical intake questionnaires are pre-verified.';
                    
                    var joinUrl = found.join_url || 'https://zoom.us/join';
                    var isLive = (found.status === 'Confirmed' || found.status === 'Scheduled' || found.status === 'In-Queue');
                    if (zoomWrap) {
                        zoomWrap.style.display = isLive ? 'flex' : 'none';
                        if (zoomLink) zoomLink.href = joinUrl;
                    }
                } else if (idEl) {
                    idEl.textContent = 'APPT #' + apptId;
                }

                window.diorOpenModal('modal-view-appointment-detail');
            } else {
                showToast('Viewing appointment details for #' + apptId);
            }
        };
    });

})(jQuery);

window.diorDownloadRxPdf = function(rxId) {
    var element = document.getElementById('rx-pdf-template-' + rxId);
    if (!element) {
        var allTemplates = document.querySelectorAll('[id^="rx-pdf-template-"]');
        if (allTemplates && allTemplates.length > 0) {
            for (var k = 0; k < allTemplates.length; k++) {
                if (allTemplates[k].id.indexOf(rxId) !== -1) {
                    element = allTemplates[k];
                    break;
                }
            }
        }
    }
    if (!element) { alert('Prescription details not found for Rx #' + rxId); return; }
    
    var cleanFileName = 'Dior-Prescription-' + String(rxId).replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';
    var innerContent = element.innerHTML;

    var tempContainer = document.createElement('div');
    tempContainer.style.position = 'fixed';
    tempContainer.style.left = '-9999px';
    tempContainer.style.top = '0';
    tempContainer.style.width = '800px';
    tempContainer.style.background = '#FFFFFF';
    tempContainer.style.zIndex = '99999';
    tempContainer.innerHTML = innerContent;
    document.body.appendChild(tempContainer);

    if (typeof html2pdf !== 'undefined') {
        var opt = {
            margin:       [8, 8, 8, 8],
            filename:     cleanFileName,
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2, useCORS: true, logging: false },
            jsPDF:        { unit: 'mm', format: 'letter', orientation: 'portrait' }
        };
        html2pdf().set(opt).from(tempContainer).save().then(function() {
            if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
        }).catch(function(err) {
            console.error('PDF export error:', err);
            if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
            if (typeof fallbackPrintWindow === 'function') {
                fallbackPrintWindow(innerContent, 'Prescription #' + rxId);
            } else {
                window.print();
            }
        });
    } else {
        if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
        if (typeof fallbackPrintWindow === 'function') {
            fallbackPrintWindow(innerContent, 'Prescription #' + rxId);
        } else {
            var printWindow = window.open('', '_blank');
            if (printWindow) {
                printWindow.document.write('<html><head><title>Prescription #' + rxId + '</title></head><body style="margin:20px;background:#fff;font-family:Arial,sans-serif;">' + innerContent + '</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(function() { printWindow.print(); }, 250);
            } else {
                window.print();
            }
        }
    }
};

