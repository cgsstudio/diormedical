<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

$uid = 6;
wp_set_current_user($uid);

$nonce = wp_create_nonce("dior_doctor_nonce");
$_POST['nonce'] = $nonce;

echo "Before mark all read:\n";
$ns = get_user_meta($uid, 'dior_doctor_notifications', true);
foreach ($ns as $n) {
    echo "- " . $n['id'] . " | is_read: " . ($n['is_read'] ? 'TRUE' : 'FALSE') . "\n";
}

// Call method
ob_start();
Dior_Doctor_Dashboard::ajax_mark_all_notif_read();
$out = ob_get_clean();
echo "Result: $out\n";

echo "After mark all read:\n";
$ns = get_user_meta($uid, 'dior_doctor_notifications', true);
foreach ($ns as $n) {
    echo "- " . $n['id'] . " | is_read: " . ($n['is_read'] ? 'TRUE' : 'FALSE') . "\n";
}
