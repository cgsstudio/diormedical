<?php
require_once __DIR__ . '/../../../../wp-load.php';

$pid = 2; // test two user id
$user = get_userdata($pid);
if (!$user) {
    echo "User $pid not found\n";
    exit;
}

$doctor   = ['name' => 'Dr. Marcus Sterling, DO', 'specialty' => 'Internal Medicine', 'license' => 'ME-984210', 'dea' => 'BS9842110'];
$profile  = Dior_Patient_Portal_Data::get_patient_profile($pid);
$intake   = get_user_meta($pid, "dior_hipaa_intake", true);
$apts     = Dior_Appointment_Service::get_patient_appointments($pid);
$rxs      = get_user_meta($pid, "dior_prescriptions", true) ?: [];
$notes    = Dior_Encounter_Service::get_patient_encounters($pid);
$docs     = Dior_Medical_Secure_Files::get_patient_documents($pid);

ob_start();
include __DIR__ . '/../templates/patient-detail-modal.php';
$html = ob_get_clean();

echo "Render SUCCESS!\n";
echo "HTML Length: " . strlen($html) . " bytes\n";
echo "Has clean wrapper: " . (strpos($html, 'dior-clean-patient-modal') !== false ? 'YES' : 'NO') . "\n";
echo "Has clean tabs: " . (strpos($html, 'dior-clean-tab-btn') !== false ? 'YES' : 'NO') . "\n";
echo "Has clean cards: " . (strpos($html, 'dior-clean-card') !== false ? 'YES' : 'NO') . "\n";
