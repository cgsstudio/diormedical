<?php

function parse_pdf_text($filename) {
    $content = file_get_contents($filename);
    if (!$content) return "Cannot read $filename";

    // 1. Extract CMaps
    preg_match_all('/\/CIDInit.*?begincmap(.*?)endcmap/s', $content, $cmap_matches);
    $cmaps = [];
    foreach ($cmap_matches[1] as $idx => $cmap_text) {
        $map = [];
        // parse beginbfchar
        if (preg_match_all('/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>/', $cmap_text, $bfchar)) {
            for ($i = 0; $i < count($bfchar[1]); $i++) {
                $src = hexdec($bfchar[1][$i]);
                $dst = hexdec($bfchar[2][$i]);
                $map[$src] = mb_chr($dst, 'UTF-8');
            }
        }
        // parse beginbfrange
        if (preg_match_all('/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>/', $cmap_text, $bfrange)) {
            for ($i = 0; $i < count($bfrange[1]); $i++) {
                $src_start = hexdec($bfrange[1][$i]);
                $src_end = hexdec($bfrange[2][$i]);
                $dst_start = hexdec($bfrange[3][$i]);
                for ($s = $src_start; $s <= $src_end; $s++) {
                    $offset = $s - $src_start;
                    $map[$s] = mb_chr($dst_start + $offset, 'UTF-8');
                }
            }
        }
        $cmaps[] = $map;
    }

    // 2. Extract content streams
    preg_match_all('/stream[\r\n]+(.*?)[\r\n]+endstream/s', $content, $stream_matches);
    $full_text = '';

    foreach ($stream_matches[1] as $raw_stream) {
        $stream = @gzuncompress($raw_stream);
        if (!$stream) continue;

        // Check if stream contains text operators BT ... ET
        if (strpos($stream, 'BT') === false) continue;

        // Match font selections /F... and text operations
        preg_match_all('/(\/F\d+)\s+[\d\.]+\s+Tf|(\/TT\d+)\s+[\d\.]+\s+Tf|<([0-9a-fA-F]+)>\s*Tj|\[(.*?)\]\s*TJ/s', $stream, $ops, PREG_SET_ORDER);

        $current_cmap = !empty($cmaps[0]) ? $cmaps[0] : [];
        $stream_text = '';

        foreach ($ops as $op) {
            if (!empty($op[1]) || !empty($op[2])) {
                $fnum = (int)preg_replace('/\D/', '', $op[1] ?: $op[2]);
                if (isset($cmaps[$fnum - 1])) {
                    $current_cmap = $cmaps[$fnum - 1];
                }
            } elseif (!empty($op[3])) { // <hex> Tj
                $hex = $op[3];
                $len = strlen($hex);
                for ($k = 0; $k < $len; $k += 4) {
                    $cid = hexdec(substr($hex, $k, 4));
                    $stream_text .= isset($current_cmap[$cid]) ? $current_cmap[$cid] : '?';
                }
            } elseif (!empty($op[4])) { // [...] TJ
                preg_match_all('/<([0-9a-fA-F]+)>|(-?\d+)/', $op[4], $parts, PREG_SET_ORDER);
                foreach ($parts as $p) {
                    if (!empty($p[1])) {
                        $hex = $p[1];
                        $len = strlen($hex);
                        for ($k = 0; $k < $len; $k += 4) {
                            $cid = hexdec(substr($hex, $k, 4));
                            $stream_text .= isset($current_cmap[$cid]) ? $current_cmap[$cid] : '?';
                        }
                    } elseif (isset($p[2]) && (int)$p[2] < -100) {
                        $stream_text .= ' ';
                    }
                }
                $stream_text .= "\n";
            }
        }
        if (trim($stream_text)) {
            $full_text .= $stream_text . "\n---\n";
        }
    }

    return $full_text;
}

$pdf1 = 'C:/Users/Admin/Downloads/New Dior Medical MultiStep Intake Form_260909114906.pdf';
$pdf2 = 'C:/Users/Admin/Downloads/New Dior Medical MultiStep Intake Form_260908184801.pdf';

echo "====== PDF 1 ======\n";
echo parse_pdf_text($pdf1);

echo "\n\n====== PDF 2 ======\n";
echo parse_pdf_text($pdf2);
