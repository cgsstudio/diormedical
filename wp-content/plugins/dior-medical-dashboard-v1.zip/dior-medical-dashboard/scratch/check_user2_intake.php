<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

// 1. Check user meta for Test one (user 2)
$u2_intake = get_user_meta(2, 'dior_hipaa_intake', true);
echo "User 2 dior_hipaa_intake:\n";
print_r($u2_intake);

echo "\nUser 2 all usermeta keys:\n";
$all_meta = get_user_meta(2);
foreach ($all_meta as $k => $v) {
    if (strpos($k, 'dior') !== false || in_array($k, ['first_name', 'last_name', 'dob', 'gender', 'sex', 'phone', 'address', 'city', 'state', 'zip'])) {
        echo "$k => " . print_r(maybe_unserialize($v[0]), true) . "\n";
    }
}
