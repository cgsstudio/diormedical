<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

echo "=== WPDDB DOCTOR POSTS ===\n";
$docs = get_posts(['post_type' => 'wpddb_doctor', 'posts_per_page' => -1, 'post_status' => 'any']);
foreach ($docs as $d) {
    $linked_uid = get_post_meta($d->ID, '_wpddb_doctor_user_id', true);
    $email = get_post_meta($d->ID, '_wpddb_doctor_email', true);
    echo "Post ID: " . $d->ID . " | Title: " . $d->post_title . " | Linked WP User ID: " . ($linked_uid ?: 'NONE') . " | Email: " . ($email ?: 'NONE') . "\n";
}

echo "\n=== DOCTOR ROLE USERS ===\n";
$users = get_users(['role__in' => ['doctor', 'administrator']]);
foreach ($users as $u) {
    echo "User ID: " . $u->ID . " | Username: " . $u->user_login . " | Email: " . $u->user_email . " | Display: " . $u->display_name . " | Roles: " . implode(',', $u->roles) . "\n";
}

echo "\n=== LATEST APPOINTMENT IN DB ===\n";
global $wpdb;
$table = $wpdb->prefix . 'dior_appointments';
$apts = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT 5", ARRAY_A);
foreach ($apts as $a) {
    echo "UID: " . $a['appt_uid'] . " | Doctor ID in DB: " . $a['doctor_id'] . " | Doctor Name: " . $a['doctor_name'] . " | Patient ID: " . $a['patient_id'] . "\n";
}
