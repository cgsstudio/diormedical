<?php
$pdf1 = 'C:/Users/Admin/Downloads/New Dior Medical MultiStep Intake Form_260909114906.pdf';
$pdf2 = 'C:/Users/Admin/Downloads/New Dior Medical MultiStep Intake Form_260908184801.pdf';

function extract_strings_from_pdf($file) {
    if (!file_exists($file)) return "File not found: $file\n";
    $content = file_get_contents($file);
    // Uncompress flate streams
    preg_match_all('/stream[\r\n]+(.*?)[\r\n]+endstream/s', $content, $matches);
    $text = '';
    foreach ($matches[1] as $stream) {
        $uncompressed = @gzuncompress($stream);
        if ($uncompressed) {
            // Extract text in parentheses (text) Tj or [(t)(e)(x)(t)] TJ
            preg_match_all('/\((.*?)\)\s*Tj/s', $uncompressed, $tmatches);
            if (!empty($tmatches[1])) {
                $text .= implode(" ", $tmatches[1]) . "\n";
            }
            preg_match_all('/\[(.*?)\]\s*TJ/s', $uncompressed, $tjmatches);
            foreach ($tjmatches[1] as $tjm) {
                preg_match_all('/\((.*?)\)/s', $tjm, $inner);
                if (!empty($inner[1])) {
                    $text .= implode("", $inner[1]) . "\n";
                }
            }
        }
    }
    return $text ?: "No stream text found in $file";
}

echo "=== PDF 1 ===\n";
echo extract_strings_from_pdf($pdf1) . "\n\n";

echo "=== PDF 2 ===\n";
echo extract_strings_from_pdf($pdf2) . "\n\n";
