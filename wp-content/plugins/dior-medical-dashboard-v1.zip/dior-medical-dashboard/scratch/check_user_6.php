<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

$u = get_userdata(6);
echo "User 6 user_login: " . ($u ? $u->user_login : 'null') . "\n";
echo "Is admin: " . (Dior_Auth_Service::is_admin(6) ? 'YES' : 'NO') . "\n";
echo "Default doc id: " . Dior_Doctor_Resolver::get_default_doctor_id() . "\n";
