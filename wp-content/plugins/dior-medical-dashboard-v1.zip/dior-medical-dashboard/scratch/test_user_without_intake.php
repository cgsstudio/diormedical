<?php
require_once 'c:/xampp/htdocs/diormedical/wp-load.php';
require_once 'c:/xampp/htdocs/diormedical/wp-content/plugins/dior-medical-dashboard/dior-medical-dashboard.php';

// Temporarily test user without intake
wp_set_current_user(4);
ob_start();
echo do_shortcode('[dior_patient_dashboard]');
$out = ob_get_clean();

echo "Dashboard rendered for User 4.\n";
echo "Has manual trigger bar button: " . (strpos($out, 'I Have Submitted My Form') !== false ? "YES (FAIL)" : "NO (REMOVED)") . "\n";
echo "Has HIPAAtizer iframe container: " . (strpos($out, 'id="dior-hipaa-form-container"') !== false ? "YES" : "NO") . "\n";
echo "Has appointment booking section: " . (strpos($out, 'id="dior-dashboard-booking-section"') !== false ? "YES" : "NO") . "\n";
