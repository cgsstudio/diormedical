<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

wp_set_current_user(2); // Patient 2 logged in

echo "1. Book appointment for logged in patient 2:\n";
$book_res = Dior_Appointment_Service::book_appointment([
    'patient_id' => 2,
    'doctor_id' => 1692,
    'doctor_name' => 'Dr. Evelyn Vance, MD',
    'condition' => 'Telehealth Medical Consultation',
    'visit_type' => 'Video Visit (HD)',
    'appt_date' => '2026-09-15',
    'appt_time' => '11:00 AM - 12:00 PM',
    'notes' => 'Patient scheduled after HIPAA intake',
    'status' => 'Confirmed'
]);

if (is_wp_error($book_res)) {
    echo "Booking Error: " . $book_res->get_error_message() . "\n";
} else {
    echo "Booking Success! UID: " . $book_res['appt_uid'] . "\n";
}

echo "2. Doctor 6 retrieves appointments:\n";
$apts = Dior_Appointment_Service::get_doctor_appointments(6);
echo "Doctor 6 appointments count: " . count($apts) . "\n";
foreach ($apts as $a) {
    echo "- " . $a['id'] . " | " . $a['patient_name'] . " | " . $a['date'] . " " . $a['time'] . " | " . $a['doctor_name'] . " | Status: " . $a['status'] . "\n";
}

// Reset back to completely clean state for the user
$table = $GLOBALS['wpdb']->prefix . 'dior_appointments';
$GLOBALS['wpdb']->query("TRUNCATE TABLE $table");
$GLOBALS['wpdb']->query("DELETE FROM {$GLOBALS['wpdb']->usermeta} WHERE meta_key = 'dior_appointments'");
$GLOBALS['wpdb']->query("DELETE FROM {$GLOBALS['wpdb']->usermeta} WHERE meta_key = 'dior_doctor_notifications'");
$GLOBALS['wpdb']->query("DELETE FROM {$GLOBALS['wpdb']->usermeta} WHERE meta_key = 'dior_notifications'");

echo "\nDatabase reset to 0 entries. Ready for live user testing!\n";
