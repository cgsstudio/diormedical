<?php
$pdf_path = 'C:/Users/Admin/Downloads/New Dior Medical MultiStep Intake Form_260909114906.pdf';
$content = file_get_contents($pdf_path);

// Let's use Python to extract text via pypdf / pdfplumber or fitz or basic pdfminer if installed, or parse PDF obj
$py_script = <<<PYTHON
import sys

def parse_pdf(fname):
    try:
        import pypdf
        reader = pypdf.PdfReader(fname)
        for i, page in enumerate(reader.pages):
            print(f"--- PAGE {i+1} ---")
            print(page.extract_text())
        return
    except Exception as e:
        pass

    try:
        import fitz
        doc = fitz.open(fname)
        for i, page in enumerate(doc):
            print(f"--- PAGE {i+1} ---")
            print(page.get_text())
        return
    except Exception as e:
        pass

    try:
        from pdfminer.high_level import extract_text
        print(extract_text(fname))
        return
    except Exception as e:
        pass

    print("No standard pdf library found")

parse_pdf(r"$pdf_path")
PYTHON;

file_put_contents(__DIR__ . '/read_pdf.py', $py_script);
echo "Wrote read_pdf.py\n";
