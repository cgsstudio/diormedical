<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

// Test 1: Doctor Marcus Sterling (User 8)
$u8 = get_userdata(8);
$redir8 = Dior_Medical_Auth::custom_login_redirect('', '', $u8);
echo "1. Dr. Marcus Sterling (User 8) redirect: $redir8\n";

// Test 2: Doctor James Chen (User 6)
$u6 = get_userdata(6);
$redir6 = Dior_Medical_Auth::custom_login_redirect('', '', $u6);
echo "2. Dr. James Chen (User 6) redirect: $redir6\n";

// Test 3: Doctor User 4
$u4 = get_userdata(4);
$redir4 = Dior_Medical_Auth::custom_login_redirect('', '', $u4);
echo "3. Doctor User 4 redirect: $redir4\n";

// Test 4: Patient User 2
$u2 = get_userdata(2);
$redir2 = Dior_Medical_Auth::custom_login_redirect('', '', $u2);
echo "4. Patient User 2 redirect: $redir2\n";
