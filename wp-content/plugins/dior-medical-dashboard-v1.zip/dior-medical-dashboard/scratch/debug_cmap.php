<?php
$content = file_get_contents('C:/Users/Admin/Downloads/New Dior Medical MultiStep Intake Form_260909114906.pdf');

preg_match_all('/\/CIDInit.*?begincmap(.*?)endcmap/s', $content, $cmap_matches);
echo "CMaps count: " . count($cmap_matches[1]) . "\n";
foreach ($cmap_matches[1] as $idx => $cm) {
    echo "--- CMap $idx ---\n";
    echo substr($cm, 0, 300) . "\n";
}

// Find first BT...ET
preg_match_all('/stream[\r\n]+(.*?)[\r\n]+endstream/s', $content, $stream_matches);
foreach ($stream_matches[1] as $idx => $raw_stream) {
    $stream = @gzuncompress($raw_stream);
    if ($stream && strpos($stream, 'BT') !== false) {
        echo "--- First text stream ($idx) ---\n";
        echo substr($stream, 0, 500) . "\n";
        break;
    }
}
