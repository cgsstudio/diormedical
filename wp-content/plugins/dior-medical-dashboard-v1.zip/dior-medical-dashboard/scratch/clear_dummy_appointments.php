<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

global $wpdb;

// 1. Truncate / delete all records from dior_appointments table
$table = $wpdb->prefix . 'dior_appointments';
$wpdb->query("TRUNCATE TABLE $table");
echo "Truncated $table.\n";

// 2. Clear dior_appointments from usermeta
$deleted_meta = $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key = 'dior_appointments'");
echo "Deleted $deleted_meta appointment usermeta rows.\n";

// 3. Clear doctor notifications & patient notifications
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key = 'dior_doctor_notifications'");
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key = 'dior_notifications'");
echo "Cleared old notifications.\n";

// 4. Verify table count
$count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
echo "Remaining appointments in DB: $count\n";
