<?php
require_once __DIR__ . '/../../../../wp-load.php';

wp_set_current_user(2); // user 2 (test two)

ob_start();
$out = Dior_Medical_Auth::render_patient_dashboard([]);
$rendered = ob_get_clean() . $out;

echo "Render Length: " . strlen($rendered) . " bytes\n";
if (strpos($rendered, 'Warning:') !== false || strpos($rendered, '<b>Warning</b>') !== false) {
    echo "FAILED: Found PHP warnings in output!\n";
    preg_match_all('/(?:<b>)?Warning(?:<\/b>)?:.*?(?:<br|$)/i', $rendered, $matches);
    print_r($matches[0]);
} else {
    echo "SUCCESS: Zero PHP warnings! Clean output.\n";
}

if (strpos($rendered, 'dior-intake-prefill-banner') !== false) {
    echo "SUCCESS: Found dior-intake-prefill-banner rendered cleanly.\n";
}
