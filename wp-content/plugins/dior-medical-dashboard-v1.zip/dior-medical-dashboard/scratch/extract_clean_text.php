<?php

function extract_full_text($pdf_file) {
    $content = file_get_contents($pdf_file);
    preg_match_all('/stream[\r\n]+(.*?)[\r\n]+endstream/s', $content, $raw_streams);
    
    $uncompressed_streams = [];
    $cmaps = [];
    
    foreach ($raw_streams[1] as $idx => $raw) {
        $unc = @gzuncompress($raw);
        if ($unc) {
            $uncompressed_streams[$idx] = $unc;
            if (strpos($unc, '/CIDInit') !== false) {
                // Parse this cmap
                $map = [];
                // parse beginbfchar
                if (preg_match_all('/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>/', $unc, $bfchar)) {
                    for ($i = 0; $i < count($bfchar[1]); $i++) {
                        $src = hexdec($bfchar[1][$i]);
                        $dst = hexdec($bfchar[2][$i]);
                        $map[$src] = mb_chr($dst, 'UTF-8');
                    }
                }
                // parse beginbfrange
                if (preg_match_all('/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>/', $unc, $bfrange)) {
                    for ($i = 0; $i < count($bfrange[1]); $i++) {
                        $src_start = hexdec($bfrange[1][$i]);
                        $src_end = hexdec($bfrange[2][$i]);
                        $dst_start = hexdec($bfrange[3][$i]);
                        for ($s = $src_start; $s <= $src_end; $s++) {
                            $offset = $s - $src_start;
                            $map[$s] = mb_chr($dst_start + $offset, 'UTF-8');
                        }
                    }
                }
                $cmaps[$idx] = $map;
            }
        }
    }
    
    // Merge all cmaps for global fallback lookup
    $global_cmap = [];
    foreach ($cmaps as $c) {
        foreach ($c as $k => $v) {
            $global_cmap[$k] = $v;
        }
    }
    
    $full_text = '';
    foreach ($uncompressed_streams as $idx => $stream) {
        if (strpos($stream, 'BT') === false) continue;
        
        $lines = explode("\n", $stream);
        $page_text = '';
        foreach ($lines as $line) {
            // Check for <hex> Tj
            if (preg_match_all('/<([0-9a-fA-F]+)>\s*Tj/', $line, $tjs)) {
                foreach ($tjs[1] as $hex) {
                    $cid = hexdec($hex);
                    $ch = isset($global_cmap[$cid]) ? $global_cmap[$cid] : '';
                    $page_text .= $ch;
                }
            }
            // Check for [ ... ] TJ
            if (preg_match('/\[(.*?)\]\s*TJ/', $line, $tjm)) {
                if (preg_match_all('/<([0-9a-fA-F]+)>/', $tjm[1], $hexes)) {
                    foreach ($hexes[1] as $hex) {
                        $len = strlen($hex);
                        for ($k = 0; $k < $len; $k += 4) {
                            $cid = hexdec(substr($hex, $k, 4));
                            $page_text .= isset($global_cmap[$cid]) ? $global_cmap[$cid] : '';
                        }
                    }
                }
                $page_text .= " ";
            }
        }
        $full_text .= trim($page_text) . "\n\n";
    }
    return $full_text;
}

$pdf1 = 'C:/Users/Admin/Downloads/New Dior Medical MultiStep Intake Form_260909114906.pdf';
$pdf2 = 'C:/Users/Admin/Downloads/New Dior Medical MultiStep Intake Form_260908184801.pdf';

echo "=== PDF 1 ===\n" . extract_full_text($pdf1) . "\n\n";
echo "=== PDF 2 ===\n" . extract_full_text($pdf2) . "\n\n";
