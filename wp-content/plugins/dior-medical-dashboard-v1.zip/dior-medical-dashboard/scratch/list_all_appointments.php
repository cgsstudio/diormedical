<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

global $wpdb;
$table = $wpdb->prefix . 'dior_appointments';
$rows = $wpdb->get_results("SELECT * FROM $table", ARRAY_A);
echo "Total rows in $table: " . count($rows) . "\n";
foreach ($rows as $r) {
    echo "ID: " . $r['id'] . " | UID: " . $r['appt_uid'] . " | Patient: " . $r['patient_id'] . " | Doctor: " . $r['doctor_id'] . " | Date: " . $r['appt_date'] . " | IsDeleted: " . $r['is_deleted'] . "\n";
}

// Also check docbooker appointments cpt
$docbooker_posts = get_posts([
    'post_type' => 'wpddb_appointment',
    'posts_per_page' => -1,
    'post_status' => 'any'
]);
echo "\nTotal DocBooker appointment posts (wpddb_appointment): " . count($docbooker_posts) . "\n";
foreach ($docbooker_posts as $p) {
    echo "DocBooker Post ID: " . $p->ID . " | Title: " . $p->post_title . "\n";
}
