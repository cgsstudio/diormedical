<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

// Clean table first
global $wpdb;
$table = $wpdb->prefix . 'dior_appointments';
$wpdb->query("TRUNCATE TABLE $table");

// Book appointment for Dr. Marcus Sterling (DocBooker ID 1693 / User 8)
wp_set_current_user(2);
$res = Dior_Appointment_Service::book_appointment([
    'patient_id' => 2,
    'doctor_id' => 1693,
    'doctor_name' => 'Dr. Marcus Sterling, DO',
    'condition' => 'Telehealth Care',
    'visit_type' => 'Video Visit (HD)',
    'appt_date' => '2026-09-18',
    'appt_time' => '02:00 PM',
    'status' => 'Confirmed'
]);

echo "Appointment booked for Dr. Marcus Sterling (1693) -> UID: " . $res['appt_uid'] . "\n\n";

// Check Marcus Sterling (User 8)
$u8_apts = Dior_Appointment_Service::get_doctor_appointments(8);
echo "1. Dr. Marcus Sterling (User 8) see appointments count: " . count($u8_apts) . " (Expected: 1)\n";

// Check Dr. James Chen (User 6)
$u6_apts = Dior_Appointment_Service::get_doctor_appointments(6);
echo "2. Dr. James Chen (User 6) see appointments count: " . count($u6_apts) . " (Expected: 0)\n";

// Check Dr. Evelyn Vance (User 7)
$u7_apts = Dior_Appointment_Service::get_doctor_appointments(7);
echo "3. Dr. Evelyn Vance (User 7) see appointments count: " . count($u7_apts) . " (Expected: 0)\n";

// Check Admin (User 1)
$u1_apts = Dior_Appointment_Service::get_doctor_appointments(1);
echo "4. Admin (User 1) see appointments count: " . count($u1_apts) . " (Expected: 1)\n";
