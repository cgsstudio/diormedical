<?php
require_once 'c:/xampp/htdocs/diormedical/wp-load.php';

$users = get_users();
foreach ($users as $u) {
    $rx = get_user_meta($u->ID, 'dior_prescriptions', true);
    if (!empty($rx)) {
        echo "User ID: " . $u->ID . " (" . $u->user_email . ")\n";
        echo json_encode($rx, JSON_PRETTY_PRINT) . "\n\n";
    }
}
