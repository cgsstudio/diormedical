<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

global $wpdb;
$meta_rows = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key = 'dior_appointments'", ARRAY_A);
echo "Users with dior_appointments meta: " . count($meta_rows) . "\n";
foreach ($meta_rows as $mr) {
    $val = maybe_unserialize($mr['meta_value']);
    echo "User " . $mr['user_id'] . " has " . (is_array($val) ? count($val) : 0) . " appointments in meta.\n";
}
