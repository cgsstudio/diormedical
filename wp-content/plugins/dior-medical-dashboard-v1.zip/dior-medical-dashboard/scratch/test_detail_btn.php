<?php
require_once __DIR__ . '/../../../../wp-load.php';

wp_set_current_user(2); // test two

ob_start();
$out = Dior_Medical_Auth::render_patient_dashboard([]);
$rendered = ob_get_clean() . $out;

if (strpos($rendered, 'diorViewAppointmentDetails') !== false) {
    echo "SUCCESS: Found diorViewAppointmentDetails button in table!\n";
} else {
    echo "FAILED: diorViewAppointmentDetails button not found!\n";
}

if (strpos($rendered, 'modal-view-appointment-detail') !== false) {
    echo "SUCCESS: Found modal-view-appointment-detail in DOM!\n";
} else {
    echo "FAILED: modal-view-appointment-detail not found!\n";
}
