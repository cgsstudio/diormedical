<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';
global $wpdb;
$table = $wpdb->prefix . 'dior_appointments';
$wpdb->query("TRUNCATE TABLE $table");
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key = 'dior_appointments'");
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key = 'dior_doctor_notifications'");
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key = 'dior_notifications'");
echo "Cleaned DB.\n";
