<?php
require_once 'c:/xampp/htdocs/diormedical/wp-load.php';
require_once 'c:/xampp/htdocs/diormedical/wp-content/plugins/dior-medical-dashboard/dior-medical-dashboard.php';

// Case A: User without intake (User 4)
wp_set_current_user(4);
ob_start();
echo do_shortcode('[dior_patient_dashboard]');
$out4 = ob_get_clean();

// Check if booking section is hidden when intake is not submitted
$has_hidden_booking_for_4 = strpos($out4, 'id="dior-dashboard-booking-section" style="margin-top:20px; border: 1.5px solid #2C6CB1; box-shadow: 0 10px 32px rgba(44, 108, 177, 0.12); border-radius:14px; overflow:hidden; display:none;"') !== false;
$has_visible_hipaa_for_4 = strpos($out4, 'id="dior-hipaa-form-container"') !== false && strpos($out4, 'id="dior-hipaa-form-container"' . "\n" . '                            style="max-width: 100%; margin: 0 auto; background: #FFFFFF; display:none;"') === false;

echo "User 4 (No Intake Submitted):\n";
echo " - Booking Section Hidden (display:none): " . ($has_hidden_booking_for_4 ? "YES" : "NO") . "\n";
echo " - HIPAAtizer Form Visible: " . ($has_visible_hipaa_for_4 ? "YES" : "NO") . "\n";
echo " - Has any manual button below form: " . (strpos($out4, 'dior-intake-flow-footer') !== false ? "YES (FAIL)" : "NO (CLEAN)") . "\n\n";

// Case B: User with intake (User 2)
wp_set_current_user(2);
ob_start();
echo do_shortcode('[dior_patient_dashboard]');
$out2 = ob_get_clean();

$has_hidden_hipaa_for_2 = strpos($out2, 'id="dior-hipaa-form-container"' . "\n" . '                            style="max-width: 100%; margin: 0 auto; background: #FFFFFF; display:none;"') !== false;
$has_visible_booking_for_2 = strpos($out2, 'id="dior-dashboard-booking-section" style="margin-top:20px; border: 1.5px solid #2C6CB1; box-shadow: 0 10px 32px rgba(44, 108, 177, 0.12); border-radius:14px; overflow:hidden; "') !== false;

echo "User 2 (Intake Already Submitted):\n";
echo " - HIPAAtizer Form Hidden (display:none): " . ($has_hidden_hipaa_for_2 ? "YES" : "NO") . "\n";
echo " - Booking Section Visible: " . ($has_visible_booking_for_2 ? "YES" : "NO") . "\n";
