<?php
require_once 'c:/xampp/htdocs/diormedical/wp-load.php';
require_once 'c:/xampp/htdocs/diormedical/wp-content/plugins/dior-medical-dashboard/dior-medical-dashboard.php';

wp_set_current_user(2);
ob_start();
echo do_shortcode('[dior_patient_dashboard]');
$out = ob_get_clean();

echo "Dashboard rendered cleanly.\n";
echo "Has 'Summary' button in appointments: " . (strpos($out, 'View Visit Summary') !== false ? "YES (FAIL)" : "NO (REMOVED)") . "\n";
echo "Has 'Detail' button in appointments: " . (strpos($out, 'View Appointment Detail') !== false ? "YES" : "NO") . "\n";
