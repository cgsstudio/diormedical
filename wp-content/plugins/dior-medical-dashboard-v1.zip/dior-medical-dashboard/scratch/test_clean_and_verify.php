<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

echo "1. Verify empty appointments:\n";
$apts = Dior_Appointment_Service::get_doctor_appointments(6);
echo "Doctor 6 appointments count: " . count($apts) . "\n";

echo "2. Simulate booking an appointment for patient 2 with doctor 1692 (Dr. Evelyn Vance):\n";
$book_res = Dior_Appointment_Service::book_appointment([
    'patient_id' => 2,
    'doctor_id' => 1692,
    'doctor_name' => 'Dr. Evelyn Vance, MD',
    'condition' => 'Telehealth Medical Consultation',
    'visit_type' => 'Video Visit (HD)',
    'appt_date' => '2026-09-15',
    'appt_time' => '11:00 AM - 12:00 PM',
    'notes' => 'Patient scheduled after HIPAA intake',
    'status' => 'Confirmed'
]);

if (is_wp_error($book_res)) {
    echo "Booking Error: " . $book_res->get_error_message() . "\n";
} else {
    echo "Booking Success! UID: " . $book_res['appt_uid'] . "\n";
}

echo "3. Verify Doctor 6 appointments now:\n";
$apts_after = Dior_Appointment_Service::get_doctor_appointments(6);
echo "Doctor 6 appointments count: " . count($apts_after) . "\n";
foreach ($apts_after as $a) {
    echo "- " . $a['id'] . " | " . $a['patient_name'] . " | " . $a['date'] . " " . $a['time'] . " | " . $a['doctor_name'] . " | Status: " . $a['status'] . "\n";
}

// Now clean it back to 0 as user requested fresh start
$table = $GLOBALS['wpdb']->prefix . 'dior_appointments';
$GLOBALS['wpdb']->query("TRUNCATE TABLE $table");
$GLOBALS['wpdb']->query("DELETE FROM {$GLOBALS['wpdb']->usermeta} WHERE meta_key = 'dior_appointments'");
$GLOBALS['wpdb']->query("DELETE FROM {$GLOBALS['wpdb']->usermeta} WHERE meta_key = 'dior_doctor_notifications'");
$GLOBALS['wpdb']->query("DELETE FROM {$GLOBALS['wpdb']->usermeta} WHERE meta_key = 'dior_notifications'");

echo "\nFinal check (clean database): " . $GLOBALS['wpdb']->get_var("SELECT COUNT(*) FROM $table") . " appointments.\n";
