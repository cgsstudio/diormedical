<?php
require_once dirname(__DIR__, 4) . '/wp-load.php';

$uid = 6;
$ns = get_user_meta($uid, 'dior_doctor_notifications', true);
echo "User 6 notifications count: " . count((array)$ns) . "\n";
print_r($ns);

$uid4 = 4;
$ns4 = get_user_meta($uid4, 'dior_doctor_notifications', true);
echo "User 4 notifications count: " . count((array)$ns4) . "\n";
