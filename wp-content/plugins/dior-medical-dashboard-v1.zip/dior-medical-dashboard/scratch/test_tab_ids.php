<?php
require_once 'c:/xampp/htdocs/diormedical/wp-load.php';
require_once 'c:/xampp/htdocs/diormedical/wp-content/plugins/dior-medical-dashboard/dior-doctor-dashboard.php';

$pid = 5;
$doctor_id = 4;
$doctor = ['zoom_link' => 'https://zoom.us/j/12345'];
$profile = get_user_meta($pid, 'dior_patient_profile', true) ?: [];
$intake = get_user_meta($pid, 'dior_medical_intake', true) ?: [];
$user = get_userdata($pid);

ob_start();
include 'c:/xampp/htdocs/diormedical/wp-content/plugins/dior-medical-dashboard/templates/patient-detail-modal.php';
$html = ob_get_clean();

$tabs = ['cpanel-intake', 'cpanel-soap', 'cpanel-docs', 'cpanel-excuse', 'cpanel-profile'];
foreach ($tabs as $t) {
    $has_panel = strpos($html, 'id="' . $t . '"') !== false;
    $has_button = strpos($html, "pchartSwitchTab(this, '$t')") !== false || strpos($html, "data-target=\"$t\"") !== false;
    echo "Tab $t: Panel=" . ($has_panel ? "YES" : "NO") . ", Button=" . ($has_button ? "YES" : "NO") . "\n";
}
