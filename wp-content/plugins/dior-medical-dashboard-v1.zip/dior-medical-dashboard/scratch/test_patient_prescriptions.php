<?php
require_once 'c:/xampp/htdocs/diormedical/wp-load.php';
require_once 'c:/xampp/htdocs/diormedical/wp-content/plugins/dior-medical-dashboard/dior-medical-dashboard.php';

update_user_meta(5, 'dior_prescriptions', [
    [
        'id' => 'RX-TEST-01',
        'medication' => 'Amoxicillin 500mg',
        'dosage' => '1 capsule every 8 hours x 7 days',
        'quantity' => '21 Capsules',
        'refills' => '1 Refill Remaining',
        'date_prescribed' => 'Sep 9, 2026',
        'prescribed_by' => 'Dr. Marcus Sterling, DO',
        'pharmacy' => 'CVS Pharmacy #4821',
        'routing_status' => 'Sent to Pharmacy',
        'status_class' => 'status-success',
        'instructions' => 'Take with food and full glass of water.'
    ]
]);

wp_set_current_user(5); // Patient user
ob_start();
echo do_shortcode('[dior_patient_dashboard]');
$out = ob_get_clean();

echo "Dashboard rendered length: " . strlen($out) . " bytes\n";
echo "Has Prescriptions & Meds menu: " . (strpos($out, 'Prescriptions &amp; Meds') !== false ? "YES" : "NO") . "\n";
echo "Has modal-view-rx-detail: " . (strpos($out, 'id="modal-view-rx-detail"') !== false ? "YES" : "NO") . "\n";
echo "Has Rx Detail button: " . (strpos($out, 'diorViewRxDetails') !== false ? "YES" : "NO") . "\n";
echo "Has Rx PDF download: " . (strpos($out, 'diorDownloadRxPdf') !== false ? "YES" : "NO") . "\n";
