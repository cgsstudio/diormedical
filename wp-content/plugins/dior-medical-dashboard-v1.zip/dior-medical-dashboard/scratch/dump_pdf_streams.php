<?php
$pdf1 = 'C:/Users/Admin/Downloads/New Dior Medical MultiStep Intake Form_260909114906.pdf';
$content = file_get_contents($pdf1);

preg_match_all('/stream[\r\n]+(.*?)[\r\n]+endstream/s', $content, $matches);
echo "Total streams: " . count($matches[1]) . "\n";
foreach ($matches[1] as $idx => $stream) {
    $unc = @gzuncompress($stream);
    if ($unc) {
        // Strip non-printable ascii
        $clean = preg_replace('/[^\x20-\x7E\r\n\t]/', '', $unc);
        if (strlen(trim($clean)) > 50) {
            echo "--- Stream $idx ---\n";
            echo substr($clean, 0, 1000) . "\n\n";
        }
    }
}
