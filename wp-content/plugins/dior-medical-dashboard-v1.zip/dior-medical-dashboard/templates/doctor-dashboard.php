<style>
/* DIOR DOCTOR DASHBOARD TABLE PAGINATION */
.dior-table-pagination {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    padding: 14px 24px !important;
    background: #FFFFFF !important;
    border-top: 1px solid #EEF2F6 !important;
    flex-wrap: wrap !important;
    gap: 12px !important;
    font-family: 'DMSans', 'DM Sans', -apple-system, sans-serif !important;
}
.dior-pagination-info {
    font-size: 13px !important;
    color: #64748B !important;
    font-weight: 500 !important;
}
.dior-pagination-info strong {
    color: #0F172A !important;
    font-weight: 700 !important;
}
.dior-pagination-nav {
    display: flex !important;
    align-items: center !important;
    gap: 6px !important;
}
.dior-page-btn {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    min-width: 32px !important;
    height: 32px !important;
    padding: 0 10px !important;
    border-radius: 8px !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    border: 1px solid #E2E8F0 !important;
    background: #FFFFFF !important;
    color: #475569 !important;
    cursor: pointer !important;
    transition: all 0.15s ease !important;
    font-family: inherit !important;
}
.dior-page-btn:hover:not(:disabled) {
    background: #F8FAFC !important;
    border-color: #CBD5E1 !important;
    color: #0F172A !important;
}
.dior-page-btn.active {
    background: linear-gradient(135deg, #2C6CB1 0%, #1A528E 100%) !important;
    color: #FFFFFF !important;
    border-color: transparent !important;
    box-shadow: 0 2px 6px rgba(44, 108, 177, 0.25) !important;
}
.dior-page-btn:disabled {
    opacity: 0.4 !important;
    cursor: not-allowed !important;
    background: #F8FAFC !important;
}
</style>
<div class="dior-wrap dior-doctor-wrap" id="dior-doctor-app">

    <div class="dior-drawer-backdrop" id="dior-doc-backdrop" onclick="diorDocCloseMobile()"></div>

    <div class="dior-app">

        <!-- ============================================================ -->
        <!-- DOCTOR SIDEBAR                                               -->
        <!-- ============================================================ -->
        <aside class="dior-side" id="dior-doc-sidebar">
            <div class="dior-side-header">
                <div class="brand">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="brand-link">
                        <?php if (!empty($logo_url)): ?>
                            <img src="<?php echo esc_url($logo_url); ?>" alt="Dior Medical" class="brand-logo">
                        <?php else: ?>
                            <span
                                style="font-size:18px;font-weight:800;color:#2C6CB1;font-family:'Montserrat',sans-serif;">Dior
                                Medical</span>
                        <?php endif; ?>
                    </a>
                </div>
                <button type="button" class="dior-side-close" onclick="diorDocCloseMobile()">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <!-- Doctor Identity Card -->
            <div class="dior-side-org-card" style="border-left:3px solid #2C6CB1;">
                <div class="org-icon-box"
                    style="background:linear-gradient(135deg,#EBF3FA,#D0E1F9);color:#2C6CB1;border:1px solid #BFDBFE;overflow:hidden;padding:0;display:flex;align-items:center;justify-content:center;">
                    <?php if (!empty($doctor['avatar_url'])): ?>
                        <img src="<?php echo esc_url($doctor['avatar_url']); ?>" alt="<?php echo esc_attr($doctor['full_name']); ?>" style="width:100%;height:100%;object-fit:cover;border-radius:10px;">
                    <?php else: ?>
                        <i class="fa-solid fa-user-doctor" style="color:#2C6CB1;font-size:18px;"></i>
                    <?php endif; ?>
                </div>
                <div class="org-info">
                    <strong><?php echo esc_html($doctor['full_name']); ?></strong>
                    <span><?php echo esc_html($doctor['specialty'] ?: 'Licensed Provider'); ?></span>
                </div>
                <i class="fa-solid fa-stethoscope" style="color:#2C6CB1;font-size:15px;" title="Licensed Provider"></i>
            </div>

            <!-- Nav -->
            <nav class="dior-side-nav">
                <div class="grp">
                    <span class="grp-title">PROVIDER MENU</span>

                    <button type="button" class="dior-nav-btn active" data-tab="doc-overview">
                        <i class="fa-solid fa-gauge-high"></i>
                        <span class="nav-label">Overview</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="doc-patients">
                        <i class="fa-solid fa-users"></i>
                        <span class="nav-label">All Patients</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="doc-appointments">
                        <i class="fa-solid fa-calendar-check"></i>
                        <span class="nav-label">Appointments</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="doc-intake">
                        <i class="fa-solid fa-file-shield"></i>
                        <span class="nav-label">Medical Intakes</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="doc-prescriptions">
                        <i class="fa-solid fa-prescription-bottle-medical"></i>
                        <span class="nav-label">Prescriptions</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="doc-records">
                        <i class="fa-solid fa-folder-open"></i>
                        <span class="nav-label">Medical Records</span>
                        <?php if (!empty($documents)): ?>
                            <span class="nav-count-badge success" style="background:#ECFDF5;color:#059669;"><?php echo count($documents); ?></span>
                        <?php endif; ?>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="doc-letters">
                        <i class="fa-solid fa-file-signature"></i>
                        <span class="nav-label">Letters & Certificates</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="doc-payments">
                        <i class="fa-solid fa-credit-card"></i>
                        <span class="nav-label">Payments</span>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="doc-notifications">
                        <i class="fa-solid fa-bell"></i>
                        <span class="nav-label">Notifications</span>
                        <?php if ($unread_count > 0): ?>
                            <span class="nav-count-badge warning doc-unread-badge"><?php echo $unread_count; ?></span>
                        <?php endif; ?>
                    </button>
                    <button type="button" class="dior-nav-btn" data-tab="doc-settings">
                        <i class="fa-solid fa-gear"></i>
                        <span class="nav-label">Settings</span>
                    </button>
                </div>

                <div class="dior-side-footer">
                    <a href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>" class="dior-side-action-btn dior-side-btn-logout">
                        <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Sign Out</span>
                    </a>
                </div>
            </nav>
        </aside>

        <!-- ============================================================ -->
        <!-- MAIN CONTENT                                                  -->
        <!-- ============================================================ -->
        <main class="dior-main-content">

            <!-- Topbar -->
            <header class="dior-topbar">
                <div class="dior-topbar-left">
                    <button type="button" class="dior-mobile-menu-toggle" onclick="diorDocOpenMobile()">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                    <div class="dior-top-search">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input type="text" id="dior-doc-search" placeholder="Search patients, appointments..."
                            oninput="diorDocSearch(this.value)">
                        <!-- <span class="search-kbd">⌘+K</span> -->
                    </div>
                </div>
                <div class="dior-topbar-right">
                    <div class="dior-notif-wrap">
                        <button type="button" class="dior-notif-btn" onclick="diorDocToggleNotif(event)">
                            <i class="fa-regular fa-bell"></i>
                            <?php if ($unread_count > 0): ?>
                                <span class="dior-notif-indicator doc-unread-badge"><?php echo $unread_count; ?></span>
                            <?php endif; ?>
                        </button>
                        <div class="dior-notif-dropdown" id="dior-doc-notif-dd">
                            <div class="dior-notif-header">
                                <h4>Notifications</h4>
                                <button type="button" onclick="diorDocMarkAllRead()">Mark all read</button>
                            </div>
                            <div class="dior-notif-list">
                                <?php foreach (array_slice($notifications, 0, 5) as $n): ?>
                                    <div class="dior-notif-item <?php echo !$n['is_read'] ? 'unread' : ''; ?>"
                                        data-notif-id="<?php echo esc_attr($n['id']); ?>">
                                        <div class="notif-icon"><i class="fa-solid <?php echo esc_attr($n['icon']); ?>"></i>
                                        </div>
                                        <div class="notif-body">
                                            <strong><?php echo esc_html($n['title']); ?></strong>
                                            <p><?php echo esc_html(mb_substr($n['message'], 0, 30) . (mb_strlen($n['message']) > 30 ? '...' : '')); ?>
                                            </p>
                                            <span class="notif-time"><?php echo esc_html(dior_format_notification_time($n)); ?></span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="dior-notif-footer">
                                <button type="button" onclick="diorDocSwitchTab('doc-notifications')">View All
                                    &rarr;</button>
                            </div>
                        </div>
                    </div>
                    <div class="dior-user-pill">
                        <div class="dior-pill-avatar" style="background:linear-gradient(135deg,#2C6CB1,#1A528E);color:#FFFFFF;overflow:hidden;display:flex;align-items:center;justify-content:center;">
                            <?php if (!empty($doctor['avatar_url'])): ?>
                                <img src="<?php echo esc_url($doctor['avatar_url']); ?>" alt="<?php echo esc_attr($doctor['full_name']); ?>" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">
                            <?php else: ?>
                                <i class="fa-solid fa-user-doctor" style="color:#FFFFFF;font-size:14px;"></i>
                            <?php endif; ?>
                        </div>
                        <div class="dior-pill-info">
                            <span class="dior-pill-name"><?php echo esc_html($doctor['full_name']); ?></span>
                            <span class="dior-pill-status"
                                style="background:#EBF3FA;color:#2C6CB1;border-color:#BFDBFE;">
                                <i class="fa-solid fa-circle"></i> Provider
                            </span>
                        </div>
                    </div>
                </div>
            </header>

            <!-- ======================================================== -->
            <!-- TAB PANELS                                                -->
            <!-- ======================================================== -->
            <div class="dior-tab-content" id="dior-doc-content">

                <!-- ── OVERVIEW ── -->
                <section class="dior-tab-panel active" id="tab-doc-overview">
                    <div class="dior-content-pad">
                        <div class="dior-page-title-bar">
                            <div class="title-left">
                                <div class="title-icon-box">
                                    <i class="fa-solid fa-user-doctor"></i>
                                </div>
                                <div>
                                    <h1>Provider Overview</h1>
                                    <p class="title-sub">Welcome back, <?php echo esc_html($doctor['full_name']); ?>.
                                        Here's your clinical summary.</p>
                                </div>
                            </div>
                            <div class="title-right">
                                <div class="dior-date-picker-pill">
                                    <i class="fa-regular fa-calendar"></i>
                                    <span><?php echo date('D, M j Y'); ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="dior-stats-cards-grid"
                            style="margin-bottom:28px; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
                            <?php
                            $stats = [
                                ['fa-users', 'card-blue', $total_patients, 'Total Patients'],
                                ['fa-calendar-clock', 'card-purple', count($pending_apts), 'Pending Appointments'],
                                ['fa-file-shield', 'card-green', count($intake_patients), 'Intake Forms'],
                            ];
                            foreach ($stats as [$icon, $bg_class, $val, $label]):
                                ?>
                                <div class="dior-stat-card <?php echo $bg_class; ?>">
                                    <div class="card-content">
                                        <div class="stat-header-row">
                                            <span class="stat-label"><i class="fa-solid <?php echo $icon; ?>"></i>
                                                <?php echo $label; ?></span>
                                        </div>
                                        <span class="stat-val"><?php echo $val; ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
                            <div class="dior-card dior-mini-card">
                                <div class="dior-card-header">
                                    <h3><i class="fa-solid fa-calendar-day"></i> Pending Appointments</h3>
                                    <button class="dior-link-action" onclick="diorDocSwitchTab('doc-appointments')">View
                                        All &rarr;</button>
                                </div>
                                <div class="dior-card-body">
                                    <?php $pa = array_slice(array_values($pending_apts), 0, 5); ?>
                                    <?php if (empty($pa)): ?>
                                        <div class="empty-text"><i class="fa-regular fa-calendar-check"></i> No pending
                                            appointments</div>
                                    <?php else: ?>
                                        <div class="mini-appt-list">
                                            <?php foreach ($pa as $apt): ?>
                                                <div class="mini-appt-item">
                                                    <div class="mini-appt-date" style="background:#EBF3FA;color:#2C6CB1;">
                                                        <span
                                                            style="font-size:16px; font-weight:700;"><?php echo esc_html(substr($apt['patient_name'] ?? 'P', 0, 1)); ?></span>
                                                    </div>
                                                    <div class="mini-appt-info">
                                                        <strong><?php echo esc_html($apt['patient_name'] ?? '—'); ?></strong>
                                                        <span><i class="fa-regular fa-clock"></i>
                                                            <?php echo esc_html($apt['date'] ?? ''); ?> &bull;
                                                            <?php echo esc_html($apt['type'] ?? 'Telehealth'); ?></span>
                                                    </div>
                                                    <div class="mini-appt-badge">
                                                        <span
                                                            class="dior-st pending"><?php echo esc_html($apt['status'] ?? 'Scheduled'); ?></span>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="dior-card dior-mini-card">
                                <div class="dior-card-header">
                                    <h3><i class="fa-solid fa-user-injured"></i> Recent Patients</h3>
                                    <button class="dior-link-action" onclick="diorDocSwitchTab('doc-patients')">View All
                                        &rarr;</button>
                                </div>
                                <div class="dior-card-body">
                                    <div class="mini-appt-list">
                                        <?php foreach (array_slice($patients, 0, 5) as $p): ?>
                                            <div class="mini-appt-item">
                                                <div class="mini-appt-date" style="background:#F5F3FF;color:#7C3AED;">
                                                    <span
                                                        style="font-size:16px; font-weight:700;"><?php echo esc_html($p['initials']); ?></span>
                                                </div>
                                                <div class="mini-appt-info">
                                                    <strong><?php echo esc_html($p['full_name']); ?></strong>
                                                    <span><?php echo esc_html($p['patient_id']); ?> &bull;
                                                        <?php echo esc_html($p['registered']); ?></span>
                                                </div>
                                                <div class="mini-appt-badge">
                                                    <?php if ($p['has_intake']): ?>
                                                        <span class="dior-st ok" title="Intake submitted"><i
                                                                class="fa-solid fa-file-shield"></i> Intake Done</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- ── ALL PATIENTS ── -->
                <section class="dior-tab-panel" id="tab-doc-patients">
                    <div class="dior-content-pad">
                        <div class="dior-page-title-bar">
                            <div class="title-left">
                                <div class="title-icon-box">
                                    <i class="fa-solid fa-users"></i>
                                </div>
                                <div>
                                    <h1>Patient Management</h1>
                                    <p class="title-sub">All registered patients, intake forms and clinical data.</p>
                                </div>
                            </div>
                            <div class="title-right">
                                <span class="dior-st ok" style="font-size:14px;"><i class="fa-solid fa-users"></i>
                                    <?php echo $total_patients; ?> Patients</span>
                            </div>
                        </div>

                        <div class="dior-card">
                            <div class="dior-card-header">
                                <h3><i class="fa-solid fa-users"></i> All Patients</h3>
                                <input type="text" class="dior-search-input" placeholder="Search patients…"
                                    oninput="diorDocFilterPatients(this.value)">
                            </div>
                            <div class="dior-card-body" style="padding:16px 24px 24px 24px;overflow-x:auto;">
                                <table class="dior-doc-table" id="dior-patients-table">
                                    <thead>
                                        <tr>
                                            <th>Patient ID</th>
                                            <th>Patient Name</th>
                                            <th>Phone</th>
                                            <th>DOB</th>
                                            <th>Joined</th>
                                            <th>Intake</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($patients as $p): ?>
                                            <tr class="patient-row"
                                                data-search="<?php echo esc_attr(strtolower($p['full_name'] . ' ' . $p['patient_id'] . ' ' . $p['email'])); ?>">
                                                <td><code
                                                        style="background:#F1F5F9;padding:4px 8px;border-radius:6px;font-size:13px;color:#1A528E;font-weight:600;border:1px solid #E2E8F0;"><?php echo esc_html($p['patient_id']); ?></code>
                                                </td>
                                                <td>
                                                    <div style="display:flex;align-items:center;gap:12px;">
                                                        <div
                                                            style="background:#F5F3FF;color:#7C3AED;width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0;">
                                                            <?php echo esc_html($p['initials']); ?>
                                                        </div>
                                                        <div>
                                                            <strong
                                                                style="color:#1E293B;font-size:14px;"><?php echo esc_html($p['full_name']); ?></strong><br>
                                                            <small
                                                                style="color:#64748B;"><?php echo esc_html($p['email']); ?></small>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><?php echo esc_html($p['phone']); ?></td>
                                                <td><?php echo esc_html($p['dob']); ?></td>
                                                <td><?php echo esc_html($p['registered']); ?></td>
                                                <td>
                                                    <?php if ($p['has_intake']): ?>
                                                        <span class="dior-st ok"><i class="fa-solid fa-file-shield"></i>
                                                            Submitted</span>
                                                    <?php else: ?>
                                                        <span class="dior-st pending">Pending</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div style="display:flex;align-items:center;gap:6px;flex-wrap:nowrap;">
                                                        <button type="button" class="dior-btn-sm"
                                                            style="display:inline-flex;align-items:center;gap:5px;padding:6px 11px;height:28px;box-sizing:border-box;border-radius:6px;font-size:11.5px;font-weight:600;line-height:1;"
                                                            onclick="diorDocViewPatient(<?php echo (int) $p['user_id']; ?>)">
                                                            <i class="fa-solid fa-eye"></i> View
                                                        </button>
                                                        <?php if (!empty($p['has_active_appt'])): ?>
                                                            <?php 
                                                                $p_zoom = !empty($doctor['zoom_link']) ? $doctor['zoom_link'] : 'https://zoom.us/join';
                                                                $p_apt_date = $p['next_appt_date'] ?? '';
                                                                $p_apt_time = $p['next_appt_time'] ?? '';
                                                                $p_apt_status = $p['next_appt_status'] ?? 'Confirmed';
                                                            ?>
                                                            <a href="<?php echo esc_url($p_zoom); ?>" target="_blank" rel="noopener noreferrer"
                                                                class="dior-call-btn"
                                                                onclick="return diorDocStartCall(event, '<?php echo esc_js(esc_url($p_zoom)); ?>', '<?php echo esc_js($p_apt_date); ?>', '<?php echo esc_js($p_apt_time); ?>', '<?php echo esc_js($p_apt_status); ?>')"
                                                                style="display:inline-flex;align-items:center;gap:5px;padding:6px 11px;height:28px;box-sizing:border-box;background:linear-gradient(135deg,#059669,#047857);color:#FFFFFF;border-radius:6px;font-size:11.5px;font-weight:700;text-decoration:none;box-shadow:0 2px 6px rgba(5,150,105,0.25);white-space:nowrap;line-height:1;transition:all 0.2s ease;"
                                                                title="Start Video Call in New Tab">
                                                                <i class="fa-solid fa-video"></i> Call
                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- ── APPOINTMENTS ── -->
                <section class="dior-tab-panel" id="tab-doc-appointments">
                    <div class="dior-content-pad">
                        <div class="dior-page-title-bar">
                            <div class="title-left">
                                <div class="title-icon-box">
                                    <i class="fa-solid fa-calendar-check"></i>
                                </div>
                                <div>
                                    <h1>Appointment Management</h1>
                                    <p class="title-sub">View, manage and update all patient appointments. DocBooker Pro
                                        integrated.</p>
                                </div>
                            </div>
                        </div>

                        <?php if (shortcode_exists('docbooker_appointments') || shortcode_exists('docbooker_calendar')): ?>
                            <div class="dior-card" style="margin-bottom:24px;">
                                <div class="dior-card-header">
                                    <h3><i class="fa-solid fa-calendar-days"></i> DocBooker Pro — Live Calendar</h3>
                                    <span class="dior-st ok"><i class="fa-solid fa-circle"></i> Live</span>
                                </div>
                                <div class="dior-card-body">
                                    <?php
                                    if (shortcode_exists('docbooker_calendar'))
                                        echo do_shortcode('[docbooker_calendar]');
                                    elseif (shortcode_exists('docbooker_appointments'))
                                        echo do_shortcode('[docbooker_appointments]');
                                    ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="dior-card">
                            <div class="dior-card-header">
                                <h3><i class="fa-solid fa-list-check"></i> All Appointments</h3>
                                <select class="dior-search-input" onchange="diorDocFilterAppts(this.value)"
                                    style="width:auto;padding:6px 12px;font-size:13px;">
                                    <option value="">All Status</option>
                                    <option>Confirmed</option>
                                    <option>Scheduled</option>
                                    <option>Completed</option>
                                    <option>Cancelled</option>
                                </select>
                            </div>
                            <div class="dior-card-body" style="padding:16px 24px 24px 24px;overflow-x:auto;">
                                <?php if (empty($appointments)): ?>
                                    <div class="dior-empty-state" style="padding:32px;"><i
                                            class="fa-regular fa-calendar"></i>
                                        <p>No appointments yet</p>
                                    </div>
                                <?php else: ?>
                                    <table class="dior-doc-table" id="dior-appts-table">
                                        <thead>
                                            <tr>
                                                <th>Patient ID</th>
                                                <th>Patient Name</th>
                                                <th>Date / Time</th>
                                                <th>Type</th>
                                                <th>Condition</th>
                                                <th>Status</th>
                                                <th>Patient Detail</th>
                                                <th>Update</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($appointments as $apt): ?>
                                                <tr class="appt-row"
                                                    data-status="<?php echo esc_attr($apt['status'] ?? ''); ?>">
                                                    <td>
                                                        <code style="background:#F1F5F9;padding:4px 8px;border-radius:6px;font-size:12.5px;color:#1A528E;font-weight:600;border:1px solid #E2E8F0;"><?php echo esc_html($apt['patient_id_meta'] ?? ($apt['patient_id'] ?? '—')); ?></code>
                                                    </td>
                                                    <td>
                                                        <strong style="color:#1E293B;font-size:14px;font-weight:600;"><?php echo esc_html($apt['patient_name'] ?? '—'); ?></strong>
                                                    </td>
                                                    <td><?php echo esc_html(trim(($apt['date'] ?? '') . ' ' . ($apt['time'] ?? ''))); ?>
                                                    </td>
                                                    <td><?php echo esc_html($apt['type'] ?? '—'); ?></td>
                                                    <td><?php echo esc_html($apt['condition'] ?? '—'); ?></td>
                                                    <td>
                                                        <?php $s = strtolower($apt['status'] ?? ''); ?>
                                                        <span
                                                            class="dior-st <?php echo $s === 'completed' ? 'ok' : ($s === 'cancelled' ? 'error' : 'pending'); ?>">
                                                            <?php echo esc_html($apt['status'] ?? '—'); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div style="display:flex;align-items:center;gap:6px;flex-wrap:nowrap;">
                                                            <button type="button" class="dior-btn-sm"
                                                                style="display:inline-flex;align-items:center;gap:5px;padding:6px 11px;height:28px;box-sizing:border-box;background:#1A528E;color:#FFFFFF;border-radius:6px;border:none;cursor:pointer;font-weight:600;font-size:11.5px;white-space:nowrap;line-height:1;"
                                                                onclick="diorDocViewPatient(<?php echo (int) ($apt['user_id'] ?? 0); ?>)">
                                                                <i class="fa-solid fa-file-waveform"></i> Detail
                                                            </button>
                                                            <?php 
                                                                $apt_st = strtolower($apt['status'] ?? '');
                                                                $is_active_apt = !in_array($apt_st, ['completed', 'cancelled', 'cancel', 'no-show', 'done']);
                                                            ?>
                                                            <?php if ($is_active_apt): ?>
                                                                <?php 
                                                                    $apt_zoom = (!empty($apt['join_url']) && strpos($apt['join_url'], 'doxy.me') === false) ? $apt['join_url'] : (!empty($doctor['zoom_link']) ? $doctor['zoom_link'] : 'https://zoom.us/join');
                                                                    $apt_date = $apt['date'] ?? '';
                                                                    $apt_time = $apt['time'] ?? '';
                                                                    $apt_status = $apt['status'] ?? 'Confirmed';
                                                                ?>
                                                                <a href="<?php echo esc_url($apt_zoom); ?>" target="_blank" rel="noopener noreferrer"
                                                                    class="dior-call-btn"
                                                                    onclick="return diorDocStartCall(event, '<?php echo esc_js(esc_url($apt_zoom)); ?>', '<?php echo esc_js($apt_date); ?>', '<?php echo esc_js($apt_time); ?>', '<?php echo esc_js($apt_status); ?>')"
                                                                    style="display:inline-flex;align-items:center;gap:5px;padding:6px 11px;height:28px;box-sizing:border-box;background:linear-gradient(135deg,#059669,#047857);color:#FFFFFF;border-radius:6px;font-size:11.5px;font-weight:700;text-decoration:none;box-shadow:0 2px 6px rgba(5,150,105,0.25);white-space:nowrap;line-height:1;transition:all 0.2s ease;"
                                                                    title="Join Video Call in New Tab">
                                                                    <i class="fa-solid fa-video"></i> Call
                                                                </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <select class="dior-search-input"
                                                            style="width:auto;padding:4px 8px;font-size:12px;"
                                                            onchange="diorDocUpdateApptStatus(this,<?php echo (int) ($apt['user_id'] ?? 0); ?>,'<?php echo esc_js($apt['id'] ?? ''); ?>')">
                                                            <?php foreach (['Confirmed', 'In-Queue', 'Completed', 'Cancelled'] as $opt): ?>
                                                                <option <?php selected($apt['status'] ?? '', $opt); ?>>
                                                                    <?php echo $opt; ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- ── MEDICAL INTAKES ── -->
                <section class="dior-tab-panel" id="tab-doc-intake">
                    <div class="dior-content-pad">
                        <div class="dior-page-title-bar">
                            <div class="title-left">
                                <div class="title-icon-box">
                                    <i class="fa-solid fa-file-shield"></i>
                                </div>
                                <div>
                                    <h1>Medical Intake Forms</h1>
                                    <p class="title-sub">Review all HIPAA-compliant patient submissions from HIPAAtizer.
                                    </p>
                                </div>
                            </div>
                            <div class="title-right">
                                <span class="dior-st ok" style="font-size:14px;"><i class="fa-solid fa-file-shield"></i>
                                    <?php echo count($intake_patients); ?> Submissions</span>
                            </div>
                        </div>
                        <?php if (empty($intake_patients)): ?>
                            <div class="dior-card">
                                <div class="dior-empty-state" style="padding:48px;"><i class="fa-solid fa-file-shield"
                                        style="color:#CBD5E1;font-size:40px;margin-bottom:12px;"></i>
                                    <p>No intake forms submitted yet.</p>
                                </div>
                            </div>
                        <?php else: ?>
                            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(380px,1fr));gap:16px;">
                                <?php foreach ($patients as $p):
                                    if (!$p['has_intake'])
                                        continue;
                                    $intake = get_user_meta($p['user_id'], 'dior_hipaa_intake', true);
                                    if (empty($intake))
                                        continue;
                                    ?>
                                    <div class="dior-card" style="border-left:4px solid #059669;">
                                        <div class="dior-card-header" style="background:#ECFDF5;border-radius:12px 12px 0 0;">
                                            <div style="display:flex;align-items:center;gap:12px;">
                                                <div
                                                    style="background:linear-gradient(135deg,#D1FAE5,#A7F3D0);color:#059669;width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0;">
                                                    <?php echo esc_html($p['initials']); ?>
                                                </div>
                                                <div>
                                                    <strong
                                                        style="color:#1E293B;font-size:14px;"><?php echo esc_html($p['full_name']); ?></strong><br>
                                                    <small
                                                        style="color:#059669;"><?php echo esc_html($p['patient_id']); ?></small>
                                                </div>
                                            </div>
                                            <span class="dior-st ok"><i class="fa-solid fa-circle-check"></i>
                                                <?php echo esc_html(date('M j, Y', strtotime($intake['submitted_at'] ?? ''))); ?></span>
                                        </div>
                                        <div class="dior-card-body">
                                            <div class="dior-form-row-2" style="margin-bottom:10px;">
                                                <div><small style="color:#64748B;font-weight:600;">DOB</small>
                                                    <div><?php echo esc_html($intake['dob'] ?: '—'); ?></div>
                                                </div>
                                                <div><small style="color:#64748B;font-weight:600;">Phone</small>
                                                    <div><?php echo esc_html($intake['phone'] ?: '—'); ?></div>
                                                </div>
                                            </div>
                                            <?php if (!empty($intake['symptoms'])): ?>
                                                <div style="margin-bottom:10px;">
                                                    <small style="color:#64748B;font-weight:600;">Symptoms</small>
                                                    <div style="background:#F8FAFC;padding:8px;border-radius:8px;font-size:13px;">
                                                        <?php echo esc_html($intake['symptoms']); ?></div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($intake['allergies'])): ?>
                                                <div class="dior-form-row-2" style="margin-bottom:10px;">
                                                    <div><small style="color:#64748B;font-weight:600;">Allergies</small>
                                                        <div><?php echo esc_html($intake['allergies']); ?></div>
                                                    </div>
                                                    <div><small style="color:#64748B;font-weight:600;">Medications</small>
                                                        <div><?php echo esc_html($intake['medications'] ?: '—'); ?></div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($intake['medical_history'])): ?>
                                                <div style="margin-bottom:10px;">
                                                    <small style="color:#64748B;font-weight:600;">Medical History</small>
                                                    <div style="background:#F8FAFC;padding:8px;border-radius:8px;font-size:13px;">
                                                        <?php echo nl2br(esc_html($intake['medical_history'])); ?></div>
                                                </div>
                                            <?php endif; ?>
                                            <div style="margin-top:14px;">
                                                <button class="dior-btn-gold-primary" style="font-size:12px;padding:8px 16px;"
                                                    onclick="diorDocViewPatient(<?php echo (int) $p['user_id']; ?>)">
                                                    <i class="fa-solid fa-user-doctor"></i> Full Profile
                                                </button>
                                            </div>
                                        </div><!-- /card-body -->
                                    </div><!-- /card -->
                                <?php endforeach; ?>
                            </div><!-- /grid -->
                        <?php endif; ?>
                    </div><!-- /content-pad -->
                </section>




                <!-- ── PRESCRIPTIONS ── -->
                <section class="dior-tab-panel" id="tab-doc-prescriptions">
                    <div class="dior-content-pad">
                        <!-- Page Title Bar -->
                        <div class="dior-page-title-bar">
                            <div class="title-left">
                                <div class="title-icon-box">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </div>
                                <div>
                                    <h1>Prescriptions</h1>
                                    <p class="title-sub">Issue and manage patient prescriptions and pharmacy routing.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Write New Prescription Card -->
                        <div
                            style="background:#FFFFFF;border:1px solid #E2E8F0;border-radius:16px;overflow:hidden;box-shadow:0 2px 12px rgba(11,16,48,0.04);margin-bottom:24px;">
                            <!-- Card Header -->
                            <div
                                style="padding:18px 24px;border-bottom:1px solid #F1F5F9;display:flex;align-items:center;gap:12px;background:#FAFBFC;">
                                <div
                                    style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#EBF3FA,#D0E1F9);display:flex;align-items:center;justify-content:center;color:#2C6CB1;flex-shrink:0;">
                                    <i class="fa-solid fa-pen-to-square" style="font-size:15px;line-height:1;"></i>
                                </div>
                                <div>
                                    <h3
                                        style="margin:0;font-size:15px;font-weight:700;color:#2C6CB1;font-family:'DMSans','DM Sans',sans-serif;">
                                        Write New Prescription</h3>
                                    <p style="margin:2px 0 0;font-size:12px;color:#64748B;">Issue an e-prescription
                                        using FDA/RxNorm approved medications.</p>
                                </div>
                            </div>
                            <!-- Card Body -->
                            <div style="padding:24px;">
                                <form id="dior-doc-rx-form" onsubmit="return false;">
                                    <!-- Patient Selector -->
                                    <div style="margin-bottom:20px;">
                                        <label
                                            style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Patient
                                            <span style="color:#DC2626;">*</span></label>
                                        <select id="rx-patient-select" required
                                            style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;cursor:pointer;box-sizing:border-box;">
                                            <option value="">— Select Patient —</option>
                                            <?php foreach ($patients as $p): ?>
                                                <option value="<?php echo (int) $p['user_id']; ?>">
                                                    <?php echo esc_html($p['full_name'] . ' (' . $p['patient_id'] . ')'); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <!-- Add Medication Section -->
                                    <div
                                        style="background:#F8FAFC;border:1.5px solid #E2E8F0;border-radius:12px;padding:20px;margin-bottom:20px;">
                                        <div
                                            style="display:flex;align-items:center;gap:10px;margin-bottom:18px;padding-bottom:14px;border-bottom:1px solid #E9EFF6;">
                                            <div
                                                style="width:32px;height:32px;border-radius:8px;background:linear-gradient(135deg,#EBF3FA,#D0E1F9);display:flex;align-items:center;justify-content:center;color:#2C6CB1;">
                                                <i class="fa-solid fa-pills" style="font-size:14px;line-height:1;"></i>
                                            </div>
                                            <h4
                                                style="margin:0;font-size:14px;font-weight:700;color:#0F172A;font-family:'DMSans','DM Sans',sans-serif;">
                                                Add Medication</h4>
                                        </div>

                                        <!-- Drug Search -->
                                        <div style="position:relative;margin-bottom:16px;">
                                            <label
                                                style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Search
                                                FDA / RxNorm Approved Medications <span
                                                    style="color:#DC2626;">*</span></label>
                                            <div style="position:relative;">
                                                <input type="text" id="rx-med-search"
                                                    placeholder="Type drug name (e.g. Amoxicillin)..."
                                                    autocomplete="off" oninput="diorDocSearchMedication(this.value)"
                                                    style="width:100%;padding:11px 38px 11px 14px !important;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;">
                                                <i class="fa-solid fa-magnifying-glass"
                                                    style="position:absolute;right:14px;left:auto;top:50%;transform:translateY(-50%);color:#94A3B8;font-size:13px;pointer-events:none;"></i>
                                            </div>
                                            <div id="rx-med-autocomplete"
                                                style="display:none;position:absolute;z-index:100;background:#fff;width:100%;border:1.5px solid #BFDBFE;border-radius:10px;max-height:200px;overflow-y:auto;box-shadow:0 8px 24px rgba(44,108,177,0.12);margin-top:4px;">
                                            </div>
                                        </div>

                                        <!-- Dosage + Refills -->
                                        <div
                                            style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
                                            <div>
                                                <label
                                                    style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Dosage
                                                    &amp; Frequency <span style="color:#DC2626;">*</span></label>
                                                <input type="text" id="rx-dosage"
                                                    placeholder="e.g. 500mg — 3x daily for 7 days"
                                                    style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;">
                                            </div>
                                            <div>
                                                <label
                                                    style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Refills</label>
                                                <input type="text" id="rx-refills" placeholder="e.g. 0 refills"
                                                    style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;">
                                            </div>
                                        </div>

                                        <!-- Clinical Notes -->
                                        <div style="margin-bottom:16px;">
                                            <label
                                                style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Clinical
                                                Notes</label>
                                            <textarea id="rx-notes" rows="3"
                                                placeholder="Take with food. Avoid alcohol. Complete full course..."
                                                style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;resize:vertical;"></textarea>
                                        </div>

                                        <button type="button" onclick="diorDocAddMedToList()"
                                            style="display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border-radius:10px;font-size:13px;font-weight:700;font-family:'Montserrat',sans-serif;background:#FFFFFF;color:#2C6CB1;border:1.5px solid #BFDBFE;cursor:pointer;">
                                            <i class="fa-solid fa-plus"></i> Add to Prescription
                                        </button>
                                    </div>

                                    <!-- Medication List Output -->
                                    <div id="rx-med-list" style="margin-bottom:20px;"></div>

                                    <!-- Send Prescription Button -->
                                    <button type="button" id="btn-send-rx" onclick="diorDocSendPrescription()"
                                        style="display:inline-flex;align-items:center;gap:8px;padding:12px 24px;border-radius:10px;font-size:14px;font-weight:700;font-family:'Montserrat',sans-serif;background:linear-gradient(135deg,#2C6CB1,#1A528E);color:#FFFFFF;border:none;cursor:pointer;box-shadow:0 4px 16px rgba(44,108,177,0.28);">
                                        <i class="fa-solid fa-paper-plane"></i> Send Prescription
                                    </button>
                                </form>
                                <div id="dior-rx-msg"
                                    style="display:none;margin-top:16px;padding:14px 18px;border-radius:10px;font-size:13.5px;font-weight:600;font-family:'DMSans','DM Sans',sans-serif;">
                                </div>
                            </div>
                        </div>

                        <!-- All Issued Prescriptions Card -->
                        <div
                            style="background:#FFFFFF;border:1px solid #E2E8F0;border-radius:16px;overflow:hidden;box-shadow:0 2px 12px rgba(11,16,48,0.04);">
                            <div
                                style="padding:18px 24px;border-bottom:1px solid #F1F5F9;display:flex;align-items:center;gap:12px;background:#FAFBFC;">
                                <div
                                    style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#EBF3FA,#D0E1F9);display:flex;align-items:center;justify-content:center;color:#2C6CB1;flex-shrink:0;">
                                    <i class="fa-solid fa-prescription-bottle-medical"
                                        style="font-size:15px;line-height:1;"></i>
                                </div>
                                <h3
                                    style="margin:0;font-size:15px;font-weight:700;color:#2C6CB1;font-family:'DMSans','DM Sans',sans-serif;">
                                    All Issued Prescriptions</h3>
                            </div>
                            <div class="dior-card-body" style="padding:16px 24px 24px 24px;overflow-x:auto;">
                                <?php
                                $all_rx = [];
                                foreach ($patients as $p) {
                                    $rxs = get_user_meta($p['user_id'], 'dior_prescriptions', true);
                                    if (!is_array($rxs))
                                        continue;
                                    foreach ($rxs as $r) {
                                        $r['patient_name'] = $p['full_name'];
                                        $all_rx[] = $r;
                                    }
                                }
                                ?>
                                <table class="dior-doc-table" id="dior-all-rx-table">
                                    <thead>
                                        <tr>
                                            <th>Patient</th>
                                            <th>Medication</th>
                                            <th>Dosage</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody id="dior-all-rx-tbody">
                                        <?php if (empty($all_rx)): ?>
                                            <tr>
                                                <td colspan="5"
                                                    style="text-align:center;padding:32px;color:#94A3B8;font-size:13.5px;">
                                                    No prescriptions issued yet.</td>
                                            </tr>
                                        <?php else:
                                            foreach ($all_rx as $r): ?>
                                                <tr>
                                                    <td><strong><?php echo esc_html($r['patient_name'] ?? '—'); ?></strong></td>
                                                    <td><?php echo esc_html($r['medication'] ?? $r['name'] ?? '—'); ?></td>
                                                    <td><?php echo esc_html($r['dosage'] ?? $r['dose'] ?? '—'); ?></td>
                                                    <td><?php echo esc_html($r['date'] ?? '—'); ?></td>
                                                    <td><span
                                                            class="dior-st ok"><?php echo esc_html($r['status'] ?? 'Active'); ?></span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- ── PAYMENTS ── -->
                <section class="dior-tab-panel" id="tab-doc-payments">
                    <div class="dior-content-pad">
                        <div class="dior-page-title-bar">
                            <div class="title-left">
                                <div class="title-icon-box">
                                    <i class="fa-solid fa-credit-card"></i>
                                </div>
                                <div>
                                    <h1>Payment Records</h1>
                                    <p class="title-sub">All patient payment transactions via Stripe.</p>
                                </div>
                            </div>
                        </div>
                        <div class="dior-card">
                            <div class="dior-card-header">
                                <h3><i class="fa-solid fa-credit-card"></i> All Payments</h3>
                            </div>
                            <div class="dior-card-body" style="padding:16px 24px 24px 24px;overflow-x:auto;">
                                <?php
                                $all_pays = [];
                                foreach ($patients as $p) {
                                    $pays = get_user_meta($p['user_id'], 'dior_payments', true);
                                    if (!is_array($pays))
                                        continue;
                                    foreach ($pays as $pay) {
                                        $pay['patient_name'] = $p['full_name'];
                                        $all_pays[] = $pay;
                                    }
                                }
                                ?>
                                <table class="dior-doc-table" id="dior-payments-table">
                                    <thead>
                                        <tr>
                                            <th>Patient</th>
                                            <th>Invoice</th>
                                            <th>Amount</th>
                                            <th>Date</th>
                                            <th>Method</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($all_pays)): ?>
                                            <tr>
                                                <td colspan="6" style="text-align:center;padding:24px;color:#94A3B8;">No
                                                    payments found.</td>
                                            </tr>
                                        <?php else:
                                            foreach ($all_pays as $pay): ?>
                                                <tr>
                                                    <td><strong><?php echo esc_html($pay['patient_name'] ?? '—'); ?></strong>
                                                    </td>
                                                    <td><code
                                                            style="font-size:12px;"><?php echo esc_html($pay['id'] ?? '—'); ?></code>
                                                    </td>
                                                    <td style="font-weight:700;color:#059669;">
                                                        <?php echo esc_html($pay['amount'] ?? '—'); ?></td>
                                                    <td><?php echo esc_html($pay['date'] ?? '—'); ?></td>
                                                    <td><?php echo esc_html($pay['method'] ?? 'Stripe'); ?></td>
                                                    <td><span
                                                            class="dior-st <?php echo strtolower($pay['status'] ?? '') === 'paid' ? 'ok' : 'pending'; ?>"><?php echo esc_html($pay['status'] ?? '—'); ?></span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- ── NOTIFICATIONS ── -->
                <section class="dior-tab-panel" id="tab-doc-notifications">
                    <div class="dior-content-pad">
                        <div class="dior-page-header-box">
                            <div>
                                <h2>Provider Notification Inbox</h2>
                                <p>Stay updated with new patient registrations, appointments, intake submissions, and
                                    system alerts.</p>
                            </div>
                            <button type="button" class="dior-btn-gold-secondary" onclick="diorDocMarkAllRead()">
                                <i class="fa-solid fa-check-double"></i> Mark All as Read
                            </button>
                        </div>

                        <div class="dior-card">
                            <div class="dior-card-body p-0">
                                <div class="dior-notifs-full-list" id="dior-doc-notif-full">
                                    <?php if (empty($notifications)): ?>
                                        <div
                                            style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:64px 24px;text-align:center;">
                                            <div
                                                style="width:64px;height:64px;border-radius:16px;background:#F1F5F9;display:flex;align-items:center;justify-content:center;margin-bottom:16px;">
                                                <i class="fa-regular fa-bell-slash"
                                                    style="font-size:26px;color:#CBD5E1;"></i>
                                            </div>
                                            <p
                                                style="font-size:15px;color:#94A3B8;margin:0;font-weight:600;font-family:'DMSans','DM Sans',sans-serif;">
                                                No notifications yet</p>
                                            <p style="font-size:13px;color:#CBD5E1;margin:6px 0 0;">You'll see new alerts
                                                and updates here.</p>
                                        </div>
                                    <?php else: ?>
                                        <?php foreach ($notifications as $n): ?>
                                            <div class="dior-full-notif-item <?php echo !$n['is_read'] ? 'unread' : ''; ?>"
                                                data-notif-id="<?php echo esc_attr($n['id']); ?>">
                                                <div class="notif-type-icon <?php echo esc_attr($n['type'] ?? 'system'); ?>">
                                                    <i class="fa-solid <?php echo esc_attr($n['icon'] ?? 'fa-bell'); ?>"></i>
                                                </div>
                                                <div class="notif-full-body">
                                                    <div class="notif-full-top">
                                                        <h4><?php echo esc_html($n['title']); ?></h4>
                                                        <span class="notif-full-time"><?php echo esc_html(dior_format_notification_time($n)); ?></span>
                                                    </div>
                                                    <p><?php echo esc_html($n['message']); ?></p>
                                                </div>
                                                <div class="notif-full-actions">
                                                    <?php if (!$n['is_read']): ?>
                                                        <button type="button" class="dior-btn-table-icon dior-mark-single-read"
                                                            title="Mark as Read"
                                                            onclick="diorDocMarkSingleRead('<?php echo esc_js($n['id']); ?>', this)">
                                                            <i class="fa-solid fa-check"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


                <!-- ── MEDICAL RECORDS & CLINICAL FILES ── -->
                <section class="dior-tab-panel" id="tab-doc-records">
                    <div class="dior-content-pad">
                        <div class="dior-page-title-bar">
                            <div class="title-left">
                                <div class="title-icon-box" style="background:linear-gradient(135deg,#2C6CB1,#1A528E);color:#FFFFFF;">
                                    <i class="fa-solid fa-folder-open"></i>
                                </div>
                                <div>
                                    <h1>Medical Records & Clinical Files</h1>
                                    <p class="title-sub">Secure HIPAA-compliant vault of all patient lab reports, imaging, excuses, and signed consent records.</p>
                                </div>
                            </div>
                            <div class="title-right" style="display:flex;gap:10px;align-items:center;">
                                <button type="button" class="dior-btn-sm dior-btn-ghost" onclick="diorDocOpenUploadModal()" style="height:36px;padding:0 16px;font-size:13px;">
                                    <i class="fa-solid fa-cloud-arrow-up" style="color:#2C6CB1;"></i>
                                    <span>Upload Document</span>
                                </button>
                                <button type="button" class="dior-btn-sm dior-btn-purple" onclick="diorDocSwitchTab('doc-letters')" style="height:36px;padding:0 16px;font-size:13px;">
                                    <i class="fa-solid fa-file-signature"></i>
                                    <span>Issue Work Excuse</span>
                                </button>
                            </div>
                        </div>

                        <!-- Records Table Card -->
                        <div class="dior-card">
                            <div class="dior-card-header" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:14px;">
                                <div class="dior-filter-pill-group" id="doc-records-filter-pills">
                                    <button type="button" class="dior-filter-pill active" onclick="diorDocFilterCategory('all', this)">
                                        All Documents <span class="pill-count"><?php echo count($documents); ?></span>
                                    </button>
                                    <button type="button" class="dior-filter-pill" onclick="diorDocFilterCategory('consent', this)">
                                        <i class="fa-solid fa-shield-halved" style="color:#2C6CB1;"></i> Consents
                                    </button>
                                    <button type="button" class="dior-filter-pill" onclick="diorDocFilterCategory('excuse', this)">
                                        <i class="fa-solid fa-file-signature" style="color:#7C3AED;"></i> Excuses & Letters
                                    </button>
                                    <button type="button" class="dior-filter-pill" onclick="diorDocFilterCategory('lab', this)">
                                        <i class="fa-solid fa-flask-vial" style="color:#059669;"></i> Lab Reports
                                    </button>
                                    <button type="button" class="dior-filter-pill" onclick="diorDocFilterCategory('clinical', this)">
                                        <i class="fa-solid fa-notes-medical" style="color:#64748B;"></i> Clinical Notes
                                    </button>
                                </div>
                                <div style="display:flex;gap:8px;align-items:center;">
                                    <input type="text" class="dior-search-input" placeholder="Search records or patients…" oninput="diorDocFilterRecordsTable(this.value)" style="width:240px;height:34px;font-size:12.5px;">
                                </div>
                            </div>
                            <div class="dior-card-body p-0" style="overflow-x:auto;">
                                <table class="dior-doc-table" id="dior-doc-records-table" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th>Patient</th>
                                            <th>Document Title</th>
                                            <th>Category</th>
                                            <th>Date Issued</th>
                                            <th>Author</th>
                                            <th>Format</th>
                                            <th style="text-align:right;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($documents)): ?>
                                            <?php foreach ($documents as $doc): 
                                                $cat_raw = $doc['category'] ?? 'Record';
                                                $cat_lower = strtolower($cat_raw);
                                                $badge_class = 'dior-badge-blue';
                                                $cat_icon = 'fa-file-lines';
                                                $data_cat = 'general';
                                                $doc_icon_color = 'blue';

                                                if (strpos($cat_lower, 'lab') !== false || strpos($cat_lower, 'result') !== false) {
                                                    $badge_class = 'dior-badge-emerald';
                                                    $cat_icon = 'fa-flask-vial';
                                                    $data_cat = 'lab';
                                                    $doc_icon_color = 'emerald';
                                                } elseif (strpos($cat_lower, 'letter') !== false || strpos($cat_lower, 'excuse') !== false || strpos($cat_lower, 'certificate') !== false) {
                                                    $badge_class = 'dior-badge-purple';
                                                    $cat_icon = 'fa-file-signature';
                                                    $data_cat = 'excuse';
                                                    $doc_icon_color = 'purple';
                                                } elseif (strpos($cat_lower, 'consent') !== false || strpos($cat_lower, 'hipaa') !== false) {
                                                    $badge_class = 'dior-badge-blue';
                                                    $cat_icon = 'fa-shield-halved';
                                                    $data_cat = 'consent';
                                                    $doc_icon_color = 'blue';
                                                } elseif (strpos($cat_lower, 'imaging') !== false || strpos($cat_lower, 'x-ray') !== false) {
                                                    $badge_class = 'dior-badge-amber';
                                                    $cat_icon = 'fa-x-ray';
                                                    $data_cat = 'imaging';
                                                    $doc_icon_color = 'amber';
                                                } else {
                                                    $badge_class = 'dior-badge-slate';
                                                    $cat_icon = 'fa-notes-medical';
                                                    $data_cat = 'clinical';
                                                    $doc_icon_color = 'slate';
                                                }

                                                $pid_val = (int)($doc['patient_user_id'] ?? 0);
                                                $doc_id_val = $doc['id'] ?? '';
                                                $stream_url = add_query_arg(['dior_action' => 'download_doc', 'patient_id' => $pid_val, 'doc_id' => $doc_id_val], home_url('/'));
                                            ?>
                                            <tr data-cat="<?php echo esc_attr($data_cat); ?>" data-search="<?php echo esc_attr(strtolower(($doc['patient_name'] ?? '') . ' ' . ($doc['title'] ?? '') . ' ' . ($doc['patient_id_num'] ?? '') . ' ' . $cat_raw)); ?>">
                                                <td>
                                                    <div style="font-weight:700;color:#0F172A;font-size:13.5px;"><?php echo esc_html($doc['patient_name']); ?></div>
                                                    <code style="background:#F1F5F9;padding:2px 6px;border-radius:4px;font-size:11px;color:#2C6CB1;font-weight:600;"><?php echo esc_html($doc['patient_id_num']); ?></code>
                                                </td>
                                                <td>
                                                    <div class="dior-doc-cell">
                                                        <div class="dior-doc-icon-wrap <?php echo $doc_icon_color; ?>">
                                                            <i class="fa-regular fa-file-pdf"></i>
                                                        </div>
                                                        <div>
                                                            <strong style="color:#0F172A;font-size:13.5px;display:block;"><?php echo esc_html($doc['title']); ?></strong>
                                                            <span style="font-size:11px;color:#94A3B8;">ID: <?php echo esc_html($doc['id']); ?></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="dior-badge-pill <?php echo $badge_class; ?>">
                                                        <i class="fa-solid <?php echo $cat_icon; ?>"></i>
                                                        <?php echo esc_html($cat_raw); ?>
                                                    </span>
                                                </td>
                                                <td style="color:#64748B;font-size:12.5px;"><?php echo esc_html($doc['date']); ?></td>
                                                <td style="color:#475569;font-size:12.5px;font-weight:500;"><?php echo esc_html($doc['author']); ?></td>
                                                <td><strong style="color:#0F172A;font-size:12px;"><?php echo esc_html($doc['file_type'] ?? 'PDF'); ?></strong></td>
                                                <td style="text-align:right;">
                                                    <div style="display:flex;align-items:center;justify-content:flex-end;gap:6px;">
                                                        <a href="<?php echo esc_url($stream_url); ?>" target="_blank" class="dior-btn-sm dior-btn-primary" title="View Document in Viewer">
                                                            <i class="fa-solid fa-eye"></i> View
                                                        </a>
                                                        <button type="button" class="dior-btn-sm dior-btn-ghost" onclick="diorDocViewPatient(<?php echo $pid_val; ?>)" title="Open Patient Chart">
                                                            <i class="fa-solid fa-folder-open"></i> Chart
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="7" style="text-align:center;padding:50px 20px;color:#94A3B8;">
                                                    <i class="fa-solid fa-folder-open fa-3x" style="display:block;margin-bottom:12px;opacity:0.3;color:#2C6CB1;"></i>
                                                    <strong style="font-size:15px;color:#334155;display:block;margin-bottom:4px;">No Medical Records on File</strong>
                                                    <span style="font-size:13px;">Upload lab reports, clinical encounter summaries, or issue medical excuse letters.</span>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- ── WORK EXCUSE & MEDICAL LETTERS STUDIO ── -->
                <section class="dior-tab-panel" id="tab-doc-letters">
                    <div class="dior-content-pad">
                        <div class="dior-page-title-bar">
                            <div class="title-left">
                                <div class="title-icon-box" style="background:linear-gradient(135deg,#7C3AED,#6D28D9);color:#FFFFFF;">
                                    <i class="fa-solid fa-file-signature"></i>
                                </div>
                                <div>
                                    <h1>Work Excuse & Medical Letter Generator</h1>
                                    <p class="title-sub">Issue certified medical absence notes, school excuses, and fit-to-work clearance certificates directly to patients.</p>
                                </div>
                            </div>
                        </div>

                        <div style="display:grid;grid-template-columns: 1.15fr 1fr;gap:24px;align-items:start;">
                            
                            <!-- Generator Form Card -->
                            <div class="dior-card">
                                <div class="dior-card-header">
                                    <h3><i class="fa-solid fa-pen-nib" style="color:#7C3AED;"></i> Letter Configuration</h3>
                                </div>
                                <div class="dior-card-body" style="padding:22px;">
                                    <form id="doc-standalone-letter-form" onsubmit="diorDocSubmitStandaloneLetter(event)">
                                        
                                        <div style="margin-bottom:16px;">
                                            <label style="display:block;font-size:11.5px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:6px;">Select Patient <span style="color:#DC2626;">*</span></label>
                                            <select id="doc_gen_patient_select" required onchange="diorDocUpdateStandaloneLetterPreview()" style="width:100%;padding:10px 14px;border:1.5px solid #CBD5E1;border-radius:8px;font-size:13.5px;background:#FFF;color:#0F172A;font-weight:600;outline:none;">
                                                <option value="">-- Choose a patient --</option>
                                                <?php foreach ($patients as $p): ?>
                                                    <option value="<?php echo (int)$p['user_id']; ?>" 
                                                            data-name="<?php echo esc_attr($p['full_name']); ?>" 
                                                            data-dob="<?php echo esc_attr($p['dob']); ?>" 
                                                            data-pid="<?php echo esc_attr($p['patient_id']); ?>">
                                                        <?php echo esc_html($p['full_name']); ?> (<?php echo esc_html($p['patient_id']); ?>)
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px;">
                                            <div>
                                                <label style="display:block;font-size:11.5px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:6px;">Letter Type</label>
                                                <select id="doc_gen_letter_type" onchange="diorDocUpdateStandaloneLetterPreview()" style="width:100%;padding:10px 12px;border:1.5px solid #CBD5E1;border-radius:8px;font-size:13px;background:#FFF;color:#0F172A;outline:none;">
                                                    <option value="Work Excuse">Work Absence Excuse Note</option>
                                                    <option value="School / College Excuse">School / University Excuse Note</option>
                                                    <option value="Fit-to-Work Clearance">Fit-to-Work / Medical Clearance</option>
                                                    <option value="Specialist Referral Letter">Specialist Referral Attestation</option>
                                                    <option value="Custom Medical Letter">Custom Medical Attestation</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label style="display:block;font-size:11.5px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:6px;">Diagnosed Condition / Reason</label>
                                                <input type="text" id="doc_gen_condition" placeholder="e.g. Acute Upper Respiratory Illness" value="" oninput="diorDocUpdateStandaloneLetterPreview()" style="width:100%;padding:10px 12px;border:1.5px solid #CBD5E1;border-radius:8px;font-size:13px;box-sizing:border-box;outline:none;">
                                            </div>
                                        </div>

                                        <!-- Quick Clinical Condition Preset Chips -->
                                        <div style="margin-bottom:16px;">
                                            <span style="font-size:11px;font-weight:700;color:#64748B;display:block;margin-bottom:6px;text-transform:uppercase;">Quick Presets:</span>
                                            <div style="display:flex;gap:6px;flex-wrap:wrap;">
                                                <button type="button" class="dior-filter-pill" onclick="diorDocApplyLetterPreset('Acute Upper Respiratory Infection', 'Full Rest / Excused from all duties', 'Patient has been clinically evaluated via telehealth. Patient is advised adequate rest and hydration.')">Acute URI</button>
                                                <button type="button" class="dior-filter-pill" onclick="diorDocApplyLetterPreset('Acute Sinusitis & Cephalea', 'Full Rest / Excused from all duties', 'Patient was treated for acute sinusitis symptoms. Excused from active workplace duties.')">Sinusitis</button>
                                                <button type="button" class="dior-filter-pill" onclick="diorDocApplyLetterPreset('Acute Gastroenteritis', 'Full Rest / Excused from all duties', 'Patient presented with acute gastrointestinal symptoms. Advised bed rest and oral rehydration.')">Gastroenteritis</button>
                                                <button type="button" class="dior-filter-pill" onclick="diorDocApplyLetterPreset('Medical Clearance / Follow-up Complete', 'Full clearance / Return without restrictions', 'Patient has satisfactorily recovered from acute condition and is cleared to resume full normal duties.')">Fit for Work</button>
                                            </div>
                                        </div>

                                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px;">
                                            <div>
                                                <label style="display:block;font-size:11.5px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:6px;">Excused From (Start Date)</label>
                                                <input type="date" id="doc_gen_start_date" value="<?php echo date('Y-m-d'); ?>" onchange="diorDocUpdateStandaloneLetterPreview()" style="width:100%;padding:9px 12px;border:1.5px solid #CBD5E1;border-radius:8px;font-size:13px;box-sizing:border-box;outline:none;">
                                            </div>
                                            <div>
                                                <label style="display:block;font-size:11.5px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:6px;">Expected Return Date</label>
                                                <input type="date" id="doc_gen_return_date" value="<?php echo date('Y-m-d', strtotime('+3 days')); ?>" onchange="diorDocUpdateStandaloneLetterPreview()" style="width:100%;padding:9px 12px;border:1.5px solid #CBD5E1;border-radius:8px;font-size:13px;box-sizing:border-box;outline:none;">
                                            </div>
                                        </div>

                                        <div style="margin-bottom:16px;">
                                            <label style="display:block;font-size:11.5px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:6px;">Activity / Duty Restrictions</label>
                                            <select id="doc_gen_restrictions" onchange="diorDocUpdateStandaloneLetterPreview()" style="width:100%;padding:10px 12px;border:1.5px solid #CBD5E1;border-radius:8px;font-size:13px;background:#FFF;color:#0F172A;outline:none;">
                                                <option value="Full Rest / Excused from all duties">Full Rest / Excused from all duties</option>
                                                <option value="Light duty only (no heavy lifting > 10 lbs)">Light duty only (no heavy lifting > 10 lbs)</option>
                                                <option value="Modified hours / Remote work permitted">Modified hours / Remote work permitted</option>
                                                <option value="Full clearance / Return without restrictions">Full clearance / Return without restrictions</option>
                                                <option value="Exempt from physical education / sports">Exempt from physical education / sports</option>
                                            </select>
                                        </div>

                                        <div style="margin-bottom:20px;">
                                            <label style="display:block;font-size:11.5px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:6px;">Physician Remarks & Clinical Instructions</label>
                                            <textarea id="doc_gen_remarks" rows="3" placeholder="Patient has been clinically assessed via telehealth. Patient is advised adequate rest and hydration..." oninput="diorDocUpdateStandaloneLetterPreview()" style="width:100%;padding:10px 12px;border:1.5px solid #CBD5E1;border-radius:8px;font-size:13px;font-family:inherit;box-sizing:border-box;outline:none;"></textarea>
                                        </div>

                                        <div style="display:flex;gap:10px;justify-content:flex-end;">
                                            <button type="button" class="dior-btn-sm dior-btn-ghost" onclick="diorDocPrintStandalonePreview()" style="height:38px;padding:0 18px;font-size:13px;">
                                                <i class="fa-solid fa-print"></i> Print / Save PDF
                                            </button>
                                            <button type="submit" id="doc-gen-submit-btn" class="dior-btn-sm dior-btn-purple" style="height:38px;padding:0 22px;font-size:13px;">
                                                <i class="fa-solid fa-paper-plane"></i> Publish to Patient Portal
                                            </button>
                                        </div>

                                    </form>
                                </div>
                            </div>

                            <!-- Live Preview Card -->
                            <div class="dior-card">
                                <div class="dior-card-header">
                                    <h3><i class="fa-solid fa-certificate" style="color:#2C6CB1;"></i> Certified Letterhead Preview</h3>
                                </div>
                                <div class="dior-card-body" style="padding:22px;">
                                    <div id="doc-standalone-letter-preview-box" style="background:#FFFFFF;border:1.5px solid #E2E8F0;border-radius:12px;padding:28px;box-shadow:0 4px 20px rgba(11,16,48,0.06);">
                                        <div style="display:flex;justify-content:space-between;border-bottom:2px solid #0F172A;padding-bottom:14px;margin-bottom:18px;">
                                            <div>
                                                <h2 style="margin:0;font-family:'Montserrat',sans-serif;font-size:18px;font-weight:800;color:#0F172A;letter-spacing:0.5px;">DIOR MEDICAL</h2>
                                                <p style="margin:2px 0 0;font-size:11px;color:#64748B;">Telehealth & Virtual Urgent Care &bull; www.diormedical.com</p>
                                            </div>
                                            <div style="text-align:right;">
                                                <span class="dior-badge-pill dior-badge-emerald">Certified Medical Attestation</span>
                                                <div style="font-size:11px;color:#64748B;margin-top:4px;">Date: <strong><?php echo date('M j, Y'); ?></strong></div>
                                            </div>
                                        </div>
                                        <div id="doc-standalone-letter-preview-content" style="font-size:13.5px;line-height:1.7;color:#334155;min-height:220px;">
                                            <p style="color:#94A3B8;text-align:center;padding:40px 0;">Please select a patient from the dropdown on the left to generate the live letterhead preview.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </section>



                <!-- ── SETTINGS ── -->
                <section class="dior-tab-panel" id="tab-doc-settings">
                    <div class="dior-content-pad">
                        <div class="dior-page-title-bar">
                            <div class="title-left">
                                <div class="title-icon-box">
                                    <i class="fa-solid fa-gear"></i>
                                </div>
                                <div>
                                    <h1>Provider Settings</h1>
                                    <p class="title-sub">Manage your profile, credentials and availability.</p>
                                </div>
                            </div>
                        </div>
                        <div class="dior-card"
                            style="border:1px solid #E2E8F0;border-radius:16px;overflow:hidden;box-shadow:0 2px 12px rgba(11,16,48,0.04);">
                            <div
                                style="padding:18px 24px;border-bottom:1px solid #F1F5F9;display:flex;align-items:center;gap:10px;background:#FAFBFC;">
                                <div
                                    style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#EBF3FA,#D0E1F9);display:flex;align-items:center;justify-content:center;color:#2C6CB1;font-size:15px;flex-shrink:0;">
                                    <i class="fa-solid fa-user-doctor"></i>
                                </div>
                                <div>
                                    <h3
                                        style="margin:0;font-size:15px;font-weight:700;color:#0B1030;font-family:'DMSans','DM Sans',sans-serif;">
                                        Provider Profile</h3>
                                    <p style="margin:2px 0 0;font-size:12px;color:#64748B;">Update your professional
                                        credentials and bio.</p>
                                </div>
                            </div>
                            <div style="padding:24px;">
                                <form id="dior-doc-profile-form" onsubmit="diorDocSaveProfile(event)">
                                    <div
                                        style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
                                        <div>
                                            <label
                                                style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">First
                                                Name <span style="color:#DC2626;">*</span></label>
                                            <input type="text" name="first_name"
                                                value="<?php echo esc_attr($doctor['first_name']); ?>" required
                                                style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;transition:border-color 0.18s ease;">
                                        </div>
                                        <div>
                                            <label
                                                style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Last
                                                Name <span style="color:#DC2626;">*</span></label>
                                            <input type="text" name="last_name"
                                                value="<?php echo esc_attr($doctor['last_name']); ?>" required
                                                style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;transition:border-color 0.18s ease;">
                                        </div>
                                    </div>
                                    <div
                                        style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
                                        <div>
                                            <label
                                                style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Specialty</label>
                                            <input type="text" name="doctor_specialty"
                                                value="<?php echo esc_attr($doctor['specialty']); ?>"
                                                style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;transition:border-color 0.18s ease;">
                                        </div>
                                        <div>
                                            <label
                                                style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">License
                                                Number</label>
                                            <input type="text" name="doctor_license"
                                                value="<?php echo esc_attr($doctor['license_no']); ?>"
                                                style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;transition:border-color 0.18s ease;">
                                        </div>
                                    </div>
                                    <div
                                        style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
                                        <div>
                                            <label
                                                style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">NPI
                                                Number</label>
                                            <input type="text" name="doctor_npi"
                                                value="<?php echo esc_attr($doctor['npi']); ?>"
                                                placeholder="10-digit NPI"
                                                style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;transition:border-color 0.18s ease;">
                                        </div>
                                        <div>
                                            <label
                                                style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Phone</label>
                                            <input type="text" name="phone"
                                                value="<?php echo esc_attr($doctor['phone']); ?>"
                                                style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;transition:border-color 0.18s ease;">
                                        </div>
                                    </div>
                                    <div style="margin-bottom:20px;">
                                        <label
                                            style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;"><i class="fa-solid fa-video" style="color:#2D8CFF;"></i> Doctor Zoom / Telehealth Meeting Link</label>
                                        <input type="url" name="doctor_zoom_link"
                                            value="<?php echo esc_attr($doctor['zoom_link'] ?? ''); ?>"
                                            placeholder="https://zoom.us/j/your-meeting-id or personal meeting room URL"
                                            style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;transition:border-color 0.18s ease;">
                                    </div>
                                    <div style="margin-bottom:20px;">
                                        <label
                                            style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Professional
                                            Bio</label>
                                        <textarea name="doctor_bio" rows="4"
                                            style="width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;resize:vertical;transition:border-color 0.18s ease;"><?php echo esc_textarea($doctor['bio']); ?></textarea>
                                    </div>
                                    <input type="hidden" name="nonce" value="<?php echo esc_attr($nonce); ?>">
                                    <button type="submit"
                                        style="display:inline-flex;align-items:center;gap:8px;padding:12px 24px;border-radius:10px;font-size:14px;font-weight:700;font-family:'Montserrat',sans-serif;background:linear-gradient(135deg,#2C6CB1,#1A528E);color:#FFFFFF;border:none;cursor:pointer;box-shadow:0 4px 16px rgba(44,108,177,0.28);transition:all 0.2s ease;">
                                        <i class="fa-solid fa-floppy-disk"></i> Save Profile
                                    </button>
                                </form>
                                <div id="dior-doc-profile-msg"
                                    style="display:none;margin-top:16px;padding:14px 18px;border-radius:10px;font-size:13.5px;font-weight:600;font-family:'DMSans','DM Sans',sans-serif;">
                                </div>
                            </div>
                        </div>

                        <!-- Account Security & Password Card -->
                        <div class="dior-card"
                            style="margin-top:24px;border:1px solid #E2E8F0;border-radius:16px;overflow:hidden;box-shadow:0 2px 12px rgba(11,16,48,0.04);">
                            <div
                                style="padding:18px 24px;border-bottom:1px solid #F1F5F9;display:flex;align-items:center;gap:10px;background:#FAFBFC;">
                                <div
                                    style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#EBF3FA,#D0E1F9);display:flex;align-items:center;justify-content:center;color:#2C6CB1;font-size:15px;flex-shrink:0;">
                                    <i class="fa-solid fa-shield-halved"></i>
                                </div>
                                <div>
                                    <h3
                                        style="margin:0;font-size:15px;font-weight:700;color:#2C6CB1;font-family:'DMSans','DM Sans',sans-serif;">
                                        Account Security & Password</h3>
                                    <p style="margin:2px 0 0;font-size:12px;color:#64748B;">Update your login password with secure encrypted authentication.</p>
                                </div>
                            </div>
                            <div style="padding:24px;">
                                <form id="dior-doc-password-form" onsubmit="diorDocChangePassword(event)">
                                    <div style="margin-bottom:16px;max-width:540px;">
                                        <label
                                            style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Current
                                            Password <span style="color:#DC2626;">*</span></label>
                                        <div style="position:relative;">
                                            <input type="password" name="current_password" id="doc-cur-pwd" required placeholder="Enter your current password"
                                                style="width:100%;padding:11px 40px 11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;">
                                            <button type="button" onclick="diorDocTogglePwd('doc-cur-pwd', this)" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:#94A3B8;cursor:pointer;padding:4px;display:flex;align-items:center;justify-content:center;">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                            </button>
                                        </div>
                                    </div>
                                    <div
                                        style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;max-width:760px;">
                                        <div>
                                            <label
                                                style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">New
                                                Password <span style="color:#DC2626;">*</span></label>
                                            <div style="position:relative;">
                                                <input type="password" name="new_password" id="doc-new-pwd" required minlength="6" placeholder="Min. 6 characters"
                                                    style="width:100%;padding:11px 40px 11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;">
                                                <button type="button" onclick="diorDocTogglePwd('doc-new-pwd', this)" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:#94A3B8;cursor:pointer;padding:4px;display:flex;align-items:center;justify-content:center;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                                </button>
                                            </div>
                                        </div>
                                        <div>
                                            <label
                                                style="display:block;font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:7px;font-family:'Montserrat',sans-serif;">Confirm
                                                New Password <span style="color:#DC2626;">*</span></label>
                                            <div style="position:relative;">
                                                <input type="password" name="confirm_password" id="doc-cnf-pwd" required minlength="6" placeholder="Re-type new password"
                                                    style="width:100%;padding:11px 40px 11px 14px;border:1.5px solid #E2E8F0;border-radius:10px;font-size:13.5px;font-family:'DMSans','DM Sans',sans-serif;color:#0F172A;background:#FFFFFF;outline:none;box-sizing:border-box;">
                                                <button type="button" onclick="diorDocTogglePwd('doc-cnf-pwd', this)" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:#94A3B8;cursor:pointer;padding:4px;display:flex;align-items:center;justify-content:center;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" id="doc-pwd-submit-btn"
                                        style="display:inline-flex;align-items:center;gap:8px;padding:12px 24px;border-radius:10px;font-size:14px;font-weight:700;font-family:'Montserrat',sans-serif;background:linear-gradient(135deg,#2C6CB1,#1A528E);color:#FFFFFF;border:none;cursor:pointer;box-shadow:0 4px 16px rgba(44,108,177,0.28);transition:all 0.2s ease;">
                                        <i class="fa-solid fa-key"></i> Update Password
                                    </button>
                                </form>
                                <div id="dior-doc-password-msg"
                                    style="display:none;margin-top:16px;padding:14px 18px;border-radius:10px;font-size:13.5px;font-weight:600;font-family:'DMSans','DM Sans',sans-serif;">
                                </div>
                            </div>
                        </div>

                        <?php if (shortcode_exists('docbooker_provider_settings')): ?>
                            <div class="dior-card" style="margin-top:20px;">
                                <div class="dior-card-header">
                                    <h3><i class="fa-solid fa-calendar-days"></i> DocBooker Pro — Availability</h3>
                                </div>
                                <div class="dior-card-body"><?php echo do_shortcode('[docbooker_provider_settings]'); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>

            </div><!-- /tab-content -->
        </main>
    </div><!-- /dior-app -->
</div><!-- /dior-doctor-wrap -->

<!-- Patient Detail Modal -->
<div class="dior-modal-overlay" id="modal-doc-patient">
    <div class="dior-modal-dialog dior-modal-lg">
        <div class="dior-modal-header">
            <h3 id="modal-doc-patient-title">Patient Detail</h3>
            <button type="button" class="dior-modal-close" onclick="diorDocCloseModal()">&times;</button>
        </div>
        <div class="dior-modal-body" id="modal-doc-patient-body">
            <div style="text-align:center;padding:32px;">
                <i class="fa-solid fa-spinner fa-spin fa-2x" style="color:#2C6CB1;"></i>
            </div>
        </div>
    </div>
</div>

<!-- Secure Document Upload Modal -->
<div class="dior-modal-overlay" id="modal-doc-upload">
    <div class="dior-modal-dialog" style="max-width: 540px; border-radius: 14px; overflow: hidden; background: #FFFFFF; box-shadow: 0 20px 50px rgba(15,23,42,0.25); padding: 0;">
        <div class="dior-modal-header" style="background: linear-gradient(135deg, #0B1030 0%, #1A2552 100%); color: #FFFFFF; padding: 18px 24px;">
            <h3 style="margin: 0; font-size: 16px; font-weight: 700; color: #FFFFFF; display: flex; align-items: center; gap: 8px;">
                <i class="fa-solid fa-cloud-arrow-up" style="color: #60A5FA;"></i> Upload Clinical Document
            </h3>
            <button type="button" class="dior-modal-close" onclick="diorDocCloseUploadModal()" style="color: #94A3B8; font-size: 22px;">&times;</button>
        </div>
        <div class="dior-modal-body" style="padding: 24px;">
            <form id="dior-doc-upload-form" onsubmit="diorDocSubmitUpload(event)">
                <div style="margin-bottom: 16px;">
                    <label style="display:block; font-size: 11.5px; font-weight: 700; color: #374151; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 6px;">Select Patient <span style="color:#EF4444;">*</span></label>
                    <select name="patient_id" required style="width: 100%; padding: 10px 12px; border: 1.5px solid #CBD5E1; border-radius: 8px; font-size: 13.5px; background: #FFF; color: #0F172A; outline: none;">
                        <option value="">-- Select Patient --</option>
                        <?php if (!empty($patients)): ?>
                            <?php foreach ($patients as $p): ?>
                                <option value="<?php echo (int)$p['user_id']; ?>">
                                    <?php echo esc_html($p['full_name']); ?> (<?php echo esc_html($p['patient_id']); ?>)
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 16px;">
                    <div>
                        <label style="display:block; font-size: 11.5px; font-weight: 700; color: #374151; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 6px;">Category <span style="color:#EF4444;">*</span></label>
                        <select name="doc_category" required style="width: 100%; padding: 10px 12px; border: 1.5px solid #CBD5E1; border-radius: 8px; font-size: 13.5px; background: #FFF; color: #0F172A; outline: none;">
                            <option value="Lab Report">Lab Report</option>
                            <option value="Imaging / Radiology">Imaging / Radiology</option>
                            <option value="Medical Record">Medical Record</option>
                            <option value="Doctor Excuse Note">Doctor Excuse Note</option>
                            <option value="Signed Consent (HIPAAtizer)">Signed Consent (HIPAA)</option>
                            <option value="Prescription / Rx">Prescription / Rx</option>
                            <option value="Referral Letter">Referral Letter</option>
                            <option value="Other">Other Clinical Document</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block; font-size: 11.5px; font-weight: 700; color: #374151; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 6px;">Document Title <span style="color:#EF4444;">*</span></label>
                        <input type="text" name="doc_title" required placeholder="e.g. CBC & Metabolic Lab Panel" style="width: 100%; padding: 10px 12px; border: 1.5px solid #CBD5E1; border-radius: 8px; font-size: 13.5px; box-sizing: border-box; outline: none;">
                    </div>
                </div>

                <div style="margin-bottom: 16px;">
                    <label style="display:block; font-size: 11.5px; font-weight: 700; color: #374151; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 6px;">Select File (PDF, PNG, JPG, DOCX) <span style="color:#EF4444;">*</span></label>
                    <div style="border: 2px dashed #CBD5E1; border-radius: 10px; padding: 20px; text-align: center; background: #F8FAFC; transition: all 0.2s ease;">
                        <input type="file" name="doc_file" id="doc_file_input" required accept=".pdf,.png,.jpg,.jpeg,.doc,.docx" style="display: block; width: 100%; font-size: 13px; color: #475569;">
                        <span style="font-size: 11.5px; color: #94A3B8; display: block; margin-top: 8px;">Max file size: 25MB. Files are automatically stored in the secure protected vault.</span>
                    </div>
                </div>

                <div style="margin-bottom: 20px;">
                    <label style="display:block; font-size: 11.5px; font-weight: 700; color: #374151; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 6px;">Clinical Notes / Remarks (Optional)</label>
                    <textarea name="doc_notes" rows="2" placeholder="Add confidential clinical context or review notes..." style="width: 100%; padding: 10px 12px; border: 1.5px solid #CBD5E1; border-radius: 8px; font-size: 13px; box-sizing: border-box; outline: none;"></textarea>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="dior-btn-sm dior-btn-ghost" onclick="diorDocCloseUploadModal()" style="height: 38px; padding: 0 18px; font-size: 13px;">
                        Cancel
                    </button>
                    <button type="submit" id="doc-upload-submit-btn" class="dior-btn-sm dior-btn-primary" style="height: 38px; padding: 0 20px; font-size: 13px;">
                        <i class="fa-solid fa-cloud-arrow-up"></i> Upload & Secure File
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Video Call Date/Status Alert Modal -->
<div class="dior-modal-overlay" id="dior-call-alert-modal" style="z-index: 999999;">
    <div class="dior-modal-dialog" style="max-width: 460px; border-radius: 14px; overflow: hidden; box-shadow: 0 20px 50px rgba(15,23,42,0.35); padding: 0; background: #FFFFFF; margin: auto;">
        <div style="background: #0F172A; color: #FFFFFF; padding: 16px 20px; display: flex; align-items: center; justify-content: space-between;">
            <h3 id="dior-call-alert-title" style="margin: 0; font-size: 15px; font-weight: 700; color: #FFFFFF;"><i class="fa-solid fa-video"></i> Video Consultation</h3>
            <button type="button" onclick="diorDocCloseCallAlert()" style="background:none; border:none; color:#94A3B8; font-size:22px; cursor:pointer; line-height:1;">&times;</button>
        </div>
        <div style="padding: 24px; text-align: center;">
            <div id="dior-call-alert-icon-wrap" style="margin-bottom: 16px;">
                <i class="fa-solid fa-calendar-check" style="font-size: 36px; color: #0284C7;"></i>
            </div>
            <div id="dior-call-alert-msg" style="font-size: 14px; color: #334155; line-height: 1.6; margin-bottom: 24px;"></div>
            <div style="display: flex; align-items: center; justify-content: center; gap: 10px; flex-wrap: wrap;">
                <button type="button" onclick="diorDocCloseCallAlert()" style="padding: 9px 20px; border-radius: 8px; font-size: 13px; font-weight: 600; border: 1px solid #CBD5E1; background: #F8FAFC; color: #475569; cursor: pointer; transition: all 0.2s ease;">
                    Close
                </button>
                <button type="button" id="dior-call-alert-override" style="display: none; padding: 9px 20px; border-radius: 8px; font-size: 13px; font-weight: 700; border: none; background: linear-gradient(135deg, #059669 0%, #047857 100%); color: #FFFFFF; cursor: pointer; box-shadow: 0 2px 8px rgba(5,150,105,0.3); transition: all 0.2s ease;">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i> Launch Room Anyway
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    window.diorDocNonce = '<?php echo esc_js($nonce); ?>';
    window.diorDocAjax = '<?php echo esc_url(admin_url('admin-ajax.php')); ?>';
    var diorDocNonce = window.diorDocNonce;
    var diorDocAjax = window.diorDocAjax;
    if (!window.pdmTab) {
        window.pdmTab = function(btn, targetId) {
            if (!btn && !targetId) return;
            var button = (btn && btn.closest) ? (btn.closest('.dior-pdm-tab-btn') || btn) : document.querySelector('.dior-pdm-tab-btn[data-tab="' + targetId + '"]');
            var wrap = (button && button.closest('.dior-pdm')) || document.getElementById('modal-doc-patient-body') || document;
            wrap.querySelectorAll('.dior-pdm-tab-btn').forEach(function(b) { b.classList.remove('active'); });
            if (button) button.classList.add('active');
            wrap.querySelectorAll('.dior-pdm-tab-pane').forEach(function(p) { p.classList.remove('active'); p.style.display = 'none'; });
            var target = wrap.querySelector('#' + targetId) || document.getElementById(targetId);
            if (target) { target.classList.add('active'); target.style.display = 'block'; }
        };
    }
</script>