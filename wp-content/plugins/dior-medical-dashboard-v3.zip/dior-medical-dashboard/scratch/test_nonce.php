<?php
require_once 'c:/xampp/htdocs/diormedical/wp-load.php';
require_once 'c:/xampp/htdocs/diormedical/wp-content/plugins/dior-medical-dashboard/dior-medical-dashboard.php';

echo "Testing verify_ajax_nonce with user 2:\n";
wp_set_current_user(2);

$_REQUEST['nonce'] = 'invalid_stale_nonce';
try {
    $res = Dior_Auth_Service::verify_ajax_nonce(['dior_portal_nonce']);
    echo "Result for logged in user with stale nonce: " . ($res ? "PASSED (Safe)" : "FAILED") . "\n";
} catch (Exception $e) {
    echo "Exception: " . $e->getMessage() . "\n";
}

echo "Testing verify_ajax_nonce with guest:\n";
wp_set_current_user(0);
$_REQUEST['nonce'] = wp_create_nonce('dior_portal_nonce');
$res_guest = Dior_Auth_Service::verify_ajax_nonce(['dior_portal_nonce']);
echo "Result for guest with valid nonce: " . ($res_guest ? "PASSED" : "FAILED") . "\n";
