<?php
require_once 'c:/xampp/htdocs/diormedical/wp-load.php';

wp_set_current_user(2);
echo "Current user ID: " . get_current_user_id() . "\n";
echo "is_user_logged_in: " . (is_user_logged_in() ? 'YES' : 'NO') . "\n";

$valid_nonce = wp_create_nonce('dior_portal_nonce');
echo "Valid nonce: $valid_nonce\n";
echo "Verify valid nonce: " . (wp_verify_nonce($valid_nonce, 'dior_portal_nonce') ? 'YES' : 'NO') . "\n";
echo "Verify invalid nonce: " . (wp_verify_nonce('bad_nonce', 'dior_portal_nonce') ? 'YES' : 'NO') . "\n";
