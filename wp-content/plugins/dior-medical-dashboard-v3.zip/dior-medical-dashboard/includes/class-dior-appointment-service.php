<?php
/**
 * Dior Medical - Appointment Engine & Scheduling State Machine
 * 
 * Manages appointment scheduling, doctor queues, valid lifecycle transitions,
 * double-booking prevention, and indexed database queries.
 * 
 * @package Dior Medical
 * @version 3.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class Dior_Appointment_Service
{
    /**
     * Valid state transitions map
     */
    private static $valid_transitions = [
        'Pending'     => ['Confirmed', 'Cancelled'],
        'Confirmed'   => ['In Progress', 'Completed', 'Cancelled', 'No Show'],
        'In Progress' => ['Completed', 'Cancelled'],
        'Completed'   => [],
        'Cancelled'   => [],
        'No Show'     => []
    ];

    /**
     * Book a new appointment
     */
    public static function book_appointment(array $data)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dior_appointments';

        $patient_id = Dior_Auth_Service::validate_id($data['patient_id'] ?? 0);
        if (!$patient_id) {
            return new WP_Error('invalid_patient', 'Valid Patient ID is required.');
        }

        $current_user_id = Dior_Auth_Service::get_current_user_id();
        if ($current_user_id && !Dior_Auth_Service::can_access_patient($patient_id, $current_user_id)) {
            Dior_Audit_Service::log('appointment_book', 'appointment', 'unauthorized', $patient_id, 'denied');
            return new WP_Error('unauthorized', 'Unauthorized to book appointment for this patient.');
        }

        $doctor_id = (int)($data['doctor_id'] ?? 1);
        $condition = sanitize_text_field($data['condition'] ?? 'Urgent Care Telehealth');
        $visit_type = sanitize_text_field($data['visit_type'] ?? 'Video Visit (HD)');
        $appt_date = Dior_Auth_Service::validate_date($data['appt_date'] ?? date('Y-m-d'));
        if (empty($appt_date)) {
            $appt_date = date('Y-m-d');
        }
        $appt_time = sanitize_text_field($data['appt_time'] ?? 'Today - ASAP');
        $join_url = esc_url_raw($data['join_url'] ?? 'https://zoom.us/join');
        $payment_status = Dior_Auth_Service::validate_enum($data['payment_status'] ?? 'Paid', ['Pending', 'Paid', 'Refunded', 'Failed'], 'Paid');
        $notes = sanitize_textarea_field($data['notes'] ?? '');

        // Check for double booking race-condition
        $duplicate = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE patient_id = %d AND appt_date = %s AND appt_time = %s AND status NOT IN ('Cancelled', 'No Show') AND is_deleted = 0",
            $patient_id, $appt_date, $appt_time
        ));

        if ($duplicate) {
            return new WP_Error('duplicate_booking', 'An active appointment is already scheduled for this time slot.');
        }

        $appt_uid = 'APT-' . rand(1000, 9999);
        $now = current_time('mysql');

        $inserted = $wpdb->insert($table, [
            'appt_uid'       => $appt_uid,
            'patient_id'     => $patient_id,
            'doctor_id'      => $doctor_id,
            'condition_name' => $condition,
            'visit_type'     => $visit_type,
            'status'         => 'Confirmed',
            'appt_date'      => $appt_date,
            'appt_time'      => $appt_time,
            'join_url'       => $join_url,
            'payment_status' => $payment_status,
            'notes'          => $notes,
            'created_at'     => $now,
            'updated_at'     => $now,
            'is_deleted'     => 0
        ]);

        if (!$inserted) {
            return new WP_Error('db_error', 'Failed to schedule appointment.');
        }

        Dior_Audit_Service::log('appointment_book', 'appointment', $appt_uid, $patient_id, 'success', [
            'doctor_id' => $doctor_id,
            'date'      => $appt_date,
            'time'      => $appt_time
        ]);

        self::sync_legacy_usermeta($patient_id);

        return self::get_appointment_by_uid($appt_uid);
    }

    /**
     * Transition appointment status with state machine validation
     */
    public static function update_status($appt_uid, $new_status)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dior_appointments';

        $appt = self::get_appointment_by_uid($appt_uid);
        if (!$appt) {
            return new WP_Error('not_found', 'Appointment not found.');
        }

        $current_user_id = Dior_Auth_Service::get_current_user_id();
        $is_doc = Dior_Auth_Service::is_doctor($current_user_id);
        $is_pat = (int)$appt['patient_id'] === $current_user_id;

        if (!$is_doc && !$is_pat) {
            Dior_Audit_Service::log('appointment_status_change', 'appointment', $appt_uid, $appt['patient_id'], 'denied');
            return new WP_Error('unauthorized', 'Unauthorized to modify this appointment.');
        }

        // Patients can only cancel their own appointments
        if (!$is_doc && $is_pat && $new_status !== 'Cancelled') {
            return new WP_Error('unauthorized', 'Patients can only cancel pending or confirmed appointments.');
        }

        $curr_status = $appt['status'];
        $allowed_next = self::$valid_transitions[$curr_status] ?? [];

        if (!in_array($new_status, $allowed_next, true) && !Dior_Auth_Service::is_admin($current_user_id)) {
            return new WP_Error('invalid_transition', "Cannot transition appointment from '{$curr_status}' to '{$new_status}'.");
        }

        $now = current_time('mysql');
        $updated = $wpdb->update(
            $table,
            ['status' => $new_status, 'updated_at' => $now],
            ['appt_uid' => $appt_uid]
        );

        if ($updated !== false) {
            Dior_Audit_Service::log('appointment_status_change', 'appointment', $appt_uid, $appt['patient_id'], 'success', [
                'from_status' => $curr_status,
                'to_status'   => $new_status
            ]);

            self::sync_legacy_usermeta($appt['patient_id']);
            return true;
        }

        return false;
    }

    /**
     * Get single appointment by UID
     */
    public static function get_appointment_by_uid($appt_uid)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dior_appointments';

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE appt_uid = %s AND is_deleted = 0",
            $appt_uid
        ), ARRAY_A);
    }

    /**
     * Get appointments for a patient
     */
    public static function get_patient_appointments($patient_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dior_appointments';
        $patient_id = (int)$patient_id;

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE patient_id = %d AND is_deleted = 0 ORDER BY appt_date DESC, id DESC",
            $patient_id
        ), ARRAY_A);

        return $results ?: [];
    }

    /**
     * Get all appointments for doctor dashboard (Optimized indexed SQL query)
     */
    public static function get_doctor_appointments($doctor_id = 0, $status = null, $date = null)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dior_appointments';

        $where = ['a.is_deleted = 0'];
        $params = [];

        $is_admin = Dior_Auth_Service::is_admin($doctor_id);
        $default_doc_id = class_exists('Dior_Doctor_Resolver') ? Dior_Doctor_Resolver::get_default_doctor_id() : 0;

        // Strict Doctor Filtering: Each doctor only sees their own appointments
        if (!$is_admin && $doctor_id) {
            $linked_post_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wpddb_doctor_user_id' AND meta_value = %s",
                (string)$doctor_id
            ));
            
            $allowed_ids = array_unique(array_filter(array_merge([(int)$doctor_id], array_map('intval', (array)$linked_post_ids))));
            
            // If primary clinic default doctor, allow general/unassigned appointments
            if ($doctor_id == $default_doc_id) {
                $allowed_ids[] = 0;
                $allowed_ids[] = 1;
                $allowed_ids = array_unique($allowed_ids);
            }

            $in_placeholders = implode(',', array_fill(0, count($allowed_ids), '%d'));
            $where[] = "a.doctor_id IN ($in_placeholders)";
            foreach ($allowed_ids as $aid) {
                $params[] = $aid;
            }
        }

        if (!empty($status)) {
            $where[] = 'a.status = %s';
            $params[] = $status;
        }

        if (!empty($date)) {
            $where[] = 'a.appt_date = %s';
            $params[] = $date;
        }

        $where_sql = implode(' AND ', $where);
        $sql = "SELECT a.*, 
                       u.display_name as patient_display_name, 
                       u.user_email as patient_email
                FROM $table a
                LEFT JOIN {$wpdb->users} u ON a.patient_id = u.ID
                WHERE $where_sql
                ORDER BY a.appt_date DESC, a.id DESC";

        $results = !empty($params) ? $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);

        if (!$results) return [];

        // Attach resolved metadata
        foreach ($results as &$r) {
            $pid = (int)$r['patient_id'];
            $fn = get_user_meta($pid, 'first_name', true);
            $ln = get_user_meta($pid, 'last_name', true);
            $fullName = trim($fn . ' ' . $ln);
            $r['user_id'] = $pid;
            $r['patient_user_id'] = $pid;
            $r['patient_name'] = $fullName ?: ($r['patient_display_name'] ?: 'Patient');
            $r['patient_id_meta'] = get_user_meta($pid, 'patient_id', true) ?: ('DM-' . (10000 + $pid));
            $r['phone'] = get_user_meta($pid, 'phone', true) ?: '—';
            $r['id'] = $r['appt_uid'];
            $r['date'] = $r['appt_date'];
            $r['time'] = $r['appt_time'];
            $r['condition'] = $r['condition_name'];
            $r['type'] = $r['visit_type'];
        }

        return $results;
    }

    /**
     * Dual-write / sync to legacy user meta for backwards compatibility
     */
    private static function sync_legacy_usermeta($patient_id)
    {
        $apts = self::get_patient_appointments($patient_id);
        $legacy = [];
        foreach ($apts as $a) {
            $legacy[] = [
                'id'             => $a['appt_uid'],
                'date'           => $a['appt_date'],
                'time'           => $a['appt_time'],
                'condition'      => $a['condition_name'],
                'provider'       => 'Dr. Evelyn Vance, MD',
                'provider_spec'  => 'Board Certified Urgent Care Physician',
                'type'           => $a['visit_type'],
                'status'         => $a['status'],
                'join_url'       => $a['join_url'],
                'payment_status' => $a['payment_status'],
                'notes'          => $a['notes'],
                'can_join'       => in_array($a['status'], ['Confirmed', 'In Progress'])
            ];
        }
        update_user_meta($patient_id, 'dior_appointments', $legacy);
    }
}
