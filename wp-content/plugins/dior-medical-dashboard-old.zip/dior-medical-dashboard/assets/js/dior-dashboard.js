/**
 * Dior Medical - Luxury Telehealth Patient Portal Interactive JS
 * Full State & AJAX Controller for Dashboard Modules, Modals, Forms & Widgets
 */

window.diorToggleNotifDropdown = function(e) {
    if (e) {
        if (typeof e.preventDefault === 'function') e.preventDefault();
        if (typeof e.stopPropagation === 'function') e.stopPropagation();
    }
    const dropdown = document.getElementById('dior-notif-dropdown');
    if (dropdown) {
        dropdown.classList.toggle('open');
    }
};

document.addEventListener('click', function(e) {
    const wrap = document.getElementById('dior-notif-dropdown-wrap');
    const dropdown = document.getElementById('dior-notif-dropdown');
    if (dropdown && dropdown.classList.contains('open')) {
        if (!wrap || !wrap.contains(e.target)) {
            dropdown.classList.remove('open');
        }
    }
});

// Universal Table Pagination (5 entries per page)
window.diorInitTablePagination = function(tableEl, pageSize) {
    if (!tableEl) return;
    pageSize = pageSize || 5;
    const tbody = tableEl.querySelector('tbody');
    if (!tbody) return;

    // Find parent container to attach pagination bar
    let parent = tableEl.parentElement;
    let paginationWrap = parent.querySelector(':scope > .dior-table-pagination') || (parent.parentElement ? parent.parentElement.querySelector(':scope > .dior-table-pagination') : null);
    
    if (!paginationWrap) {
        paginationWrap = document.createElement('div');
        paginationWrap.className = 'dior-table-pagination';
        // If wrapped inside a responsive container, put it outside/after the responsive container
        if (parent.classList.contains('dior-table-responsive') || parent.classList.contains('dior-card-body') || parent.style.overflowX === 'auto' || parent.style.overflow === 'auto') {
            parent.after(paginationWrap);
        } else {
            parent.appendChild(paginationWrap);
        }
    }

    let currentPage = 1;

    function renderPage(page) {
        currentPage = page || 1;
        const allRows = Array.from(tbody.querySelectorAll('tr')).filter(tr => !tr.classList.contains('dior-no-data-row') && tr.querySelectorAll('td').length > 1);
        
        if (allRows.length === 0) {
            paginationWrap.style.display = 'none';
            return;
        }

        const activeRows = allRows.filter(tr => tr.getAttribute('data-filter-hidden') !== 'true');
        const total = activeRows.length;
        const totalPages = Math.max(1, Math.ceil(total / pageSize));

        if (currentPage > totalPages) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;

        const startIndex = (currentPage - 1) * pageSize;
        const endIndex = startIndex + pageSize;

        // Apply visibility
        allRows.forEach(tr => {
            if (tr.getAttribute('data-filter-hidden') === 'true') {
                tr.style.display = 'none';
            }
        });

        activeRows.forEach((tr, index) => {
            if (index >= startIndex && index < endIndex) {
                tr.style.display = '';
            } else {
                tr.style.display = 'none';
            }
        });

        // Hide pagination controls if 5 or fewer entries
        if (totalPages <= 1) {
            paginationWrap.style.display = 'none';
            return;
        }

        const fromItem = total === 0 ? 0 : startIndex + 1;
        const toItem = Math.min(endIndex, total);

        let navHtml = '';
        if (totalPages > 1) {
            navHtml += `<button type="button" class="dior-page-btn" ${currentPage === 1 ? 'disabled' : ''} data-page="${currentPage - 1}" title="Previous Page"><i class="fa-solid fa-chevron-left" style="font-size:11px;"></i></button>`;

            for (let i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
                    navHtml += `<button type="button" class="dior-page-btn ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
                } else if (i === currentPage - 2 || i === currentPage + 2) {
                    navHtml += `<span style="padding: 0 4px; color: #94A3B8; font-size:12px;">...</span>`;
                }
            }

            navHtml += `<button type="button" class="dior-page-btn" ${currentPage === totalPages ? 'disabled' : ''} data-page="${currentPage + 1}" title="Next Page"><i class="fa-solid fa-chevron-right" style="font-size:11px;"></i></button>`;
        }

        paginationWrap.style.display = 'flex';
        paginationWrap.innerHTML = `
            <div class="dior-pagination-info">
                Showing <strong>${fromItem}</strong> to <strong>${toItem}</strong> of <strong>${total}</strong> entries
            </div>
            <div class="dior-pagination-nav">
                ${navHtml}
            </div>
        `;

        // Click listeners
        paginationWrap.querySelectorAll('.dior-page-btn[data-page]').forEach(btn => {
            btn.onclick = function(e) {
                e.preventDefault();
                const p = parseInt(this.getAttribute('data-page'), 10);
                if (!isNaN(p)) renderPage(p);
            };
        });
    }

    tableEl._diorRenderPage = renderPage;
    renderPage(1);
};

(function($) {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        const appWrap = document.getElementById('dior-patient-portal-app');
        if (!appWrap) {
            return;
        }

        // Initialize Pagination for all Patient Dashboard Tables (5 rows max per page)
        document.querySelectorAll('.dior-table, .dior-clean-table, .dior-doc-table').forEach(table => {
            diorInitTablePagination(table, 5);
        });

        // =========================================================================
        // 1. TOAST NOTIFICATION HELPER
        // =========================================================================
        function showToast(message, isError = false) {
            let toast = document.getElementById('dior-toast-alert');
            if (!toast) {
                toast = document.createElement('div');
                toast.id = 'dior-toast-alert';
                toast.className = 'dior-toast';
                document.body.appendChild(toast);
            }
            toast.textContent = message;
            toast.style.display = 'block';
            toast.style.borderLeftColor = isError ? 'var(--dior-danger)' : 'var(--dior-gold-500)';

            setTimeout(() => {
                toast.style.display = 'none';
            }, 4500);
        }

        // =========================================================================
        // 2. AJAX SENDER HELPER
        // =========================================================================
        function sendAjax(action, data, successCallback, errorCallback) {
            const formData = new FormData();
            formData.append('action', action);
            formData.append('nonce', dior_vars.nonce || '');

            for (let key in data) {
                formData.append(key, data[key]);
            }

            fetch(dior_vars.ajax_url, {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(response => {
                if (response.success) {
                    showToast(response.data.message || 'Action completed successfully.');
                    if (successCallback) successCallback(response.data);
                } else {
                    showToast((response.data && response.data.message) ? response.data.message : 'Error processing request.', true);
                    if (errorCallback) errorCallback(response.data);
                }
            })
            .catch(err => {
                showToast('Network error or server connection failed.', true);
                if (errorCallback) errorCallback(err);
            });
        }

        // =========================================================================
        // 3. TAB NAVIGATION & URL HASH SYNCHRONIZATION
        // =========================================================================
        const navButtons = document.querySelectorAll('.dior-nav-btn');
        const tabPanels = document.querySelectorAll('.dior-tab-panel');
        const pageTitleEl = document.getElementById('dior-current-page-title');

        const tabTitles = {
            'overview': 'Patient Overview',
            'profile': 'Profile & Telehealth Eligibility',
            'appointments': 'Telehealth Appointments',
            'payments': 'Billing & Payment Statements',
            'docs_meds': 'Medical Docs & Prescriptions',
            'questionnaire': 'Clinical Intake Questionnaires',
            'notifications': 'Notification Inbox'
        };

        function switchTab(tabId) {
            if (!document.getElementById('tab-' + tabId)) {
                tabId = 'overview';
            }

            navButtons.forEach(btn => {
                if (btn.getAttribute('data-tab') === tabId) {
                    btn.classList.add('active');
                    // Dynamic Badge Dismissal: Hide notification/count badge once opened
                    const activeBadge = btn.querySelector('.nav-count-badge');
                    if (activeBadge) {
                        activeBadge.style.display = 'none';
                        try {
                            sessionStorage.setItem('dior_dismissed_badge_' + tabId, '1');
                        } catch(e) {}
                    }
                } else {
                    btn.classList.remove('active');
                }
            });

            tabPanels.forEach(panel => {
                if (panel.id === 'tab-' + tabId) {
                    panel.classList.add('active');
                } else {
                    panel.classList.remove('active');
                }
            });

            if (pageTitleEl && tabTitles[tabId]) {
                pageTitleEl.textContent = tabTitles[tabId];
            }

            if (history.pushState) {
                history.pushState(null, null, '#tab=' + tabId);
            } else {
                location.hash = '#tab=' + tabId;
            }

            if (tabId === 'notifications') {
                document.querySelectorAll('.unread-badge-count, .dior-notif-indicator').forEach(b => {
                    b.style.display = 'none';
                });
                sendAjax('dior_patient_mark_all_notifications_read', {});
            }

            // Refresh table pagination inside activated tab
            const activePanel = document.getElementById('tab-' + tabId);
            if (activePanel) {
                activePanel.querySelectorAll('.dior-table, .dior-clean-table, .dior-doc-table').forEach(table => {
                    if (table._diorRenderPage) {
                        table._diorRenderPage(1);
                    } else {
                        diorInitTablePagination(table, 5);
                    }
                });
            }

            closeMobileDrawer();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        // Restore previously dismissed badges from session
        navButtons.forEach(btn => {
            const tab = btn.getAttribute('data-tab');
            if (tab) {
                try {
                    if (sessionStorage.getItem('dior_dismissed_badge_' + tab) === '1') {
                        const badge = btn.querySelector('.nav-count-badge');
                        if (badge) badge.style.display = 'none';
                    }
                } catch(e) {}
            }
        });

        navButtons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const tabId = this.getAttribute('data-tab');
                switchTab(tabId);
            });
        });

        // Delegate switch buttons across the dashboard
        document.addEventListener('click', function(e) {
            const target = e.target.closest('[data-switch-tab]');
            if (target) {
                e.preventDefault();
                const tabId = target.getAttribute('data-switch-tab');
                switchTab(tabId);
                // Also close notif dropdown if open
                const notifDropdown = document.getElementById('dior-notif-dropdown');
                if (notifDropdown) notifDropdown.classList.remove('open');
            }
        });

        // Deep linking via URL hash
        if (window.location.hash && window.location.hash.startsWith('#tab=')) {
            const hashTab = window.location.hash.replace('#tab=', '');
            switchTab(hashTab);
        }

        // =========================================================================
        // 4. MOBILE DRAWER NAVIGATION
        // =========================================================================
        const mobileToggle = document.getElementById('dior-mobile-menu-toggle');
        const sideClose = document.getElementById('dior-side-close');
        const sidebar = document.getElementById('dior-sidebar');
        const drawerBackdrop = document.getElementById('dior-drawer-backdrop');

        window.diorOpenMobileDrawer = function() {
            const sb = document.getElementById('dior-sidebar');
            const bg = document.getElementById('dior-drawer-backdrop');
            if (sb) sb.classList.add('mobile-open');
            if (bg) bg.classList.add('active');
            document.body.style.overflow = 'hidden';
        };

        window.diorCloseMobileDrawer = function() {
            const sb = document.getElementById('dior-sidebar');
            const bg = document.getElementById('dior-drawer-backdrop');
            if (sb) sb.classList.remove('mobile-open');
            if (bg) bg.classList.remove('active');
            document.body.style.overflow = '';
        };

        function openMobileDrawer() {
            window.diorOpenMobileDrawer();
        }

        function closeMobileDrawer() {
            window.diorCloseMobileDrawer();
        }

        if (mobileToggle) mobileToggle.addEventListener('click', window.diorOpenMobileDrawer);
        if (sideClose) sideClose.addEventListener('click', window.diorCloseMobileDrawer);
        if (drawerBackdrop) drawerBackdrop.addEventListener('click', window.diorCloseMobileDrawer);

        // =========================================================================
        // 5. MODAL SYSTEM
        // =========================================================================
        window.diorOpenModal = function(modalId) {
            const overlay = document.getElementById(modalId);
            if (overlay) {
                overlay.classList.add('open');
                document.body.style.overflow = 'hidden';
            }
        };

        window.diorCloseModal = function(modalId) {
            const overlay = document.getElementById(modalId);
            if (overlay) {
                overlay.classList.remove('open');
                document.body.style.overflow = '';
            }
        };

        document.querySelectorAll('.dior-modal-close').forEach(btn => {
            btn.addEventListener('click', function() {
                const overlay = this.closest('.dior-modal-overlay');
                if (overlay) {
                    overlay.classList.remove('open');
                    document.body.style.overflow = '';
                }
            });
        });

        document.querySelectorAll('.dior-modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('open');
                    document.body.style.overflow = '';
                }
            });
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.dior-modal-overlay.open').forEach(o => {
                    o.classList.remove('open');
                });
                document.body.style.overflow = '';
                const notifDropdown = document.getElementById('dior-notif-dropdown');
                if (notifDropdown) notifDropdown.classList.remove('open');
            }
        });

        // =========================================================================
        // 6. NOTIFICATION DROPDOWN & ACTIONS
        // =========================================================================
        const notifDropdown = document.getElementById('dior-notif-dropdown');
        const markAllNotifsBtn = document.getElementById('dior-mark-all-notifications-btn');
        const quickMarkReadBtn = document.getElementById('dior-quick-mark-read');

        window.diorToggleNotifDropdown = function(e) {
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }
            const dropdown = document.getElementById('dior-notif-dropdown');
            if (dropdown) {
                dropdown.classList.toggle('open');
            }
        };

        document.addEventListener('click', function(e) {
            const wrap = document.getElementById('dior-notif-dropdown-wrap');
            const dropdown = document.getElementById('dior-notif-dropdown');
            if (dropdown && dropdown.classList.contains('open')) {
                if (!wrap || !wrap.contains(e.target)) {
                    dropdown.classList.remove('open');
                }
            }
        });

        function markAllNotificationsRead() {
            sendAjax('dior_patient_mark_all_notifications_read', {}, () => {
                document.querySelectorAll('.unread-badge-count').forEach(el => el.style.display = 'none');
                document.querySelectorAll('.dior-notif-item.unread, .dior-full-notif-item.unread').forEach(item => {
                    item.classList.remove('unread');
                });
                document.querySelectorAll('.dior-mark-single-read').forEach(btn => btn.remove());
            });
        }

        if (markAllNotifsBtn) markAllNotifsBtn.addEventListener('click', markAllNotificationsRead);
        if (quickMarkReadBtn) quickMarkReadBtn.addEventListener('click', markAllNotificationsRead);

        // Single mark read
        document.addEventListener('click', function(e) {
            const singleBtn = e.target.closest('.dior-mark-single-read');
            if (singleBtn) {
                const item = singleBtn.closest('.dior-full-notif-item');
                const notifId = item ? item.getAttribute('data-notif-id') : '';
                if (notifId) {
                    sendAjax('dior_patient_mark_notification_read', { notif_id: notifId }, () => {
                        if (item) item.classList.remove('unread');
                        singleBtn.remove();
                    });
                }
            }
        });

        // =========================================================================
        // 7. APPOINTMENTS CONTROLLER (Booking, Reschedule, Cancel, Filter)
        // =========================================================================
        
        // Book Appointment
        const bookForm = document.getElementById('dior-form-book-patient-appt');
        if (bookForm) {
            bookForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const submitBtn = document.getElementById('dior-submit-book-btn');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Processing Booking...';
                }

                const data = {
                    condition: this.condition.value,
                    type: this.type.value,
                    provider: this.provider.value,
                    date: this.date.value,
                    time: this.time.value,
                    notes: this.notes.value
                };

                sendAjax('dior_patient_book_appointment', data, () => {
                    diorCloseModal('modal-book-appointment');
                    setTimeout(() => window.location.reload(), 1200);
                }, () => {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = '<i class="fa-solid fa-lock"></i> Confirm & Book Consultation ($49.00)';
                    }
                });
            });
        }

        // Open Reschedule Modal
        window.diorOpenRescheduleModal = function(apptId) {
            const input = document.getElementById('resched_appt_id');
            if (input) input.value = apptId;
            diorOpenModal('modal-reschedule-appointment');
        };

        const reschedForm = document.getElementById('dior-form-reschedule-appt');
        if (reschedForm) {
            reschedForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const data = {
                    appt_id: this.appt_id.value,
                    date: this.date.value,
                    time: this.time.value
                };

                sendAjax('dior_patient_reschedule_appointment', data, () => {
                    diorCloseModal('modal-reschedule-appointment');
                    setTimeout(() => window.location.reload(), 1000);
                });
            });
        }

        // Open Cancel Modal
        window.diorOpenCancelModal = function(apptId) {
            const input = document.getElementById('cancel_appt_id');
            if (input) input.value = apptId;
            diorOpenModal('modal-cancel-appointment');
        };

        const cancelForm = document.getElementById('dior-form-cancel-appt');
        if (cancelForm) {
            cancelForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const data = {
                    appt_id: this.appt_id.value,
                    reason: this.reason.value
                };

                sendAjax('dior_patient_cancel_appointment', data, () => {
                    diorCloseModal('modal-cancel-appointment');
                    setTimeout(() => window.location.reload(), 1000);
                });
            });
        }

        // Appointments Table Filter
        const apptFilterTabs = document.querySelectorAll('.dior-filter-tab');
        const apptSearchInput = document.getElementById('dior-search-appointments-input');
        const apptRows = document.querySelectorAll('.dior-appt-row');

        function filterApptTable() {
            const activeTab = document.querySelector('.dior-filter-tab.active');
            const statusFilter = activeTab ? activeTab.getAttribute('data-filter-status') : 'all';
            const searchQuery = apptSearchInput ? apptSearchInput.value.toLowerCase().trim() : '';
            const apptTable = document.getElementById('dior-patient-appointments-table');

            apptRows.forEach(row => {
                const rowStatus = row.getAttribute('data-status');
                const rowText = row.textContent.toLowerCase();

                const matchesStatus = (statusFilter === 'all') || (rowStatus === statusFilter);
                const matchesSearch = !searchQuery || rowText.includes(searchQuery);

                if (matchesStatus && matchesSearch) {
                    row.setAttribute('data-filter-hidden', 'false');
                } else {
                    row.setAttribute('data-filter-hidden', 'true');
                }
            });

            if (apptTable && apptTable._diorRenderPage) {
                apptTable._diorRenderPage(1);
            }
        }

        apptFilterTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                apptFilterTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                filterApptTable();
            });
        });

        if (apptSearchInput) {
            apptSearchInput.addEventListener('input', filterApptTable);
        }

        // Live Countdown Clock
        let minutesLeft = 32;
        let secondsLeft = 45;
        const minEl = document.getElementById('dior-cd-min');
        const secEl = document.getElementById('dior-cd-sec');

        if (minEl && secEl) {
            setInterval(() => {
                if (secondsLeft > 0) {
                    secondsLeft--;
                } else {
                    if (minutesLeft > 0) {
                        minutesLeft--;
                        secondsLeft = 59;
                    }
                }
                minEl.textContent = String(minutesLeft).padStart(2, '0');
                secEl.textContent = String(secondsLeft).padStart(2, '0');
            }, 1000);
        }

        // =========================================================================
        // 8. PROFILE CONTROLLER
        // =========================================================================
        const profileForm = document.getElementById('dior-form-patient-profile');
        if (profileForm) {
            profileForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const btn = document.getElementById('dior-save-profile-btn');
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Saving...';
                }

                const formData = new FormData(this);
                const data = {};
                formData.forEach((val, key) => data[key] = val);

                sendAjax('dior_patient_save_profile', data, () => {
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Save Profile Changes';
                    }
                }, () => {
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Save Profile Changes';
                    }
                });
            });
        }

        // Real Password Change Handler
        const pwdForm = document.getElementById('dior-form-change-password');
        if (pwdForm) {
            pwdForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const cur = this.current_password.value;
                const np = this.new_password.value;
                const cp = this.confirm_password.value;

                if (!cur || !np) {
                    showToast('Please enter both current and new password.', true);
                    return;
                }
                if (np !== cp) {
                    showToast('New passwords do not match.', true);
                    return;
                }
                if (np.length < 6) {
                    showToast('New password must be at least 6 characters.', true);
                    return;
                }

                sendAjax('dior_patient_change_password', {
                    current_password: cur,
                    new_password: np,
                    confirm_password: cp
                }, () => {
                    pwdForm.reset();
                });
            });
        }

        // =========================================================================
        // 9. MEDICAL QUESTIONNAIRE & INTAKE MODAL (With E-Sign)
        // =========================================================================
        window.diorOpenQuestionnaireForm = function(qnId, condition, symptoms, allergies, meds) {
            const modal = document.getElementById('modal-questionnaire-intake');
            if (!modal) return;

            document.getElementById('modal-qn-title').innerHTML = '<i class="fa-solid fa-clipboard-question"></i> Intake: ' + condition;
            document.getElementById('qn_input_id').value = qnId;
            document.getElementById('qn_input_condition').value = condition;
            document.getElementById('qn_input_symptoms').value = symptoms || '';
            document.getElementById('qn_input_allergies').value = allergies || '';
            document.getElementById('qn_input_meds').value = meds || '';

            diorOpenModal('modal-questionnaire-intake');
        };

        // File dropzone click
        const dropzone = document.getElementById('dior-upload-dropzone');
        const fileInput = document.getElementById('qn_file_upload');
        const filePreview = document.getElementById('dior-upload-preview');

        if (dropzone && fileInput) {
            dropzone.addEventListener('click', () => fileInput.click());

            fileInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    if (filePreview) {
                        filePreview.style.display = 'block';
                        filePreview.innerHTML = '<i class="fa-solid fa-paperclip"></i> Selected file: ' + this.files[0].name;
                    }
                }
            });
        }

        // Submit Intake Form
        const intakeForm = document.getElementById('dior-form-submit-intake');
        if (intakeForm) {
            intakeForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const submitBtn = document.getElementById('dior-submit-intake-btn');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Submitting to Doctor...';
                }

                const data = {
                    qn_id: this.qn_id.value,
                    condition: this.condition.value,
                    symptoms: this.symptoms.value,
                    allergies: this.allergies.value,
                    current_meds: this.current_meds.value,
                    medical_history: this.medical_history.value,
                    esign_name: this.esign_name.value
                };

                sendAjax('dior_patient_submit_questionnaire', data, () => {
                    diorCloseModal('modal-questionnaire-intake');
                    setTimeout(() => window.location.reload(), 1200);
                }, () => {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Clinical Intake to Doctor &rarr;';
                    }
                });
            });
        }

        // =========================================================================
        // 10. PHARMACY PREFERENCE CONTROLLER
        // =========================================================================
        window.diorOnPharmacySelectChange = function(selectEl) {
            const val = selectEl.value;
            if (val === 'custom') {
                return;
            }
            const parts = val.split('|');
            if (parts.length >= 3) {
                document.getElementById('q_pharm_name').value = parts[0];
                document.getElementById('q_pharm_address').value = parts[1];
                document.getElementById('q_pharm_phone').value = parts[2];
            }
        };

        const quickPharmForm = document.getElementById('dior-form-quick-pharmacy');
        if (quickPharmForm) {
            quickPharmForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const data = {
                    pharmacy_name: this.pharmacy_name.value,
                    pharmacy_address: this.pharmacy_address.value,
                    pharmacy_phone: this.pharmacy_phone.value
                };

                sendAjax('dior_patient_update_pharmacy', data, () => {
                    diorCloseModal('modal-change-pharmacy');
                    setTimeout(() => window.location.reload(), 1000);
                });
            });
        }

        // =========================================================================
        // 11. RECEIPT, DOCUMENT & RX DETAIL VIEWERS
        // =========================================================================
        window.diorViewReceipt = function(id, amount, service, date) {
            document.getElementById('rec-inv-id').textContent = id;
            document.getElementById('rec-amount').textContent = amount;
            document.getElementById('rec-service').textContent = service;
            document.getElementById('rec-date').textContent = date;
            diorOpenModal('modal-view-receipt');
        };

        window.diorViewDocumentModal = function(title, category, author, date, id) {
            const titleEl = document.getElementById('doc-preview-title');
            const catEl = document.getElementById('doc-preview-category');
            const authorEl = document.getElementById('doc-preview-author');
            const dateEl = document.getElementById('doc-preview-date');
            const idEl = document.getElementById('doc-preview-id');
            if (titleEl) titleEl.textContent = title || 'Medical Record';
            if (catEl) catEl.textContent = category || 'Official Document';
            if (authorEl) authorEl.textContent = author || 'Dior Medical Urgent Care';
            if (dateEl) dateEl.textContent = date || '';
            if (idEl) idEl.textContent = id || 'DOC-88219';
            diorOpenModal('modal-view-document');
        };

        window.diorDownloadCurrentDocumentPdf = function() {
            var title = (document.getElementById('doc-preview-title') && document.getElementById('doc-preview-title').textContent) || 'Medical Record';
            var docId = (document.getElementById('doc-preview-id') && document.getElementById('doc-preview-id').textContent) || 'DOC-88219';
            var cat = (document.getElementById('doc-preview-category') && document.getElementById('doc-preview-category').textContent) || 'Official Document';
            var author = (document.getElementById('doc-preview-author') && document.getElementById('doc-preview-author').textContent) || 'Dior Medical Urgent Care';
            var date = (document.getElementById('doc-preview-date') && document.getElementById('doc-preview-date').textContent) || 'Sept 4, 2026';
            var patientName = (document.getElementById('doc-preview-patient') && document.getElementById('doc-preview-patient').textContent) || 'Verified Patient';

            var cleanFileName = 'Dior-' + title.replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';

            var printContent = '<div style="max-width:760px;margin:0 auto;padding:36px;font-family:Arial,Helvetica,sans-serif;color:#0F172A;background:#FFFFFF;border:2px solid #2C6CB1;border-radius:12px;">' +
                '<div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #2C6CB1;padding-bottom:18px;margin-bottom:24px;">' +
                    '<div>' +
                        '<h1 style="margin:0;font-size:22px;color:#0B1030;font-weight:800;letter-spacing:0.02em;">DIOR MEDICAL TELEHEALTH</h1>' +
                        '<p style="margin:4px 0 0 0;font-size:12px;color:#64748B;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">Official Certified Clinical Record &amp; Medical Certificate</p>' +
                    '</div>' +
                    '<div style="text-align:right;">' +
                        '<div style="display:inline-block;padding:5px 12px;background:#EFF6FF;color:#2C6CB1;border:1px solid #BFDBFE;border-radius:20px;font-size:11.5px;font-weight:700;">' +
                            '&#10003; HIPAA Certified' +
                        '</div>' +
                        '<p style="margin:6px 0 0 0;font-size:11px;color:#64748B;">Doc Ref: <strong>' + docId + '</strong></p>' +
                    '</div>' +
                '</div>' +

                '<div style="text-align:center;padding:16px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;margin-bottom:24px;">' +
                    '<span style="display:inline-block;padding:3px 12px;background:#EFF6FF;color:#2563EB;border-radius:12px;font-size:11.5px;font-weight:700;text-transform:uppercase;margin-bottom:8px;">' + cat + '</span>' +
                    '<h2 style="margin:0;font-size:19px;color:#0F172A;font-weight:800;">' + title + '</h2>' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;margin-bottom:24px;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:8px;">' +
                    '<tr style="background:#F1F5F9;border-bottom:1px solid #CBD5E1;">' +
                        '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;width:25%;">Patient Name:</td>' +
                        '<td style="padding:10px 14px;font-size:13px;color:#0F172A;font-weight:700;width:25%;">' + patientName + '</td>' +
                        '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;width:25%;">Date Issued:</td>' +
                        '<td style="padding:10px 14px;font-size:13px;color:#0F172A;font-weight:700;width:25%;">' + date + '</td>' +
                    '</tr>' +
                    '<tr>' +
                        '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;">Issuing Authority:</td>' +
                        '<td style="padding:10px 14px;font-size:13px;color:#0F172A;font-weight:600;">' + author + '</td>' +
                        '<td style="padding:10px 14px;font-weight:700;font-size:12px;color:#475569;">Document Status:</td>' +
                        '<td style="padding:10px 14px;font-size:13px;color:#059669;font-weight:700;">Verified &amp; Active</td>' +
                    '</tr>' +
                '</table>' +

                '<div style="padding:18px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;font-size:13px;line-height:1.6;color:#334155;margin-bottom:24px;">' +
                    '<p style="margin:0 0 10px 0;"><strong>Official Record Statement:</strong></p>' +
                    '<p style="margin:0;">This certified document confirms that the individual designated above has satisfactorily completed all medical intake verifications, clinical evaluations, and electronic consent protocols via the Dior Medical Telehealth system. All records are maintained in strict accordance with 45 CFR Parts 160 and 164 (HIPAA Security &amp; Privacy Rules) and DEA Title 21 telemedicine provisions.</p>' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;border-top:2px solid #E2E8F0;padding-top:16px;margin-top:16px;">' +
                    '<tr>' +
                        '<td style="width:60%;vertical-align:bottom;font-size:11px;color:#64748B;line-height:1.5;">' +
                            '<strong style="color:#059669;">&#10003; Cryptographically Certified Electronic Record</strong><br>' +
                            'Security Hash: SHA-256 Verified &bull; Federal ESIGN &amp; UETA Act Compliant' +
                        '</td>' +
                        '<td style="width:40%;vertical-align:bottom;text-align:right;">' +
                            '<div style="font-family:\'Courier New\',Courier,monospace;font-size:15px;color:#0F172A;font-weight:700;border-bottom:1px solid #0F172A;display:inline-block;padding-bottom:2px;margin-bottom:4px;">' +
                                '/s/ Dior Medical Clinical Directorate' +
                            '</div>' +
                            '<div style="font-size:11px;color:#64748B;font-weight:600;">' +
                                'Authorized Telehealth Certification' +
                            '</div>' +
                        '</td>' +
                    '</tr>' +
                '</table>' +
            '</div>';

            var tempContainer = document.createElement('div');
            tempContainer.style.position = 'fixed';
            tempContainer.style.left = '-9999px';
            tempContainer.style.top = '0';
            tempContainer.style.width = '800px';
            tempContainer.innerHTML = printContent;
            document.body.appendChild(tempContainer);

            if (typeof html2pdf !== 'undefined') {
                var opt = {
                    margin:       [10, 10, 10, 10],
                    filename:     cleanFileName,
                    image:        { type: 'jpeg', quality: 0.98 },
                    html2canvas:  { scale: 2, useCORS: true, logging: false },
                    jsPDF:        { unit: 'mm', format: 'letter', orientation: 'portrait' }
                };
                html2pdf().set(opt).from(tempContainer.firstElementChild).save().then(function() {
                    document.body.removeChild(tempContainer);
                }).catch(function(err) {
                    console.error('PDF export error:', err);
                    document.body.removeChild(tempContainer);
                    fallbackPrintDoc(printContent, title);
                });
            } else {
                document.body.removeChild(tempContainer);
                fallbackPrintDoc(printContent, title);
            }
        };

        function fallbackPrintDoc(htmlContent, title) {
            var printWindow = window.open('', '_blank');
            if (printWindow) {
                printWindow.document.write('<html><head><title>' + title + '</title><style>@page{size:auto;margin:15mm;} body{margin:0;padding:20px;font-family:Arial,sans-serif;}</style></head><body>' + htmlContent + '</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(function() { printWindow.print(); }, 250);
            } else {
                window.print();
            }
        }

        window.diorDownloadReceiptPdf = function() {
            var invId = (document.getElementById('rec-inv-id') && document.getElementById('rec-inv-id').textContent) || 'INV-8829';
            var date = (document.getElementById('rec-date') && document.getElementById('rec-date').textContent) || 'Sept 4, 2026';
            var patientInfo = (document.getElementById('rec-patient-info') && document.getElementById('rec-patient-info').textContent) || 'Patient';
            var service = (document.getElementById('rec-service') && document.getElementById('rec-service').textContent) || 'Urgent Care Telehealth Consultation';
            var amount = (document.getElementById('rec-amount') && document.getElementById('rec-amount').textContent) || '$49.00';
            var logoImg = document.querySelector('.receipt-logo img');
            var logoUrl = logoImg ? logoImg.src : '';

            var cleanFileName = 'Dior-Receipt-' + invId.replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';

            var printContent = '<div style="max-width:720px;margin:0 auto;padding:36px;font-family:Arial,Helvetica,sans-serif;color:#0F172A;background:#FFFFFF;border:2px solid #2C6CB1;border-radius:12px;">' +
                '<div style="text-align:center;margin-bottom:20px;border-bottom:3px solid #2C6CB1;padding-bottom:18px;">' +
                    (logoUrl ? '<img src="' + logoUrl + '" alt="Dior Medical" style="height:70px;max-height:75px;object-fit:contain;margin-bottom:8px;">' : '') +
                    '<h1 style="margin:0;font-size:22px;color:#0B1030;font-weight:800;letter-spacing:0.02em;">DIOR MEDICAL TELEHEALTH</h1>' +
                    '<p style="margin:4px 0 0 0;font-size:12px;color:#64748B;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">Official Medical Statement &amp; Itemized Receipt</p>' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;margin-bottom:24px;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:8px;">' +
                    '<tr style="background:#F1F5F9;border-bottom:1px solid #CBD5E1;">' +
                        '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;width:35%;">Invoice #:</td>' +
                        '<td style="padding:12px 16px;font-size:14px;color:#0F172A;font-weight:800;">' + invId + '</td>' +
                    '</tr>' +
                    '<tr style="border-bottom:1px solid #E2E8F0;">' +
                        '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Date of Transaction:</td>' +
                        '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">' + date + '</td>' +
                    '</tr>' +
                    '<tr style="border-bottom:1px solid #E2E8F0;">' +
                        '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Patient Name &amp; ID:</td>' +
                        '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">' + patientInfo + '</td>' +
                    '</tr>' +
                    '<tr style="border-bottom:1px solid #E2E8F0;">' +
                        '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Service Description:</td>' +
                        '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">' + service + '</td>' +
                    '</tr>' +
                    '<tr style="border-bottom:1px solid #E2E8F0;">' +
                        '<td style="padding:12px 16px;font-weight:700;font-size:12.5px;color:#475569;">Payment Method:</td>' +
                        '<td style="padding:12px 16px;font-size:13px;color:#0F172A;font-weight:600;">Stripe (Credit Card / Apple Pay) &bull; Verified &bull; Paid in Full</td>' +
                    '</tr>' +
                    '<tr style="background:#EFF6FF;">' +
                        '<td style="padding:14px 16px;font-weight:800;font-size:14px;color:#1E40AF;">Total Paid:</td>' +
                        '<td style="padding:14px 16px;font-size:17px;color:#1E40AF;font-weight:800;">' + amount + '</td>' +
                    '</tr>' +
                '</table>' +

                '<div style="padding:14px 18px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;font-size:12px;color:#64748B;text-align:center;line-height:1.5;margin-bottom:24px;">' +
                    '<strong>Tax Compliance &amp; Insurance Reimbursement Notice:</strong><br>' +
                    'Dior Medical Telehealth &amp; Urgent Care &bull; Tax ID / NPI Verified &bull; Eligible for HSA / FSA Flexible Spending Account Reimbursement' +
                '</div>' +

                '<table style="width:100%;border-collapse:collapse;border-top:2px solid #E2E8F0;padding-top:16px;">' +
                    '<tr>' +
                        '<td style="width:60%;vertical-align:bottom;font-size:11px;color:#64748B;line-height:1.5;">' +
                            '<strong style="color:#059669;">&#10003; Official Electronic Payment Receipt</strong><br>' +
                            'Transaction ID: ' + invId + ' &bull; Status: Completed' +
                        '</td>' +
                        '<td style="width:40%;vertical-align:bottom;text-align:right;">' +
                            '<div style="font-family:\'Courier New\',Courier,monospace;font-size:14px;color:#0F172A;font-weight:700;border-bottom:1px solid #0F172A;display:inline-block;padding-bottom:2px;margin-bottom:4px;">' +
                                'Dior Billing Directorate' +
                            '</div>' +
                            '<div style="font-size:11px;color:#64748B;font-weight:600;">Authorized Financial Officer</div>' +
                        '</td>' +
                    '</tr>' +
                '</table>' +
            '</div>';

            var tempContainer = document.createElement('div');
            tempContainer.style.position = 'fixed';
            tempContainer.style.left = '-9999px';
            tempContainer.style.top = '0';
            tempContainer.style.width = '750px';
            tempContainer.innerHTML = printContent;
            document.body.appendChild(tempContainer);

            if (typeof html2pdf !== 'undefined') {
                var opt = {
                    margin:       [10, 10, 10, 10],
                    filename:     cleanFileName,
                    image:        { type: 'jpeg', quality: 0.98 },
                    html2canvas:  { scale: 2, useCORS: true, logging: false },
                    jsPDF:        { unit: 'mm', format: 'letter', orientation: 'portrait' }
                };
                html2pdf().set(opt).from(tempContainer.firstElementChild).save().then(function() {
                    document.body.removeChild(tempContainer);
                }).catch(function(err) {
                    console.error('PDF receipt export error:', err);
                    document.body.removeChild(tempContainer);
                    fallbackPrintDoc(printContent, invId);
                });
            } else {
                document.body.removeChild(tempContainer);
                fallbackPrintDoc(printContent, invId);
            }
        };

        window.diorPrintReceiptModal = function() {
            window.diorDownloadReceiptPdf();
        };

        window.diorViewRxDetails = function(id, medication, instructions) {
            alert('Prescription Instructions for ' + medication + ':\n\n' + instructions);
        };

        window.diorRequestRefill = function(rxId) {
            showToast('Refill request submitted electronically to prescribing physician for Rx #' + rxId);
        };

        window.diorViewAppointmentDetails = function(apptId) {
            showToast('Loading past clinical encounter summary for appointment #' + apptId + '...');
        };
    });

})(jQuery);

window.diorDownloadRxPdf = function(rxId) {
    const element = document.getElementById('rx-pdf-template-' + rxId);
    if (!element) { alert('Prescription details not found.'); return; }
    
    if (typeof html2pdf === 'undefined') {
        const printWindow = window.open('', '_blank');
        if (printWindow) {
            printWindow.document.write('<html><head><title>Prescription #' + rxId + '</title></head><body style="margin:20px;background:#fff;font-family:Arial,sans-serif;">' + element.innerHTML + '</body></html>');
            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => { printWindow.print(); }, 250);
        } else {
            window.print();
        }
        return;
    }
    
    element.style.display = 'block';
    const opt = {
        margin:       [8, 8, 8, 8],
        filename:     'Dior-Prescription-' + rxId + '.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true, logging: false },
        jsPDF:        { unit: 'mm', format: 'letter', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(element).save().then(function() {
        element.style.display = 'none';
    }).catch(function(err) {
        console.error('PDF export error:', err);
        element.style.display = 'none';
    });
};

