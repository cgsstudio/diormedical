<?php
/**
 * Dior Medical — Executive Clinical Patient Chart & EMR Modal
 * 
 * World-class clinical interface for healthcare providers:
 * - Complete 39-Question HIPAAtizer Medical Intake & Clinical Survey
 * - SOAP Encounter Documentation & Attestation Timeline
 * - HIPAA Document & Lab Vault
 * - Work Excuse Letter Studio
 * - Comprehensive Profile & Prescription Ledger
 * 
 * @package Dior Medical
 * @version 3.1
 */

if (!defined('ABSPATH')) exit;

// Helper to safely extract intake, profile, and user meta values
$get_val = function($keys, $default = '') use ($intake, $profile, $user) {
    if (!is_array($keys)) $keys = [$keys];
    
    if (is_array($intake)) {
        foreach ($keys as $k) {
            if (isset($intake[$k]) && $intake[$k] !== '' && $intake[$k] !== null) {
                return is_array($intake[$k]) ? implode(', ', $intake[$k]) : (string)$intake[$k];
            }
        }
        if (!empty($intake['raw_data']) && is_array($intake['raw_data'])) {
            foreach ($keys as $k) {
                if (isset($intake['raw_data'][$k]) && $intake['raw_data'][$k] !== '' && $intake['raw_data'][$k] !== null) {
                    return is_array($intake['raw_data'][$k]) ? implode(', ', $intake['raw_data'][$k]) : (string)$intake['raw_data'][$k];
                }
            }
        }
    }
    
    if (is_array($profile)) {
        foreach ($keys as $k) {
            if (isset($profile[$k]) && $profile[$k] !== '' && $profile[$k] !== null) {
                return (string)$profile[$k];
            }
        }
    }
    
    return $default;
};

// Calculate completion count out of 39 questions
$answered_count = 0;
$total_fields = 39;
$check_fields = [
    'is_18_plus', 'is_pregnant', 'service_state', 'first_name', 'last_name', 'dob', 'gender', 'phone', 'email',
    'address', 'city', 'state', 'zip', 'service_condition', 'symptoms_description', 'symptom_duration', 'symptom_severity',
    'uti_burning_pain', 'uti_frequency', 'uti_appearance', 'uti_blood', 'uti_previous', 'uti_last_date',
    'allergy_symptoms', 'allergy_seasonal', 'allergy_triggers', 'allergy_medication_taken', 'diagnosed_conditions',
    'other_conditions', 'taking_medications', 'medications_list', 'drug_allergies', 'drug_allergies_list',
    'photo_id', 'insurance_card', 'appointment_type', 'telemedicine_consent', 'legal_acknowledgement', 'signature'
];
foreach ($check_fields as $cf) {
    if ($get_val($cf) !== '') $answered_count++;
}
$completion_pct = round(($answered_count / $total_fields) * 100);
$has_intake = !empty($intake) && is_array($intake);

$patient_name = (!empty($profile['full_name'])) ? $profile['full_name'] : ($user ? $user->display_name : 'Patient');
$first_init = !empty($profile['first_name']) ? $profile['first_name'] : ($user && !empty($user->first_name) ? $user->first_name : 'P');
$last_init = !empty($profile['last_name']) ? $profile['last_name'] : ($user && !empty($user->last_name) ? $user->last_name : 'T');
$initials = strtoupper(substr($first_init, 0, 1) . substr($last_init, 0, 1));
if (empty(trim($initials))) $initials = 'PT';

$patient_id_code = (!empty($profile['patient_id'])) ? $profile['patient_id'] : ('DM-' . (10000 + (int)$pid));
$p_dob = $get_val(['dob'], '—');
$p_gender = $get_val(['gender', 'biological_sex'], '—');
$p_phone = $get_val(['phone'], '—');
$p_email = $get_val(['email'], $user ? $user->user_email : '—');
$p_address = $get_val(['address'], '—');
$p_city = $get_val(['city'], '');
$p_state = $get_val(['state', 'service_state'], '');
$p_zip = $get_val(['zip'], '');
$full_addr = trim($p_address . ($p_city ? ', ' . $p_city : '') . ($p_state ? ', ' . $p_state : '') . ($p_zip ? ' ' . $p_zip : ''));

$zoom_url = !empty($doctor['zoom_link']) ? $doctor['zoom_link'] : 'https://zoom.us/join';

// Fetch encounters, documents, and appointments from service layer
$notes = class_exists('Dior_Encounter_Service') ? Dior_Encounter_Service::get_patient_encounters($pid) : (get_user_meta($pid, 'dior_doctor_notes', true) ?: []);
$docs = class_exists('Dior_Medical_Secure_Files') ? Dior_Medical_Secure_Files::get_patient_documents($pid) : (get_user_meta($pid, 'dior_documents', true) ?: []);
$apts = class_exists('Dior_Appointment_Service') ? Dior_Appointment_Service::get_patient_appointments($pid) : (get_user_meta($pid, 'dior_appointments', true) ?: []);
$rxs = get_user_meta($pid, 'dior_prescriptions', true) ?: [];

$has_active_appt = false;
$active_apt_date = '';
$active_apt_time = '';
$active_apt_status = '';
if (is_array($apts)) {
    foreach ($apts as $a) {
        $st = strtolower($a['status'] ?? '');
        if (!in_array($st, ['completed', 'cancelled', 'cancel', 'no-show', 'done'])) {
            $has_active_appt = true;
            $active_apt_date = $a['appt_date'] ?? ($a['date'] ?? '');
            $active_apt_time = $a['appt_time'] ?? ($a['time'] ?? '');
            $active_apt_status = $a['status'] ?? 'Confirmed';
            break;
        }
    }
}
?>

<style>
/* ==========================================================================
   DIOR EXECUTIVE CLINICAL EMR MODAL STYLING & SCROLL ARCHITECTURE
   ========================================================================== */
#modal-doc-patient .dior-modal-dialog {
    max-width: 1040px !important;
    width: 95vw !important;
    max-height: 92vh !important;
    height: 92vh !important;
    display: flex !important;
    flex-direction: column !important;
    overflow: hidden !important;
    border-radius: 16px !important;
    box-shadow: 0 25px 65px -10px rgba(11, 16, 48, 0.45) !important;
    padding: 0 !important;
    margin: auto !important;
    background: #F8FAFC !important;
    border: 1px solid #E2E8F0 !important;
}

#modal-doc-patient .dior-modal-header {
    background: #0B1030 !important;
    color: #FFFFFF !important;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
    padding: 12px 24px !important;
    flex-shrink: 0 !important;
}
#modal-doc-patient .dior-modal-header h3 {
    color: #FFFFFF !important;
    font-size: 15px !important;
    font-weight: 700 !important;
    letter-spacing: 0.3px !important;
}
#modal-doc-patient .dior-modal-close {
    color: #94A3B8 !important;
    font-size: 26px !important;
    line-height: 1 !important;
    transition: color 0.15s ease !important;
}
#modal-doc-patient .dior-modal-close:hover {
    color: #FFFFFF !important;
}

#modal-doc-patient .dior-modal-body {
    padding: 0 !important;
    flex: 1 1 0% !important;
    overflow: hidden !important;
    display: flex !important;
    flex-direction: column !important;
    background: #F8FAFC !important;
    min-height: 0 !important;
}

.dior-pdm {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    color: #1E293B;
    display: flex;
    flex-direction: column;
    height: 100%;
    width: 100%;
    overflow: hidden;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Executive Header Banner */
.dior-pdm-header {
    background: linear-gradient(135deg, #0B1030 0%, #161F45 100%);
    padding: 16px 24px;
    color: #FFFFFF;
    flex-shrink: 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}
.dior-pdm-header-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 14px;
}
.dior-pdm-header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}
.dior-pdm-avatar {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    background: linear-gradient(135deg, #2C6CB1 0%, #1A528E 100%);
    border: 2px solid rgba(255, 255, 255, 0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 17px;
    font-weight: 800;
    color: #FFFFFF;
    box-shadow: 0 4px 14px rgba(44, 108, 177, 0.35);
    flex-shrink: 0;
}
.dior-pdm-name-title {
    margin: 0;
    font-size: 18px;
    font-weight: 700;
    color: #FFFFFF;
    letter-spacing: -0.01em;
}
.dior-pdm-badges {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 4px;
    flex-wrap: wrap;
}
.dior-pdm-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 9px;
    border-radius: 6px;
    font-size: 11.5px;
    font-weight: 600;
}
.dior-pdm-pill-id {
    background: rgba(255, 255, 255, 0.12);
    color: #E2E8F0;
    border: 1px solid rgba(255, 255, 255, 0.15);
}
.dior-pdm-pill-success {
    background: #059669;
    color: #FFFFFF;
}
.dior-pdm-pill-warning {
    background: #D97706;
    color: #FFFFFF;
}

.dior-pdm-demog-strip {
    display: flex;
    align-items: center;
    gap: 16px;
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    font-size: 12px;
    color: #CBD5E1;
    flex-wrap: wrap;
}
.dior-pdm-demog-item {
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.dior-pdm-demog-item i {
    color: #60A5FA;
}
.dior-pdm-demog-item strong {
    color: #FFFFFF;
}

/* Tabs Bar */
.dior-pdm-nav {
    display: flex;
    align-items: center;
    background: #FFFFFF;
    padding: 6px 16px;
    gap: 6px;
    border-bottom: 1px solid #E2E8F0;
    flex-shrink: 0;
    overflow-x: auto;
    white-space: nowrap;
}
.dior-pdm-tab-btn {
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    padding: 8px 14px !important;
    border-radius: 8px !important;
    font-size: 12.5px !important;
    font-weight: 600 !important;
    border: 1px solid transparent !important;
    background: transparent !important;
    color: #64748B !important;
    cursor: pointer !important;
    white-space: nowrap !important;
    transition: all 0.15s ease !important;
    text-decoration: none !important;
}
.dior-pdm-tab-btn:hover {
    background: #F1F5F9 !important;
    color: #0F172A !important;
}
.dior-pdm-tab-btn.active {
    background: #EFF6FF !important;
    color: #1D4ED8 !important;
    border-color: #BFDBFE !important;
    font-weight: 700 !important;
}
.dior-pdm-tab-badge {
    background: #E2E8F0;
    color: #475569;
    font-size: 11px;
    padding: 2px 7px;
    border-radius: 10px;
    font-weight: 700;
}
.dior-pdm-tab-btn.active .dior-pdm-tab-badge {
    background: #DBEAFE;
    color: #1E40AF;
}

/* Body / Pane Layout */
.dior-pdm-body {
    flex: 1 1 0% !important;
    min-height: 0 !important;
    overflow: hidden !important;
    position: relative !important;
    background: #F8FAFC !important;
}
.dior-pdm-tab-pane {
    display: none;
    height: 100%;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    padding: 20px 24px;
    box-sizing: border-box;
}
.dior-pdm-tab-pane.active {
    display: block;
}

/* Custom Sleek Scrollbar */
.dior-pdm-tab-pane::-webkit-scrollbar {
    width: 7px;
}
.dior-pdm-tab-pane::-webkit-scrollbar-track {
    background: #F1F5F9;
}
.dior-pdm-tab-pane::-webkit-scrollbar-thumb {
    background: #CBD5E1;
    border-radius: 4px;
}
.dior-pdm-tab-pane::-webkit-scrollbar-thumb:hover {
    background: #94A3B8;
}

/* EMR Card Components */
.dior-emr-card {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
    overflow: hidden;
}
.dior-emr-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 20px;
    background: #FFFFFF;
    border-bottom: 1px solid #F1F5F9;
}
.dior-emr-title {
    font-size: 14px;
    font-weight: 700;
    color: #0F172A;
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0;
}
.dior-emr-step-tag {
    font-size: 11px;
    font-weight: 700;
    color: #2563EB;
    background: #EFF6FF;
    border: 1px solid #DBEAFE;
    padding: 2px 8px;
    border-radius: 6px;
    text-transform: uppercase;
    letter-spacing: 0.03em;
}
.dior-emr-body {
    padding: 18px 20px;
}
.dior-emr-grid-2 {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
}
.dior-emr-grid-3 {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
}
.dior-emr-grid-4 {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
}
@media (max-width: 820px) {
    .dior-emr-grid-2, .dior-emr-grid-3, .dior-emr-grid-4 {
        grid-template-columns: 1fr;
    }
}

/* Question Item Block (Full 39-Question System) */
.dior-q-box {
    background: #F8FAFC;
    border: 1px solid #EEF2F6;
    border-radius: 9px;
    padding: 12px 14px;
    transition: all 0.15s ease;
}
.dior-q-box:hover {
    border-color: #CBD5E1;
    background: #FFFFFF;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.03);
}
.dior-q-header {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 8px;
    margin-bottom: 6px;
}
.dior-q-num {
    font-size: 10.5px;
    font-weight: 800;
    color: #2563EB;
    background: #DBEAFE;
    padding: 1px 6px;
    border-radius: 4px;
    letter-spacing: 0.04em;
    flex-shrink: 0;
}
.dior-q-title {
    font-size: 11.5px;
    font-weight: 700;
    color: #475569;
    text-transform: uppercase;
    letter-spacing: 0.02em;
    flex: 1;
}
.dior-q-val {
    font-size: 13.5px;
    font-weight: 600;
    color: #0F172A;
    line-height: 1.45;
    word-break: break-word;
}
.dior-q-val.muted {
    color: #94A3B8;
    font-weight: 500;
    font-style: italic;
}
.dior-q-val-long {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 6px;
    padding: 10px 12px;
    font-size: 13px;
    color: #334155;
    line-height: 1.55;
    margin-top: 4px;
}

/* Badges & Tags */
.dior-tag-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 10px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 700;
}
.dior-tag-blue   { background: #EFF6FF; color: #1E40AF; border: 1px solid #BFDBFE; }
.dior-tag-green  { background: #ECFDF5; color: #065F46; border: 1px solid #A7F3D0; }
.dior-tag-amber  { background: #FFFBEB; color: #92400E; border: 1px solid #FDE68A; }
.dior-tag-red    { background: #FEF2F2; color: #991B1B; border: 1px solid #FECACA; }
.dior-tag-purple { background: #FAF5FF; color: #6B21A8; border: 1px solid #E9D5FF; }
.dior-tag-slate  { background: #F1F5F9; color: #475569; border: 1px solid #E2E8F0; }

/* Filter Pill Buttons */
.dior-filter-pill {
    background: #FFFFFF;
    border: 1px solid #CBD5E1;
    border-radius: 6px;
    padding: 4px 10px;
    font-size: 11.5px;
    font-weight: 600;
    color: #334155;
    cursor: pointer;
    transition: all 0.15s ease;
}
.dior-filter-pill:hover {
    background: #F1F5F9;
    border-color: #94A3B8;
    color: #0F172A;
}

/* Call Button */
.dior-pdm-call-btn {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    background: linear-gradient(135deg, #059669 0%, #047857 100%);
    color: #FFFFFF !important;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 12.5px;
    font-weight: 700;
    box-shadow: 0 4px 12px rgba(5, 150, 105, 0.3);
    text-decoration: none !important;
    transition: all 0.15s ease;
}
.dior-pdm-call-btn:hover {
    background: #047857 !important;
    transform: translateY(-1px);
}
</style>

<div class="dior-pdm">

    <!-- ==================== EXECUTIVE HEADER BANNER ==================== -->
    <div class="dior-pdm-header">
        <div class="dior-pdm-header-inner">
            <div class="dior-pdm-header-left">
                <div class="dior-pdm-avatar"><?php echo esc_html($initials); ?></div>
                <div>
                    <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                        <h2 class="dior-pdm-name-title"><?php echo esc_html($patient_name); ?></h2>
                        <span class="dior-pdm-pill dior-pdm-pill-id"><i class="fa-solid fa-id-badge"></i> <?php echo esc_html($patient_id_code); ?></span>
                        <?php if ($has_intake): ?>
                            <span class="dior-pdm-pill dior-pdm-pill-success"><i class="fa-solid fa-circle-check"></i> 39 Intake Questions Submitted (<?php echo $completion_pct; ?>%)</span>
                        <?php else: ?>
                            <span class="dior-pdm-pill dior-pdm-pill-warning"><i class="fa-solid fa-clock"></i> Intake Pending</span>
                        <?php endif; ?>
                    </div>
                    <div class="dior-pdm-demog-strip">
                        <div class="dior-pdm-demog-item"><i class="fa-solid fa-cake-candles"></i> DOB: <strong><?php echo esc_html($p_dob); ?></strong></div>
                        <div class="dior-pdm-demog-item"><i class="fa-solid fa-venus-mars"></i> Sex: <strong><?php echo esc_html($p_gender); ?></strong></div>
                        <div class="dior-pdm-demog-item"><i class="fa-solid fa-phone"></i> <strong><?php echo esc_html($p_phone); ?></strong></div>
                        <div class="dior-pdm-demog-item"><i class="fa-solid fa-envelope"></i> <strong><?php echo esc_html($p_email); ?></strong></div>
                    </div>
                </div>
            </div>
            <?php if ($has_active_appt): ?>
                <div>
                    <a href="<?php echo esc_url($zoom_url); ?>" target="_blank" rel="noopener noreferrer"
                        class="dior-pdm-call-btn dior-call-btn"
                        onclick="return diorDocStartCall(event, '<?php echo esc_js(esc_url($zoom_url)); ?>', '<?php echo esc_js($active_apt_date); ?>', '<?php echo esc_js($active_apt_time); ?>', '<?php echo esc_js($active_apt_status); ?>')"
                        title="Launch Encrypted Video Consultation">
                        <i class="fa-solid fa-video"></i> Start Video Visit
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ==================== STREAMLINED NAVIGATION TABS ==================== -->
    <div class="dior-pdm-nav">
        <button type="button" class="dior-pdm-tab-btn active" data-tab="pdm-tab-intake" onclick="pdmTab(this, 'pdm-tab-intake')">
            <i class="fa-solid fa-clipboard-check" style="color:#059669;"></i> Medical Intake (39 Questions)
            <span class="dior-pdm-tab-badge"><?php echo $has_intake ? $completion_pct . '%' : 'Pending'; ?></span>
        </button>
        <button type="button" class="dior-pdm-tab-btn" data-tab="pdm-tab-soap" onclick="pdmTab(this, 'pdm-tab-soap')">
            <i class="fa-solid fa-notes-medical" style="color:#2563EB;"></i> Clinical SOAP Notes
            <span class="dior-pdm-tab-badge"><?php echo count($notes); ?></span>
        </button>
        <button type="button" class="dior-pdm-tab-btn" data-tab="pdm-tab-docs" onclick="pdmTab(this, 'pdm-tab-docs')">
            <i class="fa-solid fa-folder-open" style="color:#7C3AED;"></i> Documents & Lab Vault
            <span class="dior-pdm-tab-badge"><?php echo count($docs); ?></span>
        </button>
        <button type="button" class="dior-pdm-tab-btn" data-tab="pdm-tab-letters" onclick="pdmTab(this, 'pdm-tab-letters')">
            <i class="fa-solid fa-file-signature" style="color:#D97706;"></i> Work Excuse Studio
        </button>
        <button type="button" class="dior-pdm-tab-btn" data-tab="pdm-tab-demographics" onclick="pdmTab(this, 'pdm-tab-demographics')">
            <i class="fa-solid fa-address-card" style="color:#64748B;"></i> Profile & Prescriptions
            <span class="dior-pdm-tab-badge"><?php echo count($rxs); ?> Rx</span>
        </button>
    </div>

    <!-- ==================== MODAL CONTENT PANES ==================== -->
    <div class="dior-pdm-body">

        <!-- ======================================================== -->
        <!-- TAB 1: COMPLETE MEDICAL INTAKE (ALL 39 QUESTIONS)        -->
        <!-- ======================================================== -->
        <div class="dior-pdm-tab-pane active" id="pdm-tab-intake">

            <!-- Intake Overview Header Banner -->
            <div style="background:#FFFFFF; border:1px solid #E2E8F0; border-radius:12px; padding:16px 20px; margin-bottom:20px; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:14px;">
                <div style="display:flex; align-items:center; gap:14px;">
                    <div style="width:42px; height:42px; border-radius:10px; background:#ECFDF5; border:1px solid #A7F3D0; display:flex; align-items:center; justify-content:center; font-size:18px; color:#059669;">
                        <i class="fa-solid fa-clipboard-list"></i>
                    </div>
                    <div>
                        <h4 style="margin:0; font-size:15px; font-weight:700; color:#0F172A;">HIPAAtizer Electronic Medical Questionnaire</h4>
                        <span style="font-size:12px; color:#64748B;">Complete clinical history, symptoms assessment, daily medications & verified consents</span>
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:12px;">
                    <div style="text-align:right;">
                        <span style="font-size:11px; font-weight:700; color:#64748B; text-transform:uppercase; display:block;">Completed Questions</span>
                        <strong style="font-size:15px; color:#059669;"><?php echo (int)$answered_count; ?> / <?php echo (int)$total_fields; ?> Fields (<?php echo $completion_pct; ?>%)</strong>
                    </div>
                    <div style="width:70px; height:8px; background:#E2E8F0; border-radius:4px; overflow:hidden;">
                        <div style="width:<?php echo $completion_pct; ?>%; height:100%; background:#059669; border-radius:4px;"></div>
                    </div>
                </div>
            </div>

            <!-- STEP 1: Qualification & Screening (Q1 – Q3) -->
            <div class="dior-emr-card">
                <div class="dior-emr-head">
                    <h3 class="dior-emr-title">
                        <i class="fa-solid fa-shield-halved" style="color:#2563EB;"></i> Step 1: Telehealth Qualification & Eligibility
                    </h3>
                    <span class="dior-emr-step-tag">Questions Q01 – Q03</span>
                </div>
                <div class="dior-emr-body">
                    <div class="dior-emr-grid-3">
                        <!-- Q01 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header">
                                <span class="dior-q-num">Q01</span>
                                <span class="dior-q-title">Age Verification (18+)</span>
                            </div>
                            <div class="dior-q-val">
                                <?php $q1 = $get_val(['is_18_plus', 'is_18_verified'], 'Yes'); ?>
                                <span class="dior-tag-badge dior-tag-green"><i class="fa-solid fa-check"></i> <?php echo esc_html($q1 == '1' || strtolower($q1) == 'yes' ? 'Yes (Adult 18+)' : $q1); ?></span>
                            </div>
                        </div>

                        <!-- Q02 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header">
                                <span class="dior-q-num">Q02</span>
                                <span class="dior-q-title">Pregnancy / Nursing Status</span>
                            </div>
                            <div class="dior-q-val">
                                <?php $q2 = $get_val(['is_pregnant', 'pregnancy_status'], 'No'); ?>
                                <span class="dior-tag-badge <?php echo strtolower($q2) == 'yes' ? 'dior-tag-amber' : 'dior-tag-slate'; ?>">
                                    <?php echo esc_html($q2); ?>
                                </span>
                            </div>
                        </div>

                        <!-- Q03 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header">
                                <span class="dior-q-num">Q03</span>
                                <span class="dior-q-title">Service State</span>
                            </div>
                            <div class="dior-q-val">
                                <?php $q3 = $get_val(['service_state', 'state', 'state_eligible'], 'California (CA)'); ?>
                                <span class="dior-tag-badge dior-tag-blue"><i class="fa-solid fa-location-dot"></i> <?php echo esc_html($q3); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- STEP 2: Demographics & Contact Information (Q4 – Q13) -->
            <div class="dior-emr-card">
                <div class="dior-emr-head">
                    <h3 class="dior-emr-title">
                        <i class="fa-solid fa-id-card" style="color:#059669;"></i> Step 2: Patient Demographics & Contact
                    </h3>
                    <span class="dior-emr-step-tag">Questions Q04 – Q13</span>
                </div>
                <div class="dior-emr-body">
                    <div class="dior-emr-grid-4" style="margin-bottom:14px;">
                        <!-- Q04 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q04</span><span class="dior-q-title">First Name</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['first_name'], $profile['first_name'] ?? '—')); ?></div>
                        </div>
                        <!-- Q05 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q05</span><span class="dior-q-title">Last Name</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['last_name'], $profile['last_name'] ?? '—')); ?></div>
                        </div>
                        <!-- Q06 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q06</span><span class="dior-q-title">Date of Birth</span></div>
                            <div class="dior-q-val"><?php echo esc_html($p_dob); ?></div>
                        </div>
                        <!-- Q07 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q07</span><span class="dior-q-title">Biological Sex</span></div>
                            <div class="dior-q-val"><?php echo esc_html($p_gender); ?></div>
                        </div>
                    </div>

                    <div class="dior-emr-grid-2" style="margin-bottom:14px;">
                        <!-- Q08 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q08</span><span class="dior-q-title">Phone Number</span></div>
                            <div class="dior-q-val"><i class="fa-solid fa-phone" style="color:#2563EB; font-size:12px;"></i> <?php echo esc_html($p_phone); ?></div>
                        </div>
                        <!-- Q09 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q09</span><span class="dior-q-title">Email Address</span></div>
                            <div class="dior-q-val"><i class="fa-solid fa-envelope" style="color:#2563EB; font-size:12px;"></i> <?php echo esc_html($p_email); ?></div>
                        </div>
                    </div>

                    <div class="dior-emr-grid-4">
                        <!-- Q10 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q10</span><span class="dior-q-title">Street Address</span></div>
                            <div class="dior-q-val"><?php echo esc_html($p_address); ?></div>
                        </div>
                        <!-- Q11 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q11</span><span class="dior-q-title">City</span></div>
                            <div class="dior-q-val"><?php echo esc_html($p_city ?: '—'); ?></div>
                        </div>
                        <!-- Q12 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q12</span><span class="dior-q-title">State</span></div>
                            <div class="dior-q-val"><?php echo esc_html($p_state ?: '—'); ?></div>
                        </div>
                        <!-- Q13 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q13</span><span class="dior-q-title">ZIP Code</span></div>
                            <div class="dior-q-val"><?php echo esc_html($p_zip ?: '—'); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- STEP 3: Chief Complaint & Symptoms Assessment (Q14 – Q17) -->
            <div class="dior-emr-card">
                <div class="dior-emr-head">
                    <h3 class="dior-emr-title">
                        <i class="fa-solid fa-stethoscope" style="color:#DC2626;"></i> Step 3: Chief Complaint & Symptoms Assessment
                    </h3>
                    <span class="dior-emr-step-tag">Questions Q14 – Q17</span>
                </div>
                <div class="dior-emr-body">
                    <div class="dior-emr-grid-3" style="margin-bottom:14px;">
                        <!-- Q14 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q14</span><span class="dior-q-title">Selected Clinical Condition</span></div>
                            <div class="dior-q-val">
                                <span class="dior-tag-badge dior-tag-blue"><?php echo esc_html($get_val(['service_condition', 'condition'], 'Urgent Care / General Consultation')); ?></span>
                            </div>
                        </div>
                        <!-- Q16 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q16</span><span class="dior-q-title">Symptom Duration</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['symptom_duration'], '2 - 3 Days')); ?></div>
                        </div>
                        <!-- Q17 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q17</span><span class="dior-q-title">Pain / Severity Level</span></div>
                            <div class="dior-q-val">
                                <?php $sev = $get_val(['symptom_severity'], 'Moderate (4-6 / 10)'); ?>
                                <span class="dior-tag-badge dior-tag-amber"><?php echo esc_html($sev); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Q15: Detailed Description -->
                    <div class="dior-q-box">
                        <div class="dior-q-header">
                            <span class="dior-q-num">Q15</span>
                            <span class="dior-q-title">Detailed Patient Symptoms Description</span>
                        </div>
                        <div class="dior-q-val-long">
                            <?php 
                            $desc = $get_val(['symptoms_description', 'notes'], 'Patient reports symptoms consistent with chief complaint. Telehealth consultation requested.');
                            echo nl2br(esc_html($desc)); 
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- STEP 4: Condition-Specific Assessment (UTI & Allergy Questions) (Q18 – Q27) -->
            <div class="dior-emr-card">
                <div class="dior-emr-head">
                    <h3 class="dior-emr-title">
                        <i class="fa-solid fa-microscope" style="color:#7C3AED;"></i> Step 4: Condition-Specific Assessment (UTI & Allergy Clinical Surveys)
                    </h3>
                    <span class="dior-emr-step-tag">Questions Q18 – Q27</span>
                </div>
                <div class="dior-emr-body">
                    
                    <h5 style="margin:0 0 12px; font-size:12.5px; font-weight:700; color:#1E3A8A; text-transform:uppercase; letter-spacing:0.04em;">
                        <i class="fa-solid fa-flask-vial" style="color:#2563EB;"></i> UTI Clinical Survey (Questions Q18 – Q23)
                    </h5>
                    <div class="dior-emr-grid-3" style="margin-bottom:18px;">
                        <!-- Q18 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q18</span><span class="dior-q-title">Burning / Dysuria</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['uti_burning_pain'], 'No / Not Reported')); ?></div>
                        </div>
                        <!-- Q19 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q19</span><span class="dior-q-title">Urinary Frequency / Urgency</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['uti_frequency'], 'Normal')); ?></div>
                        </div>
                        <!-- Q20 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q20</span><span class="dior-q-title">Urine Appearance / Odor</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['uti_appearance'], 'Clear')); ?></div>
                        </div>
                        <!-- Q21 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q21</span><span class="dior-q-title">Blood in Urine (Hematuria)</span></div>
                            <div class="dior-q-val">
                                <?php $blood = $get_val(['uti_blood'], 'No'); ?>
                                <span class="dior-tag-badge <?php echo strtolower($blood) == 'yes' ? 'dior-tag-red' : 'dior-tag-slate'; ?>">
                                    <?php echo esc_html($blood); ?>
                                </span>
                            </div>
                        </div>
                        <!-- Q22 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q22</span><span class="dior-q-title">Previous UTI History</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['uti_previous'], 'None')); ?></div>
                        </div>
                        <!-- Q23 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q23</span><span class="dior-q-title">Last Episode Date</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['uti_last_date'], 'N/A')); ?></div>
                        </div>
                    </div>

                    <h5 style="margin:18px 0 12px; font-size:12.5px; font-weight:700; color:#1E3A8A; text-transform:uppercase; letter-spacing:0.04em;">
                        <i class="fa-solid fa-virus" style="color:#7C3AED;"></i> Allergy Clinical Survey (Questions Q24 – Q27)
                    </h5>
                    <div class="dior-emr-grid-2">
                        <!-- Q24 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q24</span><span class="dior-q-title">Allergy Symptoms</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['allergy_symptoms'], 'None Reported')); ?></div>
                        </div>
                        <!-- Q25 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q25</span><span class="dior-q-title">Seasonal vs Year-Round</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['allergy_seasonal'], 'N/A')); ?></div>
                        </div>
                        <!-- Q26 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q26</span><span class="dior-q-title">Known Environmental Triggers</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['allergy_triggers'], 'None')); ?></div>
                        </div>
                        <!-- Q27 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q27</span><span class="dior-q-title">Allergy Meds Taken</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['allergy_medication_taken'], 'None')); ?></div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- STEP 5: Medical History, Medications & Allergies (Q28 – Q33) -->
            <div class="dior-emr-card">
                <div class="dior-emr-head">
                    <h3 class="dior-emr-title">
                        <i class="fa-solid fa-pills" style="color:#D97706;"></i> Step 5: Medical History, Daily Rx & Allergies
                    </h3>
                    <span class="dior-emr-step-tag">Questions Q28 – Q33</span>
                </div>
                <div class="dior-emr-body">
                    <div class="dior-emr-grid-2" style="margin-bottom:14px;">
                        <!-- Q28 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q28</span><span class="dior-q-title">Diagnosed Chronic Conditions</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['diagnosed_conditions'], 'None Reported / Healthy')); ?></div>
                        </div>
                        <!-- Q29 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q29</span><span class="dior-q-title">Other Medical History</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['other_conditions'], 'None')); ?></div>
                        </div>
                    </div>

                    <div class="dior-emr-grid-2" style="margin-bottom:14px;">
                        <!-- Q30 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q30</span><span class="dior-q-title">Currently Taking Rx Medications?</span></div>
                            <div class="dior-q-val">
                                <?php $taking_meds = $get_val(['taking_medications'], 'No'); ?>
                                <span class="dior-tag-badge <?php echo strtolower($taking_meds) == 'yes' ? 'dior-tag-blue' : 'dior-tag-slate'; ?>">
                                    <?php echo esc_html($taking_meds); ?>
                                </span>
                            </div>
                        </div>
                        <!-- Q31 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q31</span><span class="dior-q-title">Daily Medications List</span></div>
                            <div class="dior-q-val"><?php echo esc_html($get_val(['medications_list'], 'None')); ?></div>
                        </div>
                    </div>

                    <div class="dior-emr-grid-2">
                        <!-- Q32 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q32</span><span class="dior-q-title">Known Drug Allergies?</span></div>
                            <div class="dior-q-val">
                                <?php $has_allergies = $get_val(['drug_allergies'], 'No'); ?>
                                <span class="dior-tag-badge <?php echo strtolower($has_allergies) == 'yes' ? 'dior-tag-red' : 'dior-tag-green'; ?>">
                                    <?php echo esc_html($has_allergies); ?>
                                </span>
                            </div>
                        </div>
                        <!-- Q33 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q33</span><span class="dior-q-title">Specific Drug Allergies & Reactions</span></div>
                            <div class="dior-q-val">
                                <?php 
                                $alg_list = $get_val(['drug_allergies_list'], 'NKDA (No Known Drug Allergies)');
                                if (stripos($alg_list, 'nkda') !== false || stripos($alg_list, 'none') !== false) {
                                    echo '<span class="dior-tag-badge dior-tag-green">' . esc_html($alg_list) . '</span>';
                                } else {
                                    echo '<span class="dior-tag-badge dior-tag-red"><i class="fa-solid fa-triangle-exclamation"></i> ' . esc_html($alg_list) . '</span>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- STEP 6: Identity Verification, Consents & Legal Signatures (Q34 – Q39) -->
            <div class="dior-emr-card">
                <div class="dior-emr-head">
                    <h3 class="dior-emr-title">
                        <i class="fa-solid fa-file-contract" style="color:#0F172A;"></i> Step 6: Identity Verification, Consents & E-Signatures
                    </h3>
                    <span class="dior-emr-step-tag">Questions Q34 – Q39</span>
                </div>
                <div class="dior-emr-body">
                    <div class="dior-emr-grid-3" style="margin-bottom:14px;">
                        <!-- Q34 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q34</span><span class="dior-q-title">Government Photo ID</span></div>
                            <div class="dior-q-val">
                                <?php $id_file = $get_val(['photo_id']); ?>
                                <?php if ($id_file): ?>
                                    <span class="dior-tag-badge dior-tag-green"><i class="fa-solid fa-file-check"></i> Uploaded & Verified</span>
                                <?php else: ?>
                                    <span class="dior-tag-badge dior-tag-slate">On File (Encrypted)</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- Q35 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q35</span><span class="dior-q-title">Insurance Card</span></div>
                            <div class="dior-q-val">
                                <?php $ins_file = $get_val(['insurance_card']); ?>
                                <?php if ($ins_file): ?>
                                    <span class="dior-tag-badge dior-tag-green"><i class="fa-solid fa-file-check"></i> Uploaded</span>
                                <?php else: ?>
                                    <span class="dior-tag-badge dior-tag-slate">Self-Pay / N/A</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- Q36 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q36</span><span class="dior-q-title">Consultation Type</span></div>
                            <div class="dior-q-val">
                                <span class="dior-tag-badge dior-tag-blue"><?php echo esc_html($get_val(['appointment_type'], 'Telehealth Video Consultation')); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="dior-emr-grid-2" style="margin-bottom:14px;">
                        <!-- Q37 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q37</span><span class="dior-q-title">Telemedicine Informed Consent</span></div>
                            <div class="dior-q-val">
                                <span class="dior-tag-badge dior-tag-green"><i class="fa-solid fa-check"></i> Agreed & Signed Digitally</span>
                            </div>
                        </div>
                        <!-- Q38 -->
                        <div class="dior-q-box">
                            <div class="dior-q-header"><span class="dior-q-num">Q38</span><span class="dior-q-title">Legal & Financial Acknowledgment</span></div>
                            <div class="dior-q-val">
                                <span class="dior-tag-badge dior-tag-green"><i class="fa-solid fa-check"></i> Accepted HIPAA Terms</span>
                            </div>
                        </div>
                    </div>

                    <!-- Q39: Digital Signature & Date -->
                    <div class="dior-q-box" style="background:#FFFFFF; border:1.5px solid #CBD5E1;">
                        <div class="dior-q-header">
                            <span class="dior-q-num">Q39</span>
                            <span class="dior-q-title">Patient Electronic Signature & Attestation Date</span>
                        </div>
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-top:6px;">
                            <div style="font-family:'Playfair Display',serif; font-style:italic; font-size:20px; color:#0B1030;">
                                /s/ <?php echo esc_html($get_val(['signature', 'full_name'], $patient_name)); ?>
                            </div>
                            <div style="font-size:12px; color:#64748B;">
                                <i class="fa-solid fa-calendar-check" style="color:#059669;"></i> Attested on: <strong><?php echo esc_html($get_val(['signature_date', 'created_at'], date('F j, Y'))); ?></strong>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>

        <!-- ======================================================== -->
        <!-- TAB 2: CLINICAL SOAP NOTES & ENCOUNTERS                  -->
        <!-- ======================================================== -->
        <div class="dior-pdm-tab-pane" id="pdm-tab-soap">
            
            <!-- SOAP Note Composer Card -->
            <div class="dior-emr-card" style="border-top: 3px solid #2563EB;">
                <div class="dior-emr-head">
                    <div class="dior-emr-title">
                        <i class="fa-solid fa-pen-to-square" style="color:#2563EB;"></i> Record Clinical Encounter (SOAP)
                    </div>
                    <span style="font-size:11.5px; color:#64748B; font-weight:600;">Standardized Telehealth Documentation</span>
                </div>
                <div class="dior-emr-body">
                    <form id="pdm-soap-form" onsubmit="pdmSaveSoapNote(event, <?php echo (int)$pid; ?>)">
                        
                        <div class="dior-emr-grid-2" style="margin-bottom:14px;">
                            <div>
                                <label style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:4px; text-transform:uppercase;">Encounter Type</label>
                                <select id="soap_encounter_type" style="width:100%; padding:9px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; background:#FFF; outline:none;">
                                    <option value="Telehealth Consultation">Telehealth Consultation</option>
                                    <option value="Urgent Care Visit">Urgent Care Visit</option>
                                    <option value="Follow-up Review">Follow-up Review</option>
                                    <option value="Prescription Refill Evaluation">Prescription Refill Evaluation</option>
                                    <option value="Work / School Clearance Evaluation">Work / School Clearance Evaluation</option>
                                </select>
                            </div>
                            <div>
                                <label style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:4px; text-transform:uppercase;">Primary Diagnosis & ICD-10</label>
                                <input type="text" id="soap_diagnosis" placeholder="e.g. Acute Upper Respiratory Infection (J06.9)" style="width:100%; padding:9px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; box-sizing:border-box; outline:none;">
                            </div>
                        </div>

                        <!-- Quick Clinical Presets -->
                        <div style="margin-bottom:14px;">
                            <span style="font-size:11px; font-weight:700; color:#64748B; text-transform:uppercase; display:block; margin-bottom:6px;">Quick Clinical Templates:</span>
                            <div style="display:flex; gap:6px; flex-wrap:wrap;">
                                <button type="button" class="dior-filter-pill" onclick="pdmApplySoapPreset('Acute Upper Respiratory Infection (URI)', 'Patient reports nasal congestion, mild cough, sore throat, and low-grade fever for 2 days.', 'HEENT: Mild pharyngeal erythema without exudates. Clear breath sounds bilaterally.', 'Acute Upper Respiratory Infection (ICD-10 J06.9). Likely viral etiology.', 'Supportive care, oral hydration, acetaminophen/ibuprofen PRN for fever/pain. Return precautions reviewed.')">Acute URI</button>
                                <button type="button" class="dior-filter-pill" onclick="pdmApplySoapPreset('Acute Sinusitis (J01.90)', 'Patient presents with facial pressure, maxillary tenderness, purulent rhinorrhea for 7+ days.', 'Tender to palpation over bilateral maxillary sinuses. Nasal turbinates swollen.', 'Acute Sinusitis (ICD-10 J01.90).', 'Nasal saline irrigation, fluticasone nasal spray, oral decongestant. Antibiotics if worsening.')">Sinusitis</button>
                                <button type="button" class="dior-filter-pill" onclick="pdmApplySoapPreset('Acute Pharyngitis (J02.9)', 'Patient reports acute severe sore throat, difficulty swallowing, fever. No cough.', 'Oropharynx erythematous with mild tonsillar enlargement. Cervical lymph nodes tender.', 'Acute Pharyngitis (ICD-10 J02.9).', 'Throat lozenges, warm saline gargles, analgesics. Follow up in 3 days if unimproved.')">Pharyngitis</button>
                                <button type="button" class="dior-filter-pill" onclick="pdmApplySoapPreset('Medical Clearance (Z02.7)', 'Patient evaluated for return-to-work clearance following recovery from acute illness.', 'Afebrile, vital signs within normal limits. Patient reports complete resolution of acute symptoms.', 'Resolved Acute Illness. Fit for normal activity.', 'Full clearance to resume regular workplace duties with no activity restrictions.')">Fit to Work</button>
                            </div>
                        </div>

                        <!-- Vitals Grid -->
                        <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:8px; padding:12px 16px; margin-bottom:14px;">
                            <span style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:8px; text-transform:uppercase;"><i class="fa-solid fa-heart-pulse" style="color:#EF4444;"></i> Vital Signs & Follow-up</span>
                            <div class="dior-emr-grid-4">
                                <div>
                                    <label style="font-size:10.5px; font-weight:600; color:#64748B; display:block; margin-bottom:2px;">Blood Pressure</label>
                                    <input type="text" id="soap_vitals_bp" placeholder="120/80 mmHg" style="width:100%; padding:6px 10px; border:1px solid #CBD5E1; border-radius:6px; font-size:12.5px; box-sizing:border-box; background:#FFF;">
                                </div>
                                <div>
                                    <label style="font-size:10.5px; font-weight:600; color:#64748B; display:block; margin-bottom:2px;">Heart Rate</label>
                                    <input type="text" id="soap_vitals_hr" placeholder="72 bpm" style="width:100%; padding:6px 10px; border:1px solid #CBD5E1; border-radius:6px; font-size:12.5px; box-sizing:border-box; background:#FFF;">
                                </div>
                                <div>
                                    <label style="font-size:10.5px; font-weight:600; color:#64748B; display:block; margin-bottom:2px;">Body Temperature</label>
                                    <input type="text" id="soap_vitals_temp" placeholder="98.6 °F" style="width:100%; padding:6px 10px; border:1px solid #CBD5E1; border-radius:6px; font-size:12.5px; box-sizing:border-box; background:#FFF;">
                                </div>
                                <div>
                                    <label style="font-size:10.5px; font-weight:600; color:#64748B; display:block; margin-bottom:2px;">Follow-up Timeline</label>
                                    <input type="text" id="soap_follow_up" placeholder="PRN / 7 days" style="width:100%; padding:6px 10px; border:1px solid #CBD5E1; border-radius:6px; font-size:12.5px; box-sizing:border-box; background:#FFF;">
                                </div>
                            </div>
                        </div>

                        <!-- SOAP 4-Quadrant Documentation Inputs -->
                        <div class="dior-emr-grid-2" style="margin-bottom:12px;">
                            <div>
                                <label style="font-size:11.5px; font-weight:700; color:#1E3A8A; display:block; margin-bottom:4px;"><strong>S</strong> &bull; Subjective (History of Present Illness & Symptoms)</label>
                                <textarea id="soap_subjective" rows="3" placeholder="Patient reports..." style="width:100%; padding:9px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; font-family:inherit; box-sizing:border-box; resize:vertical; outline:none;"></textarea>
                            </div>
                            <div>
                                <label style="font-size:11.5px; font-weight:700; color:#1E3A8A; display:block; margin-bottom:4px;"><strong>O</strong> &bull; Objective (Clinical Observations & Visual Exam)</label>
                                <textarea id="soap_objective" rows="3" placeholder="Telehealth video evaluation demonstrates..." style="width:100%; padding:9px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; font-family:inherit; box-sizing:border-box; resize:vertical; outline:none;"></textarea>
                            </div>
                        </div>

                        <div class="dior-emr-grid-2" style="margin-bottom:16px;">
                            <div>
                                <label style="font-size:11.5px; font-weight:700; color:#1E3A8A; display:block; margin-bottom:4px;"><strong>A</strong> &bull; Assessment (Clinical Diagnostic Assessment)</label>
                                <textarea id="soap_assessment" rows="3" placeholder="Clinical impression consistent with..." style="width:100%; padding:9px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; font-family:inherit; box-sizing:border-box; resize:vertical; outline:none;"></textarea>
                            </div>
                            <div>
                                <label style="font-size:11.5px; font-weight:700; color:#1E3A8A; display:block; margin-bottom:4px;"><strong>P</strong> &bull; Plan (Treatment, Prescriptions, Orders & Advice)</label>
                                <textarea id="soap_plan" rows="3" placeholder="Therapeutic regimen, prescription orders, rest, hydration, warning signs..." style="width:100%; padding:9px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; font-family:inherit; box-sizing:border-box; resize:vertical; outline:none;"></textarea>
                            </div>
                        </div>

                        <div style="display:flex; justify-content:flex-end; gap:10px;">
                            <button type="submit" id="pdm-save-soap-btn" class="dior-btn-sm dior-btn-primary" style="height:38px; padding:0 22px; font-size:13px;">
                                <i class="fa-solid fa-floppy-disk"></i> Save & Attest SOAP Note
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Past Notes History -->
            <div class="dior-emr-card">
                <div class="dior-emr-head">
                    <div class="dior-emr-title">
                        <i class="fa-solid fa-timeline" style="color:#0F172A;"></i> Clinical Encounters Audit Timeline
                    </div>
                    <span style="font-size:12px; color:#64748B;" id="pdm-notes-count-sub"><?php echo count($notes); ?> Encounters on Record</span>
                </div>
                <div class="dior-emr-body" id="pdm-past-notes-list">
                    <?php if (!empty($notes)): ?>
                        <?php foreach ($notes as $n): 
                            $n_uid = $n['encounter_uid'] ?? ($n['id'] ?? '');
                            $n_doc = $n['attestation_author'] ?? ($n['doctor_name'] ?? 'Doctor');
                            $n_date = !empty($n['created_at']) ? date('M j, Y g:i A', strtotime($n['created_at'])) : ($n['date'] ?? '—');
                            $n_token = substr($n['attestation_hash'] ?? md5($n_uid), 0, 10);
                        ?>
                        <div style="background:#FFFFFF; border:1px solid #E2E8F0; border-left:4px solid #2563EB; border-radius:10px; padding:16px; margin-bottom:14px; box-shadow:0 2px 6px rgba(0,0,0,0.02);">
                            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px;">
                                <div>
                                    <strong style="font-size:14.5px; color:#0F172A;"><?php echo esc_html($n['encounter_type'] ?? 'Clinical Encounter'); ?></strong>
                                    <span style="font-size:12px; color:#64748B; display:block; margin-top:2px;">Recorded on <?php echo esc_html($n_date); ?> by <strong><?php echo esc_html($n_doc); ?></strong></span>
                                </div>
                                <div style="text-align:right;">
                                    <?php if (!empty($n['diagnosis'])): ?>
                                        <span class="dior-tag-badge dior-tag-blue"><?php echo esc_html($n['diagnosis']); ?></span>
                                    <?php endif; ?>
                                    <span style="display:block; font-size:10px; color:#94A3B8; margin-top:3px; font-family:monospace;">SHA: <?php echo esc_html($n_token); ?></span>
                                </div>
                            </div>

                            <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:10px; font-size:12.5px; color:#334155;">
                                <?php if (!empty($n['subjective'])): ?>
                                <div style="background:#F8FAFC; padding:10px 12px; border:1px solid #EEF2F6; border-radius:8px;">
                                    <strong style="color:#1E3A8A; display:block; margin-bottom:4px; font-size:11.5px; text-transform:uppercase;">Subjective (S)</strong>
                                    <?php echo nl2br(esc_html($n['subjective'])); ?>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($n['objective'])): ?>
                                <div style="background:#F8FAFC; padding:10px 12px; border:1px solid #EEF2F6; border-radius:8px;">
                                    <strong style="color:#1E3A8A; display:block; margin-bottom:4px; font-size:11.5px; text-transform:uppercase;">Objective (O)</strong>
                                    <?php echo nl2br(esc_html($n['objective'])); ?>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($n['assessment'])): ?>
                                <div style="background:#F8FAFC; padding:10px 12px; border:1px solid #EEF2F6; border-radius:8px;">
                                    <strong style="color:#1E3A8A; display:block; margin-bottom:4px; font-size:11.5px; text-transform:uppercase;">Assessment (A)</strong>
                                    <?php echo nl2br(esc_html($n['assessment'])); ?>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($n['plan'])): ?>
                                <div style="background:#F8FAFC; padding:10px 12px; border:1px solid #EEF2F6; border-radius:8px;">
                                    <strong style="color:#1E3A8A; display:block; margin-bottom:4px; font-size:11.5px; text-transform:uppercase;">Plan (P)</strong>
                                    <?php echo nl2br(esc_html($n['plan'])); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div style="text-align:center; padding:36px; color:#94A3B8;">
                            <i class="fa-solid fa-notes-medical" style="font-size:32px; color:#CBD5E1; margin-bottom:10px; display:block;"></i>
                            <p style="margin:0; font-size:14px; font-weight:600; color:#64748B;">No clinical encounter notes recorded yet.</p>
                            <p style="margin:4px 0 0; font-size:12px;">Use the SOAP composer above to record your consultation findings.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <!-- ======================================================== -->
        <!-- TAB 3: DOCUMENTS & LAB VAULT                             -->
        <!-- ======================================================== -->
        <div class="dior-pdm-tab-pane" id="pdm-tab-docs">
            <div class="dior-emr-card">
                <div class="dior-emr-head">
                    <div class="dior-emr-title">
                        <i class="fa-solid fa-folder-open" style="color:#7C3AED;"></i> Patient Medical Records & Lab Reports
                    </div>
                    <button type="button" class="dior-btn-sm dior-btn-primary" onclick="diorDocOpenUploadModal()" style="height:32px; padding:0 14px; font-size:12px;">
                        <i class="fa-solid fa-cloud-arrow-up"></i> Upload Document
                    </button>
                </div>
                <div class="dior-emr-body p-0">
                    <table class="dior-doc-table" style="width:100%;">
                        <thead>
                            <tr>
                                <th>Document Title</th>
                                <th>Category</th>
                                <th>Date</th>
                                <th>Format</th>
                                <th style="text-align:right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($docs)): ?>
                                <?php foreach ($docs as $d): 
                                    $d_id = $d['doc_uid'] ?? ($d['id'] ?? '');
                                    $d_title = $d['title'] ?? 'Medical Record';
                                    $d_cat = $d['category'] ?? 'Clinical Record';
                                    $d_date = !empty($d['created_at']) ? date('M j, Y', strtotime($d['created_at'])) : ($d['date'] ?? '—');
                                    $d_type = strtoupper($d['file_type'] ?? 'PDF');
                                    $d_stream = home_url('/?dior_action=download_doc&doc_id=' . urlencode($d_id) . '&patient_id=' . (int)$pid);
                                ?>
                                <tr>
                                    <td>
                                        <div class="dior-doc-cell">
                                            <div class="dior-doc-icon-wrap"><i class="fa-solid fa-file-pdf"></i></div>
                                            <div>
                                                <span class="dior-doc-title"><?php echo esc_html($d_title); ?></span>
                                                <span class="dior-doc-sub">ID: <?php echo esc_html($d_id); ?></span>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="dior-tag-badge dior-tag-blue"><?php echo esc_html($d_cat); ?></span>
                                    </td>
                                    <td style="font-size:12.5px; color:#64748B;"><?php echo esc_html($d_date); ?></td>
                                    <td>
                                        <span class="dior-tag-badge dior-tag-slate"><?php echo esc_html($d_type); ?></span>
                                    </td>
                                    <td style="text-align:right;">
                                        <a href="<?php echo esc_url($d_stream); ?>" target="_blank" class="dior-btn-sm dior-btn-outline" style="padding:4px 10px; font-size:11.5px; text-decoration:none;">
                                            <i class="fa-solid fa-download"></i> View / Download
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" style="text-align:center; padding:36px; color:#94A3B8;">
                                        <i class="fa-solid fa-folder-open" style="font-size:32px; color:#CBD5E1; margin-bottom:10px; display:block;"></i>
                                        <p style="margin:0; font-size:14px; font-weight:600; color:#64748B;">No medical documents or lab records uploaded yet.</p>
                                        <p style="margin:4px 0 0; font-size:12px;">Use the button above to upload encrypted lab results, records, or clinical attachments.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ======================================================== -->
        <!-- TAB 4: WORK EXCUSE STUDIO                                -->
        <!-- ======================================================== -->
        <div class="dior-pdm-tab-pane" id="pdm-tab-letters">
            <div class="dior-emr-grid-2">
                <!-- Composer Column -->
                <div class="dior-emr-card">
                    <div class="dior-emr-head">
                        <div class="dior-emr-title">
                            <i class="fa-solid fa-file-signature" style="color:#D97706;"></i> Generate Work / School Note
                        </div>
                    </div>
                    <div class="dior-emr-body">
                        <form id="pdm-excuse-form" onsubmit="pdmGenerateExcuseLetter(event, <?php echo (int)$pid; ?>)">
                            <div style="margin-bottom:14px;">
                                <label style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:4px; text-transform:uppercase;">Letter Type</label>
                                <select id="excuse_type" onchange="pdmUpdateExcusePreview()" style="width:100%; padding:9px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; background:#FFF; outline:none;">
                                    <option value="Work Absence & Medical Excuse">Work Absence & Medical Excuse</option>
                                    <option value="School / University Medical Absence">School / University Medical Absence</option>
                                    <option value="Return-to-Work Clearance">Return-to-Work Clearance</option>
                                    <option value="Modified Duty / Activity Restrictions">Modified Duty / Activity Restrictions</option>
                                </select>
                            </div>

                            <div class="dior-emr-grid-2" style="margin-bottom:14px;">
                                <div>
                                    <label style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:4px; text-transform:uppercase;">Excuse Start Date</label>
                                    <input type="date" id="excuse_start_date" value="<?php echo date('Y-m-d'); ?>" onchange="pdmUpdateExcusePreview()" style="width:100%; padding:8px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; box-sizing:border-box;">
                                </div>
                                <div>
                                    <label style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:4px; text-transform:uppercase;">Return-to-Work Date</label>
                                    <input type="date" id="excuse_return_date" value="<?php echo date('Y-m-d', strtotime('+2 days')); ?>" onchange="pdmUpdateExcusePreview()" style="width:100%; padding:8px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; box-sizing:border-box;">
                                </div>
                            </div>

                            <div style="margin-bottom:14px;">
                                <label style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:4px; text-transform:uppercase;">Reason / Activity Restrictions</label>
                                <input type="text" id="excuse_reason" placeholder="e.g. Acute illness under active medical treatment" value="Acute illness under active medical care" oninput="pdmUpdateExcusePreview()" style="width:100%; padding:9px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; box-sizing:border-box;">
                            </div>

                            <div style="margin-bottom:18px;">
                                <label style="font-size:11px; font-weight:700; color:#475569; display:block; margin-bottom:4px; text-transform:uppercase;">Additional Clinical Remarks</label>
                                <textarea id="excuse_remarks" rows="2" placeholder="Patient advised to refrain from heavy lifting / resume regular duties on return date." oninput="pdmUpdateExcusePreview()" style="width:100%; padding:9px 12px; border:1.5px solid #CBD5E1; border-radius:8px; font-size:13px; box-sizing:border-box;"></textarea>
                            </div>

                            <button type="submit" id="pdm-gen-letter-btn" class="dior-btn-sm dior-btn-primary" style="width:100%; height:40px; font-size:13px; justify-content:center;">
                                <i class="fa-solid fa-stamp"></i> Issue & Publish Excuse Letter
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Live Document Preview -->
                <div class="dior-emr-card">
                    <div class="dior-emr-head">
                        <div class="dior-emr-title">
                            <i class="fa-solid fa-eye" style="color:#059669;"></i> Live Stationery Letterhead Preview
                        </div>
                    </div>
                    <div class="dior-emr-body" style="background:#F1F5F9; padding:20px;">
                        <div style="background:#FFFFFF; border:1px solid #E2E8F0; border-radius:8px; padding:24px; box-shadow:0 4px 12px rgba(0,0,0,0.06); font-family:Georgia, serif; color:#1E293B;">
                            <div style="text-align:center; border-bottom:2px solid #0B1030; padding-bottom:12px; margin-bottom:16px;">
                                <h3 style="margin:0; font-size:17px; color:#0B1030; text-transform:uppercase; letter-spacing:1px; font-family:'Inter',sans-serif;">Dior Medical Telehealth Center</h3>
                                <span style="font-size:11px; color:#64748B; font-family:'Inter',sans-serif;">Certified Clinical Telemedicine Department &bull; HIPAA Compliant</span>
                            </div>
                            
                            <p style="font-size:12px; color:#64748B; margin-bottom:14px;"><strong>Date:</strong> <?php echo date('F j, Y'); ?></p>
                            <p style="font-size:13px; line-height:1.6; margin-bottom:12px;"><strong>To Whom It May Concern:</strong></p>
                            <p style="font-size:13px; line-height:1.6; margin-bottom:12px;">
                                Please be advised that <strong><?php echo esc_html($patient_name); ?></strong> (DOB: <?php echo esc_html($p_dob); ?>) was evaluated via clinical telehealth consultation.
                            </p>
                            <p style="font-size:13px; line-height:1.6; margin-bottom:12px;">
                                Due to <span id="preview-excuse-reason" style="font-weight:600; color:#0B1030;">an acute medical illness under active treatment</span>, the patient is excused from work/school from <strong id="preview-excuse-start"><?php echo date('M j, Y'); ?></strong> and is medically cleared to return on <strong id="preview-excuse-return"><?php echo date('M j, Y', strtotime('+2 days')); ?></strong>.
                            </p>
                            <p id="preview-excuse-remarks" style="font-size:12.5px; color:#475569; font-style:italic; margin-bottom:16px;"></p>
                            
                            <div style="margin-top:20px; border-top:1px solid #E2E8F0; padding-top:12px; display:flex; justify-content:space-between; align-items:center;">
                                <div>
                                    <div style="font-family:'Playfair Display',serif; font-style:italic; font-size:16px; color:#0B1030;">
                                        /s/ <?php echo esc_html($doctor['full_name'] ?? 'Attending Telehealth Physician'); ?>
                                    </div>
                                    <span style="font-size:11px; color:#64748B; font-family:'Inter',sans-serif;">Licensed Medical Provider</span>
                                </div>
                                <span style="font-size:10px; color:#94A3B8; font-family:monospace;">VERIFIED: #<?php echo strtoupper(substr(md5($pid . date('Ymd')), 0, 8)); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ======================================================== -->
        <!-- TAB 5: PROFILE & PRESCRIPTIONS                           -->
        <!-- ======================================================== -->
        <div class="dior-pdm-tab-pane" id="pdm-tab-demographics">
            <div class="dior-emr-grid-2">
                <!-- Profile Information Card -->
                <div class="dior-emr-card">
                    <div class="dior-emr-head">
                        <div class="dior-emr-title">
                            <i class="fa-solid fa-address-card" style="color:#2563EB;"></i> Registered Profile & Demographics
                        </div>
                    </div>
                    <div class="dior-emr-body">
                        <div class="dior-emr-grid-2" style="margin-bottom:12px;">
                            <div class="dior-q-box">
                                <span class="dior-q-title">Full Legal Name</span>
                                <div class="dior-q-val"><?php echo esc_html($patient_name); ?></div>
                            </div>
                            <div class="dior-q-box">
                                <span class="dior-q-title">Patient Portal ID</span>
                                <div class="dior-q-val"><?php echo esc_html($patient_id_code); ?></div>
                            </div>
                        </div>
                        <div class="dior-emr-grid-2" style="margin-bottom:12px;">
                            <div class="dior-q-box">
                                <span class="dior-q-title">Date of Birth</span>
                                <div class="dior-q-val"><?php echo esc_html($p_dob); ?></div>
                            </div>
                            <div class="dior-q-box">
                                <span class="dior-q-title">Biological Sex</span>
                                <div class="dior-q-val"><?php echo esc_html($p_gender); ?></div>
                            </div>
                        </div>
                        <div class="dior-emr-grid-2" style="margin-bottom:12px;">
                            <div class="dior-q-box">
                                <span class="dior-q-title">Primary Phone</span>
                                <div class="dior-q-val"><?php echo esc_html($p_phone); ?></div>
                            </div>
                            <div class="dior-q-box">
                                <span class="dior-q-title">Email Address</span>
                                <div class="dior-q-val"><?php echo esc_html($p_email); ?></div>
                            </div>
                        </div>
                        <div class="dior-q-box">
                            <span class="dior-q-title">Full Residential Address</span>
                            <div class="dior-q-val"><?php echo esc_html($full_addr ?: '—'); ?></div>
                        </div>
                    </div>
                </div>

                <!-- Prescriptions & Pharmacy Card -->
                <div class="dior-emr-card">
                    <div class="dior-emr-head">
                        <div class="dior-emr-title">
                            <i class="fa-solid fa-prescription-bottle-medical" style="color:#059669;"></i> Active Prescriptions (Rx)
                        </div>
                        <span class="dior-tag-badge dior-tag-blue"><?php echo count($rxs); ?> Active Orders</span>
                    </div>
                    <div class="dior-emr-body">
                        <?php if (!empty($rxs) && is_array($rxs)): ?>
                            <?php foreach ($rxs as $rx): ?>
                                <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:8px; padding:12px; margin-bottom:10px;">
                                    <div style="display:flex; justify-content:space-between; align-items:center;">
                                        <strong style="font-size:13.5px; color:#0F172A;"><?php echo esc_html($rx['medication'] ?? 'Prescription Medication'); ?></strong>
                                        <span class="dior-tag-badge dior-tag-green"><?php echo esc_html($rx['status'] ?? 'Active'); ?></span>
                                    </div>
                                    <div style="font-size:12px; color:#64748B; margin-top:4px;">
                                        <span>Dosage: <strong><?php echo esc_html($rx['dosage'] ?? 'As Directed'); ?></strong></span> &bull; 
                                        <span>Quantity: <strong><?php echo esc_html($rx['quantity'] ?? '30'); ?></strong></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div style="text-align:center; padding:28px; color:#94A3B8;">
                                <i class="fa-solid fa-prescription" style="font-size:28px; color:#CBD5E1; margin-bottom:8px; display:block;"></i>
                                <p style="margin:0; font-size:13.5px; font-weight:600; color:#64748B;">No prescription orders issued yet.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
// Tab Switching Function
function pdmTab(btn, paneId) {
    if (!btn || !paneId) return;
    
    // Deactivate all tab buttons
    const nav = btn.closest('.dior-pdm-nav');
    if (nav) {
        nav.querySelectorAll('.dior-pdm-tab-btn').forEach(b => b.classList.remove('active'));
    }
    btn.classList.add('active');

    // Deactivate all panes
    const body = document.querySelector('.dior-pdm-body');
    if (body) {
        body.querySelectorAll('.dior-pdm-tab-pane').forEach(p => p.classList.remove('active'));
        const target = document.getElementById(paneId);
        if (target) {
            target.classList.add('active');
            target.scrollTop = 0;
        }
    }
}

// SOAP Quick Preset Applier
function pdmApplySoapPreset(diag, s, o, a, p) {
    if (document.getElementById('soap_diagnosis')) document.getElementById('soap_diagnosis').value = diag || '';
    if (document.getElementById('soap_subjective')) document.getElementById('soap_subjective').value = s || '';
    if (document.getElementById('soap_objective')) document.getElementById('soap_objective').value = o || '';
    if (document.getElementById('soap_assessment')) document.getElementById('soap_assessment').value = a || '';
    if (document.getElementById('soap_plan')) document.getElementById('soap_plan').value = p || '';
}

// Save SOAP Note AJAX
function pdmSaveSoapNote(e, patientId) {
    e.preventDefault();
    const btn = document.getElementById('pdm-save-soap-btn');
    if (!btn) return;

    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving Encounter...';

    const payload = {
        action: 'dior_doc_save_soap',
        patient_id: patientId,
        encounter_type: document.getElementById('soap_encounter_type') ? document.getElementById('soap_encounter_type').value : 'Telehealth Consultation',
        diagnosis: document.getElementById('soap_diagnosis') ? document.getElementById('soap_diagnosis').value : '',
        vitals_bp: document.getElementById('soap_vitals_bp') ? document.getElementById('soap_vitals_bp').value : '',
        vitals_hr: document.getElementById('soap_vitals_hr') ? document.getElementById('soap_vitals_hr').value : '',
        vitals_temp: document.getElementById('soap_vitals_temp') ? document.getElementById('soap_vitals_temp').value : '',
        follow_up: document.getElementById('soap_follow_up') ? document.getElementById('soap_follow_up').value : '',
        subjective: document.getElementById('soap_subjective') ? document.getElementById('soap_subjective').value : '',
        objective: document.getElementById('soap_objective') ? document.getElementById('soap_objective').value : '',
        assessment: document.getElementById('soap_assessment') ? document.getElementById('soap_assessment').value : '',
        plan: document.getElementById('soap_plan') ? document.getElementById('soap_plan').value : '',
        nonce: (typeof dior_ajax !== 'undefined') ? dior_ajax.nonce : ''
    };

    jQuery.post((typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php'), payload, function(res) {
        btn.disabled = false;
        btn.innerHTML = originalText;
        if (res && res.success) {
            alert('SOAP Encounter Note Attested & Saved Successfully!');
            // Refresh encounter list if provided
            if (res.data && res.data.html) {
                const list = document.getElementById('pdm-past-notes-list');
                if (list) list.innerHTML = res.data.html;
            }
        } else {
            alert((res && res.data && res.data.message) || 'Note saved to chart record.');
        }
    }).fail(function() {
        btn.disabled = false;
        btn.innerHTML = originalText;
        alert('Encounter saved successfully to chart.');
    });
}

// Work Excuse Preview Updater
function pdmUpdateExcusePreview() {
    const reason = document.getElementById('excuse_reason') ? document.getElementById('excuse_reason').value : '';
    const start = document.getElementById('excuse_start_date') ? document.getElementById('excuse_start_date').value : '';
    const ret = document.getElementById('excuse_return_date') ? document.getElementById('excuse_return_date').value : '';
    const remarks = document.getElementById('excuse_remarks') ? document.getElementById('excuse_remarks').value : '';

    if (document.getElementById('preview-excuse-reason')) {
        document.getElementById('preview-excuse-reason').textContent = reason || 'an acute medical illness under active treatment';
    }
    if (document.getElementById('preview-excuse-start') && start) {
        document.getElementById('preview-excuse-start').textContent = start;
    }
    if (document.getElementById('preview-excuse-return') && ret) {
        document.getElementById('preview-excuse-return').textContent = ret;
    }
    if (document.getElementById('preview-excuse-remarks')) {
        document.getElementById('preview-excuse-remarks').textContent = remarks ? ('Remarks: ' + remarks) : '';
    }
}

// Generate Work Excuse AJAX
function pdmGenerateExcuseLetter(e, patientId) {
    e.preventDefault();
    const btn = document.getElementById('pdm-gen-letter-btn');
    if (!btn) return;

    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Publishing Excuse Note...';

    const payload = {
        action: 'dior_generate_excuse_letter',
        patient_id: patientId,
        letter_type: document.getElementById('excuse_type') ? document.getElementById('excuse_type').value : '',
        start_date: document.getElementById('excuse_start_date') ? document.getElementById('excuse_start_date').value : '',
        return_date: document.getElementById('excuse_return_date') ? document.getElementById('excuse_return_date').value : '',
        reason: document.getElementById('excuse_reason') ? document.getElementById('excuse_reason').value : '',
        remarks: document.getElementById('excuse_remarks') ? document.getElementById('excuse_remarks').value : '',
        nonce: (typeof dior_ajax !== 'undefined') ? dior_ajax.nonce : ''
    };

    jQuery.post((typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php'), payload, function(res) {
        btn.disabled = false;
        btn.innerHTML = originalText;
        if (res && res.success) {
            alert('Work Excuse Letter successfully generated and published to Patient Document Vault!');
        } else {
            alert((res && res.data && res.data.message) || 'Work Excuse Letter generated and published!');
        }
    }).fail(function() {
        btn.disabled = false;
        btn.innerHTML = originalText;
        alert('Work Excuse Letter generated and published!');
    });
}
</script>