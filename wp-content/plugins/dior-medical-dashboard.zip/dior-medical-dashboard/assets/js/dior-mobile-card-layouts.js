/**
 * Dior Medical Dashboard — dedicated mobile record cards.
 * Desktop tables remain intact. Mobile cards are built from existing rows;
 * actions proxy clicks to the original controls to preserve handlers/permissions.
 */
(function () {
  'use strict';

  var rootSelector = '#dior-patient-portal-app, #dior-doctor-app';
  var tableSelector = '.dior-tab-panel table';

  function textOf(node) {
    return String(node ? node.textContent : '').replace(/\s+/g, ' ').trim();
  }

  function isCalendar(table) {
    return table.id === 'dior-doc-cal-grid-table' ||
      table.querySelector('#dior-doc-cal-grid-body') ||
      table.classList.contains('dior-bs-cal-table') ||
      table.closest('.dior-bs-calendar-container, #dior-doc-cal-month-wrap');
  }

  function isEmptyRow(row, cells) {
    return row.classList.contains('dior-empty-state') ||
      row.classList.contains('dior-mobile-empty-row') ||
      (cells.length === 1 && (cells[0].hasAttribute('colspan') ||
        /no .*found|no .*available|no records|no appointments|no prescriptions/i.test(textOf(cells[0]))));
  }

  function removeIds(node) {
    if (node.nodeType !== 1) return;
    node.removeAttribute('id');
    node.querySelectorAll('[id]').forEach(function (el) { el.removeAttribute('id'); });
  }

  function makeActionProxy(source) {
    if (source.tagName === 'A' && source.href && !source.hasAttribute('onclick')) {
      var link = document.createElement('a');
      link.className = source.className + ' dior-mobile-action-proxy';
      link.href = source.href;
      link.target = source.target || '';
      link.rel = source.rel || 'noopener noreferrer';
      link.title = source.title || source.getAttribute('aria-label') || textOf(source);
      link.setAttribute('aria-label', source.getAttribute('aria-label') || link.title || 'Open link');
      link.innerHTML = source.innerHTML;
      if (source.hasAttribute('download')) link.setAttribute('download', source.getAttribute('download') || '');
      return link;
    }

    var button = document.createElement('button');
    button.type = 'button';
    button.className = source.className + ' dior-mobile-action-proxy';
    button.innerHTML = source.innerHTML;
    button.title = source.title || source.getAttribute('aria-label') || textOf(source) || 'Action';
    button.setAttribute('aria-label', source.getAttribute('aria-label') || button.title);
    button.disabled = !!source.disabled;
    button.addEventListener('click', function (event) {
      event.preventDefault();
      if (source.disabled) return;
      source.click();
    });
    return button;
  }

  function makeField(cell, label, index, total) {
    var field = document.createElement('div');
    field.className = 'dior-mobile-record-field';
    field.setAttribute('data-column-index', String(index));

    var heading = document.createElement('span');
    heading.className = 'dior-mobile-record-label';
    heading.textContent = label || (index === total - 1 ? 'Actions' : 'Details');
    field.appendChild(heading);

    var value = document.createElement('div');
    value.className = 'dior-mobile-record-value';
    var clone = cell.cloneNode(true);
    removeIds(clone);
    clone.querySelectorAll('button, a, input, select, textarea').forEach(function (control) {
      control.remove();
    });
    value.innerHTML = clone.innerHTML;
    value.querySelectorAll('[style]').forEach(function (el) {
      el.style.maxWidth = '100%';
      el.style.whiteSpace = 'normal';
      el.style.overflowWrap = 'anywhere';
    });
    field.appendChild(value);
    return field;
  }

  function makeSelection(cell, card) {
    var source = cell.querySelector('input[type="checkbox"]');
    if (!source) return;
    var line = document.createElement('div');
    line.className = 'dior-mobile-record-select';
    var proxy = document.createElement('input');
    proxy.type = 'checkbox';
    proxy.className = 'form-check-input';
    proxy.checked = source.checked;
    proxy.disabled = source.disabled;
    proxy.setAttribute('aria-label', 'Select record');
    var label = document.createElement('span');
    label.textContent = 'Select record';
    proxy.addEventListener('change', function () {
      if (source.checked !== proxy.checked) source.click();
      window.setTimeout(function () {
        card.closest('.dior-mobile-cards').querySelectorAll('.dior-mobile-record-select input[type="checkbox"]').forEach(function (check) {
          var sourceRow = check.closest('.dior-mobile-record-card');
          var index = Number(sourceRow && sourceRow.getAttribute('data-row-index'));
          var row = card._diorSourceTable && card._diorSourceTable.querySelectorAll('tbody tr')[index];
          var original = row && row.querySelector('input[type="checkbox"]');
          if (original) check.checked = original.checked;
        });
      }, 0);
    });
    line.appendChild(proxy);
    line.appendChild(label);
    card.appendChild(line);
  }

  function makeActions(cell, card) {
    var controls = Array.prototype.slice.call(cell.querySelectorAll('button, a'));
    if (!controls.length) return null;
    var actions = document.createElement('div');
    actions.className = 'dior-mobile-record-actions';
    controls.forEach(function (control) {
      actions.appendChild(makeActionProxy(control));
    });
    return actions;
  }

  function renderCards(table, cardWrap) {
    var headersRow = table.querySelector('thead tr:last-child');
    var tbody = table.querySelector('tbody');
    if (!headersRow || !tbody) return;

    var headers = Array.prototype.slice.call(headersRow.querySelectorAll('th')).map(textOf);
    var rows = Array.prototype.slice.call(tbody.querySelectorAll(':scope > tr'));
    var fragment = document.createDocumentFragment();
    var visibleRows = 0;

    rows.forEach(function (row, rowIndex) {
      var cells = Array.prototype.slice.call(row.children).filter(function (cell) { return cell.tagName === 'TD'; });
      if (!cells.length) return;

      if (isEmptyRow(row, cells)) {
        var empty = document.createElement('div');
        empty.className = 'dior-mobile-record-empty';
        empty.textContent = textOf(cells[0]) || 'No records available.';
        empty.hidden = row.style.display === 'none';

        // Preserve existing empty-state actions such as Book, Add, or Retry.
        var emptyControls = [];
        cells.forEach(function (cell) {
          emptyControls = emptyControls.concat(Array.prototype.slice.call(cell.querySelectorAll('button, a')));
        });
        if (emptyControls.length) {
          var emptyActions = document.createElement('div');
          emptyActions.className = 'dior-mobile-record-actions';
          emptyControls.forEach(function (control) {
            emptyActions.appendChild(makeActionProxy(control));
          });
          empty.appendChild(emptyActions);
        }

        fragment.appendChild(empty);
        return;
      }

      var card = document.createElement('article');
      card.className = 'card dior-mobile-record-card';
      card.setAttribute('data-row-index', String(rowIndex));
      card._diorSourceTable = table;
      card.hidden = row.style.display === 'none';

      var body = document.createElement('div');
      body.className = 'card-body';
      var selectionCellIndex = cells.findIndex(function (cell) { return !!cell.querySelector('input[type="checkbox"]'); });
      if (selectionCellIndex !== -1) makeSelection(cells[selectionCellIndex], card);

      var actionsIndex = -1;
      for (var i = cells.length - 1; i >= 0; i--) {
        if (cells[i].querySelector('button, a')) { actionsIndex = i; break; }
      }

      var fields = document.createElement('div');
      fields.className = 'dior-mobile-record-fields';
      cells.forEach(function (cell, cellIndex) {
        if (cellIndex === selectionCellIndex) return;
        if (cellIndex === actionsIndex) return;
        if (cell.hasAttribute('colspan')) return;
        fields.appendChild(makeField(cell, headers[cellIndex], cellIndex, cells.length));
      });
      body.appendChild(fields);

      if (actionsIndex !== -1) {
        var actions = makeActions(cells[actionsIndex], card);
        if (actions) body.appendChild(actions);
      }
      card.appendChild(body);
      if (row.style.display === 'none') card.hidden = true;
      fragment.appendChild(card);
      visibleRows++;
    });

    cardWrap.replaceChildren(fragment);
    cardWrap.dataset.recordCount = String(visibleRows);
  }

  function prepareTable(table) {
    if (!table || table.dataset.diorMobileCardsReady === '1' || table.closest('.modal')) return;
    if (isCalendar(table)) return;
    // Today's Appointments has its own dedicated mobile markup in the template.
    if (table.id === 'dior-today-appointments-table') return;

    var header = table.querySelector('thead tr:last-child th');
    var tbody = table.querySelector('tbody');
    if (!header || !tbody) return;

    var sourceWrapper = table.parentElement;
    if (!sourceWrapper) return;
    sourceWrapper.classList.add('dior-mobile-source-wrapper');

    var cards = document.createElement('div');
    cards.className = 'dior-mobile-cards d-md-none';
    cards.setAttribute('aria-label', 'Mobile record cards');
    sourceWrapper.insertAdjacentElement('afterend', cards);
    table.dataset.diorMobileCardsReady = '1';
    table.dataset.diorMobileCardsWrapper = 'ready';

    var schedule = function () {
      window.clearTimeout(table._diorMobileRenderTimer);
      table._diorMobileRenderTimer = window.setTimeout(function () {
        renderCards(table, cards);
      }, 40);
    };
    schedule();

    var observer = new MutationObserver(schedule);
    observer.observe(tbody, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] });
    table._diorMobileCardObserver = observer;
  }

  function installDoctorMobileNavigation(root) {
    if (!root || root.id !== 'dior-doctor-app' || root.querySelector('.dior-doctor-mobile-bottom-nav')) return;

    var nav = document.createElement('nav');
    nav.className = 'dior-doctor-mobile-bottom-nav';
    nav.setAttribute('aria-label', 'Doctor dashboard mobile navigation');
    nav.innerHTML =
      '<button type="button" class="dior-doctor-mobile-nav-item" data-tab="doc-overview" aria-label="Dashboard">' +
        '<i class="fas fa-house" aria-hidden="true"></i><span>Dashboard</span></button>' +
      '<button type="button" class="dior-doctor-mobile-nav-item" data-tab="doc-appointments" aria-label="Appointments">' +
        '<i class="fas fa-calendar-days" aria-hidden="true"></i><span>Appointments</span></button>' +
      '<button type="button" class="dior-doctor-mobile-nav-item" data-tab="doc-patients-all" aria-label="Patients">' +
        '<i class="fas fa-user-group" aria-hidden="true"></i><span>Patients</span></button>' +
      '<button type="button" class="dior-doctor-mobile-nav-item" data-tab="doc-e-prescriptions" aria-label="Prescriptions">' +
        '<i class="fas fa-prescription-bottle-medical" aria-hidden="true"></i><span>Prescriptions</span></button>' +
      '<button type="button" class="dior-doctor-mobile-nav-item dior-doctor-mobile-more" aria-label="More navigation options">' +
        '<i class="fas fa-ellipsis" aria-hidden="true"></i><span>More</span></button>';

    nav.addEventListener('click', function (event) {
      var item = event.target.closest('.dior-doctor-mobile-nav-item');
      if (!item) return;
      var tabId = item.getAttribute('data-tab');
      if (tabId) {
        var original = root.querySelector('.dior-nav-btn[data-tab="' + tabId + '"]');
        if (original) original.click();
        return;
      }
      if (typeof window.diorDocOpenMobile === 'function') {
        window.diorDocOpenMobile();
      } else {
        var menuToggle = root.querySelector('.dior-mobile-menu-toggle');
        if (menuToggle) menuToggle.click();
      }
    });

    root.appendChild(nav);

    var syncActive = function () {
      var activeTab = root.querySelector('.dior-nav-btn.active[data-tab], .dior-nav-btn[aria-current="page"][data-tab]');
      var activeId = activeTab ? activeTab.getAttribute('data-tab') : '';
      nav.querySelectorAll('.dior-doctor-mobile-nav-item[data-tab]').forEach(function (item) {
        var isActive = item.getAttribute('data-tab') === activeId ||
          (item.getAttribute('data-tab') === 'doc-appointments' && activeId.indexOf('doc-appointments') === 0) ||
          (item.getAttribute('data-tab') === 'doc-patients-all' && activeId.indexOf('doc-patients-') === 0);
        item.classList.toggle('is-active', !!isActive);
        if (isActive) item.setAttribute('aria-current', 'page');
        else item.removeAttribute('aria-current');
      });
    };
    syncActive();
    var navObserver = new MutationObserver(syncActive);
    navObserver.observe(root, { subtree: true, attributes: true, attributeFilter: ['class', 'aria-current'] });
  }

  function init() {
    document.querySelectorAll(rootSelector).forEach(function (root) {
      root.querySelectorAll(tableSelector).forEach(prepareTable);
      installDoctorMobileNavigation(root);
    });
  }

  function boot() {
    init();
    var observer = new MutationObserver(function (mutations) {
      var hasNewTables = mutations.some(function (mutation) {
        return Array.prototype.some.call(mutation.addedNodes || [], function (node) {
          return node.nodeType === 1 && (node.matches && node.matches(tableSelector) || node.querySelector && node.querySelector(tableSelector));
        });
      });
      if (hasNewTables) init();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();