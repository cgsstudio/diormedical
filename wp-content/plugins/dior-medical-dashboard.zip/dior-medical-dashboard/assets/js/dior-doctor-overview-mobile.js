/* DIOR Doctor Dashboard — mobile overview cards.
 * Uses existing server-rendered rows; no replacement data or new actions are introduced.
 */
(function () {
    'use strict';

    function initDoctorOverviewMobile() {
        var root = document.querySelector('#dior-doctor-app #tab-doc-overview');
        if (!root || root.dataset.mobileOverviewReady === '1') return;
        root.dataset.mobileOverviewReady = '1';

        var tables = Array.prototype.slice.call(root.querySelectorAll('.table-card .table-responsive table'));
        if (!tables.length) return;

        function textOf(node) {
            return String(node ? node.textContent : '').replace(/\s+/g, ' ').trim();
        }

        function buildCard(table, row, headers, index) {
            var cells = Array.prototype.slice.call(row.cells || []);
            if (!cells.length || cells.length === 1 && cells[0].colSpan > 1) {
                var empty = document.createElement('div');
                empty.className = 'dior-doctor-overview-card text-center text-secondary small';
                empty.textContent = textOf(cells[0]) || 'No records available.';
                return empty;
            }

            var card = document.createElement('article');
            card.className = 'dior-doctor-overview-card';

            var head = document.createElement('div');
            head.className = 'dior-doctor-overview-card-head';
            var primaryIndex = table.dataset.mobilePrimaryIndex !== undefined
                ? parseInt(table.dataset.mobilePrimaryIndex, 10) : 1;
            var primaryCell = cells[primaryIndex] || cells[0];
            var primaryText = textOf(primaryCell) || 'Record ' + (index + 1);
            head.textContent = primaryText;
            card.appendChild(head);

            var fields = document.createElement('div');
            fields.className = 'dior-doctor-overview-fields';
            var actionCell = null;

            cells.forEach(function (cell, cellIndex) {
                var label = headers[cellIndex] || ('Detail ' + (cellIndex + 1));
                if (/^action$/i.test(label) || cell.querySelector('button, a')) {
                    if (cell.querySelector('button, a')) actionCell = cell;
                    if (/^action$/i.test(label)) return;
                }

                var field = document.createElement('div');
                field.className = 'dior-doctor-overview-field';
                var labelNode = document.createElement('span');
                labelNode.className = 'dior-doctor-overview-label';
                labelNode.textContent = label;
                var valueNode = document.createElement('span');
                valueNode.className = 'dior-doctor-overview-value';
                valueNode.textContent = textOf(cell) || '—';
                field.appendChild(labelNode);
                field.appendChild(valueNode);
                fields.appendChild(field);
            });

            if (fields.children.length) card.appendChild(fields);

            if (actionCell) {
                var actions = document.createElement('div');
                actions.className = 'dior-doctor-overview-actions';
                Array.prototype.forEach.call(actionCell.querySelectorAll('button, a'), function (source) {
                    var clone = source.cloneNode(true);
                    clone.removeAttribute('id');
                    actions.appendChild(clone);
                });
                if (actions.children.length) card.appendChild(actions);
            }

            return card;
        }

        function renderTable(table) {
            var wrapper = table.closest('.table-responsive');
            var body = table.tBodies && table.tBodies[0];
            if (!wrapper || !body) return false;

            var host = wrapper.parentNode.querySelector('.dior-doctor-overview-mobile-list');
            if (!host) {
                host = document.createElement('div');
                host.className = 'dior-doctor-overview-mobile-list d-md-none';
                host.setAttribute('aria-live', 'polite');
                wrapper.insertAdjacentElement('afterend', host);
            }

            var headers = Array.prototype.map.call(table.querySelectorAll('thead th'), textOf);
            var fragment = document.createDocumentFragment();
            Array.prototype.forEach.call(body.rows, function (row, index) {
                fragment.appendChild(buildCard(table, row, headers, index));
            });
            host.replaceChildren(fragment);
            return true;
        }

        var rendered = tables.map(renderTable).every(Boolean);
        if (rendered) root.classList.add('dior-overview-mobile-ready');

        if (window.MutationObserver) {
            tables.forEach(function (table) {
                var body = table.tBodies && table.tBodies[0];
                if (!body) return;
                var observer = new MutationObserver(function () {
                    if (window.matchMedia && window.matchMedia('(max-width: 767.98px)').matches) {
                        renderTable(table);
                    }
                });
                observer.observe(body, { childList: true, subtree: true, characterData: true });
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initDoctorOverviewMobile);
    } else {
        initDoctorOverviewMobile();
    }

    document.addEventListener('dior:doctor-tab-changed', initDoctorOverviewMobile);
})();
