/** Small-screen enhancements shared by the patient and provider portals. */
(function () {
    'use strict';

    function init() {
        var app = document.getElementById('dior-patient-portal-app') || document.getElementById('dior-doctor-app');
        if (!app) return;
        var mobile = window.matchMedia('(max-width: 1024px)');
        var sidebar = app.querySelector('.dior-side');
        var toggle = app.querySelector('.dior-mobile-menu-toggle');
        var close = sidebar && sidebar.querySelector('.dior-side-close');
        var wasOpen = false;

        function syncDrawer() {
            if (!sidebar || !toggle) return;
            var open = mobile.matches && (sidebar.classList.contains('mobile-open') || sidebar.classList.contains('open'));
            toggle.setAttribute('aria-expanded', String(open));
            // A closed off-canvas menu must not remain in the keyboard tab order.
            if (mobile.matches && !open) sidebar.setAttribute('inert', '');
            else sidebar.removeAttribute('inert');
            if (open && !wasOpen && close) close.focus();
            if (!open && wasOpen && mobile.matches && sidebar.contains(document.activeElement)) toggle.focus();
            wasOpen = open;
        }
        if (sidebar) {
            new MutationObserver(syncDrawer).observe(sidebar, { attributes: true, attributeFilter: ['class'] });
            window.addEventListener('resize', syncDrawer);
            syncDrawer();
        }
        document.addEventListener('keydown', function (event) {
            if (!wasOpen || !sidebar) return;
            if (event.key === 'Escape') {
                event.preventDefault();
                if (app.id === 'dior-doctor-app') window.diorDocCloseMobile();
                else window.diorCloseMobileDrawer();
                toggle.focus();
            } else if (event.key === 'Tab') {
                var items = Array.prototype.filter.call(sidebar.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'), function (el) {
                    return el.getClientRects().length > 0;
                });
                if (!items.length) return;
                var first = items[0], last = items[items.length - 1];
                if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
                else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
            }
        });

        function prepareTables() {
            app.querySelectorAll('.dior-tab-panel table').forEach(function (table) {
                // Calendar grids are not data tables and have their own responsive layout.
                if (table.closest('.dior-bs-calendar-container, #dior-doc-cal-month-wrap') || table.classList.contains('dior-bs-cal-table')) return;
                var wrapper = table.parentElement;
                if (!wrapper || wrapper.dataset.diorResponsiveTable === 'true') return;
                if (!wrapper.matches('.table-responsive, .table-responsive-xl, .va-table-wrapper, .docs-table-wrapper, .table-wrap, .dior-card-scrollable')) {
                    wrapper = document.createElement('div');
                    table.parentNode.insertBefore(wrapper, table);
                    wrapper.appendChild(table);
                }
                wrapper.classList.add('table-responsive-xl', 'dior-responsive-table');
                wrapper.dataset.diorResponsiveTable = 'true';
                wrapper.setAttribute('role', 'region');
                wrapper.setAttribute('aria-label', 'Table, scroll horizontally to see all columns');
                var hint = document.createElement('p');
                hint.className = 'dior-table-scroll-hint small text-secondary mb-2';
                hint.textContent = 'Swipe or scroll to see the full table';
                hint.hidden = true;
                wrapper.parentNode.insertBefore(hint, wrapper);
            });
            updateTables();
        }
        function updateTables() {
            app.querySelectorAll('.dior-responsive-table').forEach(function (wrapper) {
                var overflow = mobile.matches && wrapper.clientWidth > 0 && wrapper.scrollWidth > wrapper.clientWidth + 1;
                var hint = wrapper.previousElementSibling;
                if (hint && hint.classList.contains('dior-table-scroll-hint')) hint.hidden = !overflow;
                if (overflow) wrapper.setAttribute('tabindex', '0');
                else wrapper.removeAttribute('tabindex');
            });
        }
        prepareTables();
        // AJAX-rendered records can introduce tables or change their scroll width.
        var tableUpdate;
        new MutationObserver(function () {
            window.clearTimeout(tableUpdate);
            tableUpdate = window.setTimeout(prepareTables, 50);
        }).observe(app, { childList: true, subtree: true });
        window.addEventListener('resize', updateTables);
        app.addEventListener('click', function () { window.setTimeout(prepareTables, 100); });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
}());
