/**
 * Independent mobile overview interactions.
 * Uses existing dashboard navigation and Bootstrap modal APIs without altering desktop scripts.
 */
(function () {
  'use strict';

  function initMobilePatientOverview() {
    var root = document.querySelector('#tab-overview .dior-patient-overview-mobile');
    if (!root || root.dataset.mobileOverviewReady === '1') return;
    root.dataset.mobileOverviewReady = '1';

    root.addEventListener('click', function (event) {
      var trigger = event.target.closest('[data-dior-mobile-tab]');
      if (!trigger || !root.contains(trigger)) return;

      var tab = trigger.getAttribute('data-dior-mobile-tab');
      if (!tab) return;

      event.preventDefault();
      if (typeof window.diorSwitchTab === 'function') {
        window.diorSwitchTab(tab);
      } else {
        window.location.hash = 'tab=' + encodeURIComponent(tab);
      }
    });

    root.addEventListener('click', function (event) {
      var modalTrigger = event.target.closest('[data-bs-target="#diorHealthGoalsModal"]');
      if (!modalTrigger || !root.contains(modalTrigger)) return;

      if (window.bootstrap && window.bootstrap.Modal) {
        var modal = document.getElementById('diorHealthGoalsModal');
        if (modal) window.bootstrap.Modal.getOrCreateInstance(modal).show();
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMobilePatientOverview, { once: true });
  } else {
    initMobilePatientOverview();
  }
})();
