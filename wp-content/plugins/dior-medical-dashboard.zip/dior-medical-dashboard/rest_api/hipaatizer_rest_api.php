<?php
/**
 * Hipaatizer REST API
 *
 * File:
 * wp-content/plugins/dior-medical-dashboard/rest_api/hipaatizer_rest_api.php
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register REST API routes
 */
add_action('rest_api_init', function () {

    /**
     * POST
     * Hipaatizer -> Dior Medical Dashboard
     *
     * URL:
     * /wp-json/dior/v1/hipaatizer
     */
    register_rest_route('dior/v1', '/hipaatizer', [
        'methods'  => WP_REST_Server::CREATABLE,
        'callback' => 'dior_handle_hipaatizer_data',
        'permission_callback' => 'dior_hipaatizer_permission',
    ]);

    /**
     * GET
     * Get patient information
     *
     * URL:
     * /wp-json/dior/v1/patient/{id}
     */
    register_rest_route('dior/v1', '/patient/(?P<id>\d+)', [
        'methods'  => WP_REST_Server::READABLE,
        'callback' => 'dior_get_patient_data',
        'permission_callback' => 'dior_patient_permission',
    ]);
});


/**
 * API Authentication
 *
 * For testing:
 *
 * Authorization: Bearer YOUR_SECRET_KEY
 */
function dior_check_api_token(WP_REST_Request $request) {

    $expected_token = 'CHANGE_THIS_SECRET_KEY';

    $authorization = $request->get_header('authorization');
    $url_token = $request->get_param('token');

    // 1. Check Header (Bearer Token)
    if ($authorization && preg_match('/Bearer\s+(.*)$/i', $authorization, $matches)) {
        $provided_token = trim($matches[1]);
        if (hash_equals($expected_token, $provided_token)) {
            return true;
        }
    }

    // 2. Check URL Parameter (e.g. ?token=CHANGE_THIS_SECRET_KEY)
    if ($url_token && hash_equals($expected_token, $url_token)) {
        return true;
    }

    return false;
}


/**
 * POST permission
 */
function dior_hipaatizer_permission(WP_REST_Request $request) {

    if (!dior_check_api_token($request)) {
        return new WP_Error(
            'dior_unauthorized',
            'Invalid API token.',
            ['status' => 401]
        );
    }

    return true;
}


/**
 * GET permission
 */
function dior_patient_permission(WP_REST_Request $request) {

    if (!dior_check_api_token($request)) {
        return new WP_Error(
            'dior_unauthorized',
            'Invalid API token.',
            ['status' => 401]
        );
    }

    return true;
}


/**
 * POST:
 * Receive Hipaatizer data
 */
function dior_handle_hipaatizer_data(WP_REST_Request $request) {
    global $wpdb;

    // --- DEBUG LOGGING ---
    $log_file = dirname(__FILE__) . '/api_debug.log';
    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] API Hit. Params:\n" . print_r($request->get_params(), true) . "\n\n", FILE_APPEND);
    // ---------------------

    /**
     * Get JSON body
     */
    $input = $request->get_json_params();

    if (empty($input) || !is_array($input)) {

        return new WP_Error(
            'invalid_json',
            'Invalid or empty JSON payload.',
            ['status' => 400]
        );
    }


    /**
     * Support:
     *
     * {
     *   "data": {
     *      "fields": {}
     *   }
     * }
     *
     * OR
     *
     * {
     *   "fields": {}
     * }
     */

    $data = isset($input['data']) && is_array($input['data'])
        ? $input['data']
        : $input;

    $fields = isset($data['fields']) && is_array($data['fields'])
        ? $data['fields']
        : $data;


    /**
     * Smart Field Extraction
     */
    $get_field = function($keys) use ($fields) {
        foreach ((array) $keys as $key) {
            if (isset($fields[$key]) && $fields[$key] !== '') {
                return sanitize_text_field($fields[$key]);
            }
        }
        return '';
    };

    $is_pregnant = $get_field(['is_pregnant', 'Are you currently pregnant?']);
    $consultation_type = $get_field(['consultation_type', 'Preferred Consultation Type']);
    $referral_source = $get_field(['referral_source', 'How did you hear about us?']);
    
    $street_address = $get_field(['street_address', 'Street Address', 'address', 'address_line_1']);
    $city = $get_field(['city', 'City']);
    $state = $get_field(['state', 'State']);
    $zip_code = $get_field(['zip_code', 'ZIP / PIN Code']);
    
    $emergency_contact_name = $get_field(['emergency_contact_name', 'Emergency Contact Name']);
    $emergency_contact_phone = $get_field(['emergency_contact_phone', 'Emergency Contact Phone']);
    
    $insurance_provider = $get_field(['insurance_provider', 'Insurance Provider Name']);
    $insurance_member_id = $get_field(['insurance_member_id', 'Insurance Member / Policy ID']);
    
    $patient_email = sanitize_email($get_field(['email', 'Email Address']));


    /**
     * Email required
     */
    if (empty($patient_email)) {

        return new WP_Error(
            'missing_email',
            'Patient email is required.',
            ['status' => 400]
        );
    }


    /**
     * Patient table
     */
    $patient_table = $wpdb->prefix . 'dior_patients';


    /**
     * Find patient
     */
    $patient = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$patient_table} WHERE email = %s LIMIT 1",
            $patient_email
        )
    );


    /**
     * Patient not found
     */
    if (!$patient) {

        return new WP_Error(
            'patient_not_found',
            'Patient not found.',
            [
                'status' => 404,
                'email'  => $patient_email,
            ]
        );
    }


    /**
     * Patient update data (ONLY for wp_dior_patients table)
     */
    $update_data = [];

    if ($street_address !== '') {
        $update_data['address'] = $street_address; // Table uses 'address' not 'address_line_1'
    }

    if ($city !== '') {
        $update_data['city'] = $city;
    }

    if ($state !== '') {
        $update_data['state'] = $state;
    }

    // Zip Code, Emergency Contact, and Pregnancy are NOT in the `dior_patients` table schema.
    // They will be stored securely in `wp_usermeta` instead, just like other sensitive data.


    /**
     * Update patient
     */
    if (!empty($update_data)) {

        $result = $wpdb->update(
            $patient_table,
            $update_data,
            [
                'id' => $patient->id
            ]
        );

        if ($result === false) {

            return new WP_Error(
                'patient_update_failed',
                'Failed to update patient.',
                ['status' => 500]
            );
        }
    }


    /**
     * Update WordPress user meta
     */
    if (!empty($patient->user_id)) {

        update_user_meta(
            $patient->user_id,
            'dior_hipaa_intake',
            $update_data
        );

        if ($street_address !== '') {
            update_user_meta(
                $patient->user_id,
                'address',
                $street_address
            );
        }

        if ($city !== '') {
            update_user_meta(
                $patient->user_id,
                'city',
                $city
            );
        }

        if ($state !== '') {
            update_user_meta(
                $patient->user_id,
                'state',
                $state
            );
        }

        if ($zip_code !== '') {
            update_user_meta(
                $patient->user_id,
                'zip_code',
                $zip_code
            );
        }

        if ($emergency_contact_name !== '') {
            update_user_meta(
                $patient->user_id,
                'emergency_name',
                $emergency_contact_name
            );
        }

        if ($emergency_contact_phone !== '') {
            update_user_meta(
                $patient->user_id,
                'emergency_phone',
                $emergency_contact_phone
            );
        }

        if ($is_pregnant !== '') {

            $pregnant = (
                $is_pregnant === '1' ||
                strtolower($is_pregnant) === 'yes' ||
                strtolower($is_pregnant) === 'true'
            );

            update_user_meta(
                $patient->user_id,
                'pregnancy_status',
                $pregnant ? 'Pregnant' : 'Not Pregnant'
            );
        }
    }


    /**
     * Insurance
     */
    if (
        $insurance_provider !== '' &&
        $insurance_member_id !== ''
    ) {

        $insurance_table =
            $wpdb->prefix . 'dior_insurance';


        /**
         * Check existing insurance
         */
        $insurance_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM {$insurance_table}
                 WHERE patient_id = %d
                 LIMIT 1",
                $patient->id
            )
        );


        /**
         * Existing insurance
         */
        if ($insurance_id) {

            $insurance_result = $wpdb->update(
                $insurance_table,
                [
                    'primary_insurance_provider' =>
                        $insurance_provider,

                    'primary_member_id' =>
                        $insurance_member_id,

                    'updated_at' =>
                        current_time('mysql')
                ],
                [
                    'patient_id' =>
                        $patient->id
                ]
            );

        /**
         * New insurance
         */
        } else {

            $insurance_result = $wpdb->insert(
                $insurance_table,
                [
                    'patient_id' =>
                        $patient->id,

                    'primary_insurance_provider' =>
                        $insurance_provider,

                    'primary_member_id' =>
                        $insurance_member_id,

                    'created_at' =>
                        current_time('mysql'),

                    'updated_at' =>
                        current_time('mysql')
                ]
            );
        }

        if ($insurance_result === false) {

            return new WP_Error(
                'insurance_update_failed',
                'Patient updated but insurance update failed.',
                ['status' => 500]
            );
        }
    }


    /**
     * Success
     */
    return new WP_REST_Response(
        [
            'success' => true,

            'message' =>
                'Hipaatizer data processed successfully.',

            'patient_id' =>
                (int) $patient->id,

            'email' =>
                $patient_email,

            'updated_data' =>
                $update_data
        ],
        200
    );
}


/**
 * GET:
 * Retrieve patient data
 */
function dior_get_patient_data(WP_REST_Request $request) {

    global $wpdb;


    /**
     * Patient ID from URL
     */
    $patient_id = absint(
        $request->get_param('id')
    );


    if (!$patient_id) {

        return new WP_Error(
            'invalid_patient_id',
            'Invalid patient ID.',
            ['status' => 400]
        );
    }


    /**
     * Patient table
     */
    $patient_table =
        $wpdb->prefix . 'dior_patients';


    /**
     * Get patient
     */
    $patient = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$patient_table}
             WHERE id = %d
             LIMIT 1",
            $patient_id
        ),
        ARRAY_A
    );


    if (!$patient) {

        return new WP_Error(
            'patient_not_found',
            'Patient not found.',
            ['status' => 404]
        );
    }


    /**
     * Insurance
     */
    $insurance_table =
        $wpdb->prefix . 'dior_insurance';


    $insurance = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$insurance_table}
             WHERE patient_id = %d
             LIMIT 1",
            $patient_id
        ),
        ARRAY_A
    );


    /**
     * Remove sensitive/internal fields
     *
     * Add/remove fields according to your dashboard requirements.
     */
    unset($patient['password']);


    /**
     * Response
     */
    return new WP_REST_Response(
        [
            'success' => true,

            'patient' => $patient,

            'insurance' => $insurance
        ],
        200
    );
}
