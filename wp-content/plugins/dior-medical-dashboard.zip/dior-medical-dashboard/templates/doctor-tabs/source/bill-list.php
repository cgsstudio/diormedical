<?php defined('ABSPATH') || exit; ?>
<section class="dior-tab-panel dior-source-panel" id="source-bill-list">
    <div class="dior-source-inner">
        <section class="main-content">
            <div>
                <div class="breadcrumb-main">
                    <div class="row">
                        <div class="col-6">
                            <div class="breadcrumb-title">
                                <h4 class="page-title d-flex align-items-center flex-wrap gap-2"><span>Bill List</span>
                                </h4>
                            </div>
                        </div>
                        <div class="col-6">
                            <ul class="breadcrumb-list">
                                <li class="breadcrumb-item bcrumb-1"><a>
                                        <div class="breadcrumb-icon" name="home"><svg class="feather feather-home"
                                                viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                                <polyline points="9 22 9 12 15 12 15 22"></polyline>
                                            </svg></div>
                                    </a></li>
                                <li class="breadcrumb-item"><a href="#">Accounts</a></li>
                                <li class="breadcrumb-item active">Bill List</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-body">
                <div>
                    <div class="master-table-wrapper">
                        <div class="master-table-container">
                            <div class="master-table-card">
                                <div class="master-table-header">
                                    <div class="header-content">
                                        <div class="table-title-section">
                                            <h2 class="table-title">Bill List</h2>
                                            <div class="title-accent"></div>
                                        </div>
                                        <div class="header-actions-group">
                                            <div class="search-container"><i
                                                    class="material-icons search-icon">search</i><input
                                                    aria-label="Search box" class="search-input"
                                                    placeholder="Search records..." type="text" /></div>
                                            <div class="action-buttons"><button aria-label="Delete 0 selected items"
                                                    class="action-btn action-btn-danger" hidden=""><i
                                                        class="material-icons">delete</i><span
                                                        class="btn-ripple"></span></button><button
                                                    aria-label="Add new record" class="action-btn action-btn-primary"><i
                                                        class="material-icons">add</i><span
                                                        class="btn-ripple"></span></button><button
                                                    aria-label="Export to Excel"
                                                    class="action-btn action-btn-success"><i
                                                        class="material-icons">file_download</i><span
                                                        class="btn-ripple"></span></button><button
                                                    aria-label="Refresh data" class="action-btn action-btn-info"><i
                                                        class="material-icons">refresh</i><span
                                                        class="btn-ripple"></span></button></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="table-content">
                                    <div class="ngx-datatable material modern-datatable fixed-header fixed-row virtualized scroll-horz selectable checkbox-selection"
                                        columnmode="force">
                                        <div class="visible" visibilityobserver="">
                                            <div role="table">
                                                <div class="datatable-header" role="rowgroup">
                                                    <div class="datatable-header-inner" orderable="" role="row">
                                                        <div class="datatable-row-left"></div>
                                                        <div class="datatable-row-center">
                                                            <div class="datatable-header-cell" draggable=""
                                                                long-press="" resizeable="" role="columnheader"
                                                                tabindex="-1" title="">
                                                                <div class="datatable-header-cell-template-wrap"><label
                                                                        class="datatable-checkbox"><input
                                                                            type="checkbox" /></label><span
                                                                        class="datatable-header-cell-wrapper"><span
                                                                            class="datatable-header-cell-label draggable">
                                                                        </span></span><span></span></div><span
                                                                    class="resize-handle--not-resizable"></span>
                                                            </div>
                                                            <div class="datatable-header-cell resizeable sortable"
                                                                draggable="" long-press="" resizeable=""
                                                                role="columnheader" tabindex="0">
                                                                <div class="datatable-header-cell-template-wrap"><span
                                                                        aria-sort="none"
                                                                        class="datatable-header-cell-wrapper"
                                                                        role="button" tabindex="0"> Admission ID
                                                                    </span><span
                                                                        class="datatable-icon-sort-unset sort-btn"></span>
                                                                </div><span class="resize-handle"></span>
                                                            </div>
                                                            <div class="datatable-header-cell resizeable sortable"
                                                                draggable="" long-press="" resizeable=""
                                                                role="columnheader" tabindex="0">
                                                                <div class="datatable-header-cell-template-wrap"><span
                                                                        aria-sort="none"
                                                                        class="datatable-header-cell-wrapper"
                                                                        role="button" tabindex="0"> Patient Name
                                                                    </span><span
                                                                        class="datatable-icon-sort-unset sort-btn"></span>
                                                                </div><span class="resize-handle"></span>
                                                            </div>
                                                            <div class="datatable-header-cell resizeable sortable"
                                                                draggable="" long-press="" resizeable=""
                                                                role="columnheader" tabindex="0">
                                                                <div class="datatable-header-cell-template-wrap"><span
                                                                        aria-sort="none"
                                                                        class="datatable-header-cell-wrapper"
                                                                        role="button" tabindex="0"> Doctor </span><span
                                                                        class="datatable-icon-sort-unset sort-btn"></span>
                                                                </div><span class="resize-handle"></span>
                                                            </div>
                                                            <div class="datatable-header-cell resizeable sortable"
                                                                draggable="" long-press="" resizeable=""
                                                                role="columnheader" tabindex="0">
                                                                <div class="datatable-header-cell-template-wrap"><span
                                                                        aria-sort="none"
                                                                        class="datatable-header-cell-wrapper"
                                                                        role="button" tabindex="0"> Status </span><span
                                                                        class="datatable-icon-sort-unset sort-btn"></span>
                                                                </div><span class="resize-handle"></span>
                                                            </div>
                                                            <div class="datatable-header-cell resizeable sortable"
                                                                draggable="" long-press="" resizeable=""
                                                                role="columnheader" tabindex="0">
                                                                <div class="datatable-header-cell-template-wrap"><span
                                                                        aria-sort="none"
                                                                        class="datatable-header-cell-wrapper"
                                                                        role="button" tabindex="0"> Date </span><span
                                                                        class="datatable-icon-sort-unset sort-btn"></span>
                                                                </div><span class="resize-handle"></span>
                                                            </div>
                                                            <div class="datatable-header-cell resizeable sortable"
                                                                draggable="" long-press="" resizeable=""
                                                                role="columnheader" tabindex="0">
                                                                <div class="datatable-header-cell-template-wrap"><span
                                                                        aria-sort="none"
                                                                        class="datatable-header-cell-wrapper"
                                                                        role="button" tabindex="0"> Tax </span><span
                                                                        class="datatable-icon-sort-unset sort-btn"></span>
                                                                </div><span class="resize-handle"></span>
                                                            </div>
                                                            <div class="datatable-header-cell resizeable sortable"
                                                                draggable="" long-press="" resizeable=""
                                                                role="columnheader" tabindex="0">
                                                                <div class="datatable-header-cell-template-wrap"><span
                                                                        aria-sort="none"
                                                                        class="datatable-header-cell-wrapper"
                                                                        role="button" tabindex="0"> Discount
                                                                    </span><span
                                                                        class="datatable-icon-sort-unset sort-btn"></span>
                                                                </div><span class="resize-handle"></span>
                                                            </div>
                                                            <div class="datatable-header-cell resizeable sortable"
                                                                draggable="" long-press="" resizeable=""
                                                                role="columnheader" tabindex="0">
                                                                <div class="datatable-header-cell-template-wrap"><span
                                                                        aria-sort="none"
                                                                        class="datatable-header-cell-wrapper"
                                                                        role="button" tabindex="0"> Total </span><span
                                                                        class="datatable-icon-sort-unset sort-btn"></span>
                                                                </div><span class="resize-handle"></span>
                                                            </div>
                                                            <div class="datatable-header-cell resizeable" draggable=""
                                                                long-press="" resizeable="" role="columnheader"
                                                                tabindex="-1">
                                                                <div class="datatable-header-cell-template-wrap"><span
                                                                        aria-sort="none"
                                                                        class="datatable-header-cell-wrapper"
                                                                        role="button" tabindex="0"> Actions
                                                                    </span><span></span></div><span
                                                                    class="resize-handle"></span>
                                                            </div>
                                                        </div>
                                                        <div class="datatable-row-right"></div>
                                                    </div>
                                                </div>
                                                <div class="datatable-body" role="rowgroup" tabindex="0">
                                                    <div>
                                                        <div class="datatable-scroll">
                                                            <div class="datatable-row-wrapper">
                                                                <div class="datatable-body-row datatable-row-even"
                                                                    draggable="false" role="row" tabindex="-1">
                                                                    <div class="datatable-row-group datatable-row-left">
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-center datatable-row-group">
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <label class="datatable-checkbox"><input
                                                                                        type="checkbox" /></label><span
                                                                                    title=""></span></div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> HGYU89
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-image-name">
                                                                                    <img alt="User avatar"
                                                                                        class="cell-avatar"
                                                                                        src="<?php echo esc_url(!empty($doctor['avatar_url']) ? $doctor['avatar_url'] : DIOR_PORTAL_URL . 'assets/images/logo-q.png'); ?>" />
                                                                                    <div class="cell-text-wrapper">
                                                                                        <div class="cell-text">Sarah
                                                                                            Smith</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> DR.
                                                                                        Megha Trivedi </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content">
                                                                                    <div class="badge-solid col-red">
                                                                                        Unpaid </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-icon-text">
                                                                                    <i
                                                                                        class="material-icons-outlined cell-icon">
                                                                                    </i><span class="cell-text">Feb 12,
                                                                                        2018</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 8%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 5%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> $142
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-actions"><button
                                                                                        aria-label="Edit record"
                                                                                        class="action-icon-btn edit-btn"><i
                                                                                            class="fas fa-pen"></i></button><button
                                                                                        aria-label="Delete record"
                                                                                        class="action-icon-btn delete-btn"><i
                                                                                            class="far fa-trash-alt"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-group datatable-row-right">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="datatable-row-wrapper">
                                                                <div class="datatable-body-row datatable-row-odd"
                                                                    draggable="false" role="row" tabindex="-1">
                                                                    <div class="datatable-row-group datatable-row-left">
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-center datatable-row-group">
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <label class="datatable-checkbox"><input
                                                                                        type="checkbox" /></label><span
                                                                                    title=""></span></div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> HGYU99
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-image-name">
                                                                                    <img alt="User avatar"
                                                                                        class="cell-avatar"
                                                                                        src="<?php echo esc_url(!empty($doctor['avatar_url']) ? $doctor['avatar_url'] : DIOR_PORTAL_URL . 'assets/images/logo-q.png'); ?>" />
                                                                                    <div class="cell-text-wrapper">
                                                                                        <div class="cell-text">Vishal
                                                                                            Kumar</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> DR.
                                                                                        John Deo </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content">
                                                                                    <div class="badge-solid col-green">
                                                                                        Paid </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-icon-text">
                                                                                    <i
                                                                                        class="material-icons-outlined cell-icon">
                                                                                    </i><span class="cell-text">Mar 22,
                                                                                        2018</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 10%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 5%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> $126
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-actions"><button
                                                                                        aria-label="Edit record"
                                                                                        class="action-icon-btn edit-btn"><i
                                                                                            class="fas fa-pen"></i></button><button
                                                                                        aria-label="Delete record"
                                                                                        class="action-icon-btn delete-btn"><i
                                                                                            class="far fa-trash-alt"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-group datatable-row-right">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="datatable-row-wrapper">
                                                                <div class="datatable-body-row datatable-row-even"
                                                                    draggable="false" role="row" tabindex="-1">
                                                                    <div class="datatable-row-group datatable-row-left">
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-center datatable-row-group">
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <label class="datatable-checkbox"><input
                                                                                        type="checkbox" /></label><span
                                                                                    title=""></span></div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> HGYU29
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-image-name">
                                                                                    <img alt="User avatar"
                                                                                        class="cell-avatar"
                                                                                        src="<?php echo esc_url(!empty($doctor['avatar_url']) ? $doctor['avatar_url'] : DIOR_PORTAL_URL . 'assets/images/logo-q.png'); ?>" />
                                                                                    <div class="cell-text-wrapper">
                                                                                        <div class="cell-text">Rahul
                                                                                            Malhotra</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> DR.
                                                                                        Sarah Smith </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content">
                                                                                    <div class="badge-solid col-green">
                                                                                        Paid </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-icon-text">
                                                                                    <i
                                                                                        class="material-icons-outlined cell-icon">
                                                                                    </i><span class="cell-text">Feb 2,
                                                                                        2018</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 9%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 5%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> $115
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-actions"><button
                                                                                        aria-label="Edit record"
                                                                                        class="action-icon-btn edit-btn"><i
                                                                                            class="fas fa-pen"></i></button><button
                                                                                        aria-label="Delete record"
                                                                                        class="action-icon-btn delete-btn"><i
                                                                                            class="far fa-trash-alt"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-group datatable-row-right">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="datatable-row-wrapper">
                                                                <div class="datatable-body-row datatable-row-odd"
                                                                    draggable="false" role="row" tabindex="-1">
                                                                    <div class="datatable-row-group datatable-row-left">
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-center datatable-row-group">
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <label class="datatable-checkbox"><input
                                                                                        type="checkbox" /></label><span
                                                                                    title=""></span></div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> HGYU36
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-image-name">
                                                                                    <img alt="User avatar"
                                                                                        class="cell-avatar"
                                                                                        src="<?php echo esc_url(!empty($doctor['avatar_url']) ? $doctor['avatar_url'] : DIOR_PORTAL_URL . 'assets/images/logo-q.png'); ?>" />
                                                                                    <div class="cell-text-wrapper">
                                                                                        <div class="cell-text">Priya
                                                                                            Jain</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> DR.
                                                                                        Stive </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content">
                                                                                    <div class="badge-solid col-red">
                                                                                        Unpaid </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-icon-text">
                                                                                    <i
                                                                                        class="material-icons-outlined cell-icon">
                                                                                    </i><span class="cell-text">Mar 19,
                                                                                        2018</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 9%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 5%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> $142
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-actions"><button
                                                                                        aria-label="Edit record"
                                                                                        class="action-icon-btn edit-btn"><i
                                                                                            class="fas fa-pen"></i></button><button
                                                                                        aria-label="Delete record"
                                                                                        class="action-icon-btn delete-btn"><i
                                                                                            class="far fa-trash-alt"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-group datatable-row-right">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="datatable-row-wrapper">
                                                                <div class="datatable-body-row datatable-row-even"
                                                                    draggable="false" role="row" tabindex="-1">
                                                                    <div class="datatable-row-group datatable-row-left">
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-center datatable-row-group">
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <label class="datatable-checkbox"><input
                                                                                        type="checkbox" /></label><span
                                                                                    title=""></span></div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> HGYU27
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-image-name">
                                                                                    <img alt="User avatar"
                                                                                        class="cell-avatar"
                                                                                        src="<?php echo esc_url(!empty($doctor['avatar_url']) ? $doctor['avatar_url'] : DIOR_PORTAL_URL . 'assets/images/logo-q.png'); ?>" />
                                                                                    <div class="cell-text-wrapper">
                                                                                        <div class="cell-text">Radhika
                                                                                            Patel</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> DR.
                                                                                        Megha Trivedi </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content">
                                                                                    <div class="badge-solid col-red">
                                                                                        Unpaid </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-icon-text">
                                                                                    <i
                                                                                        class="material-icons-outlined cell-icon">
                                                                                    </i><span class="cell-text">May 22,
                                                                                        2018</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 10%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 5%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> $126
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-actions"><button
                                                                                        aria-label="Edit record"
                                                                                        class="action-icon-btn edit-btn"><i
                                                                                            class="fas fa-pen"></i></button><button
                                                                                        aria-label="Delete record"
                                                                                        class="action-icon-btn delete-btn"><i
                                                                                            class="far fa-trash-alt"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-group datatable-row-right">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="datatable-row-wrapper">
                                                                <div class="datatable-body-row datatable-row-odd"
                                                                    draggable="false" role="row" tabindex="-1">
                                                                    <div class="datatable-row-group datatable-row-left">
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-center datatable-row-group">
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <label class="datatable-checkbox"><input
                                                                                        type="checkbox" /></label><span
                                                                                    title=""></span></div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> HGYU12
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-image-name">
                                                                                    <img alt="User avatar"
                                                                                        class="cell-avatar"
                                                                                        src="<?php echo esc_url(!empty($doctor['avatar_url']) ? $doctor['avatar_url'] : DIOR_PORTAL_URL . 'assets/images/logo-q.png'); ?>" />
                                                                                    <div class="cell-text-wrapper">
                                                                                        <div class="cell-text">Sarah
                                                                                            Smith</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> DR.
                                                                                        Megha Trivedi </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content">
                                                                                    <div class="badge-solid col-red">
                                                                                        Unpaid </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-icon-text">
                                                                                    <i
                                                                                        class="material-icons-outlined cell-icon">
                                                                                    </i><span class="cell-text">May 7,
                                                                                        2018</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 8%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 5%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> $115
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-actions"><button
                                                                                        aria-label="Edit record"
                                                                                        class="action-icon-btn edit-btn"><i
                                                                                            class="fas fa-pen"></i></button><button
                                                                                        aria-label="Delete record"
                                                                                        class="action-icon-btn delete-btn"><i
                                                                                            class="far fa-trash-alt"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-group datatable-row-right">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="datatable-row-wrapper">
                                                                <div class="datatable-body-row datatable-row-even"
                                                                    draggable="false" role="row" tabindex="-1">
                                                                    <div class="datatable-row-group datatable-row-left">
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-center datatable-row-group">
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <label class="datatable-checkbox"><input
                                                                                        type="checkbox" /></label><span
                                                                                    title=""></span></div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> HGYU14
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-image-name">
                                                                                    <img alt="User avatar"
                                                                                        class="cell-avatar"
                                                                                        src="<?php echo esc_url(!empty($doctor['avatar_url']) ? $doctor['avatar_url'] : DIOR_PORTAL_URL . 'assets/images/logo-q.png'); ?>" />
                                                                                    <div class="cell-text-wrapper">
                                                                                        <div class="cell-text">Vishal
                                                                                            Kumar</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> DR.
                                                                                        John Deo </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content">
                                                                                    <div class="badge-solid col-green">
                                                                                        Paid </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-icon-text">
                                                                                    <i
                                                                                        class="material-icons-outlined cell-icon">
                                                                                    </i><span class="cell-text">Feb 20,
                                                                                        2018</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 10%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 5%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> $126
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-actions"><button
                                                                                        aria-label="Edit record"
                                                                                        class="action-icon-btn edit-btn"><i
                                                                                            class="fas fa-pen"></i></button><button
                                                                                        aria-label="Delete record"
                                                                                        class="action-icon-btn delete-btn"><i
                                                                                            class="far fa-trash-alt"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-group datatable-row-right">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="datatable-row-wrapper">
                                                                <div class="datatable-body-row datatable-row-odd"
                                                                    draggable="false" role="row" tabindex="-1">
                                                                    <div class="datatable-row-group datatable-row-left">
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-center datatable-row-group">
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <label class="datatable-checkbox"><input
                                                                                        type="checkbox" /></label><span
                                                                                    title=""></span></div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> HGYU09
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-image-name">
                                                                                    <img alt="User avatar"
                                                                                        class="cell-avatar"
                                                                                        src="<?php echo esc_url(!empty($doctor['avatar_url']) ? $doctor['avatar_url'] : DIOR_PORTAL_URL . 'assets/images/logo-q.png'); ?>" />
                                                                                    <div class="cell-text-wrapper">
                                                                                        <div class="cell-text">Rahul
                                                                                            Malhotra</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> DR.
                                                                                        Sarah Smith </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content">
                                                                                    <div class="badge-solid col-green">
                                                                                        Paid </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-icon-text">
                                                                                    <i
                                                                                        class="material-icons-outlined cell-icon">
                                                                                    </i><span class="cell-text">Mar 21,
                                                                                        2018</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 9%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 5%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> $142
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-actions"><button
                                                                                        aria-label="Edit record"
                                                                                        class="action-icon-btn edit-btn"><i
                                                                                            class="fas fa-pen"></i></button><button
                                                                                        aria-label="Delete record"
                                                                                        class="action-icon-btn delete-btn"><i
                                                                                            class="far fa-trash-alt"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-group datatable-row-right">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="datatable-row-wrapper">
                                                                <div class="datatable-body-row datatable-row-even"
                                                                    draggable="false" role="row" tabindex="-1">
                                                                    <div class="datatable-row-group datatable-row-left">
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-center datatable-row-group">
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <label class="datatable-checkbox"><input
                                                                                        type="checkbox" /></label><span
                                                                                    title=""></span></div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> HGYU80
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-image-name">
                                                                                    <img alt="User avatar"
                                                                                        class="cell-avatar"
                                                                                        src="<?php echo esc_url(!empty($doctor['avatar_url']) ? $doctor['avatar_url'] : DIOR_PORTAL_URL . 'assets/images/logo-q.png'); ?>" />
                                                                                    <div class="cell-text-wrapper">
                                                                                        <div class="cell-text">Priya
                                                                                            Jain</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> DR.
                                                                                        Stive </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content">
                                                                                    <div class="badge-solid col-red">
                                                                                        Unpaid </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-icon-text">
                                                                                    <i
                                                                                        class="material-icons-outlined cell-icon">
                                                                                    </i><span class="cell-text">Feb 11,
                                                                                        2018</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 9%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 5%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> $142
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-actions"><button
                                                                                        aria-label="Edit record"
                                                                                        class="action-icon-btn edit-btn"><i
                                                                                            class="fas fa-pen"></i></button><button
                                                                                        aria-label="Delete record"
                                                                                        class="action-icon-btn delete-btn"><i
                                                                                            class="far fa-trash-alt"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-group datatable-row-right">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="datatable-row-wrapper">
                                                                <div class="datatable-body-row datatable-row-odd"
                                                                    draggable="false" role="row" tabindex="-1">
                                                                    <div class="datatable-row-group datatable-row-left">
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-center datatable-row-group">
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <label class="datatable-checkbox"><input
                                                                                        type="checkbox" /></label><span
                                                                                    title=""></span></div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> HGYU38
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-image-name">
                                                                                    <img alt="User avatar"
                                                                                        class="cell-avatar"
                                                                                        src="<?php echo esc_url(!empty($doctor['avatar_url']) ? $doctor['avatar_url'] : DIOR_PORTAL_URL . 'assets/images/logo-q.png'); ?>" />
                                                                                    <div class="cell-text-wrapper">
                                                                                        <div class="cell-text">Radhika
                                                                                            Patel</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> DR.
                                                                                        Megha Trivedi </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content">
                                                                                    <div class="badge-solid col-red">
                                                                                        Unpaid </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div
                                                                                    class="cell-content cell-icon-text">
                                                                                    <i
                                                                                        class="material-icons-outlined cell-icon">
                                                                                    </i><span class="cell-text">Mar 18,
                                                                                        2018</span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 10%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> 5%
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-content"><span> $126
                                                                                    </span></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="datatable-body-cell sort-active"
                                                                            role="cell" tabindex="-1">
                                                                            <div class="datatable-body-cell-label">
                                                                                <div class="cell-actions"><button
                                                                                        aria-label="Edit record"
                                                                                        class="action-icon-btn edit-btn"><i
                                                                                            class="fas fa-pen"></i></button><button
                                                                                        aria-label="Delete record"
                                                                                        class="action-icon-btn delete-btn"><i
                                                                                            class="far fa-trash-alt"></i></button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="datatable-row-group datatable-row-right">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="datatable-footer">
                                                <div class="datatable-footer-inner selected-count">
                                                    <div class="page-count"><span> 0 selected / </span> 13 total </div>
                                                    <div class="datatable-pager">
                                                        <ul class="pager">
                                                            <li class="disabled"><a aria-label="go to first page"
                                                                    role="button"><i
                                                                        class="datatable-icon-prev"></i></a></li>
                                                            <li class="disabled"><a aria-label="go to previous page"
                                                                    role="button"><i
                                                                        class="datatable-icon-left"></i></a></li>
                                                            <li aria-label="page 1" class="pages active" role="button">
                                                                <a> 1 </a></li>
                                                            <li aria-label="page 2" class="pages" role="button"><a> 2
                                                                </a></li>
                                                            <li><a aria-label="go to next page" role="button"><i
                                                                        class="datatable-icon-right"></i></a></li>
                                                            <li><a aria-label="go to last page" role="button"><i
                                                                        class="datatable-icon-skip"></i></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</section>