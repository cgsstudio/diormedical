/* Dior Medical — Patient non-overview actions; submitted feedback is stored through authenticated AJAX. */
(function () {
    'use strict';

    function esc(value) {
        return String(value ?? '').replace(/[&<>'"]/g, function (c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c];
        });
    }

    window.diorOpenStaticModal = function (id) {
        var el = document.getElementById(id);
        if (el) el.classList.add('is-open');
    };
    window.diorCloseStaticModal = function (id) {
        var el = document.getElementById(id);
        if (el) el.classList.remove('is-open');
    };

    window.diorOpenFeedbackModal = function () {
        var modal = document.getElementById('dior-feedback-modal');
        if (!modal) return;
        document.getElementById('dior-feedback-modal-title').textContent = 'Give Feedback';
        document.getElementById('dior-feedback-id').value = '';
        document.getElementById('dior-feedback-subject').value = '';
        document.getElementById('dior-feedback-rating-5').checked = true;
        document.getElementById('dior-feedback-message').value = '';
        document.getElementById('dior-feedback-submit-btn').innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Feedback';
        diorOpenStaticModal('dior-feedback-modal');
    };

    function appendFeedbackRow(review) {
        var table = document.getElementById('dior-feedback-table');
        if (!table || !table.tBodies[0]) return;
        var tbody = table.tBodies[0];
        var emptyRow = tbody.querySelector('.dior-empty-state');
        if (emptyRow) emptyRow.closest('tr').remove();

        var row = document.createElement('tr');
        row.dataset.feedbackId = String(review.id || '');

        var cbCell = document.createElement('td');
        cbCell.className = 'text-center';
        var cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.className = 'va-checkbox dior-feedback-row-cb';
        cb.value = String(review.id || '');
        if (typeof window.diorUpdateFeedbackCheckState === 'function') {
            cb.addEventListener('change', window.diorUpdateFeedbackCheckState);
        }
        cbCell.appendChild(cb);
        row.appendChild(cbCell);

        function cellWithText(value, className) {
            var cell = document.createElement('td');
            var text = document.createElement('span');
            text.className = 'cell-text';
            text.textContent = value || '';
            cell.appendChild(text);
            if (className) cell.classList.add(className);
            return cell;
        }

        row.appendChild(cellWithText(review.subject, 'feedback-subject-cell'));
        row.appendChild(cellWithText(review.doctor, 'feedback-doctor-cell'));

        var ratingCell = document.createElement('td');
        var ratingText = document.createElement('span');
        ratingText.className = 'cell-text';
        var star = document.createElement('i');
        star.className = 'fa-solid fa-star';
        star.style.color = '#F59E0B';
        ratingText.appendChild(star);
        ratingText.appendChild(document.createTextNode(' ' + review.rating + '/5'));
        ratingCell.appendChild(ratingText);
        row.appendChild(ratingCell);

        row.appendChild(cellWithText(review.message, 'feedback-message-cell'));

        var dateCell = document.createElement('td');
        var dateContent = document.createElement('div');
        dateContent.className = 'cell-content cell-icon-text';
        var dateIcon = document.createElement('i');
        dateIcon.className = 'fa-regular fa-calendar cell-icon';
        dateContent.appendChild(dateIcon);
        var dateText = document.createElement('span');
        dateText.className = 'cell-text';
        dateText.textContent = review.date || 'Today';
        dateContent.appendChild(dateText);
        dateCell.appendChild(dateContent);
        row.appendChild(dateCell);

        var statusCell = document.createElement('td');
        var statusContent = document.createElement('div');
        statusContent.className = 'cell-content';
        var statusBadge = document.createElement('div');
        statusBadge.className = 'badge-solid ' + (review.status === 'Published' ? 'col-green' : 'col-amber');
        statusBadge.textContent = review.status || 'Pending';
        statusContent.appendChild(statusBadge);
        statusCell.appendChild(statusContent);
        row.appendChild(statusCell);

        var actionCell = document.createElement('td');
        var viewButton = document.createElement('button');
        viewButton.type = 'button';
        viewButton.className = 'dior-feedback-view-action';
        viewButton.setAttribute('aria-label', 'View feedback');
        viewButton.title = 'View feedback';
        viewButton.dataset.feedback = JSON.stringify(review);
        viewButton.innerHTML = '<i class="fa-regular fa-eye"></i>';
        viewButton.addEventListener('click', function () { window.diorViewPatientFeedback(viewButton); });
        actionCell.appendChild(viewButton);

        var editButton = document.createElement('button');
        editButton.type = 'button';
        editButton.className = 'dior-feedback-edit-action';
        editButton.setAttribute('aria-label', 'Edit feedback');
        editButton.title = 'Edit feedback';
        editButton.dataset.feedbackId = String(review.id || '');
        editButton.dataset.feedback = JSON.stringify(review);
        editButton.innerHTML = '<i class="fa-solid fa-pen-to-square"></i>';
        editButton.addEventListener('click', function () { window.diorEditPatientFeedback(editButton); });
        actionCell.appendChild(editButton);

        var delButton = document.createElement('button');
        delButton.type = 'button';
        delButton.className = 'dior-feedback-delete-action';
        delButton.setAttribute('aria-label', 'Delete feedback');
        delButton.title = 'Delete feedback';
        delButton.dataset.feedbackId = String(review.id || '');
        delButton.innerHTML = '<i class="fa-solid fa-trash" style="color:#ef4444;"></i>';
        delButton.addEventListener('click', function () { window.diorDeletePatientFeedback(delButton); });
        actionCell.appendChild(delButton);

        row.appendChild(actionCell);

        tbody.prepend(row);
        var totalLabel = document.getElementById('dior-feedback-total-count');
        if (totalLabel) totalLabel.textContent = tbody.querySelectorAll('tr[data-feedback-id]').length + ' total feedback records';
    }

    window.diorViewPatientFeedback = function (button) {
        var feedback;
        try {
            feedback = JSON.parse(button.dataset.feedback || '{}');
        } catch (error) {
            return;
        }
        var details = [
            'Doctor: ' + (feedback.doctor || 'Care team'),
            'Rating: ' + (feedback.rating || '—') + '/5',
            'Status: ' + (feedback.status || 'Pending'),
            '',
            feedback.message || ''
        ].join('\n');
        Swal.fire({
            title: feedback.subject || 'Patient Feedback',
            text: details,
            icon: 'info',
            confirmButtonColor: '#2C6CB1'
        });
    };

    window.diorEditPatientFeedback = function (button) {
        var feedbackId = button.dataset.feedbackId;
        var feedback;
        try {
            feedback = JSON.parse(button.dataset.feedback || '{}');
        } catch (error) {
            return;
        }

        var modal = document.getElementById('dior-feedback-modal');
        if (!modal) return;

        document.getElementById('dior-feedback-modal-title').textContent = 'Edit Feedback';
        document.getElementById('dior-feedback-id').value = feedbackId || '';
        document.getElementById('dior-feedback-subject').value = feedback.subject || '';
        var rating = parseInt(feedback.rating) || 5;
        var ratingInput = document.getElementById('dior-feedback-rating-' + rating);
        if (ratingInput) ratingInput.checked = true;
        document.getElementById('dior-feedback-message').value = feedback.message || '';
        document.getElementById('dior-feedback-submit-btn').innerHTML = '<i class="fa-solid fa-save"></i> Update Feedback';

        diorOpenStaticModal('dior-feedback-modal');
    };

    window.diorDeletePatientFeedback = function (button) {
        var feedbackId = button.dataset.feedbackId;
        if (!feedbackId) return;

        var row = button.closest('tr');
        if (!row) return;

        if (window.Swal) {
            Swal.fire({
                title: 'Delete Feedback?',
                text: 'Are you sure you want to delete this feedback? This action cannot be undone.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#DC2626',
                cancelButtonColor: '#94A3B8',
                confirmButtonText: 'Yes, Delete',
                cancelButtonText: 'Cancel'
            }).then(function (result) {
                if (result.isConfirmed) {
                    diorConfirmDeleteFeedback(feedbackId, row);
                }
            });
        }
    };

    function diorConfirmDeleteFeedback(feedbackId, row) {
        var cfg = window.dior_vars || window.dior_patient_dashboard || {};
        var ajaxUrl = cfg.ajax_url || '/wp-admin/admin-ajax.php';
        var nonce = cfg.nonce || cfg.portal_nonce || '';

        if (!nonce) {
            Swal.fire({ icon: 'error', title: 'Error', text: 'Session expired. Please refresh the page.' });
            return;
        }

        var formData = new FormData();
        formData.append('action', 'dior_patient_delete_feedback');
        formData.append('nonce', nonce);
        formData.append('feedback_id', feedbackId);

        fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: formData })
            .then(function (response) { return response.json(); })
            .then(function (result) {
                if (result.success) {
                    row.remove();
                    var totalLabel = document.getElementById('dior-feedback-total-count');
                    if (totalLabel) {
                        var tbody = document.querySelector('#dior-feedback-table tbody');
                        var count = tbody ? tbody.querySelectorAll('tr[data-feedback-id]').length : 0;
                        totalLabel.textContent = count + ' total feedback records';
                    }
                    Swal.fire({
                        position: "top-end",
                        icon: "success",
                        title: "Feedback Deleted",
                        showConfirmButton: false,
                        timer: 1500
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: result.data.message || 'Failed to delete feedback.' });
                }
            })
            .catch(function (error) {
                Swal.fire({ icon: 'error', title: 'Error', text: 'Network error. Please try again.' });
            });
    }

    window.diorSaveFeedback = function (event) {
        event.preventDefault();
        var form = document.getElementById('dior-feedback-form');
        var button = form && form.querySelector('button[type="submit"]');
        var cfg = window.dior_vars || window.dior_patient_dashboard || {};
        var ajaxUrl = cfg.ajax_url || '/wp-admin/admin-ajax.php';
        var nonce = cfg.nonce || cfg.portal_nonce || '';
        if (!form || !nonce) {
            var configError = 'Your secure session is missing. Refresh the page and try again.';
            Swal.fire({ icon: 'error', title: 'Feedback Not Sent', text: configError });
            return false;
        }

        var feedbackId = document.getElementById('dior-feedback-id').value;
        var isEdit = feedbackId && feedbackId !== '';

        var formData = new FormData(form);
        formData.append('action', isEdit ? 'dior_patient_update_feedback' : 'dior_patient_submit_feedback');
        formData.append('nonce', nonce);
        var originalButton = button ? button.innerHTML : '';
        if (button) {
            button.disabled = true;
            button.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> ' + (isEdit ? 'Updating...' : 'Sending...');
        }

        fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: formData })
            .then(function (response) {
                return response.text().then(function (body) {
                    var result;
                    try {
                        result = JSON.parse(body);
                    } catch (error) {
                        throw new Error(response.redirected ? 'Your session expired. Sign in and try again.' : 'The server did not return a valid response. Please try again.');
                    }
                    if (!result.success) throw new Error((result.data && result.data.message) || 'Unable to send feedback.');
                    return result;
                });
            })
            .then(function (result) {
                if (isEdit) {
                    var row = document.querySelector('tr[data-feedback-id="' + feedbackId + '"]');
                    if (row) {
                        var cells = row.querySelectorAll('td');
                        var subjCell = row.querySelector('.feedback-subject-cell .cell-text') || (cells.length > 7 ? cells[1].querySelector('.cell-text') : (cells[0] ? cells[0].querySelector('.cell-text') : null));
                        if (subjCell) subjCell.textContent = result.data.review.subject || 'Patient Feedback';
                        
                        var ratingCell = row.querySelector('.feedback-rating-cell .cell-text') || (cells.length > 7 ? cells[3].querySelector('.cell-text') : (cells[2] ? cells[2].querySelector('.cell-text') : null));
                        if (ratingCell) ratingCell.innerHTML = '<i class="fa-solid fa-star" style="color:#F59E0B;"></i> ' + (result.data.review.rating || 5) + '/5';
                        
                        var msgCell = row.querySelector('.feedback-message-cell .cell-text') || (cells.length > 7 ? cells[4].querySelector('.cell-text') : (cells[3] ? cells[3].querySelector('.cell-text') : null));
                        if (msgCell) msgCell.textContent = result.data.review.message || '';

                        var updatedData = JSON.stringify({
                            subject: result.data.review.subject,
                            doctor: result.data.review.doctor,
                            rating: result.data.review.rating,
                            message: result.data.review.message,
                            status: result.data.review.status
                        });
                        var viewButton = row.querySelector('.dior-feedback-view-action');
                        if (viewButton) viewButton.dataset.feedback = updatedData;
                        var editButton = row.querySelector('.dior-feedback-edit-action');
                        if (editButton) editButton.dataset.feedback = updatedData;
                    }
                } else {
                    appendFeedbackRow(result.data.review || {});
                }
                diorCloseStaticModal('dior-feedback-modal');
                form.reset();
                document.getElementById('dior-feedback-id').value = '';
                document.getElementById('dior-feedback-rating-5').checked = true;
                document.getElementById('dior-feedback-submit-btn').innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Feedback';
                document.getElementById('dior-feedback-modal-title').textContent = 'Give Feedback';
                if (window.Swal) {
                    Swal.fire({
                        toast: true,
                        position: "top-end",
                        icon: "success",
                        title: isEdit ? "Feedback Updated" : "Feedback Sent",
                        showConfirmButton: false,
                        timer: 1500
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: result.data.message || 'Could not save feedback.' });
                }
            })
            .catch(function (error) {
                Swal.fire({ icon: 'error', title: 'Feedback Not Sent', text: error.message });
            })
            .finally(function () {
                if (button) {
                    button.disabled = false;
                    button.innerHTML = originalButton;
                }
            });
        return false;
    };

    window.diorDeleteStaticRow = function (button, type) {
        var row = button.closest('tr');
        if (!row) return;
        if (type !== 'document') {
            var label = type === 'telemedicine' ? 'telemedicine session' : (type === 'emergency contact' ? 'emergency contact' : 'feedback');
            Swal.fire({
                title: 'Delete ' + label + '?',
                text: 'Are you sure you want to delete this ' + label + '?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc2626',
                confirmButtonText: 'Delete'
            }).then(function(r) {
                if (r.isConfirmed) row.remove();
            });
            return;
        }
        var docId = row.getAttribute('data-doc-id') || '';
        if (!docId) return;
        var cfg = window.dior_vars || window.dior_patient_dashboard || {};
        var fd = new FormData();
        fd.append('action', 'dior_delete_document');
        fd.append('nonce', cfg.nonce || cfg.portal_nonce || '');
        fd.append('doc_id', docId);
        fd.append('patient_id', cfg.current_user_id || (cfg.patient && cfg.patient.id) || '');
        var doDelete = function(){
            fetch(cfg.ajax_url || '/wp-admin/admin-ajax.php', {method:'POST', credentials:'same-origin', body:fd})
                .then(function(r){return r.json();})
                .then(function(result){
                    if(!result.success) throw new Error((result.data && result.data.message) || 'Could not delete document.');
                    row.remove();
                    Swal.fire({position:'top-end',icon:'success',title:'Document Deleted',showConfirmButton:false,timer:1400});
                }).catch(function(err){
                    Swal.fire({icon:'error',title:'Delete Failed',text:err.message});
                });
        };
        Swal.fire({
            title: 'Delete Document?',
            text: 'This document will be removed from your medical records.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc2626',
            confirmButtonText: 'Delete'
        }).then(function(r) {
            if (r.isConfirmed) doDelete();
        });
    };

    window.diorOpenDocumentUploadModal = function(){
        var modal=document.getElementById('dior-document-modal'); if(!modal) return;
        var form=document.getElementById('dior-document-form'); if(form) form.reset();
        document.getElementById('dior-document-id').value='';
        document.getElementById('dior-document-modal-title').textContent='Add Medical Document';
        document.getElementById('dior-document-save-btn').innerHTML='<i class="fa-solid fa-cloud-arrow-up"></i> Upload Document';
        document.getElementById('dior-document-file-wrap').style.display='block';
        var dropzoneLabel = document.getElementById('dior-doc-file-label');
        if (dropzoneLabel) dropzoneLabel.textContent = 'Choose File or Drag & Drop';
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden','false');
    };

    window.diorEditDocument = function(button){
        var row=button.closest('tr'); if(!row) return;
        var modal=document.getElementById('dior-document-modal'); if(!modal) return;
        var id=row.getAttribute('data-doc-id') || '';
        var title=button.getAttribute('data-doc-title') || (row.cells[1] ? row.cells[1].innerText.trim() : 'Medical Document');
        var category=button.getAttribute('data-doc-category') || (row.cells[2] ? row.cells[2].innerText.trim() : 'Clinical Record');
        document.getElementById('dior-document-id').value=id;
        document.getElementById('dior-document-title').value=title;
        document.getElementById('dior-document-category').value=category;
        document.getElementById('dior-document-modal-title').textContent='Update Medical Document';
        document.getElementById('dior-document-save-btn').innerHTML='<i class="fa-solid fa-save"></i> Save Changes';
        document.getElementById('dior-document-file-wrap').style.display='none';
        modal.classList.add('is-open'); modal.setAttribute('aria-hidden','false');
    };

    window.diorCloseDocumentModal = function(){
        var modal=document.getElementById('dior-document-modal'); if(!modal) return;
        modal.classList.remove('is-open'); modal.setAttribute('aria-hidden','true');
    };

    document.addEventListener('submit', function(event){
        if(event.target.id !== 'dior-document-form') return;
        event.preventDefault();
        var form=event.target, cfg=window.dior_vars || window.dior_patient_dashboard || {};
        var id=document.getElementById('dior-document-id').value || '';
        var btn=document.getElementById('dior-document-save-btn');
        var fd=new FormData(form);
        fd.append('action', id ? 'dior_update_document' : 'dior_upload_document');
        fd.append('nonce', cfg.nonce || cfg.portal_nonce || '');
        fd.append('patient_id', cfg.current_user_id || '');
        btn.disabled=true;
        fetch(cfg.ajax_url || '/wp-admin/admin-ajax.php',{method:'POST',credentials:'same-origin',body:fd})
            .then(function(r){return r.json();})
            .then(function(result){
                if(!result.success) throw new Error((result.data && result.data.message) || 'Unable to save document.');
                if(id){
                    var row=document.querySelector('#dior-docs-tbody tr[data-doc-id="'+CSS.escape(id)+'"]');
                    if(row){
                        var title=result.data.title || fd.get('doc_title');
                        var category=result.data.category || fd.get('doc_category');
                        if(row.cells[1] && row.cells[1].querySelector('.cell-text')) row.cells[1].querySelector('.cell-text').textContent=title;
                        if(row.cells[2] && row.cells[2].querySelector('.cell-text')) row.cells[2].querySelector('.cell-text').textContent=category;
                        var edit=row.querySelector('.edit-btn'); if(edit){edit.setAttribute('data-doc-title',title);edit.setAttribute('data-doc-category',category);}
                    }
                } else if(result.data && result.data.document){
                    var doc = result.data.document;
                    var tbody = document.getElementById('dior-docs-tbody');
                    if(tbody){
                        var emptyRow = tbody.querySelector('.dior-empty-state');
                        if(emptyRow) emptyRow.closest('tr').remove();
                        var tr = document.createElement('tr');
                        tr.setAttribute('data-doc-id', doc.id || '');
                        tr.setAttribute('data-doc-author-id', doc.author_id || '');
                        var docTitle = doc.title || 'Medical Document';
                        var docCategory = doc.category || 'Clinical Record';
                        var docType = doc.file_type || 'PDF';
                        var docDate = doc.date || 'Just now';
                        var docSize = doc.size || '—';
                        tr.innerHTML = '<td><input type="checkbox" class="dior-ic-52ff4d551f"></td>' +
                            '<td><span class="cell-text dior-ic-794116ec9b">' + docTitle + '</span></td>' +
                            '<td><span class="cell-text">' + docCategory + '</span></td>' +
                            '<td><span class="cell-text">' + docType + '</span></td>' +
                            '<td><div class="cell-content cell-icon-text"><i class="far fa-calendar cell-icon"></i><span class="cell-text">' + docDate + '</span></div></td>' +
                            '<td><span class="cell-text">' + docSize + '</span></td>' +
                            '<td><div class="cell-content"><div class="badge-solid col-green">Available</div></div></td>' +
                            '<td><div class="cell-actions">' +
                            '<button type="button" class="action-icon-btn edit-btn" title="Edit Document" data-doc-title="' + docTitle + '" data-doc-category="' + docCategory + '" onclick="diorEditDocument(this)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-vector-pen" viewBox="0 0 16 16" style="background:transparent;"><path fill-rule="evenodd" d="M10.646.646a.5.5 0 0 1 .708 0l4 4a.5.5 0 0 1 0 .708l-1.902 1.902-.829 3.313a1.5 1.5 0 0 1-1.024 1.073L1.254 14.746 4.358 4.4A1.5 1.5 0 0 1 5.43 3.377l3.313-.828zm-1.8 2.908-3.173.793a.5.5 0 0 0-.358.342l-2.57 8.565 8.567-2.57a.5.5 0 0 0 .34-.357l.794-3.174-3.6-3.6z"/><path fill-rule="evenodd" d="M2.832 13.228 8 9a1 1 0 1 0-1-1l-4.228 5.168-.026.086z"/></svg></button>' +
                            '<button type="button" class="action-icon-btn delete-btn" title="Delete Document" onclick="diorDeleteStaticRow(this, \'document\')"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#ef4444" class="bi bi-trash" viewBox="0 0 16 16" style="background:transparent;"><path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/><path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/></svg></button>' +
                            '</div></td>';
                        tbody.insertBefore(tr, tbody.firstChild);

                        var pageCount = document.getElementById('dior-docs-page-count');
                        if (pageCount) {
                            var totalRows = tbody.querySelectorAll('tr[data-doc-id]').length;
                            pageCount.textContent = '0 selected / ' + totalRows + ' total';
                        }
                    }
                }
                diorCloseDocumentModal();
                if(window.Swal) Swal.fire({position:'top-end',icon:'success',title:id?'Document Updated':'Document Uploaded',showConfirmButton:false,timer:1500});
            })
            .catch(function(err){Swal.fire({icon:'error',title:'Document Not Saved',text:err.message});})
            .finally(function(){btn.disabled=false;});
    });

    window.diorViewTelemedicine = function (button) {
        var row = button.closest('tr');
        if (!row) return;
        var cells = row.querySelectorAll('td');
        var doctor = cells[2] ? cells[2].innerText.trim() : 'Attending Physician';
        var date = cells[4] ? cells[4].innerText.trim() : '—';
        var time = cells[5] ? cells[5].innerText.trim() : '—';
        Swal.fire({
            title: 'Telemedicine Session',
            html: '<div class="text-start"><strong>Doctor:</strong> ' + doctor + '<br><strong>Date:</strong> ' + date + '<br><strong>Time:</strong> ' + time + '</div>',
            icon: 'info',
            confirmButtonColor: '#2C6CB1'
        });
    };

    window.diorFilterStaticTable = function (input, tableId) {
        var query = (input.value || '').toLowerCase();
        var table = document.getElementById(tableId);
        if (!table || !table.tBodies[0]) return;
        Array.prototype.forEach.call(table.tBodies[0].rows, function (row) {
            row.style.display = row.innerText.toLowerCase().indexOf(query) !== -1 ? '' : 'none';
        });
    };

    document.addEventListener('click', function (event) {
        if (event.target.classList.contains('dior-static-modal-backdrop')) event.target.classList.remove('is-open');
    });
    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') return;
        document.querySelectorAll('.dior-static-modal-backdrop.is-open').forEach(function (modal) { modal.classList.remove('is-open'); });
    });

    window.diorBulkDeleteStaticRows = function (btn) {
        var wrapper = btn.closest('.docs-card, .va-table-wrapper, .card, .medidash-card, .dior-tab-panel');
        if (!wrapper) return;
        var table = wrapper.querySelector('table');
        if (!table) return;
        var checkedBoxes = table.querySelectorAll('tbody input[type="checkbox"]:checked');
        if (checkedBoxes.length === 0) {
            Swal.fire({ icon: 'info', title: 'No Rows Selected', text: 'Please select at least one row to delete.' });
            return;
        }

        var performDelete = function() {
            checkedBoxes.forEach(function(cb) {
                var row = cb.closest('tr');
                if (row) row.remove();
            });
            var masterCb = table.querySelector('thead input[type="checkbox"]');
            if (masterCb) masterCb.checked = false;
            
            // Try updating count if exists
            var countEl = wrapper.querySelector('[id*="-page-count"]');
            if (countEl) {
                var total = table.querySelectorAll('tbody tr:not(.dior-empty-state)').length;
                countEl.innerText = '0 selected / ' + total + ' total';
            }
        };

        if (window.Swal) {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to delete ' + checkedBoxes.length + ' selected record(s).',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'Yes, delete them!'
            }).then(function(result) {
                if (result.isConfirmed) {
                    performDelete();
                    Swal.fire({ position: 'top-end', icon: 'success', title: 'Records Deleted', showConfirmButton: false, timer: 1500 });
                }
            });
        }
    };
}());
