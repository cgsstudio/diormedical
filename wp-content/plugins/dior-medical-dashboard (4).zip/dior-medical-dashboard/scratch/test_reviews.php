<?php
require_once __DIR__ . '/../../../../wp-load.php';
global $wpdb;

$table = $wpdb->prefix . 'dior_reviews';
echo "Table: $table\n";
echo "Count: " . $wpdb->get_var("SELECT COUNT(*) FROM $table") . "\n";

$rows = $wpdb->get_results("SELECT * FROM $table LIMIT 10", ARRAY_A);
print_r($rows);
