<?php
require_once __DIR__ . '/../../../../wp-load.php';

$u = get_userdata(2);
if ($u) {
    $notifs = Dior_Patient_Portal_Data::get_patient_notifications(2);
    echo "User 2 ({$u->user_login}): " . count($notifs) . " notifications\n";
    foreach ($notifs as $n) {
        echo "  - [{$n['id']}] Title: {$n['title']} | Msg: {$n['message']} | Type: {$n['type']} | IsRead: " . ($n['is_read'] ? 'YES' : 'NO') . "\n";
    }
}
