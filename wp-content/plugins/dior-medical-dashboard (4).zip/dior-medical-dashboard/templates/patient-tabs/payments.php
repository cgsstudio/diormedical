<section class="dior-tab-panel dior-ic-44a70a0420" id="tab-payments">
    <!-- Breadcrumb Header -->
    <div class="mb-4" style="display:flex;justify-content:space-between;align-items:center;padding:0 24px;">
        <div>
            <h4 class="mb-0 text-dark" style="font-size:20px;font-weight:700;">Billing</h4>
        </div>
        <div>
            <ul class="va-breadcrumb-list">
                <li><a href="#"><i class="fas fa-house" style="font-size:14px;color:#4F46E5;"></i></a></li>
                <li><span style="color:#94A3B8;">/</span></li>
                <li class="active"><span>Billing</span></li>
            </ul>
        </div>
    </div>

    <!-- Subtab Navigation Bar -->
    <div class="dior-subtab-nav-bar px-3 px-md-4 mb-4">
        <button type="button" class="dior-subtab-pill btn active" data-patient-tab="payments" onclick="if(typeof diorSwitchTab==='function') diorSwitchTab('payments');">
            <i class="fas fa-wallet"></i> Billing & Payments
        </button>
        <button type="button" class="dior-subtab-pill btn" data-patient-tab="insurance" onclick="if(typeof diorSwitchTab==='function') diorSwitchTab('insurance');">
            <i class="fas fa-shield-heart"></i> Insurance Claims
        </button>
    </div>

    <div class="docs-card">
        <div class="docs-header-container">
            <div class="docs-title-box">
                <h2 class="table-title">Billing</h2>
                <div class="docs-title-line"></div>
            </div>
            <div class="docs-actions-wrapper">
                <div class="input-group input-group-sm dior-bs-search-group" style="width: 240px;">

                    <input type="text" id="dior-bill-search-input" class="form-control border-start-0 ps-0"
                        placeholder="Search records..." aria-label="Search box" onkeyup="diorFilterBill()">
                </div>
                <div class="docs-actions-group">
                    <button type="button" aria-label="Delete selected items" class="docs-icon-btn docs-btn-danger btn"
                        title="Delete Selected" onclick="diorBulkDeleteStaticRows(this)">
                        <i class="fas fa-trash"></i>
                    </button>
                    <button type="button" aria-label="Export to CSV" class="docs-icon-btn docs-btn-success btn"
                        title="Export to CSV" onclick="diorDownloadBillCSV()">
                        <i class="fas fa-file-arrow-down"></i>
                    </button>
                    <button type="button" aria-label="Refresh data" class="docs-icon-btn docs-btn-info btn" title="Refresh Page"
                        onclick="window.location.reload()">
                        <i class="fas fa-rotate-right"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="docs-table-wrapper">
            <table class="docs-table table table-hover" id="dior-bill-table">
                <thead>
                    <tr>
                        <th>Invoice No</th>
                        <th>Doctor</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Tax</th>
                        <th>Discount</th>
                        <th>Total</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="dior-bill-tbody">
                    <?php
                    $billing_mock = [
                        ['#A348', 'Dr.Jacob Ryan', 'Mar 4, 2016', '$40', '10%', '$5', '$39'],
                        ['#A645', 'Dr.Rajesh', 'Apr 11, 2016', '$25', '10%', '$5', '$22'],
                        ['#A873', 'Dr.Jay Soni', 'Apr 18, 2016', '$50', '10%', '$5', '$47'],
                        ['#A927', 'Dr.John Deo', 'May 22, 2016', '$45', '10%', '$5', '$42'],
                        ['#A228', 'Dr.Megha Trivedi', 'Jul 9, 2016', '$62', '10%', '$5', '$57'],
                        ['#A345', 'Dr.Sarah Smith', 'Jul 14, 2016', '$60', '10%', '$5', '$56'],
                        ['#A765', 'Dr.Jacob Ryan', 'Jun 22, 2016', '$40', '10%', '$5', '$39'],
                        ['#A125', 'Dr.Rajesh', 'Jun 23, 2016', '$30', '10%', '$5', '$29']
                        ,
                        ['#A905', 'Dr.Sarah Smith', 'Aug 2, 2016', '$72', '8%', '$4', '$74']
                        ,
                        ['#A981', 'Dr.James Chen', 'Aug 16, 2016', '$95', '8%', '$0', '$103']
                    ];
                    foreach ($billing_mock as $bm):
                        ?>
                        <tr onclick="diorOpenBillingModal('<?php echo esc_js($bm[0]); ?>', '<?php echo esc_js($bm[1]); ?>', '<?php echo esc_js($bm[2]); ?>', '<?php echo esc_js($bm[3]); ?>', '<?php echo esc_js($bm[4]); ?>', '<?php echo esc_js($bm[5]); ?>', '<?php echo esc_js($bm[6]); ?>')"
                            class="dior-ic-8e7e606bc6">
                            <td><span class="cell-text"><?php echo esc_html($bm[0]); ?></span></td>
                            <td><span class="cell-text"><?php echo esc_html($bm[1]); ?></span></td>
                            <td>
                                <div class="cell-content cell-icon-text">
                                    <i class="far fa-calendar cell-icon dior-ic-d53ea48df0"></i>
                                    <span class="cell-text"><?php echo esc_html($bm[2]); ?></span>
                                </div>
                            </td>
                            <td><span class="cell-text"><?php echo esc_html($bm[3]); ?></span></td>
                            <td><span class="cell-text"><?php echo esc_html($bm[4]); ?></span></td>
                            <td><span class="cell-text"><?php echo esc_html($bm[5]); ?></span></td>
                            <td><span class="cell-text"><?php echo esc_html($bm[6]); ?></span></td>
                            <td>
                                <div class="cell-content action-cell" style="gap:8px;">
                                    <button type="button" class="btn btn-sm btn-success" title="Download Bill">
                                        <i class="fas fa-download"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-info" title="View Bill">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-secondary" title="Print Bill">
                                        <i class="fas fa-print"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>


    <div class="dior-billing-modal-backdrop dior-ic-b546859a82" id="diorBillingModal">
        <div class="modal-content dior-ic-7903a9dded">
            <div class="modal-header details-modal-header dior-ic-feb0429751">
                <div class="header-left dior-ic-fbd29a13bb">
                    <div class="header-icon-wrapper dior-ic-01e9887431">
                        info
                    </div>
                    <div class="header-title-wrapper">
                        <h4 class="modal-title dior-ic-515659bf18">Billing Details</h4>
                        <span class="modal-subtitle dior-ic-55709c3d5d" id="billModalSubtitle"></span>
                    </div>
                </div>
                <div class="header-actions dior-ic-fbd29a13bb">
                    <button type="button" class="btn btn-light dior-ic-7a752f6c0e">
                        <span>Edit</span>
                    </button>
                    <button type="button" onclick="diorCloseBillingModal()" class="dior-ic-7a752f6c0e btn">
                        close
                    </button>
                </div>
            </div>
            <div class="modal-body details-modal-body dior-ic-602bae732d">
                <div class="details-hero-card dior-ic-49c0d4651a">
                    <div class="hero-avatar-wrapper">
                        <img alt="avatar" class="hero-avatar dior-ic-02045d41a0" id="billModalAvatar" src="">
                    </div>
                    <div class="hero-content">
                        <h3 class="hero-title dior-ic-6bc196bb21" id="billModalDocName"></h3>
                    </div>
                </div>
                <div class="details-grid-container">
                    <div class="row g-3 dior-ic-bd41a014a7">

                        <div class="col-lg-6 col-md-6 col-sm-12 col-xl-6 dior-ic-f8f25bc60b">
                            <div class="detail-field-card dior-ic-57d219ccba">
                                <div class="field-label-group dior-ic-b85bb26d7d">
                                    <span class="field-label">Invoice No</span>
                                </div>
                                <div class="field-value-wrapper"><span class="field-value dior-ic-3b2d8e2576"
                                        id="billModalInv"></span></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12 col-xl-6 dior-ic-f8f25bc60b">
                            <div class="detail-field-card dior-ic-57d219ccba">
                                <div class="field-label-group dior-ic-b85bb26d7d">
                                    <span class="field-label">Doctor Name</span>
                                </div>
                                <div class="field-value-wrapper"><span class="field-value dior-ic-3b2d8e2576"
                                        id="billModalDocName2"></span></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12 col-xl-6 dior-ic-f8f25bc60b">
                            <div class="detail-field-card dior-ic-57d219ccba">
                                <div class="field-label-group dior-ic-b85bb26d7d">
                                    <span class="field-label">Date</span>
                                </div>
                                <div class="field-value-wrapper"><span class="field-value dior-ic-3b2d8e2576"
                                        id="billModalDate"></span></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12 col-xl-6 dior-ic-f8f25bc60b">
                            <div class="detail-field-card dior-ic-57d219ccba">
                                <div class="field-label-group dior-ic-b85bb26d7d">
                                    <span class="field-label">Amount</span>
                                </div>
                                <div class="field-value-wrapper"><span class="field-value dior-ic-3b2d8e2576"
                                        id="billModalAmount"></span></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12 col-xl-6 dior-ic-f8f25bc60b">
                            <div class="detail-field-card dior-ic-57d219ccba">
                                <div class="field-label-group dior-ic-b85bb26d7d">
                                    <span class="field-label">Tax</span>
                                </div>
                                <div class="field-value-wrapper"><span class="field-value dior-ic-3b2d8e2576"
                                        id="billModalTax"></span></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12 col-xl-6 dior-ic-f8f25bc60b">
                            <div class="detail-field-card dior-ic-57d219ccba">
                                <div class="field-label-group dior-ic-b85bb26d7d">
                                    <span class="field-label">Discount</span>
                                </div>
                                <div class="field-value-wrapper"><span class="field-value dior-ic-3b2d8e2576"
                                        id="billModalDisc"></span></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12 col-xl-6 dior-ic-f8f25bc60b">
                            <div class="detail-field-card dior-ic-57d219ccba">
                                <div class="field-label-group dior-ic-b85bb26d7d">
                                    <span class="field-label">Total</span>
                                </div>
                                <div class="field-value-wrapper"><span class="field-value dior-ic-3b2d8e2576"
                                        id="billModalTotal"></span></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12 col-xl-6 dior-ic-f8f25bc60b">
                            <div class="detail-field-card dior-ic-57d219ccba">
                                <div class="field-label-group dior-ic-b85bb26d7d">
                                    <span class="field-label">Actions</span>
                                </div>
                                <div class="field-value-wrapper"><span class="field-value dior-ic-e304798bad">--</span>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="modal-footer details-modal-footer dior-ic-a11f69ed01">
                <button type="button" class="btn btn-light dior-ic-ce5cec6499" onclick="diorCloseBillingModal()">
                    Close
                </button>
            </div>
        </div>
    </div>
</section>