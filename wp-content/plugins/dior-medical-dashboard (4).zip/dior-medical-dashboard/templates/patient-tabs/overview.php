<section class="dior-tab-panel active custom-patient-overview" id="tab-overview">
  <div class="content-head">
    <div>
      <?php $display_first_name = !empty($profile['first_name']) ? ucfirst(strtolower($profile['first_name'])) : ''; ?>
      <h1>Welcome Back, <?php echo esc_html(strtoupper($display_first_name)); ?></h1>
      <p class="subtitle">Manage your telehealth visits, prescriptions, and medical records.</p>
    </div>
    <a href="#tab=appointments" data-appt-subtab="book" class="gold-btn btn" onclick="event.preventDefault(); if(typeof diorSwitchTab==='function') diorSwitchTab('appointments'); if(typeof diorSwitchApptSubTab==='function') diorSwitchApptSubTab('book');" style="text-decoration:none; display:inline-flex; align-items:center; gap:8px; font-size:16px !important; cursor:pointer;">
      <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/></svg>
      Book An Appointment
    </a>
  </div>

  <div class="dashboard-grid">

    <div class="left-col">
      <div class="stats">
        <div class="card stat-card"><div class="stat-num"><?php echo str_pad(count($appointments), 2, '0', STR_PAD_LEFT); ?></div><div class="stat-label">Total Consultations</div></div>
        <div class="card stat-card"><div class="stat-num"><?php echo str_pad(count($prescriptions), 2, '0', STR_PAD_LEFT); ?></div><div class="stat-label">Active Prescriptions</div></div>
        <div class="card stat-card"><div class="stat-num"><?php echo str_pad(count($upcoming_list), 2, '0', STR_PAD_LEFT); ?></div><div class="stat-label">Upcoming Appointments</div></div>
      </div>

      <div class="mid-grid">
        <div class="card patient-card">
          <div class="patient-top">
            <div class="patient-photo" id="dior-patient-photo-box">
                <?php if (!empty($profile['avatar_url'])): ?>
                <img id="dior-overview-patient-img" src="<?php echo esc_url($profile['avatar_url']); ?>" alt="Profile">
                <?php else: ?>
                <img id="dior-overview-patient-img" src="<?php echo esc_url(get_avatar_url(get_current_user_id(), ['size' => 200])); ?>" alt="<?php echo esc_attr($profile['full_name'] ?? 'Profile'); ?>">
                <?php endif; ?>
            </div>
            <div class="patient-info">
              <?php $patient_identifier = !empty($profile['patient_id']) ? $profile['patient_id'] : get_user_meta($user_id, 'patient_id', true); if (empty($patient_identifier)) $patient_identifier = 'DM-' . (10000 + (int)$user_id); ?>
              <h2><?php echo esc_html(!empty($profile['full_name']) ? $profile['full_name'] : 'Patient'); ?> <span class="patient-id"><?php echo esc_html($patient_identifier); ?></span></h2>
                <?php
                $dob_raw = !empty($profile['dob']) ? $profile['dob'] : '';
                $age_str = '';
                if (!empty($dob_raw)) {
                    try {
                        $age_calc = (new DateTime('today'))->diff(new DateTime($dob_raw))->y;
                        $age_str = $age_calc . ' Years Old';
                    } catch(Exception $e) { $age_str = ''; }
                }
                ?>
              <div class="age"><?php echo esc_html($age_str ?: '—'); ?></div>
              <div class="metrics">
                <?php
                $p_height = !empty($profile['height']) ? trim($profile['height']) : '';
                $p_weight = !empty($profile['weight']) ? trim($profile['weight']) : '';

                $h_display = $p_height === '' ? '—' : ((is_numeric($p_height)) ? $p_height . ' cm' : $p_height);
                $w_display = $p_weight === '' ? '—' : ((is_numeric($p_weight)) ? $p_weight . ' kg' : $p_weight);
                ?>
                <div class="metric"><strong><?php echo esc_html($h_display); ?></strong><span>Height</span></div>
                <div class="metric"><strong><?php echo esc_html($w_display); ?></strong><span>Weight</span></div>
              </div>
            </div>
          </div>
          <button class="edit-btn btn" data-switch-tab="profile">Edit Profile</button>
        </div>

        <div class="card goals-card">
          <h3 class="section-title">Health Goals</h3>
            <?php
            $health_goals = get_user_meta($user_id, 'dior_health_goals', true);
            $health_goals = is_array($health_goals) ? $health_goals : [];

            // Only display health goals actually saved for this patient.
            $display_goals = $health_goals;
            ?>
            <?php foreach($display_goals as $goal): ?>
          <div class="goal"><div class="goal-row"><span><?php echo esc_html($goal['name']); ?></span><span class="goal-value"><?php echo esc_html($goal['val']); ?></span></div><div class="progress"><i style="width:<?php echo esc_attr(min(100, (int)($goal['pct'] ?? 50))); ?>%"></i></div></div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="card table-card">
        <div class="table-head">
          <h3 class="section-title">Previous Consultation</h3>
          <a class="view-all" href="#" data-switch-tab="appointments" onclick="if(typeof diorSwitchTab==='function') diorSwitchTab('appointments');">View All &rarr;</a>
        </div>
        <div class="table-wrap dior-card-scrollable" style="max-height: 275px; overflow-y: auto; overflow-x: auto;">
        <table class="table align-middle mb-0">
          <thead style="position: sticky; top: 0; background: #fff; z-index: 2;">
            <tr><th style="width:29%">Consultation Name</th><th style="width:31%">Doctor Name</th><th style="width:20%">Date</th><th style="width:14%">Time</th><th style="width:16%">Status</th></tr>
          </thead>
          <tbody>
            <?php 
            $prev_apts = !empty($past_list) ? $past_list : [];
            // Only show consultations returned for the current patient; never substitute demo records.
            foreach($prev_apts as $prev_apt):
                $pa_cond = !empty($prev_apt['condition']) ? $prev_apt['condition'] : (!empty($prev_apt['condition_name']) ? $prev_apt['condition_name'] : 'General Consultation');
                $pa_doc  = !empty($prev_apt['provider']) ? $prev_apt['provider'] : (!empty($prev_apt['doctor_name']) ? $prev_apt['doctor_name'] : 'Dr. Diorca Aquino de la Cruz');
                $pa_date = !empty($prev_apt['date']) ? $prev_apt['date'] : (!empty($prev_apt['appt_date']) ? $prev_apt['appt_date'] : 'Sep 10, 2026');
                $pa_time = !empty($prev_apt['time']) ? $prev_apt['time'] : (!empty($prev_apt['appt_time']) ? $prev_apt['appt_time'] : '03:00 PM');
                $pa_status = !empty($prev_apt['status']) ? strtolower($prev_apt['status']) : 'completed';
                $s_cls = 'done';
                if ($pa_status === 'cancelled') $s_cls = 'cancel';
                if ($pa_status === 'in progress') $s_cls = 'progressing';
                if ($pa_status === 'pending') $s_cls = 'progressing';
            ?>
            <tr><td><?php echo esc_html($pa_cond); ?></td><td><?php echo esc_html($pa_doc); ?></td><td><?php echo esc_html($pa_date); ?></td><td><?php echo esc_html($pa_time); ?></td><td><span class="status <?php echo $s_cls; ?>"><?php echo esc_html(ucfirst($pa_status)); ?></span></td></tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        </div>
      </div>

      <div class="card lab-card">
        <div class="table-head">
          <h3 class="section-title">Latest Lab Results</h3>
          <a class="view-all" href="#" data-switch-tab="documents" onclick="if(typeof diorSwitchTab==='function') diorSwitchTab('documents');">View All &rarr;</a>
        </div>
        <div class="table-wrap dior-card-scrollable" style="max-height: 235px; overflow-y: auto; overflow-x: auto;">
        <table class="lab-table table align-middle mb-0">
          <thead style="position: sticky; top: 0; background: #fff; z-index: 2;">
            <tr><th style="width:29%">Test Name</th><th style="width:20%">Date</th><th style="width:18%">Status</th><th style="width:25%">Ordered By</th><th style="width:8%">Action</th></tr>
          </thead>
          <tbody>
            <?php
            $lab_docs = [];
            foreach ($documents as $doc) {
                $dtype = strtolower($doc['type'] ?? ($doc['document_type'] ?? ''));
                if (strpos($dtype, 'lab') !== false || strpos($dtype, 'result') !== false || strpos($dtype, 'test') !== false) {
                    $lab_docs[] = $doc;
                }
            }
            // Lab results are sourced from this patient's stored documents only.
            foreach($lab_docs as $lab):
                $lab_name   = !empty($lab['title']) ? $lab['title'] : (!empty($lab['name']) ? $lab['name'] : 'Lab Test');
                $lab_date   = !empty($lab['date']) ? $lab['date'] : 'Sep 10, 2026';
                $lab_status = !empty($lab['status']) ? $lab['status'] : 'Normal';
                $lab_by     = !empty($lab['ordered_by']) ? $lab['ordered_by'] : (!empty($lab['doctor_name']) ? $lab['doctor_name'] : 'Dr. Diorca Aquino de la Cruz');
                $lab_url    = !empty($lab['file_url']) ? $lab['file_url'] : '#';
                $s_cls = (strtolower($lab_status) === 'abnormal') ? 'abnormal' : 'normal';
            ?>
            <tr>
              <td><?php echo esc_html($lab_name); ?></td>
              <td><?php echo esc_html($lab_date); ?></td>
              <td><span class="status <?php echo $s_cls; ?>"><?php echo esc_html($lab_status); ?></span></td>
              <td><?php echo esc_html($lab_by); ?></td>
              <td>
                <a href="<?php echo esc_url($lab_url); ?>" class="btn btn-sm btn-outline-primary d-inline-flex align-items-center justify-content-center p-1" style="width:30px;height:30px;" title="Download Lab Report">
                  <i class="bi bi-download"></i>
                </a>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        </div>
      </div>
    </div>

    <div class="right-col">
      <?php
      if (!function_exists('dior_resolve_doctor_avatar')) {
          function dior_resolve_doctor_avatar($apt) {
              if (!empty($apt['avatar'])) return $apt['avatar'];
              if (!empty($apt['doctor_avatar'])) return $apt['doctor_avatar'];
              
              $doc_id = !empty($apt['doctor_id']) ? (int)$apt['doctor_id'] : (!empty($apt['provider_id']) ? (int)$apt['provider_id'] : 0);
              $doc_user_id = !empty($apt['doctor_user_id']) ? (int)$apt['doctor_user_id'] : 0;
              
              if ($doc_id) {
                  $post = get_post($doc_id);
                  if ($post && $post->post_type === 'wpddb_doctor') {
                      $post_avatar = get_post_meta($doc_id, '_wpddb_doctor_avatar', true)
                          ?: get_post_meta($doc_id, 'wpddb_doctor_avatar', true)
                          ?: get_the_post_thumbnail_url($doc_id, 'thumbnail');
                      if (!empty($post_avatar)) return $post_avatar;
                      if (!$doc_user_id) {
                          $doc_user_id = (int) get_post_meta($doc_id, '_wpddb_doctor_user_id', true);
                      }
                  } elseif (!$doc_user_id && $post === null) {
                      $doc_user_id = $doc_id;
                  }
              }
              
              if ($doc_user_id) {
                  $user_avatar = get_user_meta($doc_user_id, 'dior_profile_image', true)
                      ?: get_user_meta($doc_user_id, 'doctor_avatar', true)
                      ?: get_user_meta($doc_user_id, 'profile_picture', true)
                      ?: get_user_meta($doc_user_id, 'profile_image', true)
                      ?: get_user_meta($doc_user_id, 'avatar_url', true);
                  if (!empty($user_avatar)) return $user_avatar;
                  
                  $wp_avatar = get_avatar_url($doc_user_id, ['size' => 120]);
                  if (!empty($wp_avatar)) return $wp_avatar;
              }
              
              return site_url('/wp-content/uploads/2026/10/diormedical-experts-1.webp');
          }
      }
      ?>

      <div class="card doctor-card" id="dior-overview-doctor-card">
        <?php 
        $has_next = !empty($next_appointment);
        $ha_default_img = site_url('/wp-content/uploads/2026/10/diormedical-experts-1.webp');
        $ha_id = '';
        $ha_name = 'No upcoming consultation';
        $ha_spec = 'Telehealth Urgent Care';
        $ha_date = 'No appointment scheduled';
        $ha_time = 'Available 24/7';
        $ha_avatar = $ha_default_img;
        $ha_join_url = '';
        $ha_type = 'Video Visit (HD)';
        
        if ($has_next) {
            $ha_id = !empty($next_appointment['id']) ? $next_appointment['id'] : (!empty($next_appointment['appt_uid']) ? $next_appointment['appt_uid'] : '');
            $ha_name = !empty($next_appointment['doctor_name']) ? $next_appointment['doctor_name'] : (!empty($next_appointment['provider']) ? $next_appointment['provider'] : 'Attending Physician');
            $ha_spec = !empty($next_appointment['provider_spec']) ? $next_appointment['provider_spec'] : 'Telehealth Urgent Care Physician';
            
            $ha_raw_date = !empty($next_appointment['date']) ? $next_appointment['date'] : (!empty($next_appointment['appt_date']) ? $next_appointment['appt_date'] : '');
            $ha_ts = strtotime($ha_raw_date);
            $ha_date = $ha_ts ? date('M j, Y', $ha_ts) : $ha_raw_date;
            $ha_time = !empty($next_appointment['time']) ? $next_appointment['time'] : (!empty($next_appointment['appt_time']) ? $next_appointment['appt_time'] : '');
            
            $ha_avatar = !empty($next_appointment['avatar']) ? $next_appointment['avatar'] : dior_resolve_doctor_avatar($next_appointment);
            $ha_join_url = !empty($next_appointment['join_url']) ? $next_appointment['join_url'] : '';
            $ha_type = !empty($next_appointment['type']) ? $next_appointment['type'] : (!empty($next_appointment['visit_type']) ? $next_appointment['visit_type'] : 'Video Visit (HD)');
        }
        $is_next_video = (stripos($ha_type, 'phone') === false);
        ?>
        <div class="doctor-top">
          <div class="doctor-photo">
            <img src="<?php echo esc_url($ha_avatar); ?>" alt="<?php echo esc_attr($ha_name); ?>" onerror="this.onerror=null;this.src='<?php echo esc_url($ha_default_img); ?>';">
          </div>
          <div class="doctor-copy">
            <div class="doctor-type"><?php echo $has_next ? 'Next Scheduled Consultation' : 'Telehealth Medical Care'; ?></div>
            <div class="doctor-role"><?php echo esc_html($ha_spec); ?></div>
            <div class="doctor-name" style="font-weight:700;"><?php echo esc_html($ha_name); ?></div>
            <div class="meta">
              <?php if ($has_next): ?>
              <span><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/></svg><?php echo esc_html($ha_date); ?></span>
              <span><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/></svg><?php echo esc_html($ha_time); ?></span>
              <?php else: ?>
              <span style="color:#64748B;"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/></svg> No upcoming visit</span>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="doctor-actions">
          <?php if ($has_next): ?>
            <?php if ($is_next_video && !empty($ha_join_url)): ?>
              <a href="<?php echo esc_url($ha_join_url); ?>" target="_blank" class="primary-btn btn" style="text-decoration:none; display:inline-flex; align-items:center; justify-content:center; gap:6px;">
                <i class="fas fa-video"></i> Join Video Consultation Room
              </a>
            <?php else: ?>
              <button class="primary-btn btn" data-switch-tab="consultation" onclick="if(typeof diorSwitchTab==='function') diorSwitchTab('consultation');">
                <i class="fas fa-video me-1"></i> Join Video Consultation Room
              </button>
            <?php endif; ?>
            <button class="outline-btn btn" data-switch-tab="appointments" onclick="if(typeof diorOpenRescheduleModal==='function' && '<?php echo esc_js($ha_id); ?>'){diorOpenRescheduleModal('<?php echo esc_js($ha_id); ?>');}else if(typeof diorSwitchTab==='function'){diorSwitchTab('appointments');}">
              <i class="bi bi-arrow-repeat me-1"></i> Reschedule
            </button>
          <?php else: ?>
            <button class="primary-btn btn" data-switch-tab="appointments" onclick="if(typeof diorSwitchTab==='function'){diorSwitchTab('appointments');if(typeof diorSwitchApptSubTab==='function')diorSwitchApptSubTab('book');}" style="flex:1;">
              <i class="fas fa-calendar-plus me-1"></i> Book An Appointment
            </button>
          <?php endif; ?>
        </div>
      </div>

      <div class="card upcoming" id="dior-overview-upcoming-card">
        <div class="table-head" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
          <h3 class="section-title mb-0" style="margin:0;">Upcoming Consultation</h3>
          <a class="view-all" href="#" data-switch-tab="appointments" onclick="if(typeof diorSwitchTab==='function'){diorSwitchTab('appointments');if(typeof diorSwitchApptSubTab==='function')diorSwitchApptSubTab('upcoming');}return false;">View All &rarr;</a>
        </div>
        <div class="consult-list-wrap dior-card-scrollable" id="dior-overview-upcoming-list" style="max-height: 250px; overflow-y: auto; padding-right: 4px;">
        <?php 
        $display_list = !empty($upcoming_list) ? $upcoming_list : [];
        if (empty($display_list)):
        ?>
          <div class="dior-upcoming-empty" style="padding: 28px 16px; text-align: center; color: #94A3B8;">
            <i class="bi bi-calendar2-check" style="font-size: 28px; color: #CBD5E1; margin-bottom: 8px; display: block;"></i>
            <div style="font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 4px;">No upcoming consultations</div>
            <div style="font-size: 12px; color: #94A3B8; margin-bottom: 12px;">Your upcoming consultations will appear here.</div>
            <button type="button" class="btn btn-sm btn-primary" onclick="if(typeof diorSwitchTab==='function'){diorSwitchTab('appointments');if(typeof diorSwitchApptSubTab==='function')diorSwitchApptSubTab('book');}" style="background:#2c71b7; border-color:#2c71b7; color:#fff; font-size:11.5px; font-weight:600; padding:6px 16px; border-radius:20px; display:inline-flex; align-items:center; gap:6px;">
              <i class="bi bi-plus-lg"></i> Book Consultation
            </button>
          </div>
        <?php 
        else:
          foreach($display_list as $apt): 
            $apt_id = !empty($apt['id']) ? $apt['id'] : (!empty($apt['appt_uid']) ? $apt['appt_uid'] : '');
            $doc_name = !empty($apt['doctor_name']) ? $apt['doctor_name'] : (!empty($apt['provider']) ? $apt['provider'] : 'Provider');
            $doc_spec = !empty($apt['provider_spec']) ? $apt['provider_spec'] : 'Telehealth Physician';
            $doc_avatar = !empty($apt['avatar']) ? $apt['avatar'] : (function_exists('dior_resolve_doctor_avatar') ? dior_resolve_doctor_avatar($apt) : $ha_default_img);
            
            $apt_raw_date = !empty($apt['date']) ? $apt['date'] : (!empty($apt['appt_date']) ? $apt['appt_date'] : '');
            $apt_ts = strtotime($apt_raw_date);
            $apt_date_display = $apt_ts ? date('M j, Y', $apt_ts) : $apt_raw_date;
            $apt_time_display = !empty($apt['time']) ? $apt['time'] : (!empty($apt['appt_time']) ? $apt['appt_time'] : '');
            $apt_type = !empty($apt['type']) ? $apt['type'] : (!empty($apt['visit_type']) ? $apt['visit_type'] : 'Video Visit (HD)');
            $apt_status = !empty($apt['status']) ? $apt['status'] : 'Confirmed';
            $apt_join = !empty($apt['join_url']) ? $apt['join_url'] : '';
            $is_video = (stripos($apt_type, 'phone') === false);
        ?>
        <div class="consult" data-appt-id="<?php echo esc_attr($apt_id); ?>">
          <div class="consult-photo">
            <img src="<?php echo esc_url($doc_avatar); ?>" alt="<?php echo esc_attr($doc_name); ?>" onerror="this.onerror=null;this.src='<?php echo esc_url($ha_default_img); ?>';">
          </div>
          <div class="consult-body flex-grow-1">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
              <div class="consult-role" style="margin:0; font-size:14px;"><?php echo esc_html($doc_spec); ?></div>
              <span class="badge" style="background:#ECFDF5; color:#059669; font-size:10px; font-weight:600; padding:2px 8px; border-radius:12px; border:1px solid #A7F3D0;">
                <?php echo esc_html($apt_status); ?>
              </span>
            </div>
            <div class="consult-name" style="font-weight:600; color:#1E293B; margin-bottom:5px; font-size:13px;"><?php echo esc_html($doc_name); ?></div>
            <div class="consult-meta" style="font-size:11.5px; margin-bottom:8px;">
              <span><i class="bi bi-calendar-event me-1 text-primary"></i> <?php echo esc_html($apt_date_display); ?></span>
              <span><i class="bi bi-clock me-1 text-primary"></i> <?php echo esc_html($apt_time_display); ?></span>
            </div>
            <div class="consult-actions" style="display:flex; align-items:center; gap:8px; margin-top:6px;">
              <?php if ($is_video && !empty($apt_join)): ?>
              <a href="<?php echo esc_url($apt_join); ?>" target="_blank" class="btn btn-sm" style="font-size:11px; font-weight:600; padding:3px 12px; border-radius:14px; background:#2c71b7; border:1px solid #2c71b7; color:#fff; text-decoration:none; display:inline-flex; align-items:center; gap:4px;">
                <i class="fas fa-video"></i> Join Room
              </a>
              <?php endif; ?>
              <button type="button" class="btn btn-sm btn-outline-primary" onclick="if(typeof diorOpenRescheduleModal==='function' && '<?php echo esc_js($apt_id); ?>'){diorOpenRescheduleModal('<?php echo esc_js($apt_id); ?>');}else if(typeof diorSwitchTab==='function'){diorSwitchTab('appointments');}" style="font-size:11px; font-weight:600; padding:3px 12px; border-radius:14px;">
                <i class="bi bi-arrow-repeat me-1"></i> Reschedule
              </button>
            </div>
          </div>
        </div>
        <?php 
          endforeach; 
        endif; 
        ?>
        </div>
      </div>

      <div class="card prescriptions">
        <div class="table-head">
          <h3 class="section-title">Prescriptions</h3>
          <a class="view-all" href="#" data-switch-tab="docs_meds" onclick="if(typeof diorSwitchTab==='function') diorSwitchTab('docs_meds');">View All &rarr;</a>
        </div>
        <div class="rx-list-wrap dior-card-scrollable" style="max-height: 290px; overflow-y: auto; padding-right: 4px;">
        <?php
        $rx_display = !empty($prescriptions) ? $prescriptions : [];
        if (empty($rx_display)):
        ?>
            <div style="padding: 28px 16px; text-align: center; color: #94A3B8; font-size: 13px;">
                <i class="bi bi-capsule" style="font-size:24px;color:#CBD5E1;margin-bottom:8px;display:block;"></i>
                No active prescriptions yet.
            </div>
        <?php
        else:
            foreach($rx_display as $rx):
                $rx_id     = !empty($rx['id']) ? $rx['id'] : (!empty($rx['order_id']) ? $rx['order_id'] : 'RX-001');
                $rx_name   = !empty($rx['title']) && $rx['title'] !== 'General Medical Prescription' ? $rx['title'] : (!empty($rx['name']) ? $rx['name'] : (!empty($rx['medication']) ? $rx['medication'] : 'Medication'));
                $rx_sub    = !empty($rx['medication']) && $rx['medication'] !== $rx_name ? $rx['medication'] : (!empty($rx['instructions']) ? $rx['instructions'] : '');
                $rx_by     = !empty($rx['prescribed_by']) ? $rx['prescribed_by'] : 'Provider';
                $rx_status = !empty($rx['status']) ? $rx['status'] : 'Active';
                $is_active = (strtolower($rx_status) === 'active');
                $rx_badge_cls = $is_active ? 'badge bg-success-subtle text-success border border-success-subtle' : 'badge bg-secondary-subtle text-secondary border';
            ?>
            <div class="rx d-flex align-items-center justify-content-between py-2 border-bottom">
                <div class="me-2" style="min-width: 0;">
                    <div class="rx-name fw-semibold text-dark text-truncate" style="font-size: 13.5px;"><?php echo esc_html($rx_name); ?></div>
                    <?php if ($rx_sub !== ''): ?>
                        <div class="small text-muted text-truncate" style="font-size: 11px; max-width: 200px;">
                            <?php echo esc_html($rx_sub); ?>
                        </div>
                    <?php endif; ?>
                    <div class="rx-doctor small text-muted" style="font-size: 11px;"><?php echo esc_html($rx_by); ?></div>
                </div>
                <div class="d-flex align-items-center gap-2 flex-shrink-0">
                    <span class="<?php echo esc_attr($rx_badge_cls); ?> px-2 py-1 small rounded-pill"><?php echo esc_html(ucfirst($rx_status)); ?></span>
                    <button type="button" class="btn btn-sm btn-outline-primary d-inline-flex align-items-center gap-1"
                        title="View Prescription Details"
                        onclick="diorViewRxDetails('<?php echo esc_js($rx_id); ?>', '<?php echo esc_js($rx_name); ?>', '<?php echo esc_js($rx['instructions'] ?? ''); ?>')">
                        <i class="bi bi-eye"></i> View
                    </button>
                </div>
            </div>
            <?php endforeach;
        endif;
        ?>
        </div>
      </div>
    </div>

  </div>
</section>
